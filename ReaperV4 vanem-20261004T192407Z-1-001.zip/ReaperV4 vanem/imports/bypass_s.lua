-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1, SHX21_1, SHX22_1, SHX23_1, SHX24_1, SHX25_1, SHX26_1, SHX27_1, SHX28_1, SHX29_1, SHX30_1, SHX31_1, SHX32_1, SHX33_1, SHX34_1, SHX35_1, SHX36_1, SHX37_1, SHX38_1, SHX39_1, SHX40_1, SHX41_1, SHX42_1, SHX43_1, SHX44_1, SHX45_1, SHX46_1, SHX47_1, SHX48_1, SHX49_1, SHX50_1, SHX51_1, SHX52_1, SHX53_1, SHX54_1, SHX55_1, SHX56_1, SHX57_1, SHX58_1, SHX59_1, SHX60_1, SHX61_1, SHX62_1, SHX63_1, SHX64_1, SHX65_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = IsDuplicityVersion
SHX0_1 = SHX0_1()
if not SHX0_1 then
  return
end
SHX0_1 = LoadSharedReaper
if nil == SHX0_1 then
  SHX0_1 = print
  SHX1_1 = "[REAPER] - Failed to load needed dependencies from @ReaperV4/imports/bypass.lua"
  return SHX0_1(SHX1_1)
end
SHX0_1 = GetConvar
SHX1_1 = tostring
SHX2_1 = GetGameTimer
SHX3_1 = print
SHX4_1 = json
SHX4_1 = SHX4_1.decode
SHX5_1 = GetConvarInt
SHX6_1 = table
SHX6_1 = SHX6_1.insert
SHX7_1 = type
SHX8_1 = CreateThread
SHX9_1 = Citizen
SHX9_1 = SHX9_1.CreateThreadNow
SHX10_1 = GetPedInVehicleSeat
SHX11_1 = json
SHX11_1 = SHX11_1.encode
SHX12_1 = IsPedAPlayer
SHX13_1 = pairs
SHX14_1 = NetworkGetEntityOwner
SHX15_1 = Wait
SHX16_1 = math
SHX16_1 = SHX16_1.random
SHX17_1 = RegisterNetEvent
SHX18_1 = LoadResourceFile
SHX19_1 = debug
SHX19_1 = SHX19_1.getinfo
SHX20_1 = LoadSharedReaper
SHX20_1 = SHX20_1()
SHX21_1 = SHX20_1.ReaperExports
SHX22_1 = SHX20_1.resource_name
SHX23_1 = SHX20_1.HookFunction
SHX24_1 = SHX20_1.hash
SHX25_1 = SHX20_1.IsEventIgnored
SHX26_1 = SHX20_1._ch
SHX27_1 = SHX20_1.parseArgs
SHX28_1 = SHX20_1.Logger
SHX29_1 = SHX20_1.load_imports_file
SHX30_1 = SHX20_1.AdvancedHook
function SHX31_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX5_2, SHX6_2
  SHX5_2 = SHX9_1
  function SHX6_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX0_3 = SHX21_1
    SHX0_3 = SHX0_3()
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.InvokeSLogger
    SHX2_3 = "NewLog"
    SHX3_3 = SHX0_2
    SHX4_3 = SHX1_2
    SHX5_3 = SHX2_2
    SHX6_3 = SHX3_2
    SHX7_3 = SHX4_2
    SHX0_3, SHX1_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
    if not SHX0_3 then
      SHX2_3 = SHX3_1
      SHX3_3 = "[REAPER] FAILED TO UPLOAD LOG"
      SHX4_3 = SHX1_3
      SHX2_3(SHX3_3, SHX4_3)
    end
  end
  SHX5_2(SHX6_2)
end
function SHX32_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  if not SHX4_2 then
    SHX6_2 = {}
    SHX4_2 = SHX6_2
  end
  SHX6_2 = GetPlayerIdentifierByType
  SHX7_2 = SHX0_2
  SHX8_2 = "license"
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.gsub
  SHX8_2 = "license:"
  SHX9_2 = ""
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX4_2.identifier = SHX6_2
  SHX6_2 = SHX31_1
  SHX7_2 = SHX1_2
  SHX8_2 = SHX2_2
  SHX9_2 = SHX3_2
  SHX10_2 = SHX4_2
  SHX11_2 = SHX5_2
  return SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
end
function SHX33_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = tonumber
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if SHX1_2 and 0 ~= SHX0_2 then
    SHX1_2 = GetPlayerName
    SHX2_2 = SHX0_2
    SHX1_2 = SHX1_2(SHX2_2)
    if nil ~= SHX1_2 then
      SHX1_2 = GetPlayerPed
      SHX2_2 = SHX0_2
      SHX1_2 = SHX1_2(SHX2_2)
      SHX0_2 = SHX1_2
    end
  end
  SHX1_2 = DoesEntityExist
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if not SHX1_2 then
    SHX1_2 = false
    SHX2_2 = SHX0_2
    return SHX1_2, SHX2_2
  end
  SHX1_2 = SHX12_1
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = SHX0_2
  return SHX1_2, SHX2_2
end
function SHX34_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = SHX19_1
  SHX2_2 = SHX0_2 or SHX2_2
  if not SHX0_2 then
    SHX2_2 = 3
  end
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = SHX1_2.source
  SHX3_2 = ":"
  SHX4_2 = SHX1_2.currentline
  SHX2_2 = SHX2_2 .. SHX3_2 .. SHX4_2
  return SHX2_2
end
function SHX35_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = SHX7_1
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if "nil" == SHX1_2 then
    SHX2_2 = ""
    return SHX2_2
  elseif "table" == SHX1_2 then
    SHX2_2 = "System.Object[]"
    return SHX2_2
  elseif "boolean" == SHX1_2 then
    if SHX0_2 then
      SHX2_2 = "True"
      if SHX2_2 then
        goto SHX_LABEL_22
      end
    end
    SHX2_2 = "False"
    -- [FIX IF ERROR] Move ::SHX_LABEL_22:: outside nested blocks until all 'goto SHX_LABEL_22' can see it
    ::SHX_LABEL_22::
    return SHX2_2
  else
    SHX2_2 = SHX1_1
    SHX3_2 = SHX0_2
    return SHX2_2(SHX3_2)
  end
end
SHX36_1 = SHX4_1
SHX37_1 = SHX18_1
SHX38_1 = "ReaperV4"
SHX39_1 = "cache/event_lock.json"
SHX37_1 = SHX37_1(SHX38_1, SHX39_1)
if not SHX37_1 then
  SHX37_1 = "{}"
end
SHX36_1 = SHX36_1(SHX37_1)
SHX37_1 = SHX17_1
SHX38_1 = "Reaper:SyncKeyLock"
function SHX39_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX0_2 = source
  if "" ~= SHX0_2 then
    SHX1_2 = SHX21_1
    SHX1_2 = SHX1_2()
    SHX2_2 = SHX1_2
    SHX1_2 = SHX1_2.InvokeSPlayer
    SHX3_2 = SHX0_2
    SHX4_2 = "newDetection"
    SHX5_2 = "antiTriggerServerEvent"
    SHX6_2 = {}
    SHX6_2.eventName = "Reaper:SyncKeyLock"
    SHX7_2 = SHX22_1
    SHX6_2.resource = SHX7_2
    SHX6_2.inv_resource = "na"
    SHX6_2.method = "net_missmatch"
    SHX7_2 = {}
    SHX8_2 = "Reaper:SyncKeyLock"
    SHX7_2[1] = SHX8_2
    return SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
  end
  SHX1_2 = SHX4_1
  SHX2_2 = SHX18_1
  SHX3_2 = "ReaperV4"
  SHX4_2 = "cache/event_lock.json"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if not SHX2_2 then
    SHX2_2 = "{}"
  end
  SHX1_2 = SHX1_2(SHX2_2)
  SHX36_1 = SHX1_2
end
SHX37_1(SHX38_1, SHX39_1)
SHX37_1 = {}
SHX38_1 = SHX4_1
SHX39_1 = SHX18_1
SHX40_1 = "ReaperV4"
SHX41_1 = "cache/executions-"
SHX42_1 = SHX22_1
SHX43_1 = ".json"
SHX41_1 = SHX41_1 .. SHX42_1 .. SHX43_1
SHX39_1 = SHX39_1(SHX40_1, SHX41_1)
if not SHX39_1 then
  SHX39_1 = "{}"
end
SHX38_1 = SHX38_1(SHX39_1)
SHX39_1 = SHX38_1
if nil == SHX39_1 then
  SHX40_1 = SHX8_1
  function SHX41_1()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_2, SHX1_2, SHX2_2, SHX3_2
    while true do
      SHX0_2 = SHX15_1
      SHX1_2 = 1000
      SHX0_2(SHX1_2)
      SHX0_2 = SHX3_1
      SHX1_2 = "[ReaperV4] File corrupted \"cache/executions-"
      SHX2_2 = SHX22_1
      SHX3_2 = ".json\""
      SHX1_2 = SHX1_2 .. SHX2_2 .. SHX3_2
      SHX0_2(SHX1_2)
    end
  end
  SHX40_1(SHX41_1)
end
SHX39_1 = nil
SHX40_1 = SHX8_1
function SHX41_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX0_2 = nil
  while true do
    SHX1_2 = SHX15_1
    SHX2_2 = 60000
    SHX1_2(SHX2_2)
    SHX1_2 = SHX11_1
    SHX2_2 = SHX38_1
    SHX1_2 = SHX1_2(SHX2_2)
    SHX2_2 = SHX24_1
    SHX3_2 = SHX1_2
    SHX2_2 = SHX2_2(SHX3_2)
    if nil == SHX1_2 then
      SHX3_2 = SHX4_1
      SHX4_2 = SHX18_1
      SHX5_2 = "ReaperV4"
      SHX6_2 = "cache/executions-"
      SHX7_2 = SHX22_1
      SHX8_2 = ".json"
      SHX6_2 = SHX6_2 .. SHX7_2 .. SHX8_2
      SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
      if not SHX4_2 then
        SHX4_2 = "{}"
      end
      SHX3_2 = SHX3_2(SHX4_2)
      SHX38_1 = SHX3_2
      SHX3_2 = SHX3_1
      SHX4_2 = "[ReaperV4] File corrupted \"cache/executions-"
      SHX5_2 = SHX22_1
      SHX6_2 = ".json\" possibly recovered"
      SHX4_2 = SHX4_2 .. SHX5_2 .. SHX6_2
      SHX3_2(SHX4_2)
    elseif SHX2_2 ~= SHX0_2 then
      SHX0_2 = SHX2_2
      SHX3_2 = SaveResourceFile
      SHX4_2 = "ReaperV4"
      SHX5_2 = "cache/executions-"
      SHX6_2 = SHX22_1
      SHX7_2 = ".json"
      SHX5_2 = SHX5_2 .. SHX6_2 .. SHX7_2
      SHX6_2 = SHX1_2
      SHX7_2 = #SHX1_2
      SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2)
    end
  end
end
SHX40_1(SHX41_1)
SHX40_1 = {}
SHX41_1 = {}
SHX42_1 = SHX4_1
SHX43_1 = SHX18_1
SHX44_1 = "ReaperV4"
SHX45_1 = "cache/flaggedEvents.json"
SHX43_1 = SHX43_1(SHX44_1, SHX45_1)
if not SHX43_1 then
  SHX43_1 = "{}"
end
SHX42_1 = SHX42_1(SHX43_1)
SHX43_1 = SHX17_1
SHX44_1 = "Reaper:UpdateFlaggedEvents"
function SHX45_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX0_2 = source
  if "" ~= SHX0_2 then
    SHX1_2 = SHX21_1
    SHX1_2 = SHX1_2()
    SHX2_2 = SHX1_2
    SHX1_2 = SHX1_2.InvokeSPlayer
    SHX3_2 = SHX0_2
    SHX4_2 = "newDetection"
    SHX5_2 = "antiTriggerServerEvent"
    SHX6_2 = {}
    SHX6_2.eventName = "Reaper:UpdateFlaggedEvents"
    SHX7_2 = SHX22_1
    SHX6_2.resource = SHX7_2
    SHX6_2.inv_resource = "na"
    SHX6_2.method = "net_missmatch"
    SHX7_2 = {}
    SHX8_2 = "Reaper:UpdateFlaggedEvents"
    SHX7_2[1] = SHX8_2
    return SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
  end
  SHX1_2 = SHX4_1
  SHX2_2 = SHX18_1
  SHX3_2 = "ReaperV4"
  SHX4_2 = "cache/flaggedEvents.json"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if not SHX2_2 then
    SHX2_2 = "{}"
  end
  SHX1_2 = SHX1_2(SHX2_2)
  SHX42_1 = SHX1_2
  SHX1_2 = SHX13_1
  SHX2_2 = SHX42_1
  SHX1_2, SHX2_2, SHX3_2, SHX4_2 = SHX1_2(SHX2_2)
  for SHX5_2, SHX6_2 in SHX1_2, SHX2_2, SHX3_2, SHX4_2 do
    SHX7_2 = SHX41_1
    SHX7_2 = SHX7_2[SHX5_2]
    if SHX7_2 then
      SHX7_2 = SHX40_1
      SHX7_2 = SHX7_2[SHX5_2]
      if nil == SHX7_2 then
        SHX7_2 = SHX40_1
        SHX7_2[SHX5_2] = true
        SHX7_2 = SHX6_2.log
        SHX9_2 = SHX7_2
        SHX8_2 = SHX7_2.gsub
        SHX10_2 = "EventName"
        SHX11_2 = SHX5_2
        SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2)
        SHX7_2 = SHX8_2
        SHX9_2 = SHX7_2
        SHX8_2 = SHX7_2.gsub
        SHX10_2 = "ResourceName"
        SHX11_2 = SHX22_1
        SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2)
        SHX7_2 = SHX8_2
        SHX8_2 = SHX31_1
        SHX9_2 = SHX7_2
        SHX10_2 = "warn"
        SHX11_2 = "events"
        SHX12_2 = {}
        SHX13_2 = SHX22_1
        SHX12_2.resource = SHX13_2
        SHX12_2.eventName = SHX5_2
        SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2)
        SHX8_2 = TriggerEvent
        SHX9_2 = "Reaper:FlaggedEventFound"
        SHX10_2 = SHX5_2
        SHX11_2 = SHX42_1
        SHX11_2 = SHX11_2[SHX5_2]
        SHX8_2(SHX9_2, SHX10_2, SHX11_2)
      end
    end
  end
end
SHX43_1(SHX44_1, SHX45_1)
SHX43_1 = SHX0_1
SHX44_1 = "reaper_pro_addon_enabled"
SHX45_1 = "false"
SHX43_1 = SHX43_1(SHX44_1, SHX45_1)
SHX43_1 = "true" == SHX43_1
SHX44_1 = AddConvarChangeListener
SHX45_1 = "reaper_pro_addon_enabled"
function SHX46_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2
  SHX0_2 = SHX0_1
  SHX1_2 = "reaper_pro_addon_enabled"
  SHX2_2 = "false"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = "true" == SHX0_2
  SHX43_1 = SHX0_2
end
SHX44_1(SHX45_1, SHX46_1)
SHX44_1 = false
SHX45_1 = SHX4_1
SHX46_1 = SHX18_1
SHX47_1 = "ReaperV4"
SHX48_1 = "cache/events-"
SHX49_1 = SHX22_1
SHX50_1 = ".json"
SHX48_1 = SHX48_1 .. SHX49_1 .. SHX50_1
SHX46_1 = SHX46_1(SHX47_1, SHX48_1)
if not SHX46_1 then
  SHX46_1 = "{}"
end
SHX45_1 = SHX45_1(SHX46_1)
SHX46_1 = {}
function SHX47_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX4_2 = SHX1_1
  SHX5_2 = SHX0_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX0_2 = SHX4_2
  SHX4_2 = SHX45_1
  SHX4_2[SHX0_2] = SHX1_2
  SHX1_2.auto_whitelisted = SHX3_2
  if SHX3_2 then
    SHX4_2 = GetPlayerIdentifierByType
    SHX5_2 = SHX2_2
    SHX6_2 = "license"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.gsub
    SHX6_2 = "license:"
    SHX7_2 = ""
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX1_2.player_license = SHX4_2
  end
  SHX4_2 = json
  SHX4_2 = SHX4_2.encode
  SHX5_2 = SHX45_1
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = SaveResourceFile
  SHX6_2 = "ReaperV4"
  SHX7_2 = "cache/events-"
  SHX8_2 = SHX22_1
  SHX9_2 = ".json"
  SHX7_2 = SHX7_2 .. SHX8_2 .. SHX9_2
  SHX8_2 = SHX4_2
  SHX9_2 = #SHX4_2
  SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  SHX5_2 = SHX32_1
  SHX6_2 = SHX2_2
  SHX7_2 = "(^3TriggerServerEvent('%s')^7) (^3%s^7) sent from (^3%s^7) by (^3%s^7) (^3id:%s^7) was auto whitelisted."
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.format
  SHX9_2 = SHX1_2.event
  SHX10_2 = SHX0_2
  SHX11_2 = SHX1_2.path
  SHX12_2 = GetPlayerName
  SHX13_2 = SHX2_2
  SHX12_2 = SHX12_2(SHX13_2)
  SHX13_2 = SHX2_2
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  SHX8_2 = "warn"
  SHX9_2 = "pro_addon"
  SHX10_2 = {}
  SHX10_2.executionId = SHX0_2
  SHX10_2.executionData = SHX1_2
  SHX10_2.auto_whitelisted = SHX3_2
  SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
end
SHX48_1 = SHX17_1
SHX49_1 = "Reaper:ProAddonAutoWhitelist"
function SHX50_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX2_2 = source
  if "" ~= SHX2_2 then
    SHX3_2 = SHX21_1
    SHX3_2 = SHX3_2()
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.InvokeSPlayer
    SHX5_2 = SHX2_2
    SHX6_2 = "newDetection"
    SHX7_2 = "antiTriggerServerEvent"
    SHX8_2 = {}
    SHX8_2.eventName = "Reaper:ProAddonAutoWhitelist"
    SHX9_2 = SHX22_1
    SHX8_2.resource = SHX9_2
    SHX8_2.inv_resource = "na"
    SHX8_2.method = "net_missmatch"
    SHX9_2 = {}
    SHX10_2 = "Reaper:ProAddonAutoWhitelist"
    SHX9_2[1] = SHX10_2
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  end
  if "all" ~= SHX0_2 then
    SHX3_2 = SHX22_1
    if SHX0_2 ~= SHX3_2 then
      return
    end
  end
  SHX44_1 = SHX1_2
end
SHX48_1(SHX49_1, SHX50_1)
SHX48_1 = SHX17_1
SHX49_1 = "Reaper:ProAddonRefreshWhitelist"
function SHX50_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX0_2 = source
  if "" ~= SHX0_2 then
    SHX1_2 = SHX21_1
    SHX1_2 = SHX1_2()
    SHX2_2 = SHX1_2
    SHX1_2 = SHX1_2.InvokeSPlayer
    SHX3_2 = SHX0_2
    SHX4_2 = "newDetection"
    SHX5_2 = "antiTriggerServerEvent"
    SHX6_2 = {}
    SHX6_2.eventName = "Reaper:ProAddonRefreshWhitelist"
    SHX7_2 = SHX22_1
    SHX6_2.resource = SHX7_2
    SHX6_2.inv_resource = "na"
    SHX6_2.method = "net_missmatch"
    SHX7_2 = {}
    SHX8_2 = "Reaper:ProAddonRefreshWhitelist"
    SHX7_2[1] = SHX8_2
    return SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
  end
  SHX1_2 = SHX4_1
  SHX2_2 = SHX18_1
  SHX3_2 = "ReaperV4"
  SHX4_2 = "cache/events-"
  SHX5_2 = SHX22_1
  SHX6_2 = ".json"
  SHX4_2 = SHX4_2 .. SHX5_2 .. SHX6_2
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if not SHX2_2 then
    SHX2_2 = "{}"
  end
  SHX1_2 = SHX1_2(SHX2_2)
  SHX45_1 = SHX1_2
end
SHX48_1(SHX49_1, SHX50_1)
SHX48_1 = SHX17_1
SHX49_1 = "Reaper:ProAddonEnabled"
function SHX50_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX2_2 = source
  if "" ~= SHX2_2 then
    SHX3_2 = SHX21_1
    SHX3_2 = SHX3_2()
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.InvokeSPlayer
    SHX5_2 = SHX2_2
    SHX6_2 = "newDetection"
    SHX7_2 = "antiTriggerServerEvent"
    SHX8_2 = {}
    SHX8_2.eventName = "Reaper:ProAddonEnabled"
    SHX9_2 = SHX22_1
    SHX8_2.resource = SHX9_2
    SHX8_2.inv_resource = "na"
    SHX8_2.method = "net_missmatch"
    SHX9_2 = {}
    SHX10_2 = "Reaper:ProAddonEnabled"
    SHX9_2[1] = SHX10_2
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  end
  SHX3_2 = SHX22_1
  if SHX0_2 == SHX3_2 or "all" == SHX0_2 then
    SHX3_2 = not SHX1_2
    SHX43_1 = SHX3_2
  end
end
SHX48_1(SHX49_1, SHX50_1)
SHX48_1 = SHX17_1
SHX49_1 = "ProAddon:AddWhitelister"
function SHX50_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX1_2 = source
  if "" ~= SHX1_2 then
    SHX2_2 = SHX21_1
    SHX2_2 = SHX2_2()
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.InvokeSPlayer
    SHX4_2 = SHX1_2
    SHX5_2 = "newDetection"
    SHX6_2 = "antiTriggerServerEvent"
    SHX7_2 = {}
    SHX7_2.eventName = "Reaper:AddWhitelister"
    SHX8_2 = SHX22_1
    SHX7_2.resource = SHX8_2
    SHX7_2.inv_resource = "na"
    SHX7_2.method = "net_missmatch"
    SHX8_2 = {}
    SHX9_2 = "Reaper:AddWhitelister"
    SHX8_2[1] = SHX9_2
    return SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  end
  SHX2_2 = SHX1_1
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SHX46_1
  SHX3_2[SHX2_2] = true
end
SHX48_1(SHX49_1, SHX50_1)
SHX48_1 = SHX0_1
SHX49_1 = "reaper_event_logger_console"
SHX50_1 = "false"
SHX48_1 = SHX48_1(SHX49_1, SHX50_1)
SHX48_1 = "true" == SHX48_1
SHX49_1 = {}
SHX50_1 = {}
SHX49_1.events_received = SHX50_1
SHX50_1 = {}
SHX49_1.events_sent = SHX50_1
SHX50_1 = {}
SHX49_1.resources_received = SHX50_1
SHX50_1 = {}
SHX49_1.resources_sent = SHX50_1
SHX50_1 = os
SHX50_1 = SHX50_1.time
SHX50_1 = SHX50_1()
SHX49_1.last_flush = SHX50_1
SHX50_1 = SHX0_1
SHX51_1 = "reaper_event_monitor_flush_interval"
SHX52_1 = "30"
SHX50_1 = SHX50_1(SHX51_1, SHX52_1)
SHX51_1 = tonumber
SHX52_1 = SHX50_1
SHX51_1 = SHX51_1(SHX52_1)
SHX50_1 = SHX51_1 or SHX50_1
if not SHX51_1 then
  SHX50_1 = 30
end
function SHX51_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2
  SHX2_2 = SHX0_2[SHX1_2]
  if not SHX2_2 then
    SHX0_2[SHX1_2] = 0
  end
  SHX2_2 = SHX0_2[SHX1_2]
  SHX2_2 = SHX2_2 + 1
  SHX0_2[SHX1_2] = SHX2_2
end
function SHX52_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX0_2 = next
  SHX1_2 = SHX49_1.events_received
  SHX0_2 = SHX0_2(SHX1_2)
  if not SHX0_2 then
    SHX0_2 = next
    SHX1_2 = SHX49_1.events_sent
    SHX0_2 = SHX0_2(SHX1_2)
    if not SHX0_2 then
      SHX0_2 = next
      SHX1_2 = SHX49_1.resources_received
      SHX0_2 = SHX0_2(SHX1_2)
      if not SHX0_2 then
        SHX0_2 = next
        SHX1_2 = SHX49_1.resources_sent
        SHX0_2 = SHX0_2(SHX1_2)
      end
    end
  end
  if SHX0_2 then
    SHX1_2 = TriggerEvent
    SHX2_2 = "EventMonitor:BatchUpdate"
    SHX3_2 = {}
    SHX4_2 = SHX49_1.events_received
    SHX3_2.events_received = SHX4_2
    SHX4_2 = SHX49_1.events_sent
    SHX3_2.events_sent = SHX4_2
    SHX4_2 = SHX49_1.resources_received
    SHX3_2.resources_received = SHX4_2
    SHX4_2 = SHX49_1.resources_sent
    SHX3_2.resources_sent = SHX4_2
    SHX1_2(SHX2_2, SHX3_2)
    SHX1_2 = {}
    SHX49_1.events_received = SHX1_2
    SHX1_2 = {}
    SHX49_1.events_sent = SHX1_2
    SHX1_2 = {}
    SHX49_1.resources_received = SHX1_2
    SHX1_2 = {}
    SHX49_1.resources_sent = SHX1_2
  end
  SHX1_2 = os
  SHX1_2 = SHX1_2.time
  SHX1_2 = SHX1_2()
  SHX49_1.last_flush = SHX1_2
end
SHX53_1 = SHX8_1
function SHX54_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  while true do
    SHX0_2 = SHX15_1
    SHX1_2 = SHX50_1
    SHX1_2 = SHX1_2 * 1000
    SHX0_2(SHX1_2)
    SHX0_2 = SHX52_1
    SHX0_2()
  end
end
SHX53_1(SHX54_1)
SHX53_1 = AddConvarChangeListener
SHX54_1 = "reaper_event_logger_console"
function SHX55_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2
  SHX0_2 = SHX0_1
  SHX1_2 = "reaper_event_logger_console"
  SHX2_2 = "false"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = "true" == SHX0_2
  SHX48_1 = SHX0_2
end
SHX53_1(SHX54_1, SHX55_1)
SHX53_1 = SHX23_1
SHX54_1 = "TriggerClientEvent"
function SHX55_1(SHX0_2, SHX1_2, SHX2_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX3_2 = SHX1_1
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  SHX1_2 = SHX3_2
  SHX3_2 = SHX51_1
  SHX4_2 = SHX49_1.events_sent
  SHX5_2 = SHX1_2
  SHX3_2(SHX4_2, SHX5_2)
  SHX3_2 = SHX51_1
  SHX4_2 = SHX49_1.resources_sent
  SHX5_2 = GetInvokingResource
  SHX5_2 = SHX5_2()
  if not SHX5_2 then
    SHX5_2 = SHX22_1
  end
  SHX3_2(SHX4_2, SHX5_2)
  SHX3_2 = SHX48_1
  if SHX3_2 then
    SHX3_2 = msgpack
    SHX3_2 = SHX3_2.pack_args
    SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = ...
    SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
    SHX4_2 = string
    SHX4_2 = SHX4_2.len
    SHX5_2 = SHX3_2
    SHX4_2 = SHX4_2(SHX5_2)
    SHX5_2 = SHX3_1
    SHX6_2 = "^3%s^7 (^3size:%s^7) was just sent. Large: ^3%s^7"
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.format
    SHX8_2 = SHX1_2
    SHX9_2 = SHX4_2
    SHX10_2 = 50000
    SHX10_2 = SHX4_2 >= SHX10_2
    SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
    SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  end
  SHX3_2 = SHX25_1
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  if SHX3_2 then
    SHX3_2 = SHX0_2
    SHX4_2 = SHX1_2
    SHX5_2 = SHX2_2
    SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = ...
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  end
  SHX3_2 = SHX2_1
  SHX3_2 = SHX3_2()
  SHX4_2 = math
  SHX4_2 = SHX4_2.random
  SHX5_2 = 0
  SHX6_2 = 9999999
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX3_2 = SHX3_2 + SHX4_2
  SHX4_2 = SHX24_1
  SHX5_2 = SHX1_2
  SHX6_2 = SHX3_2
  SHX7_2 = 0
  SHX5_2 = SHX5_2 .. SHX6_2 .. SHX7_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = SHX0_2
  SHX6_2 = SHX1_2
  SHX7_2 = SHX2_2
  SHX8_2 = "REAPER_PROTECTED"
  SHX9_2 = {}
  SHX9_2.id = SHX3_2
  SHX9_2.time = 0
  SHX9_2.key = SHX4_2
  SHX9_2.from = "server"
  SHX10_2 = ...
  return SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
end
SHX53_1(SHX54_1, SHX55_1)
SHX53_1 = SHX23_1
SHX54_1 = "TriggerLatentClientEvent"
function SHX55_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX4_2 = SHX1_1
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX1_2 = SHX4_2
  SHX4_2 = SHX51_1
  SHX5_2 = SHX49_1.events_sent
  SHX6_2 = SHX1_2
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = SHX51_1
  SHX5_2 = SHX49_1.resources_sent
  SHX6_2 = GetInvokingResource
  SHX6_2 = SHX6_2()
  if not SHX6_2 then
    SHX6_2 = SHX22_1
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = SHX48_1
  if SHX4_2 then
    SHX4_2 = msgpack
    SHX4_2 = SHX4_2.pack_args
    SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = ...
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
    SHX5_2 = string
    SHX5_2 = SHX5_2.len
    SHX6_2 = SHX4_2
    SHX5_2 = SHX5_2(SHX6_2)
    SHX6_2 = SHX3_1
    SHX7_2 = "^3%s^7 (^3size:%s^7) was just sent. Large: %s"
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.format
    SHX9_2 = SHX1_2
    SHX10_2 = SHX5_2
    SHX11_2 = 50000
    SHX11_2 = SHX5_2 >= SHX11_2
    SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2)
    SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  end
  SHX4_2 = SHX25_1
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  if SHX4_2 then
    SHX4_2 = SHX0_2
    SHX5_2 = SHX1_2
    SHX6_2 = SHX2_2
    SHX7_2 = SHX3_2
    SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = ...
    return SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  end
  SHX4_2 = SHX2_1
  SHX4_2 = SHX4_2()
  SHX5_2 = SHX24_1
  SHX6_2 = SHX1_2
  SHX7_2 = SHX4_2
  SHX8_2 = 0
  SHX6_2 = SHX6_2 .. SHX7_2 .. SHX8_2
  SHX5_2 = SHX5_2(SHX6_2)
  SHX6_2 = SHX0_2
  SHX7_2 = SHX1_2
  SHX8_2 = SHX2_2
  SHX9_2 = SHX3_2
  SHX10_2 = "REAPER_PROTECTED"
  SHX11_2 = {}
  SHX11_2.id = SHX4_2
  SHX11_2.time = 0
  SHX11_2.key = SHX5_2
  SHX11_2.from = "server"
  SHX12_2 = ...
  return SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
end
SHX53_1(SHX54_1, SHX55_1)
SHX53_1 = SHX23_1
SHX54_1 = "TriggerEvent"
function SHX55_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  if "EventMonitor:BatchUpdate" ~= SHX1_2 then
    SHX2_2 = SHX51_1
    SHX3_2 = SHX49_1.events_sent
    SHX4_2 = SHX1_1
    SHX5_2 = SHX1_2
    SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2 = SHX4_2(SHX5_2)
    SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
    SHX2_2 = SHX51_1
    SHX3_2 = SHX49_1.resources_sent
    SHX4_2 = GetInvokingResource
    SHX4_2 = SHX4_2()
    if not SHX4_2 then
      SHX4_2 = SHX22_1
    end
    SHX2_2(SHX3_2, SHX4_2)
  end
  SHX2_2 = SHX48_1
  if SHX2_2 then
    SHX2_2 = msgpack
    SHX2_2 = SHX2_2.pack_args
    SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2 = ...
    SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
    SHX3_2 = string
    SHX3_2 = SHX3_2.len
    SHX4_2 = SHX2_2
    SHX3_2 = SHX3_2(SHX4_2)
    SHX4_2 = SHX3_1
    SHX5_2 = "^3%s^7 (^3size:%s^7) was just sent local. Large: %s"
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.format
    SHX7_2 = SHX1_2
    SHX8_2 = SHX3_2
    SHX9_2 = 50000
    SHX9_2 = SHX3_2 >= SHX9_2
    SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2)
    SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  end
  SHX2_2 = SHX0_2
  SHX3_2 = SHX1_2
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2 = ...
  return SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
end
SHX53_1(SHX54_1, SHX55_1)
SHX53_1 = {}
SHX54_1 = {}
SHX55_1 = {}
SHX56_1 = {}
SHX57_1 = {}
SHX57_1.key = ""
SHX57_1.path = ""
SHX58_1 = SHX0_1
SHX59_1 = "reaper_event_logger"
SHX60_1 = "false"
SHX58_1 = SHX58_1(SHX59_1, SHX60_1)
SHX58_1 = "true" == SHX58_1
SHX59_1 = SHX0_1
SHX60_1 = "reaper_event_logger:"
SHX61_1 = SHX22_1
SHX60_1 = SHX60_1 .. SHX61_1
SHX61_1 = "false"
SHX59_1 = SHX59_1(SHX60_1, SHX61_1)
SHX59_1 = "true" == SHX59_1
SHX60_1 = AddConvarChangeListener
SHX61_1 = "reaper_event_logger:"
SHX62_1 = SHX22_1
SHX61_1 = SHX61_1 .. SHX62_1
function SHX62_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2
  SHX0_2 = SHX0_1
  SHX1_2 = "reaper_event_logger:"
  SHX2_2 = SHX22_1
  SHX1_2 = SHX1_2 .. SHX2_2
  SHX2_2 = "false"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = "true" == SHX0_2
  SHX59_1 = SHX0_2
end
SHX60_1(SHX61_1, SHX62_1)
SHX60_1 = AddConvarChangeListener
SHX61_1 = "reaper_event_logger"
function SHX62_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2
  SHX0_2 = SHX0_1
  SHX1_2 = "reaper_event_logger"
  SHX2_2 = "false"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = "true" == SHX0_2
  SHX58_1 = SHX0_2
end
SHX60_1(SHX61_1, SHX62_1)
SHX60_1 = SHX4_1
SHX61_1 = SHX0_1
SHX62_1 = "reaper_event_rule_names"
SHX63_1 = "{}"
SHX61_1, SHX62_1, SHX63_1, SHX64_1, SHX65_1 = SHX61_1(SHX62_1, SHX63_1)
SHX60_1 = SHX60_1(SHX61_1, SHX62_1, SHX63_1, SHX64_1, SHX65_1)
SHX61_1 = AddConvarChangeListener
SHX62_1 = "reaper_event_rule_names"
function SHX63_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2
  SHX0_2 = SHX4_1
  SHX1_2 = SHX0_1
  SHX2_2 = "reaper_event_rule_names"
  SHX3_2 = "{}"
  SHX1_2, SHX2_2, SHX3_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX60_1 = SHX0_2
end
SHX61_1(SHX62_1, SHX63_1)
SHX61_1 = SHX23_1
SHX62_1 = "AddEventHandler"
function SHX63_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX3_2 = SHX1_1
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  SHX1_2 = SHX3_2
  SHX3_2 = SHX16_1
  SHX4_2 = 1
  SHX5_2 = 99999999
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX7_1
  SHX5_2 = SHX2_2
  SHX4_2 = SHX4_2(SHX5_2)
  if "function" ~= SHX4_2 then
    return
  end
  SHX4_2 = SHX41_1
  SHX4_2[SHX1_2] = true
  SHX4_2 = SHX25_1
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  if SHX4_2 then
    SHX4_2 = SHX0_2
    SHX5_2 = SHX1_2
    SHX6_2 = SHX2_2
    return SHX4_2(SHX5_2, SHX6_2)
  end
  SHX4_2 = string
  SHX4_2 = SHX4_2.match
  SHX6_2 = SHX1_2
  SHX5_2 = SHX1_2.lower
  SHX5_2 = SHX5_2(SHX6_2)
  SHX6_2 = "reaper"
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = SHX42_1
  SHX5_2 = SHX5_2[SHX1_2]
  if SHX5_2 then
    SHX5_2 = SHX40_1
    SHX5_2[SHX1_2] = true
    SHX5_2 = SHX8_1
    function SHX6_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
      while true do
        SHX0_3 = GlobalState
        SHX0_3 = SHX0_3.ReaperStarted
        if SHX0_3 then
          break
        end
        SHX0_3 = SHX15_1
        SHX1_3 = 3000
        SHX0_3(SHX1_3)
      end
      SHX1_3 = SHX1_2
      SHX0_3 = SHX42_1
      SHX0_3 = SHX0_3[SHX1_3]
      SHX0_3 = SHX0_3.log
      SHX2_3 = SHX0_3
      SHX1_3 = SHX0_3.gsub
      SHX3_3 = "EventName"
      SHX4_3 = SHX1_2
      SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3)
      SHX0_3 = SHX1_3
      SHX2_3 = SHX0_3
      SHX1_3 = SHX0_3.gsub
      SHX3_3 = "ResourceName"
      SHX4_3 = SHX22_1
      SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3)
      SHX0_3 = SHX1_3
      SHX1_3 = SHX31_1
      SHX2_3 = SHX0_3
      SHX3_3 = "warn"
      SHX4_3 = "events"
      SHX5_3 = {}
      SHX6_3 = SHX22_1
      SHX5_3.resource = SHX6_3
      SHX6_3 = SHX1_2
      SHX5_3.eventName = SHX6_3
      SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3)
      SHX1_3 = TriggerEvent
      SHX2_3 = "Reaper:FlaggedEventFound"
      SHX3_3 = SHX1_2
      SHX5_3 = SHX1_2
      SHX4_3 = SHX42_1
      SHX4_3 = SHX4_3[SHX5_3]
      SHX1_3(SHX2_3, SHX3_3, SHX4_3)
    end
    SHX5_2(SHX6_2)
  end
  SHX5_2 = SHX0_2
  SHX6_2 = SHX1_2
  function SHX7_2(SHX0_3, SHX1_3, ...)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3
    SHX2_3 = source
    SHX3_3 = SHX1_2
    if "EventMonitor:BatchUpdate" ~= SHX3_3 then
      SHX3_3 = SHX51_1
      SHX4_3 = SHX49_1.events_received
      SHX5_3 = SHX1_2
      SHX3_3(SHX4_3, SHX5_3)
      SHX3_3 = SHX51_1
      SHX4_3 = SHX49_1.resources_received
      SHX5_3 = SHX22_1
      SHX3_3(SHX4_3, SHX5_3)
    end
    if "REAPER_PROTECTED" ~= SHX0_3 then
      if "" ~= SHX2_3 then
        SHX3_3 = SHX25_1
        SHX4_3 = SHX1_2
        SHX3_3 = SHX3_3(SHX4_3)
        if not SHX3_3 then
          goto SHX_LABEL_38
        end
      end
      SHX3_3 = _G
      SHX3_3.source = SHX2_3
      SHX3_3 = {}
      SHX3_3.type = "not_reaper_protected"
      SHX3_3.from = "unknown"
      SHX3_3.path = "unknown_path"
      SHX3_3.key = "unknown_key"
      SHX57_1 = SHX3_3
      SHX3_3 = SHX2_2
      SHX4_3 = SHX0_3
      SHX5_3 = SHX1_3
      SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = ...
      return SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
    end
    -- [FIX IF ERROR] Move ::SHX_LABEL_38:: outside nested blocks until all 'goto SHX_LABEL_38' can see it
    ::SHX_LABEL_38::
    SHX4_3 = SHX1_2
    SHX3_3 = SHX55_1
    SHX3_3 = SHX3_3[SHX4_3]
    if SHX3_3 and "" ~= SHX2_3 then
      SHX3_3 = SHX21_1
      SHX3_3 = SHX3_3()
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.InvokeSPlayer
      SHX5_3 = SHX2_3
      SHX6_3 = "newDetection"
      SHX7_3 = "antiTriggerServerOnlyEvent"
      SHX8_3 = {}
      SHX9_3 = SHX1_2
      SHX8_3.eventName = SHX9_3
      SHX9_3 = SHX22_1
      SHX8_3.resource = SHX9_3
      SHX8_3.inv_resource = "na"
      SHX8_3.method = "net_missmatch"
      SHX9_3 = {}
      SHX10_3 = SHX1_2
      SHX9_3[1] = SHX10_3
      return SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    end
    if "REAPER_PROTECTED" ~= SHX0_3 then
      SHX3_3 = SHX21_1
      SHX3_3 = SHX3_3()
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.InvokeSPlayer
      SHX5_3 = SHX2_3
      SHX6_3 = "newDetection"
      SHX7_3 = "antiTriggerServerEvent"
      SHX8_3 = {}
      SHX9_3 = SHX1_2
      SHX8_3.eventName = SHX9_3
      SHX9_3 = SHX22_1
      SHX8_3.resource = SHX9_3
      SHX9_3 = {}
      SHX10_3 = SHX1_2
      SHX9_3[1] = SHX10_3
      SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
      SHX3_3 = 0
      return SHX3_3
    end
    SHX3_3 = SHX1_3.R_P_2
    if SHX3_3 then
      SHX3_3 = SHX1_3.key2
      SHX4_3 = SHX24_1
      SHX5_3 = SHX1_3.key2
      SHX6_3 = SHX1_3.execution_key
      SHX5_3 = SHX5_3 + SHX6_3
      SHX6_3 = SHX1_3.key
      SHX5_3 = SHX5_3 + SHX6_3
      SHX4_3 = SHX4_3(SHX5_3)
      if SHX3_3 ~= SHX4_3 then
        SHX3_3 = TriggerEvent
        SHX4_3 = "Reaper:NewDetection"
        SHX5_3 = {}
        SHX5_3.type = "antiModifyEvent"
        SHX6_3 = {}
        SHX6_3.method = "two"
        SHX7_3 = SHX1_2
        SHX6_3.eventName = SHX7_3
        SHX6_3.p2 = SHX1_3
        SHX7_3 = msgpack
        SHX7_3 = SHX7_3.pack_args
        SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = ...
        SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
        SHX6_3.data = SHX7_3
        SHX7_3 = {}
        SHX7_3.source = SHX2_3
        SHX6_3.server_data = SHX7_3
        SHX7_3 = SHX24_1
        SHX8_3 = SHX1_2
        SHX9_3 = SHX1_3.id
        SHX10_3 = SHX1_3.key2
        SHX11_3 = SHX1_3.resource
        SHX8_3 = SHX8_3 .. SHX9_3 .. SHX10_3 .. SHX11_3
        SHX7_3 = SHX7_3(SHX8_3)
        SHX6_3.real_hash = SHX7_3
        SHX6_3.source = SHX2_3
        SHX5_3.data = SHX6_3
        SHX6_3 = {}
        SHX7_3 = SHX1_2
        SHX6_3[1] = SHX7_3
        SHX5_3.params = SHX6_3
        SHX5_3.action = "Ban Player"
        SHX6_3 = SHX2_3
        return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      end
    else
      SHX3_3 = SHX1_3.key
      SHX4_3 = SHX24_1
      SHX5_3 = SHX1_2
      SHX6_3 = SHX1_3.id
      SHX7_3 = SHX1_3.key2
      SHX8_3 = SHX1_3.resource
      SHX9_3 = SHX1_3.source
      SHX5_3 = SHX5_3 .. SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3
      SHX4_3 = SHX4_3(SHX5_3)
      if SHX3_3 ~= SHX4_3 then
        SHX3_3 = TriggerEvent
        SHX4_3 = "Reaper:NewDetection"
        SHX5_3 = {}
        SHX5_3.type = "antiModifyEvent"
        SHX6_3 = {}
        SHX7_3 = SHX1_2
        SHX6_3.eventName = SHX7_3
        SHX6_3.p2 = SHX1_3
        SHX7_3 = msgpack
        SHX7_3 = SHX7_3.pack_args
        SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = ...
        SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
        SHX6_3.data = SHX7_3
        SHX7_3 = {}
        SHX7_3.source = SHX2_3
        SHX6_3.server_data = SHX7_3
        SHX7_3 = SHX24_1
        SHX8_3 = SHX1_2
        SHX9_3 = SHX1_3.id
        SHX10_3 = SHX1_3.key2
        SHX11_3 = SHX1_3.resource
        SHX8_3 = SHX8_3 .. SHX9_3 .. SHX10_3 .. SHX11_3
        SHX7_3 = SHX7_3(SHX8_3)
        SHX6_3.real_hash = SHX7_3
        SHX6_3.source = SHX2_3
        SHX5_3.data = SHX6_3
        SHX6_3 = {}
        SHX7_3 = SHX1_2
        SHX6_3[1] = SHX7_3
        SHX5_3.params = SHX6_3
        SHX5_3.action = "Ban Player"
        SHX6_3 = SHX2_3
        return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      end
      SHX3_3 = SHX1_3.source
      if SHX3_3 ~= SHX2_3 then
        SHX3_3 = tonumber
        SHX4_3 = SHX1_3.source
        SHX3_3 = SHX3_3(SHX4_3)
        if 0 ~= SHX3_3 then
          SHX3_3 = TriggerEvent
          SHX4_3 = "Reaper:NewDetection"
          SHX5_3 = {}
          SHX5_3.type = "antiReTriggerServerEvent"
          SHX6_3 = {}
          SHX7_3 = SHX1_2
          SHX6_3.eventName = SHX7_3
          SHX6_3.p2 = SHX1_3
          SHX7_3 = msgpack
          SHX7_3 = SHX7_3.pack_args
          SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = ...
          SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
          SHX6_3.data = SHX7_3
          SHX7_3 = {}
          SHX7_3.source = SHX2_3
          SHX6_3.server_data = SHX7_3
          SHX7_3 = SHX24_1
          SHX8_3 = SHX1_2
          SHX9_3 = SHX1_3.id
          SHX10_3 = SHX1_3.key2
          SHX11_3 = SHX1_3.resource
          SHX8_3 = SHX8_3 .. SHX9_3 .. SHX10_3 .. SHX11_3
          SHX7_3 = SHX7_3(SHX8_3)
          SHX6_3.real_hash = SHX7_3
          SHX6_3.source = SHX2_3
          SHX5_3.data = SHX6_3
          SHX6_3 = {}
          SHX7_3 = SHX1_2
          SHX6_3[1] = SHX7_3
          SHX5_3.params = SHX6_3
          SHX5_3.action = "Ban Player"
          SHX6_3 = SHX2_3
          return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
        end
      end
    end
    SHX3_3 = {}
    SHX3_3.type = "reaper_protected"
    SHX4_3 = SHX1_3.resource
    if not SHX4_3 then
      SHX4_3 = "unknown"
    end
    SHX3_3.from = SHX4_3
    SHX4_3 = SHX1_3.path
    if not SHX4_3 then
      SHX4_3 = "unknown_path"
    end
    SHX3_3.path = SHX4_3
    SHX4_3 = SHX1_3.key2
    if not SHX4_3 then
      SHX4_3 = "unknown_key"
    end
    SHX3_3.key = SHX4_3
    SHX5_3 = SHX1_2
    SHX4_3 = SHX60_1
    SHX4_3 = SHX4_3[SHX5_3]
    if SHX4_3 then
      SHX4_3 = SHX21_1
      SHX4_3 = SHX4_3()
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.EventRulesCheck
      SHX6_3 = SHX1_2
      SHX7_3 = {}
      SHX7_3.source = SHX2_3
      SHX8_3 = {}
      SHX9_3 = SHX1_3.path
      SHX8_3.path = SHX9_3
      SHX9_3 = SHX1_3.key2
      SHX8_3.executionId = SHX9_3
      SHX9_3 = SHX1_3.execution_key
      SHX8_3.extendedExecutionId = SHX9_3
      SHX9_3 = SHX1_3.resource
      SHX8_3.resource = SHX9_3
      SHX9_3 = {}
      SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = ...
      SHX9_3[1] = SHX10_3
      SHX9_3[2] = SHX11_3
      SHX9_3[3] = SHX12_3
      SHX9_3[4] = SHX13_3
      SHX9_3[5] = SHX14_3
      SHX9_3[6] = SHX15_3
      SHX9_3[7] = SHX16_3
      SHX8_3.args = SHX9_3
      SHX7_3.req = SHX8_3
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      if false == SHX4_3 then
        return
      end
    end
    SHX5_3 = SHX1_2
    SHX4_3 = SHX53_1
    SHX4_3 = SHX4_3[SHX5_3]
    if SHX4_3 then
      SHX4_3 = nil
      SHX5_3 = SHX13_1
      SHX7_3 = SHX1_2
      SHX6_3 = SHX53_1
      SHX6_3 = SHX6_3[SHX7_3]
      SHX5_3, SHX6_3, SHX7_3, SHX8_3 = SHX5_3(SHX6_3)
      for SHX9_3, SHX10_3 in SHX5_3, SHX6_3, SHX7_3, SHX8_3 do
        SHX57_1 = SHX3_3
        SHX11_3 = SHX10_3.callback
        SHX12_3 = SHX2_3
        SHX13_3, SHX14_3, SHX15_3, SHX16_3 = ...
        SHX11_3 = SHX11_3(SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
        if not SHX11_3 then
          SHX4_3 = SHX10_3.name
          break
        end
      end
      if SHX4_3 then
        SHX5_3 = SHX31_1
        SHX6_3 = "The event (^3%s^7) sent by ^3%s^7 (^3id:%s^7) was canceled by the hook on (^3%s^7)"
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.format
        SHX8_3 = SHX1_2
        SHX9_3 = GetPlayerName
        SHX10_3 = SHX2_3
        SHX9_3 = SHX9_3(SHX10_3)
        SHX10_3 = SHX2_3
        SHX11_3 = SHX4_3
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
        SHX7_3 = "warn"
        SHX8_3 = "events"
        SHX9_3 = {}
        SHX10_3 = SHX1_2
        SHX9_3.eventName = SHX10_3
        SHX9_3.failed_hook = SHX4_3
        return SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3)
      end
    end
    SHX4_3 = SHX43_1
    if SHX4_3 then
      SHX4_3 = SHX0_1
      SHX5_3 = "reaper_log_ProAddonEnabled"
      SHX6_3 = "false"
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
      if "true" == SHX4_3 then
        SHX4_3 = SHX3_1
        SHX5_3 = SHX43_1
        SHX4_3(SHX5_3)
      end
      SHX4_3 = SHX1_1
      SHX5_3 = SHX1_3.key2
      SHX4_3 = SHX4_3(SHX5_3)
      SHX5_3 = SHX45_1
      SHX5_3 = SHX5_3[SHX4_3]
      if nil == SHX5_3 then
        SHX5_3 = false
        SHX6_3 = SHX0_1
        SHX7_3 = "reaper_auto_whitelist_scripts"
        SHX8_3 = "false"
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
        if "true" == SHX6_3 then
          SHX6_3 = SHX44_1
          if false == SHX6_3 then
            SHX6_3 = "auto_whitelisted_"
            SHX7_3 = SHX1_2
            SHX6_3 = SHX6_3 .. SHX7_3
            SHX7_3 = SHX45_1
            SHX6_3 = SHX7_3[SHX6_3]
            if nil == SHX6_3 then
              SHX6_3 = SHX21_1
              SHX6_3 = SHX6_3()
              SHX7_3 = SHX6_3
              SHX6_3 = SHX6_3.VerifyExecution
              SHX8_3 = SHX1_2
              SHX9_3 = SHX4_3
              SHX10_3 = SHX1_3.path
              SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
              SHX5_3 = SHX6_3
            end
          end
        end
        if not SHX5_3 then
          SHX6_3 = SHX44_1
          if not SHX6_3 then
            SHX6_3 = SHX1_1
            SHX7_3 = SHX2_3
            SHX6_3 = SHX6_3(SHX7_3)
            SHX7_3 = SHX46_1
            SHX6_3 = SHX7_3[SHX6_3]
            if not SHX6_3 then
              SHX6_3 = SHX4_2
              if not SHX6_3 then
                goto SHX_LABEL_404
              end
            end
          end
        end
        SHX6_3 = SHX47_1
        SHX7_3 = SHX1_3.key2
        SHX8_3 = {}
        SHX9_3 = SHX22_1
        SHX8_3.resource = SHX9_3
        SHX9_3 = SHX1_2
        SHX8_3.event = SHX9_3
        SHX9_3 = SHX1_3.path
        SHX8_3.path = SHX9_3
        SHX9_3 = SHX2_3
        SHX10_3 = SHX5_3
        SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
        goto SHX_LABEL_422
        -- [FIX IF ERROR] Move ::SHX_LABEL_404:: outside nested blocks until all 'goto SHX_LABEL_404' can see it
        ::SHX_LABEL_404::
        SHX6_3 = TriggerEvent
        SHX7_3 = "Reaper:UnknownExecutionPath"
        SHX8_3 = {}
        SHX8_3.type = "event"
        SHX9_3 = SHX22_1
        SHX8_3.resource = SHX9_3
        SHX9_3 = SHX1_3.resource
        SHX8_3.invoking_resource = SHX9_3
        SHX9_3 = SHX1_2
        SHX8_3.param = SHX9_3
        SHX9_3 = SHX1_3.path
        SHX8_3.path = SHX9_3
        SHX9_3 = SHX1_3.key2
        SHX8_3.key = SHX9_3
        SHX8_3.source = SHX2_3
        SHX6_3(SHX7_3, SHX8_3)
        return
      end
    end
    -- [FIX IF ERROR] Move ::SHX_LABEL_422:: outside nested blocks until all 'goto SHX_LABEL_422' can see it
    ::SHX_LABEL_422::
    SHX5_3 = SHX1_2
    SHX4_3 = SHX42_1
    SHX4_3 = SHX4_3[SHX5_3]
    if SHX4_3 then
      SHX5_3 = SHX1_2
      SHX4_3 = SHX42_1
      SHX4_3 = SHX4_3[SHX5_3]
      SHX4_3 = SHX4_3.key_lock
      if SHX4_3 then
        SHX4_3 = "%s_%s"
        SHX5_3 = SHX4_3
        SHX4_3 = SHX4_3.format
        SHX6_3 = SHX24_1
        SHX7_3 = SHX22_1
        SHX8_3 = "97ae7727-b78e47fc-075ea9de-c852f7da-44587eed"
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
        SHX7_3 = SHX24_1
        SHX8_3 = SHX1_2
        SHX9_3 = "97ae7727-b78e47fc-075ea9de-c852f7da-44587eed"
        SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = SHX7_3(SHX8_3, SHX9_3)
        SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
        SHX5_3 = SHX36_1
        SHX5_3 = SHX5_3[SHX4_3]
        if nil == SHX5_3 then
          SHX5_3 = SHX36_1
          SHX7_3 = SHX1_2
          SHX6_3 = SHX42_1
          SHX6_3 = SHX6_3[SHX7_3]
          SHX6_3 = SHX6_3.known_keys
          if not SHX6_3 then
            SHX6_3 = {}
          end
          SHX5_3[SHX4_3] = SHX6_3
          SHX5_3 = SHX36_1
          SHX5_3 = SHX5_3[SHX4_3]
          SHX6_3 = SHX1_1
          SHX7_3 = SHX1_3.execution_key
          SHX6_3 = SHX6_3(SHX7_3)
          SHX7_3 = {}
          SHX7_3.type = "auto"
          SHX8_3 = SHX1_2
          SHX7_3.event_name = SHX8_3
          SHX8_3 = SHX22_1
          SHX7_3.resource = SHX8_3
          SHX8_3 = SHX1_3.resource
          SHX7_3.invoking_resource = SHX8_3
          SHX8_3 = SHX1_3.path
          SHX7_3.path = SHX8_3
          SHX5_3[SHX6_3] = SHX7_3
          SHX5_3 = SHX32_1
          SHX6_3 = SHX2_3
          SHX7_3 = "The event (^3%s^7) sent from (^3%s^7) was just locked to the execution key ^3%s^7"
          SHX8_3 = SHX7_3
          SHX7_3 = SHX7_3.format
          SHX9_3 = SHX1_2
          SHX10_3 = "%s:%s"
          SHX11_3 = SHX10_3
          SHX10_3 = SHX10_3.format
          SHX12_3 = SHX1_3.resource
          SHX13_3 = SHX1_3.path
          SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
          SHX11_3 = SHX1_3.execution_key
          SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3)
          SHX8_3 = "info"
          SHX9_3 = "event_key_locks"
          SHX10_3 = {}
          SHX11_3 = SHX1_2
          SHX10_3.eventName = SHX11_3
          SHX11_3 = SHX1_3.execution_key
          SHX10_3.execution_key = SHX11_3
          SHX11_3 = SHX22_1
          SHX10_3.resource = SHX11_3
          SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
          SHX5_3 = SHX11_1
          SHX6_3 = SHX36_1
          SHX5_3 = SHX5_3(SHX6_3)
          SHX6_3 = SaveResourceFile
          SHX7_3 = "ReaperV4"
          SHX8_3 = "cache/event_lock.json"
          SHX9_3 = SHX5_3
          SHX10_3 = #SHX5_3
          SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
        end
        SHX5_3 = SHX36_1
        SHX5_3 = SHX5_3[SHX4_3]
        SHX6_3 = SHX1_1
        SHX7_3 = SHX1_3.execution_key
        SHX6_3 = SHX6_3(SHX7_3)
        SHX5_3 = SHX5_3[SHX6_3]
        if nil == SHX5_3 then
          SHX5_3 = SHX32_1
          SHX6_3 = SHX2_3
          SHX7_3 = "^3%s^7 (^3id:%s^7) just triggered the event (^3%s^7) with an invalid key (^3%s^7) from (^3%s^7) and was blocked. ^1An invalid key can be caused by a modification made to the script, an event being triggered from multiple places in a script, or from a cheat. If you know this key is legit, you can allow the key by running the following command. ^3reaper addeventkey %s %s %s^7"
          SHX8_3 = SHX7_3
          SHX7_3 = SHX7_3.format
          SHX9_3 = GetPlayerName
          SHX10_3 = SHX2_3
          SHX9_3 = SHX9_3(SHX10_3)
          SHX10_3 = SHX2_3
          SHX11_3 = SHX1_2
          SHX12_3 = SHX1_3.execution_key
          SHX13_3 = "%s:%s"
          SHX14_3 = SHX13_3
          SHX13_3 = SHX13_3.format
          SHX15_3 = SHX1_3.resource
          SHX16_3 = SHX1_3.path
          SHX13_3 = SHX13_3(SHX14_3, SHX15_3, SHX16_3)
          SHX14_3 = SHX22_1
          SHX15_3 = SHX1_2
          SHX16_3 = SHX1_3.execution_key
          SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
          SHX8_3 = "info"
          SHX9_3 = "event_key_locks"
          SHX10_3 = {}
          SHX11_3 = SHX1_2
          SHX10_3.eventName = SHX11_3
          SHX11_3 = SHX1_3.execution_key
          SHX10_3.execution_key = SHX11_3
          SHX11_3 = SHX22_1
          SHX10_3.resource = SHX11_3
          SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
          SHX5_3 = SHX0_1
          SHX6_3 = "reaper_ban_for_invalid_key_lock"
          SHX7_3 = "true"
          SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
          if "true" == SHX5_3 then
            SHX5_3 = SHX21_1
            SHX5_3 = SHX5_3()
            SHX6_3 = SHX5_3
            SHX5_3 = SHX5_3.InvokeSPlayer
            SHX7_3 = SHX2_3
            SHX8_3 = "newDetection"
            SHX9_3 = "invalidKeyLock"
            SHX10_3 = {}
            SHX11_3 = SHX1_2
            SHX10_3.event = SHX11_3
            SHX11_3 = SHX1_3.execution_key
            SHX10_3.execution_key = SHX11_3
            SHX11_3 = SHX22_1
            SHX10_3.resource = SHX11_3
            SHX11_3 = SHX1_3.resource
            SHX10_3.invoking_resource = SHX11_3
            SHX11_3 = SHX1_3.path
            SHX10_3.path = SHX11_3
            SHX11_3 = {}
            SHX12_3 = SHX1_2
            SHX13_3 = SHX1_3.execution_key
            SHX11_3[1] = SHX12_3
            SHX11_3[2] = SHX13_3
            SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
          end
          return
        end
      end
    end
    SHX4_3 = SHX1_1
    SHX5_3 = SHX1_3.execution_key
    SHX4_3 = SHX4_3(SHX5_3)
    SHX6_3 = SHX1_2
    SHX5_3 = SHX38_1
    SHX5_3 = SHX5_3[SHX6_3]
    if nil == SHX5_3 then
      SHX6_3 = SHX1_2
      SHX5_3 = SHX38_1
      SHX7_3 = {}
      SHX5_3[SHX6_3] = SHX7_3
    end
    SHX5_3 = SHX2_3
    SHX6_3 = SHX4_3
    SHX7_3 = SHX1_2
    SHX5_3 = SHX5_3 .. SHX6_3 .. SHX7_3
    SHX6_3 = SHX37_1
    SHX5_3 = SHX6_3[SHX5_3]
    if nil == SHX5_3 then
      SHX5_3 = SHX2_3
      SHX6_3 = SHX4_3
      SHX7_3 = SHX1_2
      SHX5_3 = SHX5_3 .. SHX6_3 .. SHX7_3
      SHX6_3 = SHX37_1
      SHX6_3[SHX5_3] = true
      SHX6_3 = SHX1_2
      SHX5_3 = SHX38_1
      SHX5_3 = SHX5_3[SHX6_3]
      SHX5_3 = SHX5_3[SHX4_3]
      if nil == SHX5_3 then
        SHX5_3 = SHX4_3
        SHX6_3 = SHX1_2
        SHX5_3 = SHX5_3 .. SHX6_3
        SHX6_3 = SHX37_1
        SHX7_3 = SHX4_3
        SHX8_3 = SHX1_2
        SHX7_3 = SHX7_3 .. SHX8_3
        SHX8_3 = SHX37_1
        SHX7_3 = SHX8_3[SHX7_3]
        if not SHX7_3 then
          SHX7_3 = 0
        end
        SHX7_3 = SHX7_3 + 1
        SHX6_3[SHX5_3] = SHX7_3
        SHX5_3 = SHX4_3
        SHX6_3 = SHX1_2
        SHX5_3 = SHX5_3 .. SHX6_3
        SHX6_3 = SHX37_1
        SHX5_3 = SHX6_3[SHX5_3]
        if SHX5_3 >= 3 then
          SHX6_3 = SHX1_2
          SHX5_3 = SHX38_1
          SHX5_3 = SHX5_3[SHX6_3]
          SHX5_3[SHX4_3] = 3
        end
      else
        SHX6_3 = SHX1_2
        SHX5_3 = SHX38_1
        SHX5_3 = SHX5_3[SHX6_3]
        SHX7_3 = SHX1_2
        SHX6_3 = SHX38_1
        SHX6_3 = SHX6_3[SHX7_3]
        SHX6_3 = SHX6_3[SHX4_3]
        SHX6_3 = SHX6_3 + 1
        SHX5_3[SHX4_3] = SHX6_3
      end
    end
    SHX6_3 = SHX1_2
    SHX5_3 = SHX38_1
    SHX5_3 = SHX5_3[SHX6_3]
    SHX5_3 = SHX5_3[SHX4_3]
    if not SHX5_3 then
      SHX5_3 = 0
    end
    if SHX5_3 <= 3 then
      SHX5_3 = true
      SHX6_3 = SHX13_1
      SHX8_3 = SHX1_2
      SHX7_3 = SHX38_1
      SHX7_3 = SHX7_3[SHX8_3]
      SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX6_3(SHX7_3)
      for SHX10_3, SHX11_3 in SHX6_3, SHX7_3, SHX8_3, SHX9_3 do
        SHX5_3 = true
        break
      end
      if SHX5_3 then
        SHX6_3 = SHX2_1
        SHX6_3 = SHX6_3()
        SHX7_3 = SHX1_2
        SHX8_3 = SHX1_3.execution_key
        SHX7_3 = SHX7_3 .. SHX8_3
        SHX8_3 = SHX56_1
        SHX7_3 = SHX8_3[SHX7_3]
        if not SHX7_3 then
          SHX7_3 = 0
        end
        SHX6_3 = SHX6_3 - SHX7_3
        SHX7_3 = 60000
        if SHX6_3 > SHX7_3 then
          SHX6_3 = SHX32_1
          SHX7_3 = SHX2_3
          SHX8_3 = "^3%s^7 (^3id:%s^7) just triggered the event ^3%s^7 from ^3%s^7 with an uncommon execution id. ID: ^3%s^7"
          SHX9_3 = SHX8_3
          SHX8_3 = SHX8_3.format
          SHX10_3 = GetPlayerName
          SHX11_3 = SHX2_3
          SHX10_3 = SHX10_3(SHX11_3)
          SHX11_3 = SHX2_3
          SHX12_3 = SHX1_2
          SHX13_3 = "%s:%s"
          SHX14_3 = SHX13_3
          SHX13_3 = SHX13_3.format
          SHX15_3 = SHX1_3.resource
          SHX16_3 = SHX1_3.path
          SHX13_3 = SHX13_3(SHX14_3, SHX15_3, SHX16_3)
          SHX14_3 = SHX1_3.execution_key
          SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
          SHX9_3 = "warn"
          SHX10_3 = "uncommon_executions"
          SHX11_3 = {}
          SHX12_3 = SHX1_2
          SHX11_3.eventName = SHX12_3
          SHX12_3 = SHX1_3.execution_key
          SHX11_3.execution_key = SHX12_3
          SHX12_3 = SHX22_1
          SHX11_3.resource = SHX12_3
          SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
          SHX6_3 = SHX1_2
          SHX7_3 = SHX1_3.execution_key
          SHX6_3 = SHX6_3 .. SHX7_3
          SHX7_3 = SHX56_1
          SHX8_3 = SHX2_1
          SHX8_3 = SHX8_3()
          SHX7_3[SHX6_3] = SHX8_3
        end
      end
    end
    SHX5_3 = "player:"
    SHX6_3 = SHX2_3
    SHX5_3 = SHX5_3 .. SHX6_3
    SHX6_3 = SHX54_1
    SHX5_3 = SHX6_3[SHX5_3]
    if nil == SHX5_3 then
      SHX5_3 = "player:"
      SHX6_3 = SHX2_3
      SHX5_3 = SHX5_3 .. SHX6_3
      SHX6_3 = SHX54_1
      SHX7_3 = {}
      SHX6_3[SHX5_3] = SHX7_3
    end
    SHX5_3 = "player:"
    SHX6_3 = SHX2_3
    SHX5_3 = SHX5_3 .. SHX6_3
    SHX6_3 = SHX54_1
    SHX5_3 = SHX6_3[SHX5_3]
    SHX6_3 = SHX1_3.key
    SHX7_3 = SHX3_2
    SHX6_3 = SHX6_3 .. SHX7_3
    SHX5_3 = SHX5_3[SHX6_3]
    if SHX5_3 then
      return
    else
      SHX5_3 = "player:"
      SHX6_3 = SHX2_3
      SHX5_3 = SHX5_3 .. SHX6_3
      SHX6_3 = SHX54_1
      SHX5_3 = SHX6_3[SHX5_3]
      SHX6_3 = SHX1_3.key
      SHX7_3 = SHX3_2
      SHX6_3 = SHX6_3 .. SHX7_3
      SHX5_3[SHX6_3] = true
    end
    SHX5_3 = SHX58_1
    if not SHX5_3 then
      SHX5_3 = SHX59_1
      if not SHX5_3 then
        goto SHX_LABEL_791
      end
    end
    SHX5_3 = GetPlayerIdentifierByType
    SHX6_3 = SHX2_3
    SHX7_3 = "license"
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.gsub
    SHX7_3 = "license:"
    SHX8_3 = ""
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    SHX6_3 = TriggerEvent
    SHX7_3 = "Reaper:log_to_file"
    SHX8_3 = "event_logs/player-%s.log"
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.format
    SHX10_3 = SHX5_3
    SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
    SHX9_3 = SHX11_1
    SHX10_3 = {}
    SHX11_3 = SHX1_2
    SHX10_3.event_name = SHX11_3
    SHX11_3 = SHX22_1
    SHX10_3.resource_handler = SHX11_3
    SHX11_3 = SHX1_3.resource
    SHX10_3.resource_invoker = SHX11_3
    SHX10_3.p2 = SHX1_3
    SHX11_3 = {}
    SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = ...
    SHX11_3[1] = SHX12_3
    SHX11_3[2] = SHX13_3
    SHX11_3[3] = SHX14_3
    SHX11_3[4] = SHX15_3
    SHX11_3[5] = SHX16_3
    SHX10_3.event_data = SHX11_3
    SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = SHX9_3(SHX10_3)
    SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
    -- [FIX IF ERROR] Move ::SHX_LABEL_791:: outside nested blocks until all 'goto SHX_LABEL_791' can see it
    ::SHX_LABEL_791::
    SHX5_3 = SHX48_1
    if SHX5_3 then
      SHX5_3 = msgpack
      SHX5_3 = SHX5_3.pack_args
      SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = ...
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
      SHX6_3 = string
      SHX6_3 = SHX6_3.len
      SHX7_3 = SHX5_3
      SHX6_3 = SHX6_3(SHX7_3)
      SHX7_3 = SHX3_1
      SHX8_3 = "^3%s^7 (^3size:%s^7) was just received. Large: %s"
      SHX9_3 = SHX8_3
      SHX8_3 = SHX8_3.format
      SHX10_3 = SHX1_2
      SHX11_3 = SHX6_3
      SHX12_3 = 50000
      SHX12_3 = SHX6_3 >= SHX12_3
      SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3)
      SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
    end
    SHX57_1 = SHX3_3
    SHX5_3 = _G
    SHX5_3.source = SHX2_3
    SHX5_3 = SHX2_2
    SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = ...
    return SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
  end
  return SHX5_2(SHX6_2, SHX7_2)
end
SHX61_1(SHX62_1, SHX63_1)
SHX61_1 = SHX23_1
SHX62_1 = "RemoveEventHandler"
function SHX63_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  if SHX1_2 then
    SHX2_2 = SHX1_2.key
    if SHX2_2 then
      SHX2_2 = SHX1_2.name
      if SHX2_2 then
        goto SHX_LABEL_13
      end
    end
  end
  SHX2_2 = error
  SHX3_2 = "Invalid event data passed to RemoveEventHandler()"
  SHX4_2 = 2
  SHX2_2(SHX3_2, SHX4_2)
  -- [FIX IF ERROR] Move ::SHX_LABEL_13:: outside nested blocks until all 'goto SHX_LABEL_13' can see it
  ::SHX_LABEL_13::
  SHX3_2 = SHX1_2.name
  SHX2_2 = SHX41_1
  SHX2_2[SHX3_2] = nil
  SHX2_2 = SHX0_2
  SHX3_2 = SHX1_2
  return SHX2_2(SHX3_2)
end
SHX61_1(SHX62_1, SHX63_1)
SHX61_1 = SHX17_1
SHX62_1 = "Reaper:PlayerDropped"
function SHX63_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX1_2 = source
  if "" ~= SHX1_2 then
    SHX2_2 = SHX21_1
    SHX2_2 = SHX2_2()
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.InvokeSPlayer
    SHX4_2 = SHX1_2
    SHX5_2 = "newDetection"
    SHX6_2 = "antiTriggerServerEvent"
    SHX7_2 = {}
    SHX7_2.eventName = "Reaper:PlayerDropped"
    SHX8_2 = SHX22_1
    SHX7_2.resource = SHX8_2
    SHX7_2.inv_resource = "na"
    SHX7_2.method = "net_missmatch"
    SHX8_2 = {}
    SHX9_2 = "Reaper:PlayerDropped"
    SHX8_2[1] = SHX9_2
    return SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  end
  SHX2_2 = "player:"
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2 .. SHX3_2
  SHX3_2 = SHX54_1
  SHX3_2[SHX2_2] = nil
end
SHX61_1(SHX62_1, SHX63_1)
SHX61_1 = SHX23_1
SHX62_1 = "RegisterServerEvent"
function SHX63_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX3_2 = 0
  SHX4_2 = SHX0_2
  SHX5_2 = SHX1_2
  SHX4_2(SHX5_2)
  if SHX2_2 then
    SHX4_2 = AddEventHandler
    SHX5_2 = SHX1_2
    SHX6_2 = SHX2_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    SHX3_2 = SHX4_2
  end
  return SHX3_2
end
SHX61_1(SHX62_1, SHX63_1)
SHX61_1 = SHX23_1
SHX62_1 = "RegisterNetEvent"
function SHX63_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX3_2 = 0
  if SHX2_2 then
    SHX4_2 = AddEventHandler
    SHX5_2 = SHX1_2
    SHX6_2 = SHX2_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    SHX3_2 = SHX4_2
  end
  SHX4_2 = SHX0_2
  SHX5_2 = SHX1_2
  SHX4_2(SHX5_2)
  return SHX3_2
end
SHX61_1(SHX62_1, SHX63_1)
SHX61_1 = {}
SHX62_1 = SHX23_1
SHX63_1 = "GiveWeaponToPed"
function SHX64_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2
  SHX4_2 = SHX33_1
  SHX5_2 = SHX1_2
  SHX4_2, SHX5_2 = SHX4_2(SHX5_2)
  if not SHX4_2 then
    SHX6_2 = SHX0_2
    SHX7_2 = SHX1_2
    SHX8_2 = SHX2_2
    SHX9_2 = SHX3_2
    SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = ...
    return SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
  end
  SHX6_2 = SHX14_1
  SHX7_2 = SHX5_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX7_2 = "weapon:"
  SHX8_2 = SHX2_2
  SHX9_2 = "_src:"
  SHX10_2 = SHX6_2
  SHX7_2 = SHX7_2 .. SHX8_2 .. SHX9_2 .. SHX10_2
  SHX8_2 = SHX61_1
  SHX8_2 = SHX8_2[SHX7_2]
  if true ~= SHX8_2 then
    SHX8_2 = SHX61_1
    SHX9_2 = SHX21_1
    SHX9_2 = SHX9_2()
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.InvokeSPlayer
    SHX11_2 = SHX6_2
    SHX12_2 = "rpc_await"
    SHX13_2 = "Reaper:GiveWeaponToPed"
    SHX14_2 = {}
    SHX15_2 = SHX2_2
    SHX16_2 = SHX3_2
    SHX17_2 = ...
    SHX14_2[1] = SHX15_2
    SHX14_2[2] = SHX16_2
    SHX14_2[3] = SHX17_2
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
    SHX8_2[SHX7_2] = SHX9_2
  end
  SHX8_2 = SHX61_1
  SHX8_2 = SHX8_2[SHX7_2]
  if not SHX8_2 then
    SHX8_2 = warn
    SHX9_2 = "The client %s did not respond with approval to spawn the weapon %s. Skipping"
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.format
    SHX11_2 = SHX6_2
    SHX12_2 = SHX2_2
    SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2)
    SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
    SHX8_2 = 0
    return SHX8_2
  end
  SHX8_2 = SHX0_1
  SHX9_2 = "reaper_log_weapon_spawns"
  SHX10_2 = "false"
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  if "true" == SHX8_2 then
    SHX8_2 = SHX28_1
    SHX9_2 = "The weapon %s was just given to %s (id:%s)"
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.format
    SHX11_2 = SHX2_2
    SHX12_2 = GetPlayerName
    SHX13_2 = SHX6_2
    SHX12_2 = SHX12_2(SHX13_2)
    SHX13_2 = SHX6_2
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2)
    SHX10_2 = "info"
    SHX8_2(SHX9_2, SHX10_2)
  end
  SHX8_2 = SHX0_2
  SHX9_2 = SHX1_2
  SHX10_2 = SHX2_2
  SHX11_2 = SHX3_2
  SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = ...
  return SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
end
SHX62_1(SHX63_1, SHX64_1)
SHX62_1 = SHX23_1
SHX63_1 = "CreateVehicle"
function SHX64_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX21_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.tempAllowEntity
  SHX4_2 = SHX26_1
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = SHX34_1
  SHX6_2 = 3
  SHX5_2, SHX6_2 = SHX5_2(SHX6_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  SHX2_2 = SHX0_2
  SHX3_2 = SHX1_2
  SHX4_2, SHX5_2, SHX6_2 = ...
  return SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
end
SHX62_1(SHX63_1, SHX64_1)
SHX62_1 = SHX23_1
SHX63_1 = "CreateVehicleServerSetter"
function SHX64_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX21_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.tempAllowEntity
  SHX4_2 = SHX26_1
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = SHX34_1
  SHX6_2 = 3
  SHX5_2, SHX6_2 = SHX5_2(SHX6_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  SHX2_2 = SHX0_2
  SHX3_2 = SHX1_2
  SHX4_2, SHX5_2, SHX6_2 = ...
  return SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
end
SHX62_1(SHX63_1, SHX64_1)
SHX62_1 = SHX23_1
SHX63_1 = "CreatePed"
function SHX64_1(SHX0_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX1_2 = SHX27_1
  SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2 = ...
  SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  SHX9_2 = SHX21_1
  SHX9_2 = SHX9_2()
  SHX10_2 = SHX9_2
  SHX9_2 = SHX9_2.tempAllowEntity
  SHX11_2 = SHX26_1
  SHX12_2 = SHX2_2
  SHX11_2 = SHX11_2(SHX12_2)
  SHX12_2 = SHX34_1
  SHX13_2 = 3
  SHX12_2, SHX13_2 = SHX12_2(SHX13_2)
  SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  SHX9_2 = SHX0_2
  SHX10_2, SHX11_2, SHX12_2, SHX13_2 = ...
  return SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2)
end
SHX62_1(SHX63_1, SHX64_1)
SHX62_1 = SHX23_1
SHX63_1 = "CreatePedInsideVehicle"
function SHX64_1(SHX0_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX1_2 = SHX27_1
  SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = ...
  SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  SHX7_2 = SHX21_1
  SHX7_2 = SHX7_2()
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.tempAllowEntity
  SHX9_2 = SHX26_1
  SHX10_2 = SHX3_2
  SHX9_2 = SHX9_2(SHX10_2)
  SHX10_2 = SHX34_1
  SHX11_2 = 3
  SHX10_2, SHX11_2 = SHX10_2(SHX11_2)
  SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  SHX7_2 = SHX0_2
  SHX8_2, SHX9_2, SHX10_2, SHX11_2 = ...
  return SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2)
end
SHX62_1(SHX63_1, SHX64_1)
SHX62_1 = SHX23_1
SHX63_1 = "CreateObject"
function SHX64_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX21_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.tempAllowEntity
  SHX4_2 = SHX26_1
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = SHX34_1
  SHX6_2 = 3
  SHX5_2, SHX6_2 = SHX5_2(SHX6_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  SHX2_2 = SHX0_2
  SHX3_2 = SHX1_2
  SHX4_2, SHX5_2, SHX6_2 = ...
  return SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
end
SHX62_1(SHX63_1, SHX64_1)
SHX62_1 = SHX23_1
SHX63_1 = "CreateObjectNoOffset"
function SHX64_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX21_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.tempAllowEntity
  SHX4_2 = SHX26_1
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = SHX34_1
  SHX6_2 = 3
  SHX5_2, SHX6_2 = SHX5_2(SHX6_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  SHX2_2 = SHX0_2
  SHX3_2 = SHX1_2
  SHX4_2, SHX5_2, SHX6_2 = ...
  return SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
end
SHX62_1(SHX63_1, SHX64_1)
SHX62_1 = SHX23_1
SHX63_1 = "SetEntityCoords"
function SHX64_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX2_2 = SHX33_1
  SHX3_2 = SHX1_2
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX4_2 = SHX0_2
    SHX5_2 = SHX1_2
    SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = ...
    return SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  end
  SHX4_2 = SHX21_1
  SHX4_2 = SHX4_2()
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.InvokeSPlayer
  SHX6_2 = SHX14_1
  SHX7_2 = SHX3_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX7_2 = "rpc_await"
  SHX8_2 = "Reaper:SetState"
  SHX9_2 = {}
  SHX10_2 = "LastFailedMovementChecks"
  SHX11_2 = "%GameTimer%"
  SHX9_2[1] = SHX10_2
  SHX9_2[2] = SHX11_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  if true == SHX4_2 then
    SHX5_2 = SHX0_2
    SHX6_2 = SHX1_2
    SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = ...
    return SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  end
  SHX5_2 = 0
  return SHX5_2
end
SHX62_1(SHX63_1, SHX64_1)
SHX62_1 = SHX23_1
SHX63_1 = "TaskWarpPedIntoVehicle"
function SHX64_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX2_2 = SHX33_1
  SHX3_2 = SHX1_2
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX4_2 = SHX0_2
    SHX5_2 = SHX1_2
    SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = ...
    return SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  end
  SHX4_2 = SHX21_1
  SHX4_2 = SHX4_2()
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.InvokeSPlayer
  SHX6_2 = SHX14_1
  SHX7_2 = SHX3_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX7_2 = "rpc_await"
  SHX8_2 = "Reaper:SetState"
  SHX9_2 = {}
  SHX10_2 = "LastFailedMovementChecks"
  SHX11_2 = "%GameTimer%"
  SHX9_2[1] = SHX10_2
  SHX9_2[2] = SHX11_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  if true == SHX4_2 then
    SHX5_2 = SHX0_2
    SHX6_2 = SHX1_2
    SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = ...
    return SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  end
  SHX5_2 = 0
  return SHX5_2
end
SHX62_1(SHX63_1, SHX64_1)
SHX62_1 = SHX23_1
SHX63_1 = "TaskEnterVehicle"
function SHX64_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX2_2 = SHX33_1
  SHX3_2 = SHX1_2
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX4_2 = SHX0_2
    SHX5_2 = SHX1_2
    SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = ...
    return SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  end
  SHX4_2 = SHX21_1
  SHX4_2 = SHX4_2()
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.InvokeSPlayer
  SHX6_2 = SHX14_1
  SHX7_2 = SHX3_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX7_2 = "rpc_await"
  SHX8_2 = "Reaper:SetState"
  SHX9_2 = {}
  SHX10_2 = "LastFailedMovementChecks"
  SHX11_2 = "%GameTimer%"
  SHX9_2[1] = SHX10_2
  SHX9_2[2] = SHX11_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  if true == SHX4_2 then
    SHX5_2 = SHX0_2
    SHX6_2 = SHX1_2
    SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = ...
    return SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  end
  SHX5_2 = 0
  return SHX5_2
end
SHX62_1(SHX63_1, SHX64_1)
SHX62_1 = SHX23_1
SHX63_1 = "SetPedIntoVehicle"
function SHX64_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX2_2 = SHX33_1
  SHX3_2 = SHX1_2
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX4_2 = SHX0_2
    SHX5_2 = SHX1_2
    SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = ...
    return SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  end
  SHX4_2 = SHX21_1
  SHX4_2 = SHX4_2()
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.InvokeSPlayer
  SHX6_2 = SHX14_1
  SHX7_2 = SHX3_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX7_2 = "rpc_await"
  SHX8_2 = "Reaper:SetState"
  SHX9_2 = {}
  SHX10_2 = "LastFailedMovementChecks"
  SHX11_2 = "%GameTimer%"
  SHX9_2[1] = SHX10_2
  SHX9_2[2] = SHX11_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  if true == SHX4_2 then
    SHX5_2 = SHX0_2
    SHX6_2 = SHX1_2
    SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = ...
    return SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  end
  SHX5_2 = 0
  return SHX5_2
end
SHX62_1(SHX63_1, SHX64_1)
SHX62_1 = SHX23_1
SHX63_1 = "SetVehicleBodyHealth"
function SHX64_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX3_2 = SHX10_1
  SHX4_2 = SHX1_2
  SHX5_2 = -1
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX33_1
  SHX5_2 = SHX3_2
  SHX4_2, SHX5_2 = SHX4_2(SHX5_2)
  if not SHX4_2 then
    SHX6_2 = SHX0_2
    SHX7_2 = SHX1_2
    SHX8_2 = SHX2_2
    return SHX6_2(SHX7_2, SHX8_2)
  end
  SHX6_2 = SHX21_1
  SHX6_2 = SHX6_2()
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.InvokeSPlayer
  SHX8_2 = SHX14_1
  SHX9_2 = SHX5_2
  SHX8_2 = SHX8_2(SHX9_2)
  SHX9_2 = "rpc_await"
  SHX10_2 = "Reaper:SetState"
  SHX11_2 = {}
  SHX12_2 = "LastVehicleFIx"
  SHX13_2 = "%GameTimer%"
  SHX11_2[1] = SHX12_2
  SHX11_2[2] = SHX13_2
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  if true == SHX6_2 then
    SHX7_2 = SHX0_2
    SHX8_2 = SHX1_2
    SHX9_2 = SHX2_2
    return SHX7_2(SHX8_2, SHX9_2)
  end
  SHX7_2 = 0
  return SHX7_2
end
SHX65_1 = "gta5"
SHX62_1(SHX63_1, SHX64_1, SHX65_1)
SHX62_1 = GetVehicleNumberPlateText
GetVehicleNumberPlateText1 = SHX62_1
SHX62_1 = SHX23_1
SHX63_1 = "GetVehicleNumberPlateText"
function SHX64_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2
  SHX2_2 = DoesEntityExist
  SHX3_2 = SHX1_2
  SHX2_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX2_2 = nil
    return SHX2_2
  end
  SHX2_2 = Entity
  SHX3_2 = SHX1_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX2_2 = SHX2_2.state
  SHX2_2 = SHX2_2.VehiclePlate
  if not SHX2_2 then
    SHX2_2 = SHX0_2
    SHX3_2 = SHX1_2
    SHX2_2 = SHX2_2(SHX3_2)
  end
  return SHX2_2
end
SHX65_1 = "gta5"
SHX62_1(SHX63_1, SHX64_1, SHX65_1)
SHX62_1 = SHX23_1
SHX63_1 = "SetVehicleNumberPlateText"
function SHX64_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX3_2 = DoesEntityExist
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  if not SHX3_2 then
    SHX3_2 = nil
    return SHX3_2
  end
  SHX3_2 = SHX10_1
  SHX4_2 = SHX1_2
  SHX5_2 = -1
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX33_1
  SHX5_2 = SHX3_2
  SHX4_2, SHX5_2 = SHX4_2(SHX5_2)
  SHX6_2 = Entity
  SHX7_2 = SHX1_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX6_2 = SHX6_2.state
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.set
  SHX8_2 = "VehiclePlate"
  SHX9_2 = SHX2_2
  SHX10_2 = true
  SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  if not SHX4_2 then
    SHX6_2 = SHX0_2
    SHX7_2 = SHX1_2
    SHX8_2 = SHX2_2
    return SHX6_2(SHX7_2, SHX8_2)
  end
  SHX6_2 = SHX21_1
  SHX6_2 = SHX6_2()
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.InvokeSPlayer
  SHX8_2 = SHX14_1
  SHX9_2 = SHX5_2
  SHX8_2 = SHX8_2(SHX9_2)
  SHX9_2 = "rpc_await"
  SHX10_2 = "Reaper:SetState"
  SHX11_2 = {}
  SHX12_2 = "vehicle_plate"
  SHX13_2 = {}
  SHX13_2.vehicle = SHX1_2
  SHX13_2.plate = SHX2_2
  SHX11_2[1] = SHX12_2
  SHX11_2[2] = SHX13_2
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  if true == SHX6_2 then
    SHX7_2 = SHX0_2
    SHX8_2 = SHX1_2
    SHX9_2 = SHX2_2
    return SHX7_2(SHX8_2, SHX9_2)
  end
  SHX7_2 = 0
  return SHX7_2
end
SHX65_1 = "gta5"
SHX62_1(SHX63_1, SHX64_1, SHX65_1)
SHX62_1 = {}
SHX63_1 = {}
SHX63_1.AdvancedHook = SHX30_1
function SHX64_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = SHX7_1
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2)
  if "string" == SHX2_2 then
    SHX2_2 = SHX7_1
    SHX3_2 = SHX1_2
    SHX2_2 = SHX2_2(SHX3_2)
    if "function" == SHX2_2 then
      goto SHX_LABEL_13
    end
  end
  SHX2_2 = 0
  return SHX2_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_13:: outside nested blocks until all 'goto SHX_LABEL_13' can see it
  ::SHX_LABEL_13::
  SHX2_2 = debug
  SHX2_2 = SHX2_2.getinfo
  SHX3_2 = 2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SHX53_1
  SHX3_2 = SHX3_2[SHX0_2]
  if nil == SHX3_2 then
    SHX3_2 = SHX53_1
    SHX4_2 = {}
    SHX3_2[SHX0_2] = SHX4_2
  end
  SHX3_2 = SHX6_1
  SHX4_2 = SHX53_1
  SHX4_2 = SHX4_2[SHX0_2]
  SHX5_2 = {}
  SHX5_2.callback = SHX1_2
  SHX6_2 = SHX2_2.short_src
  SHX7_2 = ":"
  SHX8_2 = SHX2_2.currentline
  SHX6_2 = SHX6_2 .. SHX7_2 .. SHX8_2
  SHX5_2.name = SHX6_2
  SHX3_2(SHX4_2, SHX5_2)
  SHX3_2 = 1
  return SHX3_2
end
SHX63_1.RegisterEventHook = SHX64_1
function SHX64_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX57_1
  if not SHX0_2 then
    SHX0_2 = nil
    return SHX0_2
  end
  SHX0_2 = SHX57_1.from
  return SHX0_2
end
SHX63_1.GetEventSource = SHX64_1
function SHX64_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX57_1
  if not SHX0_2 then
    SHX0_2 = nil
    return SHX0_2
  end
  SHX0_2 = SHX57_1.path
  return SHX0_2
end
SHX63_1.GetEventPath = SHX64_1
function SHX64_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX57_1.key
  return SHX0_2
end
SHX63_1.GetEventKey = SHX64_1
function SHX64_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX55_1
  SHX1_2[SHX0_2] = true
  SHX1_2 = 1
  return SHX1_2
end
SHX63_1.RegisterEventAsServerOnly = SHX64_1
function SHX64_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2
  SHX4_2 = "%s_%s"
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.format
  SHX6_2 = SHX24_1
  SHX7_2 = SHX22_1
  SHX8_2 = "97ae7727-b78e47fc-075ea9de-c852f7da-44587eed"
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = SHX24_1
  SHX8_2 = SHX0_2
  SHX9_2 = "97ae7727-b78e47fc-075ea9de-c852f7da-44587eed"
  SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
  SHX5_2 = SHX36_1
  SHX5_2 = SHX5_2[SHX4_2]
  if nil == SHX5_2 then
    SHX5_2 = SHX36_1
    SHX6_2 = SHX42_1
    SHX6_2 = SHX6_2[SHX0_2]
    if SHX6_2 then
      SHX6_2 = SHX42_1
      SHX6_2 = SHX6_2[SHX0_2]
      SHX6_2 = SHX6_2.known_keys
      if SHX6_2 then
        goto SHX_LABEL_28
      end
    end
    SHX6_2 = {}
    -- [FIX IF ERROR] Move ::SHX_LABEL_28:: outside nested blocks until all 'goto SHX_LABEL_28' can see it
    ::SHX_LABEL_28::
    SHX5_2[SHX4_2] = SHX6_2
    SHX5_2 = SHX36_1
    SHX5_2 = SHX5_2[SHX4_2]
    SHX6_2 = SHX1_1
    SHX7_2 = SHX1_2
    SHX6_2 = SHX6_2(SHX7_2)
    SHX7_2 = {}
    SHX7_2.type = "auto"
    SHX7_2.event_name = SHX0_2
    SHX8_2 = SHX22_1
    SHX7_2.resource = SHX8_2
    SHX7_2.invoking_resource = SHX3_2
    SHX7_2.path = SHX2_2
    SHX5_2[SHX6_2] = SHX7_2
    SHX5_2 = SHX31_1
    SHX6_2 = "The event (^3%s^7) sent from (^3%s^7) was just locked to the execution key ^3%s^7"
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.format
    SHX8_2 = SHX0_2
    SHX9_2 = "%s:%s"
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.format
    SHX11_2 = SHX3_2
    SHX12_2 = SHX2_2
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2)
    SHX10_2 = SHX1_2
    SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
    SHX7_2 = "info"
    SHX8_2 = "event_key_locks"
    SHX9_2 = {}
    SHX9_2.eventName = SHX0_2
    SHX9_2.execution_key = SHX1_2
    SHX10_2 = SHX22_1
    SHX9_2.resource = SHX10_2
    SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2)
    SHX5_2 = SHX11_1
    SHX6_2 = SHX36_1
    SHX5_2 = SHX5_2(SHX6_2)
    SHX6_2 = SaveResourceFile
    SHX7_2 = "ReaperV4"
    SHX8_2 = "cache/event_lock.json"
    SHX9_2 = SHX5_2
    SHX10_2 = #SHX5_2
    SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  end
  SHX5_2 = SHX36_1
  SHX5_2 = SHX5_2[SHX4_2]
  SHX6_2 = SHX1_1
  SHX7_2 = SHX1_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX5_2 = SHX5_2[SHX6_2]
  if nil == SHX5_2 then
    SHX5_2 = SHX31_1
    SHX6_2 = "^3%s^7 (^3id:%s^7) just triggered the event (^3%s^7) with an invalid key (^3%s^7) from (^3%s^7) and was blocked. ^1An invalid key can be caused by a modification made to the script, an event being triggered from multiple places in a script, or from a cheat. If you know this key is legit, you can allow the key by running the following command. ^3reaper addeventkey %s %s %s^7"
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.format
    SHX8_2 = GetPlayerName
    SHX9_2 = source
    SHX8_2 = SHX8_2(SHX9_2)
    SHX9_2 = source
    SHX10_2 = SHX0_2
    SHX11_2 = SHX1_2
    SHX12_2 = "%s:%s"
    SHX13_2 = SHX12_2
    SHX12_2 = SHX12_2.format
    SHX14_2 = SHX3_2
    SHX15_2 = SHX2_2
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2)
    SHX13_2 = SHX22_1
    SHX14_2 = SHX0_2
    SHX15_2 = SHX1_2
    SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
    SHX7_2 = "info"
    SHX8_2 = "event_key_locks"
    SHX9_2 = {}
    SHX9_2.eventName = SHX0_2
    SHX9_2.execution_key = SHX1_2
    SHX10_2 = SHX22_1
    SHX9_2.resource = SHX10_2
    SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2)
    SHX5_2 = SHX0_1
    SHX6_2 = "reaper_ban_for_invalid_key_lock"
    SHX7_2 = "true"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    if "true" == SHX5_2 then
      SHX5_2 = SHX21_1
      SHX5_2 = SHX5_2()
      SHX6_2 = SHX5_2
      SHX5_2 = SHX5_2.InvokeSPlayer
      SHX7_2 = source
      SHX8_2 = "newDetection"
      SHX9_2 = "invalidKeyLock"
      SHX10_2 = {}
      SHX10_2.event = SHX0_2
      SHX10_2.execution_key = SHX1_2
      SHX11_2 = SHX22_1
      SHX10_2.resource = SHX11_2
      SHX10_2.invoking_resource = SHX3_2
      SHX10_2.path = SHX2_2
      SHX11_2 = {}
      SHX12_2 = SHX0_2
      SHX13_2 = SHX1_2
      SHX11_2[1] = SHX12_2
      SHX11_2[2] = SHX13_2
      SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
    end
    SHX5_2 = true
    return SHX5_2
  end
  SHX5_2 = false
  return SHX5_2
end
SHX63_1.VerifyEventKeyLock = SHX64_1
SHX62_1.API = SHX63_1
ReaperAC = SHX62_1
SHX62_1 = SHX29_1
SHX62_1()
