-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1, SHX21_1, SHX22_1, SHX23_1, SHX24_1, SHX25_1, SHX26_1, SHX27_1, SHX28_1, SHX29_1, SHX30_1, SHX31_1, SHX32_1, SHX33_1, SHX34_1, SHX35_1, SHX36_1, SHX37_1, SHX38_1, SHX39_1, SHX40_1, SHX41_1, SHX42_1, SHX43_1, SHX44_1, SHX45_1, SHX46_1, SHX47_1, SHX48_1, SHX49_1, SHX50_1, SHX51_1, SHX52_1, SHX53_1, SHX54_1, SHX55_1, SHX56_1, SHX57_1, SHX58_1, SHX59_1, SHX60_1, SHX61_1, SHX62_1, SHX63_1, SHX64_1, SHX65_1, SHX66_1, SHX67_1, SHX68_1, SHX69_1, SHX70_1, SHX71_1, SHX72_1, SHX73_1
function SHX0_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX1_2 = {}
  SHX2_2 = pairs
  SHX3_2 = SHX0_2
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX1_2[SHX6_2] = SHX7_2
  end
  SHX2_2 = setmetatable
  SHX3_2 = SHX1_2
  SHX4_2 = getmetatable
  SHX5_2 = SHX0_2
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX4_2(SHX5_2)
  return SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
end
SHX1_1 = LoadResourceFile
SHX2_1 = load
SHX3_1 = print
SHX4_1 = type
SHX5_1 = GetHashKey
SHX6_1 = SHX5_1
SHX7_1 = getmetatable
SHX8_1 = setmetatable
SHX9_1 = pairs
SHX10_1 = GetResourceState
SHX11_1 = CreateThread
SHX12_1 = string
SHX12_1 = SHX12_1.match
SHX13_1 = string
SHX13_1 = SHX13_1.sub
SHX14_1 = string
SHX14_1 = SHX14_1.gsub
SHX15_1 = string
SHX15_1 = SHX15_1.byte
SHX16_1 = table
SHX16_1 = SHX16_1.insert
SHX17_1 = table
SHX17_1 = SHX17_1.unpack
SHX18_1 = SHX4_1
SHX19_1 = IsDuplicityVersion
SHX20_1 = GetCurrentResourceName
SHX21_1 = GetConvarInt
SHX22_1 = GetConvar
SHX23_1 = msgpack
SHX23_1 = SHX23_1.pack_args
SHX24_1 = msgpack
SHX24_1 = SHX24_1.unpack
SHX25_1 = AddConvarChangeListener
if not SHX25_1 then
  function SHX25_1(...)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_2, SHX1_2
  end
end
SHX26_1 = json
SHX26_1 = SHX26_1.decode
SHX27_1 = nil
SHX28_1 = rawset
SHX29_1 = rawget
SHX30_1 = SHX19_1
SHX30_1 = SHX30_1()
if SHX30_1 then
  SHX30_1 = SHX0_1
  SHX31_1 = GlobalState
  SHX30_1 = SHX30_1(SHX31_1)
  SHX27_1 = SHX30_1
else
  SHX30_1 = SHX0_1
  SHX31_1 = LocalPlayer
  SHX31_1 = SHX31_1.state
  SHX30_1 = SHX30_1(SHX31_1)
  SHX27_1 = SHX30_1
end
SHX30_1 = SHX19_1
SHX30_1 = SHX30_1()
SHX31_1 = SHX20_1
SHX31_1 = SHX31_1()
SHX32_1 = SHX22_1
SHX33_1 = "reaper_gameType"
SHX34_1 = SHX22_1
SHX35_1 = "gamename"
SHX36_1 = "gta5"
SHX34_1, SHX35_1, SHX36_1, SHX37_1, SHX38_1, SHX39_1, SHX40_1, SHX41_1, SHX42_1, SHX43_1, SHX44_1, SHX45_1, SHX46_1, SHX47_1, SHX48_1, SHX49_1, SHX50_1, SHX51_1, SHX52_1, SHX53_1, SHX54_1, SHX55_1, SHX56_1, SHX57_1, SHX58_1, SHX59_1, SHX60_1, SHX61_1, SHX62_1, SHX63_1, SHX64_1, SHX65_1, SHX66_1, SHX67_1, SHX68_1, SHX69_1, SHX70_1, SHX71_1, SHX72_1, SHX73_1 = SHX34_1(SHX35_1, SHX36_1)
SHX32_1 = SHX32_1(SHX33_1, SHX34_1, SHX35_1, SHX36_1, SHX37_1, SHX38_1, SHX39_1, SHX40_1, SHX41_1, SHX42_1, SHX43_1, SHX44_1, SHX45_1, SHX46_1, SHX47_1, SHX48_1, SHX49_1, SHX50_1, SHX51_1, SHX52_1, SHX53_1, SHX54_1, SHX55_1, SHX56_1, SHX57_1, SHX58_1, SHX59_1, SHX60_1, SHX61_1, SHX62_1, SHX63_1, SHX64_1, SHX65_1, SHX66_1, SHX67_1, SHX68_1, SHX69_1, SHX70_1, SHX71_1, SHX72_1, SHX73_1)
function SHX33_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX0_2 = "patches/resource_%s.lua"
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.format
  SHX2_2 = SHX31_1
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX1_2 = SHX1_1
  SHX2_2 = "ReaperV4"
  SHX3_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  if SHX1_2 then
    SHX2_2 = SHX2_1
    SHX3_2 = SHX1_2
    SHX4_2 = SHX0_2
    SHX2_2, SHX3_2 = SHX2_2(SHX3_2, SHX4_2)
    if not SHX2_2 then
      SHX4_2 = SHX3_1
      SHX5_2 = SHX3_2
      return SHX4_2(SHX5_2)
    end
    SHX4_2 = SHX2_2
    SHX4_2()
  end
end
function SHX34_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX2_2 = SHX0_2
  SHX3_2 = SHX1_2 or SHX3_2
  if not SHX1_2 then
    SHX3_2 = "f0ad51e9-048479cf-9fba5eee-83b7f0b2-1c28924a"
  end
  SHX2_2 = SHX2_2 .. SHX3_2
  SHX0_2 = SHX2_2
  SHX2_2 = 5381
  SHX3_2 = 1
  SHX4_2 = #SHX0_2
  SHX5_2 = 1
  for SHX6_2 = SHX3_2, SHX4_2, SHX5_2 do
    SHX7_2 = SHX15_1
    SHX8_2 = SHX0_2
    SHX9_2 = SHX6_2
    SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
    SHX8_2 = SHX2_2 * 33
    SHX2_2 = SHX8_2 ~ SHX7_2
  end
  return SHX2_2
end
function SHX35_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  if 1 == SHX0_2 or true == SHX0_2 then
    SHX1_2 = true
    return SHX1_2
  else
    SHX1_2 = false
    return SHX1_2
  end
end
function SHX36_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = SHX4_1
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if "string" == SHX1_2 then
    SHX1_2 = SHX6_1
    SHX2_2 = SHX0_2
    return SHX1_2(SHX2_2)
  end
  return SHX0_2
end
SHX37_1 = false
SHX38_1 = SHX0_1
SHX39_1 = exports
SHX39_1 = SHX39_1.ReaperV4
SHX38_1 = SHX38_1(SHX39_1)
function SHX39_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  while true do
    SHX0_2 = SHX10_1
    SHX1_2 = "ReaperV4"
    SHX0_2 = SHX0_2(SHX1_2)
    if "started" == SHX0_2 then
      break
    end
    SHX0_2 = Wait
    SHX1_2 = 200
    SHX0_2(SHX1_2)
  end
  SHX0_2 = SHX30_1
  if SHX0_2 then
    while true do
      SHX0_2 = SHX37_1
      if false ~= SHX0_2 then
        break
      end
      SHX0_2 = GlobalState
      SHX0_2 = SHX0_2.ExportsLoaded
      if true == SHX0_2 then
        break
      end
      SHX0_2 = Wait
      SHX1_2 = 200
      SHX0_2(SHX1_2)
    end
    SHX0_2 = true
    SHX37_1 = SHX0_2
  else
    while true do
      SHX0_2 = SHX27_1.ExportsLoaded
      if true == SHX0_2 then
        break
      end
      SHX0_2 = Wait
      SHX1_2 = 200
      SHX0_2(SHX1_2)
    end
  end
  SHX0_2 = SHX38_1
  return SHX0_2
end
SHX40_1 = nil
function SHX41_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX30_1
  if SHX0_2 then
    SHX0_2 = ""
    return SHX0_2
  end
  SHX0_2 = SHX40_1
  if nil == SHX0_2 then
    SHX0_2 = SHX39_1
    SHX0_2 = SHX0_2()
    SHX1_2 = SHX0_2
    SHX0_2 = SHX0_2.GetReaperKeys
    SHX0_2 = SHX0_2(SHX1_2)
    SHX40_1 = SHX0_2
  end
  SHX0_2 = SHX40_1
  return SHX0_2
end
function SHX42_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX30_1
  if SHX0_2 then
    SHX0_2 = ""
    return SHX0_2
  end
  SHX0_2 = SHX41_1
  SHX0_2 = SHX0_2()
  SHX0_2 = SHX0_2.security_key
  return SHX0_2
end
function SHX43_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2
  SHX2_2 = SHX11_1
  function SHX3_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
    SHX0_3 = "[^3resource:"
    SHX1_3 = SHX31_1
    SHX2_3 = "^7] "
    SHX3_3 = SHX0_2
    SHX0_3 = SHX0_3 .. SHX1_3 .. SHX2_3 .. SHX3_3
    SHX0_2 = SHX0_3
    SHX0_3 = SHX30_1
    if SHX0_3 then
      SHX0_3 = SHX39_1
      SHX0_3 = SHX0_3()
      SHX1_3 = SHX0_3
      SHX0_3 = SHX0_3.InvokeSLogger
      SHX2_3 = "log"
      SHX3_3 = SHX0_2
      SHX4_3 = SHX1_2
      SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3)
    else
      SHX0_3 = SHX21_1
      SHX1_3 = "reaper_log_level"
      SHX2_3 = 0
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
      if 1 ~= SHX0_3 then
        SHX0_3 = SHX1_2
        if "debug" == SHX0_3 then
          goto SHX_LABEL_34
        end
      end
      SHX0_3 = SHX39_1
      SHX0_3 = SHX0_3()
      SHX1_3 = SHX0_3
      SHX0_3 = SHX0_3.InvokeCLogger
      SHX2_3 = "log"
      SHX3_3 = SHX0_2
      SHX4_3 = SHX1_2
      SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3)
    end
    -- [FIX IF ERROR] Move ::SHX_LABEL_34:: outside nested blocks until all 'goto SHX_LABEL_34' can see it
    ::SHX_LABEL_34::
  end
  SHX2_2(SHX3_2)
end
SHX44_1 = SHX22_1
SHX45_1 = "reaper_log_hooked_function_calls"
SHX46_1 = "false"
SHX44_1 = SHX44_1(SHX45_1, SHX46_1)
SHX44_1 = "true" == SHX44_1
SHX45_1 = {}
function SHX46_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = tostring
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = SHX45_1
  SHX1_2 = SHX2_2[SHX1_2]
  SHX1_2 = nil ~= SHX1_2
  return SHX1_2
end
function SHX47_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2
  SHX3_2 = _G
  SHX3_2 = SHX3_2[SHX0_2]
  SHX4_2 = tostring
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = SHX45_1
  SHX5_2[SHX4_2] = true
  if SHX2_2 then
    SHX4_2 = SHX32_1
  end
  if SHX2_2 ~= SHX4_2 or nil == SHX3_2 then
    return
  end
  SHX4_2 = _G
  function SHX5_2(...)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
    SHX0_3 = SHX44_1
    if SHX0_3 then
      SHX0_3 = SHX3_1
      SHX1_3 = "HookFunction"
      SHX2_3 = SHX31_1
      SHX3_3 = SHX0_2
      SHX4_3 = ...
      SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3)
    end
    SHX0_3 = SHX1_2
    SHX1_3 = SHX3_2
    SHX2_3, SHX3_3, SHX4_3 = ...
    return SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3)
  end
  SHX4_2[SHX0_2] = SHX5_2
end
function SHX48_1(...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2
  SHX0_2 = {}
  SHX1_2 = {}
  SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2 = ...
  SHX1_2[1] = SHX2_2
  SHX1_2[2] = SHX3_2
  SHX1_2[3] = SHX4_2
  SHX1_2[4] = SHX5_2
  SHX1_2[5] = SHX6_2
  SHX1_2[6] = SHX7_2
  SHX1_2[7] = SHX8_2
  SHX1_2[8] = SHX9_2
  SHX1_2[9] = SHX10_2
  SHX1_2[10] = SHX11_2
  SHX1_2[11] = SHX12_2
  SHX1_2[12] = SHX13_2
  SHX1_2[13] = SHX14_2
  SHX1_2[14] = SHX15_2
  SHX2_2 = 1
  SHX3_2 = 1
  SHX4_2 = #SHX1_2
  SHX5_2 = 1
  for SHX6_2 = SHX3_2, SHX4_2, SHX5_2 do
    SHX7_2 = SHX1_2[SHX6_2]
    SHX8_2 = SHX18_1
    SHX9_2 = SHX7_2
    SHX8_2 = SHX8_2(SHX9_2)
    if "vector3" == SHX8_2 or "vector4" == SHX8_2 then
      SHX9_2 = SHX9_1
      SHX10_2 = SHX7_2
      SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX9_2(SHX10_2)
      for SHX13_2, SHX14_2 in SHX9_2, SHX10_2, SHX11_2, SHX12_2 do
        SHX0_2[SHX2_2] = SHX14_2
        SHX2_2 = SHX2_2 + 1
      end
    else
      SHX0_2[SHX2_2] = SHX7_2
      SHX2_2 = SHX2_2 + 1
    end
  end
  SHX3_2 = SHX17_1
  SHX4_2 = SHX0_2
  return SHX3_2(SHX4_2)
end
function SHX49_1(SHX0_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = SHX23_1
  SHX2_2, SHX3_2 = ...
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX2_2 = SHX11_1
  function SHX3_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    SHX0_3 = SHX0_2
    SHX1_3 = SHX17_1
    SHX2_3 = SHX24_1
    SHX3_3 = SHX1_2
    SHX2_3, SHX3_3 = SHX2_3(SHX3_3)
    SHX1_3, SHX2_3, SHX3_3 = SHX1_3(SHX2_3, SHX3_3)
    return SHX0_3(SHX1_3, SHX2_3, SHX3_3)
  end
  return SHX2_2(SHX3_2)
end
SHX50_1 = {}
SHX50_1.clearPedTasksEvent = true
SHX50_1.giveWeaponEvent = true
SHX50_1.removeWeaponEvent = true
SHX50_1.entityRemoved = true
SHX50_1.entityCreated = true
SHX50_1.entityCreating = true
SHX50_1.onResourceListRefresh = true
SHX50_1.onServerResourceStart = true
SHX50_1.onServerResourceStop = true
SHX50_1.ptFxEvent = true
SHX50_1.explosionEvent = true
SHX50_1.playerDropped = true
SHX50_1.weaponDamageEvent = true
SHX50_1.getMapDirectives = true
SHX50_1.onClientMapStart = true
SHX50_1.entityDamaged = true
SHX50_1.gameEventTriggered = true
SHX50_1.mumbleConnected = true
SHX50_1.mumbleDisconnected = true
SHX50_1.onClientResourceStart = true
SHX50_1.onClientResourceStop = true
SHX50_1.onResourceStart = true
SHX50_1.onResourceStarting = true
SHX50_1.onResourceStop = true
SHX50_1.populationPedCreating = true
SHX50_1.playerSpawned = true
SHX50_1.onPlayerJoining = true
SHX50_1.onPlayerDropped = true
SHX50_1.mapDataLoaded = true
SHX50_1.startprojectileevent = true
SHX50_1.rconCommand = true
SHX50_1.hostingSession = true
SHX50_1.hostedSession = true
SHX50_1.playerConnecting = true
SHX50_1.playerEnteredScope = true
SHX50_1.playerJoining = true
SHX50_1.playerLeftScope = true
SHX50_1.REAPER_SYNC_EVENT = true
SHX50_1.entityOwnershipTransfer = true
SHX51_1 = {}
SHX52_1 = {}
SHX53_1 = false
SHX54_1 = SHX0_1
SHX55_1 = SHX50_1
SHX54_1 = SHX54_1(SHX55_1)
function SHX55_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX0_2 = SHX0_1
  SHX1_2 = SHX54_1
  SHX0_2 = SHX0_2(SHX1_2)
  SHX1_2 = {}
  SHX2_2 = SHX9_1
  SHX3_2 = SHX26_1
  SHX4_2 = SHX22_1
  SHX5_2 = "Reaper_IgnoredEvents"
  SHX6_2 = "{}"
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX8_2 = SHX13_1
    SHX9_2 = SHX6_2
    SHX10_2 = 1
    SHX11_2 = 3
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2)
    if "pm=" == SHX8_2 then
      SHX8_2 = SHX14_1
      SHX9_2 = SHX6_2
      SHX10_2 = "pm="
      SHX11_2 = ""
      SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2)
      SHX9_2 = SHX16_1
      SHX10_2 = SHX1_2
      SHX11_2 = SHX8_2
      SHX9_2(SHX10_2, SHX11_2)
    else
      SHX0_2[SHX6_2] = SHX7_2
    end
  end
  SHX50_1 = SHX0_2
  SHX51_1 = SHX1_2
  SHX2_2 = true
  SHX53_1 = SHX2_2
end
SHX56_1 = SHX25_1
SHX57_1 = "Reaper_IgnoredEvents"
function SHX58_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX55_1
  SHX0_2()
end
SHX56_1(SHX57_1, SHX58_1)
function SHX56_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX1_2 = SHX52_1
  SHX1_2 = SHX1_2[SHX0_2]
  if nil == SHX1_2 then
    SHX1_2 = false
    SHX2_2 = SHX9_1
    SHX3_2 = SHX51_1
    SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
    for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
      SHX8_2 = SHX12_1
      SHX9_2 = SHX0_2
      SHX10_2 = SHX7_2
      SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
      if SHX8_2 then
        SHX1_2 = true
        break
      end
    end
    SHX2_2 = SHX52_1
    SHX2_2[SHX0_2] = SHX1_2
  end
  SHX1_2 = SHX52_1
  SHX1_2 = SHX1_2[SHX0_2]
  return SHX1_2
end
function SHX57_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX54_1
  SHX1_2 = SHX1_2[SHX0_2]
  return SHX1_2
end
function SHX58_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  SHX2_2 = SHX53_1
  if false == SHX2_2 then
    SHX2_2 = SHX55_1
    SHX2_2()
  end
  if SHX1_2 then
    SHX2_2 = SHX50_1
    SHX2_2 = SHX2_2[SHX0_2]
    if not SHX2_2 then
      SHX2_2 = SHX56_1
      SHX3_2 = SHX0_2
      SHX2_2 = SHX2_2(SHX3_2)
    end
    return SHX2_2
  else
    SHX3_2 = SHX0_2
    SHX2_2 = SHX0_2.match
    SHX4_2 = "__cfx"
    SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
    if not SHX2_2 then
      SHX2_2 = string
      SHX2_2 = SHX2_2.match
      SHX3_2 = SHX0_2
      SHX4_2 = "CEvent"
      SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
      if not SHX2_2 then
        SHX2_2 = SHX50_1
        SHX2_2 = SHX2_2[SHX0_2]
        if not SHX2_2 then
          SHX2_2 = SHX56_1
          SHX3_2 = SHX0_2
          SHX2_2 = SHX2_2(SHX3_2)
        end
      end
    end
    return SHX2_2
  end
end
function SHX59_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX0_2 = SHX1_1
  SHX1_2 = "ReaperV4"
  SHX2_2 = "imports/imports.lua"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  if SHX0_2 then
    SHX1_2 = SHX2_1
    SHX2_2 = SHX0_2
    SHX3_2 = "imports/imports.lua"
    SHX1_2, SHX2_2 = SHX1_2(SHX2_2, SHX3_2)
    if SHX2_2 or not SHX1_2 then
      SHX3_2 = SHX43_1
      SHX4_2 = [[
Failed to load imports/imports.lua. Reason: 
%s]]
      SHX5_2 = SHX4_2
      SHX4_2 = SHX4_2.format
      SHX6_2 = SHX2_2
      SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
      SHX5_2 = "error"
      return SHX3_2(SHX4_2, SHX5_2)
    end
    SHX3_2 = SHX1_2
    SHX3_2()
  end
end
SHX60_1 = SHX8_1
SHX61_1 = {}
SHX62_1 = {}
SHX62_1.__mode = "k"
SHX60_1 = SHX60_1(SHX61_1, SHX62_1)
SHX61_1 = {}
SHX62_1 = {}
SHX63_1 = {}
function SHX64_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2
  SHX0_2 = {}
  SHX1_2 = {}
  SHX2_2 = {}
  function SHX3_2(SHX0_3, SHX1_3, SHX2_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX3_3
    SHX3_3 = SHX1_2
    if SHX0_3 ~= SHX3_3 then
      SHX3_3 = false
      return SHX3_3
    end
    SHX3_3 = SHX0_2
    SHX3_3[SHX1_3] = SHX2_3
    SHX3_3 = true
    return SHX3_3
  end
  SHX2_2.set = SHX3_2
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3
    SHX2_3 = SHX1_2
    if SHX0_3 ~= SHX2_3 then
      SHX2_3 = nil
      return SHX2_3
    end
    SHX2_3 = SHX0_2
    SHX2_3 = SHX2_3[SHX1_3]
    return SHX2_3
  end
  SHX2_2.get = SHX3_2
  SHX2_2.key = SHX1_2
  return SHX2_2
end
SHX65_1 = SHX64_1
SHX65_1 = SHX65_1()
SHX66_1 = SHX64_1
SHX66_1 = SHX66_1()
SHX67_1 = 0
function SHX68_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX2_2 = SHX0_2
  SHX3_2 = tostring
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = tostring
  SHX5_2 = math
  SHX5_2 = SHX5_2.random
  SHX5_2 = SHX5_2()
  SHX4_2 = SHX4_2(SHX5_2)
  SHX2_2 = SHX2_2 .. SHX3_2 .. SHX4_2
  SHX3_2 = SHX34_1
  SHX4_2 = SHX2_2
  SHX5_2 = "hook_integrity_key_v2"
  return SHX3_2(SHX4_2, SHX5_2)
end
function SHX69_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX3_2 = SHX67_1
  SHX3_2 = SHX3_2 + 1
  SHX67_1 = SHX3_2
  SHX3_2 = SHX67_1
  SHX4_2 = SHX68_1
  SHX5_2 = SHX0_2
  SHX6_2 = SHX3_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = SHX65_1.set
  SHX6_2 = SHX65_1.key
  SHX7_2 = SHX3_2
  SHX8_2 = SHX2_2
  SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX5_2 = SHX66_1.set
  SHX6_2 = SHX66_1.key
  SHX7_2 = SHX3_2
  SHX8_2 = SHX1_2
  SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  function SHX5_2(...)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
    SHX0_3 = SHX65_1.get
    SHX1_3 = SHX65_1.key
    SHX2_3 = SHX3_2
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
    SHX1_3 = SHX66_1.get
    SHX2_3 = SHX66_1.key
    SHX3_3 = SHX3_2
    SHX1_3 = SHX1_3(SHX2_3, SHX3_3)
    if not SHX0_3 then
      SHX2_3 = SHX30_1
      if not SHX2_3 then
        SHX2_3 = SHX11_1
        function SHX3_3()
          -- [AI CLEANUP] Decompiled Lua - Fix these:
          -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
          -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
          -- 3. Replace goto/label with while/repeat-until where possible
          -- 4. Remove decompiler comments, add meaningful ones
          -- 5. Fix indentation and formatting
          
          local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4, SHX8_4, SHX9_4, SHX10_4
          SHX0_4 = SHX39_1
          SHX0_4 = SHX0_4()
          SHX1_4 = SHX0_4
          SHX0_4 = SHX0_4.InvokeCPlayer
          SHX2_4 = SHX42_1
          SHX2_4 = SHX2_4()
          SHX3_4 = "newDetection"
          SHX4_4 = "hookTampering"
          SHX5_4 = "Ban Player"
          SHX6_4 = {}
          SHX7_4 = {}
          SHX8_4 = "Hook tampering detected on %s - callback removed"
          SHX9_4 = SHX8_4
          SHX8_4 = SHX8_4.format
          SHX10_4 = SHX0_2
          SHX8_4, SHX9_4, SHX10_4 = SHX8_4(SHX9_4, SHX10_4)
          SHX7_4[1] = SHX8_4
          SHX7_4[2] = SHX9_4
          SHX7_4[3] = SHX10_4
          SHX0_4(SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4)
        end
        SHX2_3(SHX3_3)
      end
      if SHX1_3 then
        SHX2_3 = SHX1_3
        SHX3_3, SHX4_3 = ...
        return SHX2_3(SHX3_3, SHX4_3)
      end
      return
    end
    if not SHX1_3 then
      SHX2_3 = SHX30_1
      if not SHX2_3 then
        SHX2_3 = SHX11_1
        function SHX3_3()
          -- [AI CLEANUP] Decompiled Lua - Fix these:
          -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
          -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
          -- 3. Replace goto/label with while/repeat-until where possible
          -- 4. Remove decompiler comments, add meaningful ones
          -- 5. Fix indentation and formatting
          
          local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4, SHX8_4, SHX9_4, SHX10_4
          SHX0_4 = SHX39_1
          SHX0_4 = SHX0_4()
          SHX1_4 = SHX0_4
          SHX0_4 = SHX0_4.InvokeCPlayer
          SHX2_4 = SHX42_1
          SHX2_4 = SHX2_4()
          SHX3_4 = "newDetection"
          SHX4_4 = "hookTampering"
          SHX5_4 = "Ban Player"
          SHX6_4 = {}
          SHX7_4 = {}
          SHX8_4 = "Hook tampering detected on %s - original function removed"
          SHX9_4 = SHX8_4
          SHX8_4 = SHX8_4.format
          SHX10_4 = SHX0_2
          SHX8_4, SHX9_4, SHX10_4 = SHX8_4(SHX9_4, SHX10_4)
          SHX7_4[1] = SHX8_4
          SHX7_4[2] = SHX9_4
          SHX7_4[3] = SHX10_4
          SHX0_4(SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4)
        end
        SHX2_3(SHX3_3)
      end
      return
    end
    SHX3_3 = SHX3_2
    SHX2_3 = SHX62_1
    SHX2_3 = SHX2_3[SHX3_3]
    SHX3_3 = SHX4_2
    if SHX2_3 ~= SHX3_3 then
      SHX2_3 = SHX30_1
      if not SHX2_3 then
        SHX2_3 = SHX11_1
        function SHX3_3()
          -- [AI CLEANUP] Decompiled Lua - Fix these:
          -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
          -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
          -- 3. Replace goto/label with while/repeat-until where possible
          -- 4. Remove decompiler comments, add meaningful ones
          -- 5. Fix indentation and formatting
          
          local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4, SHX8_4, SHX9_4, SHX10_4
          SHX0_4 = SHX39_1
          SHX0_4 = SHX0_4()
          SHX1_4 = SHX0_4
          SHX0_4 = SHX0_4.InvokeCPlayer
          SHX2_4 = SHX42_1
          SHX2_4 = SHX2_4()
          SHX3_4 = "newDetection"
          SHX4_4 = "hookTampering"
          SHX5_4 = "Ban Player"
          SHX6_4 = {}
          SHX7_4 = {}
          SHX8_4 = "Hook tampering detected on %s - integrity mismatch"
          SHX9_4 = SHX8_4
          SHX8_4 = SHX8_4.format
          SHX10_4 = SHX0_2
          SHX8_4, SHX9_4, SHX10_4 = SHX8_4(SHX9_4, SHX10_4)
          SHX7_4[1] = SHX8_4
          SHX7_4[2] = SHX9_4
          SHX7_4[3] = SHX10_4
          SHX0_4(SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4)
        end
        SHX2_3(SHX3_3)
      end
    end
    SHX2_3 = SHX0_3
    SHX3_3 = SHX1_3
    SHX4_3 = ...
    return SHX2_3(SHX3_3, SHX4_3)
  end
  SHX6_2 = SHX62_1
  SHX6_2[SHX3_2] = SHX4_2
  SHX6_2 = SHX61_1
  SHX6_2[SHX0_2] = SHX5_2
  return SHX5_2
end
function SHX70_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX1_2 = SHX60_1
  SHX1_2 = SHX1_2[SHX0_2]
  if SHX1_2 then
    SHX1_2 = SHX60_1
    SHX1_2 = SHX1_2[SHX0_2]
    return SHX1_2
  end
  SHX1_2 = SHX7_1
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if not SHX1_2 then
    SHX1_2 = {}
  end
  SHX2_2 = SHX64_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX64_1
  SHX3_2 = SHX3_2()
  SHX4_2 = {}
  SHX5_2 = SHX1_2.__newindex
  SHX4_2.old_newindex = SHX5_2
  SHX5_2 = SHX2_2.key
  SHX4_2.hooks_key = SHX5_2
  SHX4_2.hooks_storage = SHX2_2
  SHX5_2 = SHX3_2.key
  SHX4_2.pending_key = SHX5_2
  SHX4_2.pending_storage = SHX3_2
  SHX5_2 = SHX1_2.__index
  function SHX6_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = SHX60_1
    SHX2_3 = SHX2_3[SHX0_3]
    if not SHX2_3 then
      SHX3_3 = SHX5_2
      if SHX3_3 then
        SHX3_3 = SHX4_1
        SHX4_3 = SHX5_2
        SHX3_3 = SHX3_3(SHX4_3)
        if "function" == SHX3_3 then
          SHX3_3 = SHX5_2
          SHX4_3 = SHX0_3
          SHX5_3 = SHX1_3
          return SHX3_3(SHX4_3, SHX5_3)
        else
          SHX3_3 = SHX5_2
          SHX3_3 = SHX3_3[SHX1_3]
          return SHX3_3
        end
      end
      SHX3_3 = SHX29_1
      SHX4_3 = SHX0_3
      SHX5_3 = SHX1_3
      return SHX3_3(SHX4_3, SHX5_3)
    end
    SHX3_3 = SHX2_3.hooks_storage
    SHX3_3 = SHX3_3.get
    SHX4_3 = SHX2_3.hooks_key
    SHX5_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if SHX3_3 then
      SHX4_3 = SHX29_1
      SHX5_3 = SHX0_3
      SHX6_3 = SHX1_3
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
      if nil ~= SHX4_3 then
        return SHX4_3
      end
    end
    SHX4_3 = SHX5_2
    if SHX4_3 then
      SHX4_3 = SHX4_1
      SHX5_3 = SHX5_2
      SHX4_3 = SHX4_3(SHX5_3)
      if "function" == SHX4_3 then
        SHX4_3 = SHX5_2
        SHX5_3 = SHX0_3
        SHX6_3 = SHX1_3
        return SHX4_3(SHX5_3, SHX6_3)
      else
        SHX4_3 = SHX5_2
        SHX4_3 = SHX4_3[SHX1_3]
        return SHX4_3
      end
    end
    SHX4_3 = SHX29_1
    SHX5_3 = SHX0_3
    SHX6_3 = SHX1_3
    return SHX4_3(SHX5_3, SHX6_3)
  end
  function SHX7_2(SHX0_3, SHX1_3, SHX2_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3
    SHX3_3 = SHX60_1
    SHX3_3 = SHX3_3[SHX0_3]
    if not SHX3_3 then
      return
    end
    SHX4_3 = SHX3_3.pending_storage
    SHX4_3 = SHX4_3.get
    SHX5_3 = SHX3_3.pending_key
    SHX6_3 = SHX1_3
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    if SHX4_3 then
      SHX5_3 = SHX4_1
      SHX6_3 = SHX2_3
      SHX5_3 = SHX5_3(SHX6_3)
      if "table" == SHX5_3 then
        SHX5_3 = SHX28_1
        SHX6_3 = SHX0_3
        SHX7_3 = SHX1_3
        SHX8_3 = SHX2_3
        SHX5_3(SHX6_3, SHX7_3, SHX8_3)
        SHX5_3 = ipairs
        SHX6_3 = SHX4_3
        SHX5_3, SHX6_3, SHX7_3, SHX8_3 = SHX5_3(SHX6_3)
        for SHX9_3, SHX10_3 in SHX5_3, SHX6_3, SHX7_3, SHX8_3 do
          SHX11_3 = pcall
          SHX12_3 = SHX10_3
          SHX13_3 = SHX2_3
          SHX11_3(SHX12_3, SHX13_3)
        end
        SHX5_3 = SHX3_3.pending_storage
        SHX5_3 = SHX5_3.set
        SHX6_3 = SHX3_3.pending_key
        SHX7_3 = SHX1_3
        SHX8_3 = nil
        SHX5_3(SHX6_3, SHX7_3, SHX8_3)
        return
      end
    end
    SHX5_3 = SHX3_3.hooks_storage
    SHX5_3 = SHX5_3.get
    SHX6_3 = SHX3_3.hooks_key
    SHX7_3 = SHX1_3
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
    if SHX5_3 then
      SHX6_3 = SHX4_1
      SHX7_3 = SHX2_3
      SHX6_3 = SHX6_3(SHX7_3)
      if "function" == SHX6_3 then
        SHX6_3 = ipairs
        SHX7_3 = SHX5_3
        SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX6_3(SHX7_3)
        for SHX10_3, SHX11_3 in SHX6_3, SHX7_3, SHX8_3, SHX9_3 do
          SHX12_3 = SHX69_1
          SHX13_3 = SHX11_3.fullpath
          SHX14_3 = SHX2_3
          SHX15_3 = SHX11_3.cb
          SHX12_3 = SHX12_3(SHX13_3, SHX14_3, SHX15_3)
          SHX2_3 = SHX12_3
        end
      end
    end
    SHX6_3 = SHX3_3.old_newindex
    if SHX6_3 then
      SHX7_3 = SHX4_1
      SHX8_3 = SHX6_3
      SHX7_3 = SHX7_3(SHX8_3)
      if "function" == SHX7_3 then
        SHX7_3 = SHX6_3
        SHX8_3 = SHX0_3
        SHX9_3 = SHX1_3
        SHX10_3 = SHX2_3
        return SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      else
        SHX7_3 = SHX28_1
        SHX8_3 = SHX6_3
        SHX9_3 = SHX1_3
        SHX10_3 = SHX2_3
        SHX7_3(SHX8_3, SHX9_3, SHX10_3)
        return
      end
    else
      SHX7_3 = SHX28_1
      SHX8_3 = SHX0_3
      SHX9_3 = SHX1_3
      SHX10_3 = SHX2_3
      SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      return
    end
  end
  SHX8_2 = {}
  SHX8_2.__index = SHX6_2
  SHX8_2.__newindex = SHX7_2
  SHX8_2.__metatable = "Access denied"
  SHX9_2 = SHX8_1
  SHX10_2 = SHX0_2
  SHX11_2 = SHX8_2
  SHX9_2(SHX10_2, SHX11_2)
  SHX9_2 = SHX60_1
  SHX9_2[SHX0_2] = SHX4_2
  return SHX4_2
end
function SHX71_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2
  SHX5_2 = #SHX1_2
  if SHX2_2 < SHX5_2 then
    SHX5_2 = SHX1_2[SHX2_2]
    SHX6_2 = SHX29_1
    SHX7_2 = SHX0_2
    SHX8_2 = SHX5_2
    SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
    SHX7_2 = SHX4_1
    SHX8_2 = SHX6_2
    SHX7_2 = SHX7_2(SHX8_2)
    if "table" == SHX7_2 then
      SHX7_2 = SHX71_1
      SHX8_2 = SHX6_2
      SHX9_2 = SHX1_2
      SHX10_2 = SHX2_2 + 1
      SHX11_2 = SHX3_2
      SHX12_2 = SHX4_2
      return SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
    else
      SHX7_2 = SHX70_1
      SHX8_2 = SHX0_2
      SHX7_2 = SHX7_2(SHX8_2)
      SHX8_2 = SHX7_2.pending_storage
      SHX8_2 = SHX8_2.get
      SHX9_2 = SHX7_2.pending_key
      SHX10_2 = SHX5_2
      SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
      if not SHX8_2 then
        SHX8_2 = {}
      end
      SHX9_2 = table
      SHX9_2 = SHX9_2.insert
      SHX10_2 = SHX8_2
      function SHX11_2(SHX0_3)
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX1_3, SHX2_3
        SHX1_3 = pcall
        function SHX2_3()
          -- [AI CLEANUP] Decompiled Lua - Fix these:
          -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
          -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
          -- 3. Replace goto/label with while/repeat-until where possible
          -- 4. Remove decompiler comments, add meaningful ones
          -- 5. Fix indentation and formatting
          
          local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4
          SHX0_4 = SHX71_1
          SHX1_4 = SHX0_3
          SHX2_4 = SHX1_2
          SHX3_4 = SHX2_2
          SHX3_4 = SHX3_4 + 1
          SHX4_4 = SHX3_2
          SHX5_4 = SHX4_2
          SHX0_4(SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4)
        end
        SHX1_3(SHX2_3)
      end
      SHX9_2(SHX10_2, SHX11_2)
      SHX9_2 = SHX7_2.pending_storage
      SHX9_2 = SHX9_2.set
      SHX10_2 = SHX7_2.pending_key
      SHX11_2 = SHX5_2
      SHX12_2 = SHX8_2
      SHX9_2(SHX10_2, SHX11_2, SHX12_2)
      return
    end
  else
    SHX5_2 = #SHX1_2
    SHX5_2 = SHX1_2[SHX5_2]
    SHX6_2 = SHX70_1
    SHX7_2 = SHX0_2
    SHX6_2 = SHX6_2(SHX7_2)
    SHX7_2 = SHX6_2.hooks_storage
    SHX7_2 = SHX7_2.get
    SHX8_2 = SHX6_2.hooks_key
    SHX9_2 = SHX5_2
    SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
    if not SHX7_2 then
      SHX7_2 = {}
    end
    SHX8_2 = table
    SHX8_2 = SHX8_2.insert
    SHX9_2 = SHX7_2
    SHX10_2 = {}
    SHX10_2.fullpath = SHX3_2
    SHX10_2.cb = SHX4_2
    SHX8_2(SHX9_2, SHX10_2)
    SHX8_2 = SHX6_2.hooks_storage
    SHX8_2 = SHX8_2.set
    SHX9_2 = SHX6_2.hooks_key
    SHX10_2 = SHX5_2
    SHX11_2 = SHX7_2
    SHX8_2(SHX9_2, SHX10_2, SHX11_2)
    SHX8_2 = SHX63_1
    SHX8_2[SHX3_2] = true
    SHX8_2 = SHX29_1
    SHX9_2 = SHX0_2
    SHX10_2 = SHX5_2
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
    SHX9_2 = SHX4_1
    SHX10_2 = SHX8_2
    SHX9_2 = SHX9_2(SHX10_2)
    if "function" == SHX9_2 then
      SHX9_2 = SHX8_2
      SHX10_2 = ipairs
      SHX11_2 = SHX7_2
      SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX10_2(SHX11_2)
      for SHX14_2, SHX15_2 in SHX10_2, SHX11_2, SHX12_2, SHX13_2 do
        SHX16_2 = SHX69_1
        SHX17_2 = SHX15_2.fullpath
        SHX18_2 = SHX9_2
        SHX19_2 = SHX15_2.cb
        SHX16_2 = SHX16_2(SHX17_2, SHX18_2, SHX19_2)
        SHX9_2 = SHX16_2
      end
      SHX10_2 = SHX28_1
      SHX11_2 = SHX0_2
      SHX12_2 = SHX5_2
      SHX13_2 = SHX9_2
      SHX10_2(SHX11_2, SHX12_2, SHX13_2)
      SHX10_2 = SHX61_1
      SHX10_2[SHX3_2] = SHX9_2
    end
    return
  end
end
function SHX72_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX2_2 = SHX4_1
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2)
  if "string" == SHX2_2 then
    SHX2_2 = SHX4_1
    SHX3_2 = SHX1_2
    SHX2_2 = SHX2_2(SHX3_2)
    if "function" == SHX2_2 then
      goto SHX_LABEL_14
    end
  end
  SHX2_2 = error
  SHX3_2 = "AdvancedHook(path_string, callback_function)"
  SHX2_2(SHX3_2)
  -- [FIX IF ERROR] Move ::SHX_LABEL_14:: outside nested blocks until all 'goto SHX_LABEL_14' can see it
  ::SHX_LABEL_14::
  SHX2_2 = {}
  SHX3_2 = string
  SHX3_2 = SHX3_2.gmatch
  SHX4_2 = SHX0_2
  SHX5_2 = "[%w_]+"
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2, SHX5_2)
  for SHX7_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    SHX8_2 = table
    SHX8_2 = SHX8_2.insert
    SHX9_2 = SHX2_2
    SHX10_2 = SHX7_2
    SHX8_2(SHX9_2, SHX10_2)
  end
  SHX3_2 = #SHX2_2
  if 0 == SHX3_2 then
    SHX3_2 = error
    SHX4_2 = "invalid path"
    SHX3_2(SHX4_2)
  end
  SHX3_2 = SHX71_1
  SHX4_2 = _G
  SHX5_2 = SHX2_2
  SHX6_2 = 1
  SHX7_2 = table
  SHX7_2 = SHX7_2.concat
  SHX8_2 = SHX2_2
  SHX9_2 = "."
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX8_2 = SHX1_2
  SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
end
function SHX73_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = _G
  SHX0_2.LoadSharedReaper = nil
  SHX0_2 = {}
  SHX1_2 = SHX32_1
  SHX0_2.gameType = SHX1_2
  SHX1_2 = SHX31_1
  SHX0_2.resource_name = SHX1_2
  SHX1_2 = SHX33_1
  SHX0_2.load_resource_patches = SHX1_2
  SHX1_2 = SHX59_1
  SHX0_2.load_imports_file = SHX1_2
  SHX1_2 = SHX34_1
  SHX0_2.hash = SHX1_2
  SHX1_2 = SHX35_1
  SHX0_2._cv = SHX1_2
  SHX1_2 = SHX36_1
  SHX0_2._ch = SHX1_2
  SHX1_2 = SHX0_1
  SHX0_2.table_copy = SHX1_2
  SHX1_2 = SHX39_1
  SHX0_2.ReaperExports = SHX1_2
  SHX1_2 = SHX41_1
  SHX0_2.GetReaperKeys = SHX1_2
  SHX1_2 = SHX42_1
  SHX0_2.GetReaperResourceKey = SHX1_2
  SHX1_2 = SHX43_1
  SHX0_2.Logger = SHX1_2
  SHX1_2 = SHX47_1
  SHX0_2.HookFunction = SHX1_2
  SHX1_2 = SHX44_1
  SHX0_2.log_hooked_function_calls = SHX1_2
  SHX1_2 = SHX46_1
  SHX0_2.IsFunctionAHook = SHX1_2
  SHX1_2 = SHX48_1
  SHX0_2.parseArgs = SHX1_2
  SHX1_2 = SHX58_1
  SHX0_2.IsEventIgnored = SHX1_2
  SHX1_2 = SHX57_1
  SHX0_2.IsCoreEvent = SHX1_2
  SHX1_2 = SHX49_1
  SHX0_2.CreateThreadWithData = SHX1_2
  SHX1_2 = SHX72_1
  SHX0_2.AdvancedHook = SHX1_2
  return SHX0_2
end
LoadSharedReaper = SHX73_1
