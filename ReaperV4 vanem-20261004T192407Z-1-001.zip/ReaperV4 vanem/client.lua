-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1, SHX21_1, SHX22_1, SHX23_1, SHX24_1, SHX25_1, SHX26_1, SHX27_1, SHX28_1, SHX29_1, SHX30_1, SHX31_1, SHX32_1, SHX33_1, SHX34_1, SHX35_1, SHX36_1, SHX37_1, SHX38_1, SHX39_1, SHX40_1, SHX41_1, SHX42_1, SHX43_1, SHX44_1, SHX45_1, SHX46_1, SHX47_1, SHX48_1, SHX49_1, SHX50_1, SHX51_1
SHX0_1 = Security
SHX1_1 = Logger
SHX2_1 = RPC
SHX3_1 = Player
SHX4_1 = NUI
SHX5_1 = NativeRules
SHX7_1 = SHX1_1
SHX6_1 = SHX1_1.log
SHX8_1 = "client.lua loaded"
SHX9_1 = "debug"
SHX6_1(SHX7_1, SHX8_1, SHX9_1)
SHX6_1 = GetConvar
SHX7_1 = RegisterCommand
SHX8_1 = Wait
SHX9_1 = CreateThread
SHX10_1 = GetGameTimer
SHX11_1 = GetInvokingResource
SHX12_1 = json
SHX12_1 = SHX12_1.encode
SHX13_1 = json
SHX13_1 = SHX13_1.decode
SHX14_1 = QuitGame
if not SHX14_1 then
  function SHX14_1()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_2, SHX1_2
    while true do
    end
  end
end
SHX15_1 = LocalPlayer
SHX15_1 = SHX15_1.state
SHX16_1 = tostring
SHX17_1 = print
SHX18_1 = table
SHX18_1 = SHX18_1.insert
SHX19_1 = table
SHX19_1 = SHX19_1.sort
SHX20_1 = table
SHX20_1 = SHX20_1.reverse
SHX21_1 = SetLocalStateValue
SHX22_1 = Citizen
SHX22_1 = SHX22_1.GetFunctionReference
SHX23_1 = {}
SHX25_1 = SHX4_1
SHX24_1 = SHX4_1.on
SHX26_1 = "httpError"
function SHX27_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  SHX2_2 = SHX0_2.type
  if "screen.js" == SHX2_2 then
    SHX2_2 = SHX17_1
    SHX3_2 = json
    SHX3_2 = SHX3_2.encode
    SHX4_2 = SHX0_2
    SHX3_2, SHX4_2 = SHX3_2(SHX4_2)
    SHX2_2(SHX3_2, SHX4_2)
    SHX2_2 = TriggerServerEvent
    SHX3_2 = "Reaper:CustomDrop"
    SHX4_2 = "reaperac.com - failed to load needed data"
    SHX2_2(SHX3_2, SHX4_2)
  end
  SHX2_2 = SHX1_2
  SHX3_2 = true
  SHX2_2(SHX3_2)
end
SHX24_1(SHX25_1, SHX26_1, SHX27_1)
SHX25_1 = SHX2_1
SHX24_1 = SHX2_1.register
SHX26_1 = "invokeCPlayer"
function SHX27_1(SHX0_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = SHX3_1
  SHX1_2 = SHX1_2[SHX0_2]
  SHX2_2 = SHX3_1
  SHX3_2 = ...
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX24_1(SHX25_1, SHX26_1, SHX27_1)
SHX24_1 = SHX6_1
SHX25_1 = "reaper_config"
SHX26_1 = ""
SHX24_1 = SHX24_1(SHX25_1, SHX26_1)
if "" == SHX24_1 then
  SHX26_1 = SHX2_1
  SHX25_1 = SHX2_1.await
  SHX27_1 = "GetConfig"
  SHX25_1 = SHX25_1(SHX26_1, SHX27_1)
  SHX24_1 = SHX25_1
else
  SHX25_1 = SHX13_1
  SHX26_1 = SHX24_1
  SHX25_1 = SHX25_1(SHX26_1)
  SHX24_1 = SHX25_1
end
SHX25_1 = SHX6_1
SHX26_1 = "reaper_gameType"
SHX27_1 = "unknown"
SHX25_1 = SHX25_1(SHX26_1, SHX27_1)
if "rdr3" ~= SHX25_1 and "gta5" ~= SHX25_1 then
  SHX27_1 = SHX1_1
  SHX26_1 = SHX1_1.log
  SHX28_1 = "^3%s^7 is not a valid game type supported by Reaper."
  SHX29_1 = SHX28_1
  SHX28_1 = SHX28_1.format
  SHX30_1 = SHX25_1
  SHX28_1 = SHX28_1(SHX29_1, SHX30_1)
  SHX29_1 = "error"
  SHX30_1 = true
  return SHX26_1(SHX27_1, SHX28_1, SHX29_1, SHX30_1)
end
if "RESPONSE_FAILED" == SHX24_1 then
  SHX27_1 = SHX1_1
  SHX26_1 = SHX1_1.log
  SHX28_1 = "FAILED TO LOAD CONFIG, STAGE #1"
  SHX29_1 = "error"
  SHX26_1(SHX27_1, SHX28_1, SHX29_1)
  SHX26_1 = TriggerServerEvent
  SHX27_1 = "Reaper:CustomDrop"
  SHX28_1 = "reaperac.com - FAILED TO LOAD CONFIG, STAGE #1"
  SHX26_1(SHX27_1, SHX28_1)
  SHX26_1 = SHX8_1
  SHX27_1 = 5000
  SHX26_1(SHX27_1)
  SHX26_1 = SHX14_1
  SHX26_1()
  return
end
if "KEY_MISSMATCH" ~= SHX24_1 then
  SHX27_1 = SHX0_1
  SHX26_1 = SHX0_1.hash
  SHX28_1 = SHX24_1.config
  SHX26_1 = SHX26_1(SHX27_1, SHX28_1)
  SHX27_1 = SHX24_1.key
  if SHX26_1 == SHX27_1 then
    goto SHX_LABEL_120
  end
end
SHX27_1 = SHX1_1
SHX26_1 = SHX1_1.log
SHX28_1 = "FAILED TO LOAD CONFIG, STAGE #2"
SHX29_1 = "error"
SHX30_1 = true
SHX26_1(SHX27_1, SHX28_1, SHX29_1, SHX30_1)
SHX26_1 = TriggerServerEvent
SHX27_1 = "Reaper:CustomDrop"
SHX28_1 = "reaperac.com - FAILED TO LOAD CONFIG, STAGE #2"
SHX26_1(SHX27_1, SHX28_1)
SHX26_1 = SHX8_1
SHX27_1 = 5000
SHX26_1(SHX27_1)
SHX26_1 = SHX14_1
SHX26_1()
return
-- [FIX IF ERROR] Move ::SHX_LABEL_120:: outside nested blocks until all 'goto SHX_LABEL_120' can see it
::SHX_LABEL_120::
SHX27_1 = SHX2_1
SHX26_1 = SHX2_1.onNet
SHX28_1 = "Reaper:UpdateConfig"
function SHX29_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX1_2 = SHX13_1
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.hash
  SHX4_2 = SHX1_2.config
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX3_2 = SHX1_2.key
  if SHX2_2 ~= SHX3_2 then
    SHX2_2 = TriggerServerEvent
    SHX3_2 = "Reaper:CustomDrop"
    SHX4_2 = "reaperac.com - FAILED TO LOAD CONFIG, STAGE #2"
    SHX2_2(SHX3_2, SHX4_2)
    SHX2_2 = SHX8_1
    SHX3_2 = 5000
    SHX2_2(SHX3_2)
    SHX2_2 = SHX1_1
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.log
    SHX4_2 = "FAILED TO LOAD CONFIG, STAGE #2"
    SHX5_2 = "error"
    SHX6_2 = true
    SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
    return
  end
  SHX2_2 = SHX3_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.set
  SHX4_2 = "config"
  SHX5_2 = SHX13_1
  SHX6_2 = SHX1_2.config
  SHX5_2, SHX6_2 = SHX5_2(SHX6_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  SHX2_2 = SHX1_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.log
  SHX4_2 = "Successfully received and verified config from the server. Key: ^3%s"
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.format
  SHX6_2 = SHX1_2.key
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = "debug"
  SHX6_2 = true
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  SHX2_2 = SHX2_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.emit
  SHX4_2 = "configUpdated"
  SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX13_1
  SHX3_2 = SHX1_2.config
  SHX2_2 = SHX2_2(SHX3_2)
  SHX0_2 = SHX2_2
end
SHX26_1(SHX27_1, SHX28_1, SHX29_1)
SHX27_1 = SHX3_1
SHX26_1 = SHX3_1.set
SHX28_1 = "gameType"
SHX29_1 = SHX25_1
SHX26_1(SHX27_1, SHX28_1, SHX29_1)
SHX27_1 = SHX3_1
SHX26_1 = SHX3_1.set
SHX28_1 = "config"
SHX29_1 = SHX13_1
SHX30_1 = SHX24_1.config
SHX29_1, SHX30_1, SHX31_1, SHX32_1, SHX33_1, SHX34_1, SHX35_1, SHX36_1, SHX37_1, SHX38_1, SHX39_1, SHX40_1, SHX41_1, SHX42_1, SHX43_1, SHX44_1, SHX45_1, SHX46_1, SHX47_1, SHX48_1, SHX49_1, SHX50_1, SHX51_1 = SHX29_1(SHX30_1)
SHX26_1(SHX27_1, SHX28_1, SHX29_1, SHX30_1, SHX31_1, SHX32_1, SHX33_1, SHX34_1, SHX35_1, SHX36_1, SHX37_1, SHX38_1, SHX39_1, SHX40_1, SHX41_1, SHX42_1, SHX43_1, SHX44_1, SHX45_1, SHX46_1, SHX47_1, SHX48_1, SHX49_1, SHX50_1, SHX51_1)
SHX27_1 = SHX1_1
SHX26_1 = SHX1_1.log
SHX28_1 = "Successfully received and verified config from the server. Key: ^3%s"
SHX29_1 = SHX28_1
SHX28_1 = SHX28_1.format
SHX30_1 = SHX24_1.key
SHX28_1 = SHX28_1(SHX29_1, SHX30_1)
SHX29_1 = "debug"
SHX30_1 = true
SHX26_1(SHX27_1, SHX28_1, SHX29_1, SHX30_1)
SHX26_1 = SHX13_1
SHX27_1 = SHX24_1.config
SHX26_1 = SHX26_1(SHX27_1)
SHX24_1 = SHX26_1
SHX27_1 = SHX2_1
SHX26_1 = SHX2_1.emit
SHX28_1 = "reaperReady"
SHX26_1(SHX27_1, SHX28_1)
SHX27_1 = SHX3_1
SHX26_1 = SHX3_1.set
SHX28_1 = "reaperReady"
SHX29_1 = true
SHX26_1(SHX27_1, SHX28_1, SHX29_1)
SHX27_1 = SHX2_1
SHX26_1 = SHX2_1.register
SHX28_1 = "ClipScreen"
function SHX29_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX4_1
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.clipScreen
  return SHX0_2(SHX1_2)
end
SHX26_1(SHX27_1, SHX28_1, SHX29_1)
SHX27_1 = SHX2_1
SHX26_1 = SHX2_1.register
SHX28_1 = "ScreenshotScreen"
function SHX29_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX4_1
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.screenshot
  return SHX0_2(SHX1_2)
end
SHX26_1(SHX27_1, SHX28_1, SHX29_1)
SHX27_1 = SHX2_1
SHX26_1 = SHX2_1.register
SHX28_1 = "Get_OCR"
function SHX29_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX4_1
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.getOCRText
  return SHX0_2(SHX1_2)
end
SHX26_1(SHX27_1, SHX28_1, SHX29_1)
SHX27_1 = SHX2_1
SHX26_1 = SHX2_1.onNet
SHX28_1 = "Reaper:SetState"
function SHX29_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX2_2 = SHX11_1
  SHX2_2 = SHX2_2()
  if nil ~= SHX2_2 then
    return
  end
  if "%GameTimer%" == SHX1_2 then
    SHX2_2 = SHX10_1
    SHX2_2 = SHX2_2()
    SHX1_2 = SHX2_2
  end
  SHX2_2 = SHX3_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.set
  SHX4_2 = SHX0_2
  SHX5_2 = SHX1_2
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
end
SHX26_1(SHX27_1, SHX28_1, SHX29_1)
SHX27_1 = SHX2_1
SHX26_1 = SHX2_1.register
SHX28_1 = "Reaper:SetState"
function SHX29_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX2_2 = SHX11_1
  SHX2_2 = SHX2_2()
  if nil ~= SHX2_2 then
    return
  end
  if "%GameTimer%" == SHX1_2 then
    SHX2_2 = SHX10_1
    SHX2_2 = SHX2_2()
    SHX1_2 = SHX2_2
  end
  SHX2_2 = SHX3_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.set
  SHX4_2 = SHX0_2
  SHX5_2 = SHX1_2
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = true
  return SHX2_2
end
SHX26_1(SHX27_1, SHX28_1, SHX29_1)
SHX27_1 = SHX2_1
SHX26_1 = SHX2_1.onNet
SHX28_1 = "Reaper:setSyncedState"
function SHX29_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = SHX1_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.getLogLevel
  SHX2_2 = SHX2_2(SHX3_2)
  if 1 == SHX2_2 then
    SHX2_2 = SHX1_1
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.log
    SHX4_2 = "Reaper:setSyncedState: %s -> %s"
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.format
    SHX6_2 = SHX0_2
    SHX7_2 = SHX1_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX5_2 = "debug"
    SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  end
  SHX2_2 = SHX3_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.set
  SHX4_2 = SHX0_2
  SHX5_2 = "_synced"
  SHX4_2 = SHX4_2 .. SHX5_2
  SHX5_2 = SHX1_2
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
end
SHX26_1(SHX27_1, SHX28_1, SHX29_1)
SHX26_1 = {}
SHX27_1 = nil
SHX28_1 = 0
SHX29_1 = {}
SHX31_1 = SHX2_1
SHX30_1 = SHX2_1.onNet
SHX32_1 = "Reaper:ClientSetState"
function SHX33_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX2_2 = SHX11_1
  SHX2_2 = SHX2_2()
  if nil == SHX2_2 then
    return
  end
  if SHX0_2 ~= SHX2_2 then
    return
  end
  SHX3_2 = SHX29_1
  SHX3_2 = SHX3_2[SHX0_2]
  if SHX3_2 then
    return
  end
  SHX3_2 = SHX29_1
  SHX3_2[SHX0_2] = true
  SHX3_2 = SHX10_1
  SHX3_2 = SHX3_2()
  SHX27_1 = SHX3_2
  SHX3_2 = SHX28_1
  SHX3_2 = SHX3_2 + 1
  SHX28_1 = SHX3_2
  SHX3_2 = pairs
  SHX4_2 = SHX1_2
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
  for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    SHX9_2 = SHX18_1
    SHX10_2 = SHX26_1
    SHX11_2 = SHX8_2
    SHX9_2(SHX10_2, SHX11_2)
  end
end
SHX30_1(SHX31_1, SHX32_1, SHX33_1)
SHX30_1 = SHX9_1
function SHX31_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2
  while true do
    SHX0_2 = SHX8_1
    SHX1_2 = 100
    SHX0_2(SHX1_2)
    SHX0_2 = SHX27_1
    if SHX0_2 then
      SHX0_2 = SHX10_1
      SHX0_2 = SHX0_2()
      SHX1_2 = SHX27_1
      SHX0_2 = SHX0_2 - SHX1_2
      SHX1_2 = 25000
      if SHX0_2 > SHX1_2 then
        SHX0_2 = SHX19_1
        SHX1_2 = SHX26_1
        function SHX2_2(SHX0_3, SHX1_3)
          -- [AI CLEANUP] Decompiled Lua - Fix these:
          -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
          -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
          -- 3. Replace goto/label with while/repeat-until where possible
          -- 4. Remove decompiler comments, add meaningful ones
          -- 5. Fix indentation and formatting
          
          local SHX2_3, SHX3_3
          SHX2_3 = SHX0_3.time
          SHX3_3 = SHX1_3.time
          SHX2_3 = SHX2_3 < SHX3_3
          return SHX2_3
        end
        SHX0_2(SHX1_2, SHX2_2)
        SHX0_2 = pairs
        SHX1_2 = SHX26_1
        SHX0_2, SHX1_2, SHX2_2, SHX3_2 = SHX0_2(SHX1_2)
        for SHX4_2, SHX5_2 in SHX0_2, SHX1_2, SHX2_2, SHX3_2 do
          SHX6_2 = SHX3_1
          SHX7_2 = SHX6_2
          SHX6_2 = SHX6_2.set
          SHX8_2 = SHX5_2.index
          SHX9_2 = SHX5_2.data
          SHX6_2(SHX7_2, SHX8_2, SHX9_2)
          SHX6_2 = SHX15_1
          SHX7_2 = SHX6_2
          SHX6_2 = SHX6_2.set
          SHX8_2 = "reaper:"
          SHX9_2 = SHX0_1
          SHX10_2 = SHX9_2
          SHX9_2 = SHX9_2.hash
          SHX11_2 = SHX5_2.index
          SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
          SHX8_2 = SHX8_2 .. SHX9_2
          SHX9_2 = {}
          SHX10_2 = SHX0_1
          SHX11_2 = SHX10_2
          SHX10_2 = SHX10_2.hash
          SHX12_2 = SHX5_2.index
          SHX13_2 = SHX16_1
          SHX14_2 = SHX5_2.data
          SHX13_2 = SHX13_2(SHX14_2)
          SHX14_2 = SHX5_2.time
          SHX12_2 = SHX12_2 .. SHX13_2 .. SHX14_2
          SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
          SHX9_2.key = SHX10_2
          SHX10_2 = SHX5_2.time
          SHX9_2.key2 = SHX10_2
          SHX10_2 = SHX5_2.data
          SHX9_2.key3 = SHX10_2
          SHX10_2 = SHX5_2.index
          SHX9_2.eventName = SHX10_2
          SHX6_2(SHX7_2, SHX8_2, SHX9_2)
        end
        SHX0_2 = SHX3_1
        SHX1_2 = SHX0_2
        SHX0_2 = SHX0_2.set
        SHX2_2 = "queued_events"
        SHX3_2 = SHX26_1
        SHX0_2(SHX1_2, SHX2_2, SHX3_2)
        SHX0_2 = SHX3_1
        SHX1_2 = SHX0_2
        SHX0_2 = SHX0_2.set
        SHX2_2 = "start_detections"
        SHX3_2 = true
        SHX0_2(SHX1_2, SHX2_2, SHX3_2)
        break
      end
    end
  end
end
SHX30_1(SHX31_1)
SHX30_1 = SHX6_1
SHX31_1 = "reaper_record_natives"
SHX32_1 = "false"
SHX30_1 = SHX30_1(SHX31_1, SHX32_1)
SHX30_1 = "true" == SHX30_1
SHX31_1 = {}
StateRecorder = SHX31_1
function SHX31_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX1_2 = {}
  if nil == SHX0_2 then
    SHX2_2 = StateRecorder
    SHX0_2 = #SHX2_2
  end
  SHX2_2 = pairs
  SHX3_2 = SHX20_1
  SHX4_2 = table
  SHX4_2 = SHX4_2.filter
  SHX5_2 = StateRecorder
  function SHX6_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3
    SHX1_3 = string
    SHX1_3 = SHX1_3.match
    SHX2_3 = SHX0_3.index
    SHX3_3 = "joaat"
    SHX1_3 = SHX1_3(SHX2_3, SHX3_3)
    SHX1_3 = not SHX1_3
    return SHX1_3
  end
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    if SHX0_2 < SHX6_2 then
      break
    end
    SHX8_2 = SHX18_1
    SHX9_2 = SHX1_2
    SHX10_2 = SHX7_2
    SHX8_2(SHX9_2, SHX10_2)
  end
  return SHX1_2
end
GetLastStateRecorderData = SHX31_1
SHX32_1 = SHX2_1
SHX31_1 = SHX2_1.register
SHX33_1 = "getLastRecordedStateData"
function SHX34_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  SHX2_2 = table
  SHX2_2 = SHX2_2.filter
  SHX3_2 = GetLastStateRecorderData
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  function SHX4_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3
    SHX1_3 = SHX0_2
    SHX1_3 = "" == SHX1_3
    return SHX1_3
  end
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  return SHX2_2
end
SHX31_1(SHX32_1, SHX33_1, SHX34_1)
SHX31_1 = SHX6_1
SHX32_1 = "reaper_expose_state"
SHX33_1 = "false"
SHX31_1 = SHX31_1(SHX32_1, SHX33_1)
if "true" == SHX31_1 then
  SHX31_1 = SHX7_1
  SHX32_1 = "rdumpstate"
  function SHX33_1()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
    SHX0_2 = SHX12_1
    SHX1_2 = GetLastStateRecorderData
    SHX2_2 = StateRecorder
    SHX2_2 = #SHX2_2
    SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX1_2(SHX2_2)
    SHX0_2 = SHX0_2(SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2)
    SHX1_2 = SHX17_1
    SHX2_2 = "Data: %s"
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.format
    SHX4_2 = SHX0_1
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.encrypt
    SHX6_2 = SHX0_2
    SHX4_2, SHX5_2, SHX6_2 = SHX4_2(SHX5_2, SHX6_2)
    SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
    SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  end
  SHX31_1(SHX32_1, SHX33_1)
end
SHX31_1 = SHX6_1
SHX32_1 = "reaper_expose_state_setters"
SHX33_1 = "false"
SHX31_1 = SHX31_1(SHX32_1, SHX33_1)
SHX31_1 = "true" == SHX31_1
function SHX32_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX2_2 = SHX31_1
  if false == SHX2_2 then
    SHX2_2 = false
    return SHX2_2
  end
  SHX2_2 = SHX10_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX3_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.set
  SHX5_2 = SHX0_2
  SHX6_2 = SHX1_2
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = SHX15_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.set
  SHX5_2 = "reaper:"
  SHX6_2 = SHX0_1
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.hash
  SHX8_2 = SHX0_2
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX5_2 = SHX5_2 .. SHX6_2
  SHX6_2 = {}
  SHX7_2 = SHX0_1
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.hash
  SHX9_2 = SHX0_2
  SHX10_2 = SHX16_1
  SHX11_2 = SHX1_2
  SHX10_2 = SHX10_2(SHX11_2)
  SHX11_2 = SHX2_2
  SHX9_2 = SHX9_2 .. SHX10_2 .. SHX11_2
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX6_2.key = SHX7_2
  SHX6_2.key2 = SHX2_2
  SHX6_2.key3 = SHX1_2
  SHX6_2.eventName = SHX0_2
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = true
  return SHX3_2
end
SHX33_1 = {}
SHX34_1 = exports
SHX35_1 = "RequestEntitySpawn"
function SHX36_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2
  SHX2_2 = SHX31_1
  if false == SHX2_2 then
    SHX2_2 = false
    return SHX2_2
  end
  SHX2_2 = SHX11_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX6_1
  SHX4_2 = "reaper_auto_entity_whitelist"
  SHX5_2 = "false"
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  if "false" == SHX3_2 then
    SHX3_2 = true
    return SHX3_2
  end
  SHX3_2 = SHX33_1
  SHX3_2 = SHX3_2[SHX0_2]
  if SHX3_2 then
    SHX3_2 = true
    return SHX3_2
  end
  SHX3_2 = "exports['ReaperV4'].RequestEntitySpawn('%s')"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX0_1
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.hash
  SHX6_2 = SHX3_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = SHX2_1
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.await
  SHX7_2 = "requestSpawn"
  SHX8_2 = SHX0_2
  SHX9_2 = SHX1_2
  SHX10_2 = SHX3_2
  SHX11_2 = SHX4_2
  SHX12_2 = SHX4_2
  SHX13_2 = SHX0_1
  SHX14_2 = SHX13_2
  SHX13_2 = SHX13_2.hash
  SHX15_2 = SHX3_2
  SHX16_2 = SHX4_2
  SHX15_2 = SHX15_2 .. SHX16_2
  SHX13_2 = SHX13_2(SHX14_2, SHX15_2)
  SHX14_2 = SHX0_1
  SHX15_2 = SHX14_2
  SHX14_2 = SHX14_2.hash
  SHX16_2 = SHX3_2
  SHX17_2 = SHX4_2
  SHX16_2 = SHX16_2 .. SHX17_2
  SHX14_2 = SHX14_2(SHX15_2, SHX16_2)
  SHX15_2 = "ReaperV4"
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
  SHX6_2 = SHX33_1
  SHX6_2[SHX0_2] = SHX5_2
  return SHX5_2
end
SHX34_1(SHX35_1, SHX36_1)
SHX34_1 = {}
function SHX35_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX4_2 = SHX11_1
  SHX4_2 = SHX4_2()
  SHX5_2 = SHX16_1
  SHX6_2 = SHX0_1
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.hash
  SHX8_2 = "pro_addon"
  SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  SHX6_2 = SHX24_1
  SHX5_2 = SHX6_2[SHX5_2]
  if false == SHX5_2 then
    SHX5_2 = {}
    SHX6_2 = true
    SHX7_2 = SHX0_1
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.hash
    SHX9_2 = SHX2_2
    SHX10_2 = "yes"
    SHX9_2 = SHX9_2 .. SHX10_2
    SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX7_2(SHX8_2, SHX9_2)
    SHX5_2[1] = SHX6_2
    SHX5_2[2] = SHX7_2
    SHX5_2[3] = SHX8_2
    SHX5_2[4] = SHX9_2
    SHX5_2[5] = SHX10_2
    SHX5_2[6] = SHX11_2
    SHX5_2[7] = SHX12_2
    return SHX5_2
  end
  SHX5_2 = SHX1_1
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.log
  SHX7_2 = "IsExecutionValid('%s', '%s', '%s', '%s')"
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.format
  SHX9_2 = SHX0_2
  SHX10_2 = SHX1_2
  SHX11_2 = SHX2_2
  SHX12_2 = SHX3_2
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  SHX8_2 = "debug"
  SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX5_2 = SHX4_2
  SHX6_2 = SHX2_2
  SHX5_2 = SHX5_2 .. SHX6_2
  SHX6_2 = SHX34_1
  SHX5_2 = SHX6_2[SHX5_2]
  if nil == SHX5_2 then
    SHX5_2 = SHX2_1
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.await
    SHX7_2 = "check_custom_execution"
    SHX8_2 = SHX4_2
    SHX9_2 = SHX0_2
    SHX10_2 = SHX1_2
    SHX11_2 = SHX2_2
    SHX12_2 = SHX3_2
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
    if false == SHX5_2 then
      SHX6_2 = {}
      SHX7_2 = false
      SHX8_2 = 0
      SHX6_2[1] = SHX7_2
      SHX6_2[2] = SHX8_2
      return SHX6_2
    end
    SHX6_2 = SHX4_2
    SHX7_2 = SHX2_2
    SHX6_2 = SHX6_2 .. SHX7_2
    SHX7_2 = SHX34_1
    SHX8_2 = SHX0_1
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.hash
    SHX10_2 = SHX2_2
    SHX11_2 = "yes"
    SHX10_2 = SHX10_2 .. SHX11_2
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
    SHX7_2[SHX6_2] = SHX8_2
  end
  SHX5_2 = {}
  SHX6_2 = true
  SHX7_2 = SHX4_2
  SHX8_2 = SHX2_2
  SHX7_2 = SHX7_2 .. SHX8_2
  SHX8_2 = SHX34_1
  SHX7_2 = SHX8_2[SHX7_2]
  SHX5_2[1] = SHX6_2
  SHX5_2[2] = SHX7_2
  return SHX5_2
end
SHX36_1 = false
SHX38_1 = SHX2_1
SHX37_1 = SHX2_1.register
SHX39_1 = "toggle_state_tracker"
function SHX40_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX36_1
  SHX0_2 = not SHX0_2
  SHX36_1 = SHX0_2
  SHX0_2 = SHX36_1
  return SHX0_2
end
SHX37_1(SHX38_1, SHX39_1, SHX40_1)
function SHX37_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2
  SHX6_2 = SHX11_1
  SHX6_2 = SHX6_2()
  if nil == SHX6_2 then
    SHX7_2 = TriggerServerEvent
    SHX8_2 = "Reaper:CustomDrop"
    SHX9_2 = "reaperac.com - ERROR SETTING STATE #1"
    SHX7_2(SHX8_2, SHX9_2)
    SHX7_2 = SHX8_1
    SHX8_2 = 5000
    SHX7_2(SHX8_2)
    SHX7_2 = SHX14_1
    SHX7_2()
    SHX7_2 = false
    return SHX7_2
  end
  SHX7_2 = SHX36_1
  if SHX7_2 then
    SHX7_2 = SHX3_1
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.get
    SHX9_2 = SHX0_2
    SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
    if SHX7_2 ~= SHX1_2 then
      SHX7_2 = SHX2_1
      SHX8_2 = SHX7_2
      SHX7_2 = SHX7_2.emitNet
      SHX9_2 = "Reaper:LogPlayerState"
      SHX10_2 = SHX12_1
      SHX11_2 = {}
      SHX11_2.state = SHX0_2
      SHX11_2.value = SHX1_2
      SHX11_2.path = SHX2_2
      SHX11_2.traceback = SHX5_2
      SHX11_2.invoking_resource = SHX6_2
      SHX11_2.id = SHX3_2
      SHX12_2 = {}
      SHX12_2.indent = true
      SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2 = SHX10_2(SHX11_2, SHX12_2)
      SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
    end
  end
  SHX7_2 = SHX3_1
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.set
  SHX9_2 = SHX0_2
  SHX10_2 = SHX1_2
  SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  SHX7_2 = SHX15_1
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.set
  SHX9_2 = "reaper:"
  SHX10_2 = SHX0_1
  SHX11_2 = SHX10_2
  SHX10_2 = SHX10_2.hash
  SHX12_2 = SHX0_2
  SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
  SHX9_2 = SHX9_2 .. SHX10_2
  SHX10_2 = {}
  SHX11_2 = SHX0_1
  SHX12_2 = SHX11_2
  SHX11_2 = SHX11_2.hash
  SHX13_2 = SHX0_2
  SHX14_2 = SHX16_1
  SHX15_2 = SHX1_2
  SHX14_2 = SHX14_2(SHX15_2)
  SHX15_2 = SHX4_2
  SHX13_2 = SHX13_2 .. SHX14_2 .. SHX15_2
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
  SHX10_2.key = SHX11_2
  SHX10_2.key2 = SHX4_2
  SHX10_2.key3 = SHX1_2
  SHX10_2.eventName = SHX0_2
  SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  SHX7_2 = SHX18_1
  SHX8_2 = StateRecorder
  SHX9_2 = {}
  SHX9_2.index = SHX0_2
  SHX9_2.value = SHX1_2
  SHX9_2.id = SHX3_2
  SHX9_2.invoking_resource = SHX6_2
  SHX9_2.path = SHX2_2
  SHX9_2.time = SHX4_2
  SHX10_2 = SHX10_1
  SHX10_2 = SHX10_2()
  SHX9_2.h_time = SHX10_2
  SHX7_2(SHX8_2, SHX9_2)
  SHX7_2 = SHX1_1
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.getLogLevel
  SHX7_2 = SHX7_2(SHX8_2)
  if 1 == SHX7_2 then
    SHX7_2 = SHX1_1
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.log
    SHX9_2 = "(^3state:%s^7) was just set to (^3value:%s^7) from (^3path:%s^7) (^3resource:%s^7) (^3id:%s^7)"
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.format
    SHX11_2 = SHX0_2
    SHX12_2 = SHX16_1
    SHX13_2 = SHX1_2
    SHX12_2 = SHX12_2(SHX13_2)
    SHX13_2 = SHX2_2
    SHX14_2 = SHX6_2
    SHX15_2 = SHX3_2
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
    SHX10_2 = "debug"
    SHX11_2 = SHX30_1
    SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  end
  SHX7_2 = true
  return SHX7_2
end
function SHX38_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX1_2 = SHX10_1
  SHX1_2 = SHX1_2()
  SHX2_2 = SHX11_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX36_1
  if SHX3_2 then
    SHX3_2 = SHX3_1
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.get
    SHX5_2 = SHX0_2.index
    SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
    SHX4_2 = SHX0_2.value
    if SHX3_2 ~= SHX4_2 then
      SHX3_2 = SHX2_1
      SHX4_2 = SHX3_2
      SHX3_2 = SHX3_2.emitNet
      SHX5_2 = "Reaper:LogPlayerState"
      SHX6_2 = SHX12_1
      SHX7_2 = {}
      SHX8_2 = SHX0_2.index
      SHX7_2.state = SHX8_2
      SHX8_2 = SHX0_2.value
      SHX7_2.value = SHX8_2
      SHX8_2 = SHX0_2.path
      SHX7_2.path = SHX8_2
      SHX7_2.invoking_resource = SHX2_2
      SHX8_2 = SHX0_2.executionId
      SHX7_2.executionId = SHX8_2
      SHX8_2 = SHX0_2.extendedExecutionId
      SHX7_2.extendedExecutionId = SHX8_2
      SHX8_2 = {}
      SHX8_2.indent = true
      SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = SHX6_2(SHX7_2, SHX8_2)
      SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
    end
  end
  SHX3_2 = SHX0_2.native
  if SHX3_2 then
    SHX3_2 = SHX5_1
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.evaluateNative
    SHX5_2 = SHX0_2.native
    SHX6_2 = {}
    SHX7_2 = {}
    SHX7_2.resource = SHX2_2
    SHX8_2 = SHX0_2.path
    SHX7_2.path = SHX8_2
    SHX8_2 = SHX0_2.executionId
    SHX7_2.executionId = SHX8_2
    SHX8_2 = SHX0_2.extendedExecutionId
    SHX7_2.extendedExecutionId = SHX8_2
    SHX8_2 = SHX0_2.params
    SHX7_2.params = SHX8_2
    SHX6_2.req = SHX7_2
    SHX3_2, SHX4_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  end
  SHX3_2 = SHX3_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.set
  SHX5_2 = SHX0_2.index
  SHX6_2 = SHX0_2.value
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = SHX15_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.set
  SHX5_2 = "reaper:"
  SHX6_2 = SHX0_1
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.hash
  SHX8_2 = SHX0_2.index
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX5_2 = SHX5_2 .. SHX6_2
  SHX6_2 = {}
  SHX7_2 = SHX0_1
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.hash
  SHX9_2 = SHX0_2.index
  SHX10_2 = SHX16_1
  SHX11_2 = SHX0_2.value
  SHX10_2 = SHX10_2(SHX11_2)
  SHX11_2 = SHX1_2
  SHX9_2 = SHX9_2 .. SHX10_2 .. SHX11_2
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX6_2.key = SHX7_2
  SHX6_2.key2 = SHX1_2
  SHX7_2 = SHX0_2.value
  SHX6_2.key3 = SHX7_2
  SHX7_2 = SHX0_2.index
  SHX6_2.eventName = SHX7_2
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = true
  return SHX3_2
end
function SHX39_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX1_2 = SHX11_1
  SHX1_2 = SHX1_2()
  SHX2_2 = SHX5_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.evaluateNative
  SHX4_2 = SHX0_2.native
  SHX5_2 = {}
  SHX6_2 = {}
  SHX6_2.resource = SHX1_2
  SHX7_2 = SHX0_2.path
  SHX6_2.path = SHX7_2
  SHX7_2 = SHX0_2.executionId
  SHX6_2.executionId = SHX7_2
  SHX7_2 = SHX0_2.extendedExecutionId
  SHX6_2.extendedExecutionId = SHX7_2
  SHX7_2 = SHX0_2.params
  SHX6_2.params = SHX7_2
  SHX5_2.req = SHX6_2
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  return SHX3_2
end
function SHX40_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX4_2 = SHX3_1
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.newDetection
  SHX6_2 = SHX0_2
  SHX7_2 = SHX1_2
  SHX8_2 = SHX2_2
  SHX9_2 = SHX3_2
  return SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
end
SHX41_1 = {}
SHX42_1 = SHX22_1
SHX43_1 = SHX35_1
SHX42_1 = SHX42_1(SHX43_1)
SHX41_1.IsExecutionValid = SHX42_1
SHX42_1 = SHX22_1
SHX43_1 = SHX37_1
SHX42_1 = SHX42_1(SHX43_1)
SHX41_1.SetState = SHX42_1
SHX42_1 = SHX22_1
SHX43_1 = SHX38_1
SHX42_1 = SHX42_1(SHX43_1)
SHX41_1.SetState2 = SHX42_1
SHX42_1 = SHX22_1
SHX43_1 = SHX32_1
SHX42_1 = SHX42_1(SHX43_1)
SHX41_1.SetStateData = SHX42_1
SHX42_1 = SHX22_1
SHX43_1 = SHX40_1
SHX42_1 = SHX42_1(SHX43_1)
SHX41_1.NewDetection = SHX42_1
SHX42_1 = SHX22_1
SHX43_1 = SHX39_1
SHX42_1 = SHX42_1(SHX43_1)
SHX41_1.EvaluateNative = SHX42_1
SHX42_1 = {}
SHX44_1 = SHX2_1
SHX43_1 = SHX2_1.onNet
SHX45_1 = "onResourceStop"
function SHX46_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = SHX11_1
  SHX1_2 = SHX1_2()
  if nil ~= SHX1_2 then
    return
  end
  SHX2_2 = SHX42_1
  SHX2_2[SHX0_2] = nil
end
SHX43_1(SHX44_1, SHX45_1, SHX46_1)
SHX43_1 = AddEventHandler
SHX44_1 = "onResourceStop"
function SHX45_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = SHX11_1
  SHX1_2 = SHX1_2()
  if nil == SHX1_2 then
    SHX3_2 = SHX23_1
    SHX2_2 = SHX23_1
    SHX2_2[SHX3_2] = nil
  end
end
SHX43_1(SHX44_1, SHX45_1)
SHX43_1 = exports
SHX44_1 = "GetReaperKeys"
function SHX45_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2
  SHX0_2 = SHX11_1
  SHX0_2 = SHX0_2()
  SHX1_2 = SHX23_1
  SHX1_2 = SHX1_2[SHX0_2]
  if SHX1_2 then
    SHX1_2 = error
    SHX2_2 = "[ReaperV4] Keys already requested for this resource"
    SHX1_2(SHX2_2)
    return
  end
  if nil ~= SHX0_2 then
    SHX1_2 = SHX42_1
    SHX1_2 = SHX1_2[SHX0_2]
    if not SHX1_2 then
      goto SHX_LABEL_18
    end
  end
  return
  -- [FIX IF ERROR] Move ::SHX_LABEL_18:: outside nested blocks until all 'goto SHX_LABEL_18' can see it
  ::SHX_LABEL_18::
  SHX1_2 = SHX42_1
  SHX1_2[SHX0_2] = true
  SHX1_2 = SHX23_1
  SHX1_2 = SHX1_2[SHX0_2]
  SHX41_1.security_key = SHX1_2
  SHX1_2 = SHX41_1
  return SHX1_2
end
SHX43_1(SHX44_1, SHX45_1)
SHX43_1 = {}
SHX44_1 = _G
SHX44_1 = SHX44_1.RequestEntitySpawn
SHX45_1 = _G
SHX45_1 = SHX45_1.GetExecutionData
SHX46_1 = _G
SHX46_1.GetExecutionData = nil
SHX46_1 = _G
SHX46_1.RequestEntitySpawn = nil
SHX47_1 = SHX2_1
SHX46_1 = SHX2_1.onNet
SHX48_1 = "Reaper:RequestVehicle"
function SHX49_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = SHX3_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.set
  SHX4_2 = "enteringVehicle"
  SHX5_2 = SHX10_1
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2()
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  SHX2_2 = SHX43_1
  SHX2_2 = SHX2_2[SHX0_2]
  if not SHX2_2 then
    SHX2_2 = SHX11_1
    SHX2_2 = SHX2_2()
    if "vMenu" == SHX2_2 then
      goto SHX_LABEL_23
    end
  end
  SHX2_2 = LocalPlayer
  SHX2_2 = SHX2_2.state
  SHX3_2 = "reaper:"
  SHX4_2 = SHX0_2
  SHX5_2 = SHX1_2
  SHX3_2 = SHX3_2 .. SHX4_2 .. SHX5_2
  SHX2_2[SHX3_2] = true
  return
  -- [FIX IF ERROR] Move ::SHX_LABEL_23:: outside nested blocks until all 'goto SHX_LABEL_23' can see it
  ::SHX_LABEL_23::
  SHX2_2 = SHX45_1
  SHX3_2 = 2
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  SHX4_2 = SHX44_1
  SHX5_2 = SHX0_2
  SHX6_2 = 2
  SHX7_2 = SHX2_2
  SHX8_2 = SHX3_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  if SHX4_2 then
    SHX5_2 = SHX43_1
    SHX5_2[SHX0_2] = true
    SHX5_2 = LocalPlayer
    SHX5_2 = SHX5_2.state
    SHX6_2 = "reaper:"
    SHX7_2 = SHX0_2
    SHX8_2 = SHX1_2
    SHX6_2 = SHX6_2 .. SHX7_2 .. SHX8_2
    SHX5_2[SHX6_2] = true
  else
    SHX5_2 = SHX43_1
    SHX5_2[SHX0_2] = false
  end
end
SHX46_1(SHX47_1, SHX48_1, SHX49_1)
SHX46_1 = {}
SHX46_1.antiTeleport = true
SHX46_1.antiInvisible = true
SHX46_1.antiNoClip = true
SHX46_1.antiFreeCam = true
SHX46_1.antiFreeCam2 = true
SHX46_1.antiFreeCam3 = true
SHX46_1.antiGodMode = true
SHX46_1.antiVehicleModifier = true
SHX46_1.antiSkinChanger = true
SHX47_1 = exports
SHX48_1 = "HookDetection"
function SHX49_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX46_1
  SHX2_2 = SHX2_2[SHX0_2]
  if nil == SHX2_2 then
    SHX2_2 = SHX1_1
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.log
    SHX4_2 = "[^3HookDetection^7] -> Invalid detection name. ^3%s^7 is not a valid detection type"
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.format
    SHX6_2 = SHX0_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    SHX5_2 = "error"
    return SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  end
  SHX2_2 = SHX3_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.get
  SHX4_2 = "running_detections"
  SHX5_2 = false
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  if SHX2_2 then
    SHX2_2 = SHX1_1
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.log
    SHX4_2 = "[^3HookDetection^7] -> Was called too late. This can only be called when the player first joins"
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.format
    SHX6_2 = SHX0_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    SHX5_2 = "error"
    return SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  end
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.addDetectionHook
  SHX4_2 = SHX0_2
  SHX5_2 = SHX1_2
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = true
  return SHX2_2
end
SHX47_1(SHX48_1, SHX49_1)
SHX15_1.ExportsLoaded = true
SHX15_1.ReaperIsRunning = true
if "gta5" == SHX25_1 then
  SHX47_1 = SHX9_1
  function SHX48_1()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2, SHX34_2, SHX35_2, SHX36_2, SHX37_2, SHX38_2, SHX39_2, SHX40_2, SHX41_2, SHX42_2, SHX43_2, SHX44_2, SHX45_2, SHX46_2, SHX47_2, SHX48_2, SHX49_2, SHX50_2
    SHX0_2 = {}
    SHX1_2 = "PICKUP_AMMO_BULLET_MP"
    SHX2_2 = "PICKUP_AMMO_FIREWORK"
    SHX3_2 = "PICKUP_AMMO_FLAREGUN"
    SHX4_2 = "PICKUP_AMMO_GRENADELAUNCHER"
    SHX5_2 = "PICKUP_AMMO_GRENADELAUNCHER_MP"
    SHX6_2 = "PICKUP_AMMO_HOMINGLAUNCHER"
    SHX7_2 = "PICKUP_AMMO_MG"
    SHX8_2 = "PICKUP_AMMO_MINIGUN"
    SHX9_2 = "PICKUP_AMMO_MISSILE_MP"
    SHX10_2 = "PICKUP_AMMO_PISTOL"
    SHX11_2 = "PICKUP_AMMO_RIFLE"
    SHX12_2 = "PICKUP_AMMO_RPG"
    SHX13_2 = "PICKUP_AMMO_SHOTGUN"
    SHX14_2 = "PICKUP_AMMO_SMG"
    SHX15_2 = "PICKUP_AMMO_SNIPER"
    SHX16_2 = "PICKUP_ARMOUR_STANDARD"
    SHX17_2 = "PICKUP_CAMERA"
    SHX18_2 = "PICKUP_CUSTOM_SCRIPT"
    SHX19_2 = "PICKUP_GANG_ATTACK_MONEY"
    SHX20_2 = "PICKUP_HEALTH_SNACK"
    SHX21_2 = "PICKUP_HEALTH_STANDARD"
    SHX22_2 = "PICKUP_MONEY_CASE"
    SHX23_2 = "PICKUP_MONEY_DEP_BAG"
    SHX24_2 = "PICKUP_MONEY_MED_BAG"
    SHX25_2 = "PICKUP_MONEY_PAPER_BAG"
    SHX26_2 = "PICKUP_MONEY_PURSE"
    SHX27_2 = "PICKUP_MONEY_SECURITY_CASE"
    SHX28_2 = "PICKUP_MONEY_VARIABLE"
    SHX29_2 = "PICKUP_MONEY_WALLET"
    SHX30_2 = "PICKUP_PARACHUTE"
    SHX31_2 = "PICKUP_PORTABLE_CRATE_FIXED_INCAR"
    SHX32_2 = "PICKUP_PORTABLE_CRATE_UNFIXED"
    SHX33_2 = "PICKUP_PORTABLE_CRATE_UNFIXED_INCAR"
    SHX34_2 = "PICKUP_PORTABLE_CRATE_UNFIXED_INCAR_SMALL"
    SHX35_2 = "PICKUP_PORTABLE_CRATE_UNFIXED_LOW_GLOW"
    SHX36_2 = "PICKUP_PORTABLE_DLC_VEHICLE_PACKAGE"
    SHX37_2 = "PICKUP_PORTABLE_PACKAGE"
    SHX38_2 = "PICKUP_SUBMARINE"
    SHX39_2 = "PICKUP_VEHICLE_ARMOUR_STANDARD"
    SHX40_2 = "PICKUP_VEHICLE_CUSTOM_SCRIPT"
    SHX41_2 = "PICKUP_VEHICLE_CUSTOM_SCRIPT_LOW_GLOW"
    SHX42_2 = "PICKUP_VEHICLE_HEALTH_STANDARD"
    SHX43_2 = "PICKUP_VEHICLE_HEALTH_STANDARD_LOW_GLOW"
    SHX44_2 = "PICKUP_VEHICLE_MONEY_VARIABLE"
    SHX45_2 = "PICKUP_VEHICLE_WEAPON_APPISTOL"
    SHX46_2 = "PICKUP_VEHICLE_WEAPON_ASSAULTSMG"
    SHX47_2 = "PICKUP_VEHICLE_WEAPON_COMBATPISTOL"
    SHX48_2 = "PICKUP_VEHICLE_WEAPON_GRENADE"
    SHX49_2 = "PICKUP_VEHICLE_WEAPON_MICROSMG"
    SHX50_2 = "PICKUP_VEHICLE_WEAPON_MOLOTOV"
    SHX0_2[1] = SHX1_2
    SHX0_2[2] = SHX2_2
    SHX0_2[3] = SHX3_2
    SHX0_2[4] = SHX4_2
    SHX0_2[5] = SHX5_2
    SHX0_2[6] = SHX6_2
    SHX0_2[7] = SHX7_2
    SHX0_2[8] = SHX8_2
    SHX0_2[9] = SHX9_2
    SHX0_2[10] = SHX10_2
    SHX0_2[11] = SHX11_2
    SHX0_2[12] = SHX12_2
    SHX0_2[13] = SHX13_2
    SHX0_2[14] = SHX14_2
    SHX0_2[15] = SHX15_2
    SHX0_2[16] = SHX16_2
    SHX0_2[17] = SHX17_2
    SHX0_2[18] = SHX18_2
    SHX0_2[19] = SHX19_2
    SHX0_2[20] = SHX20_2
    SHX0_2[21] = SHX21_2
    SHX0_2[22] = SHX22_2
    SHX0_2[23] = SHX23_2
    SHX0_2[24] = SHX24_2
    SHX0_2[25] = SHX25_2
    SHX0_2[26] = SHX26_2
    SHX0_2[27] = SHX27_2
    SHX0_2[28] = SHX28_2
    SHX0_2[29] = SHX29_2
    SHX0_2[30] = SHX30_2
    SHX0_2[31] = SHX31_2
    SHX0_2[32] = SHX32_2
    SHX0_2[33] = SHX33_2
    SHX0_2[34] = SHX34_2
    SHX0_2[35] = SHX35_2
    SHX0_2[36] = SHX36_2
    SHX0_2[37] = SHX37_2
    SHX0_2[38] = SHX38_2
    SHX0_2[39] = SHX39_2
    SHX0_2[40] = SHX40_2
    SHX0_2[41] = SHX41_2
    SHX0_2[42] = SHX42_2
    SHX0_2[43] = SHX43_2
    SHX0_2[44] = SHX44_2
    SHX0_2[45] = SHX45_2
    SHX0_2[46] = SHX46_2
    SHX0_2[47] = SHX47_2
    SHX0_2[48] = SHX48_2
    SHX0_2[49] = SHX49_2
    SHX0_2[50] = SHX50_2
    SHX1_2 = "PICKUP_VEHICLE_WEAPON_PISTOL"
    SHX2_2 = "PICKUP_VEHICLE_WEAPON_PISTOL50"
    SHX3_2 = "PICKUP_VEHICLE_WEAPON_SAWNOFF"
    SHX4_2 = "PICKUP_VEHICLE_WEAPON_SMG"
    SHX5_2 = "PICKUP_VEHICLE_WEAPON_SMOKEGRENADE"
    SHX6_2 = "PICKUP_VEHICLE_WEAPON_STICKYBOMB"
    SHX7_2 = "PICKUP_WEAPON_ADVANCEDRIFLE"
    SHX8_2 = "PICKUP_WEAPON_APPISTOL"
    SHX9_2 = "PICKUP_WEAPON_ASSAULTRIFLE"
    SHX10_2 = "PICKUP_WEAPON_ASSAULTSHOTGUN"
    SHX11_2 = "PICKUP_WEAPON_ASSAULTSMG"
    SHX12_2 = "PICKUP_WEAPON_AUTOSHOTGUN"
    SHX13_2 = "PICKUP_WEAPON_BAT"
    SHX14_2 = "PICKUP_WEAPON_BATTLEAXE"
    SHX15_2 = "PICKUP_WEAPON_BOTTLE"
    SHX16_2 = "PICKUP_WEAPON_BULLPUPRIFLE"
    SHX17_2 = "PICKUP_WEAPON_BULLPUPSHOTGUN"
    SHX18_2 = "PICKUP_WEAPON_CARBINERIFLE"
    SHX19_2 = "PICKUP_WEAPON_COMBATMG"
    SHX20_2 = "PICKUP_WEAPON_COMBATPDW"
    SHX21_2 = "PICKUP_WEAPON_COMBATPISTOL"
    SHX22_2 = "PICKUP_WEAPON_COMPACTLAUNCHER"
    SHX23_2 = "PICKUP_WEAPON_COMPACTRIFLE"
    SHX24_2 = "PICKUP_WEAPON_CROWBAR"
    SHX25_2 = "PICKUP_WEAPON_DAGGER"
    SHX26_2 = "PICKUP_WEAPON_DBSHOTGUN"
    SHX27_2 = "PICKUP_WEAPON_FIREWORK"
    SHX28_2 = "PICKUP_WEAPON_FLAREGUN"
    SHX29_2 = "PICKUP_WEAPON_FLASHLIGHT"
    SHX30_2 = "PICKUP_WEAPON_GRENADE"
    SHX31_2 = "PICKUP_WEAPON_GRENADELAUNCHER"
    SHX32_2 = "PICKUP_WEAPON_GUSENBERG"
    SHX33_2 = "PICKUP_WEAPON_GOLFCLUB"
    SHX34_2 = "PICKUP_WEAPON_HAMMER"
    SHX35_2 = "PICKUP_WEAPON_HATCHET"
    SHX36_2 = "PICKUP_WEAPON_HEAVYPISTOL"
    SHX37_2 = "PICKUP_WEAPON_HEAVYSHOTGUN"
    SHX38_2 = "PICKUP_WEAPON_HEAVYSNIPER"
    SHX39_2 = "PICKUP_WEAPON_HOMINGLAUNCHER"
    SHX40_2 = "PICKUP_WEAPON_KNIFE"
    SHX41_2 = "PICKUP_WEAPON_KNUCKLE"
    SHX42_2 = "PICKUP_WEAPON_MACHETE"
    SHX43_2 = "PICKUP_WEAPON_MACHINEPISTOL"
    SHX44_2 = "PICKUP_WEAPON_MARKSMANPISTOL"
    SHX45_2 = "PICKUP_WEAPON_MARKSMANRIFLE"
    SHX46_2 = "PICKUP_WEAPON_MG"
    SHX47_2 = "PICKUP_WEAPON_MICROSMG"
    SHX48_2 = "PICKUP_WEAPON_MINIGUN"
    SHX49_2 = "PICKUP_WEAPON_MINISMG"
    SHX50_2 = "PICKUP_WEAPON_MOLOTOV"
    SHX0_2[51] = SHX1_2
    SHX0_2[52] = SHX2_2
    SHX0_2[53] = SHX3_2
    SHX0_2[54] = SHX4_2
    SHX0_2[55] = SHX5_2
    SHX0_2[56] = SHX6_2
    SHX0_2[57] = SHX7_2
    SHX0_2[58] = SHX8_2
    SHX0_2[59] = SHX9_2
    SHX0_2[60] = SHX10_2
    SHX0_2[61] = SHX11_2
    SHX0_2[62] = SHX12_2
    SHX0_2[63] = SHX13_2
    SHX0_2[64] = SHX14_2
    SHX0_2[65] = SHX15_2
    SHX0_2[66] = SHX16_2
    SHX0_2[67] = SHX17_2
    SHX0_2[68] = SHX18_2
    SHX0_2[69] = SHX19_2
    SHX0_2[70] = SHX20_2
    SHX0_2[71] = SHX21_2
    SHX0_2[72] = SHX22_2
    SHX0_2[73] = SHX23_2
    SHX0_2[74] = SHX24_2
    SHX0_2[75] = SHX25_2
    SHX0_2[76] = SHX26_2
    SHX0_2[77] = SHX27_2
    SHX0_2[78] = SHX28_2
    SHX0_2[79] = SHX29_2
    SHX0_2[80] = SHX30_2
    SHX0_2[81] = SHX31_2
    SHX0_2[82] = SHX32_2
    SHX0_2[83] = SHX33_2
    SHX0_2[84] = SHX34_2
    SHX0_2[85] = SHX35_2
    SHX0_2[86] = SHX36_2
    SHX0_2[87] = SHX37_2
    SHX0_2[88] = SHX38_2
    SHX0_2[89] = SHX39_2
    SHX0_2[90] = SHX40_2
    SHX0_2[91] = SHX41_2
    SHX0_2[92] = SHX42_2
    SHX0_2[93] = SHX43_2
    SHX0_2[94] = SHX44_2
    SHX0_2[95] = SHX45_2
    SHX0_2[96] = SHX46_2
    SHX0_2[97] = SHX47_2
    SHX0_2[98] = SHX48_2
    SHX0_2[99] = SHX49_2
    SHX0_2[100] = SHX50_2
    SHX1_2 = "PICKUP_WEAPON_MUSKET"
    SHX2_2 = "PICKUP_WEAPON_NIGHTSTICK"
    SHX3_2 = "PICKUP_WEAPON_PETROLCAN"
    SHX4_2 = "PICKUP_WEAPON_PIPEBOMB"
    SHX5_2 = "PICKUP_WEAPON_PISTOL"
    SHX6_2 = "PICKUP_WEAPON_PISTOL50"
    SHX7_2 = "PICKUP_WEAPON_POOLCUE"
    SHX8_2 = "PICKUP_WEAPON_PROXMINE"
    SHX9_2 = "PICKUP_WEAPON_PUMPSHOTGUN"
    SHX10_2 = "PICKUP_WEAPON_RAILGUN"
    SHX11_2 = "PICKUP_WEAPON_REVOLVER"
    SHX12_2 = "PICKUP_WEAPON_RPG"
    SHX13_2 = "PICKUP_WEAPON_SAWNOFFSHOTGUN"
    SHX14_2 = "PICKUP_WEAPON_SMG"
    SHX15_2 = "PICKUP_WEAPON_SMOKEGRENADE"
    SHX16_2 = "PICKUP_WEAPON_SNIPERRIFLE"
    SHX17_2 = "PICKUP_WEAPON_SNSPISTOL"
    SHX18_2 = "PICKUP_WEAPON_SPECIALCARBINE"
    SHX19_2 = "PICKUP_WEAPON_STICKYBOMB"
    SHX20_2 = "PICKUP_WEAPON_STUNGUN"
    SHX21_2 = "PICKUP_WEAPON_SWITCHBLADE"
    SHX22_2 = "PICKUP_WEAPON_VINTAGEPISTOL"
    SHX23_2 = "PICKUP_WEAPON_WRENCH"
    SHX24_2 = "PICKUP_WEAPON_RAYCARBINE"
    SHX0_2[101] = SHX1_2
    SHX0_2[102] = SHX2_2
    SHX0_2[103] = SHX3_2
    SHX0_2[104] = SHX4_2
    SHX0_2[105] = SHX5_2
    SHX0_2[106] = SHX6_2
    SHX0_2[107] = SHX7_2
    SHX0_2[108] = SHX8_2
    SHX0_2[109] = SHX9_2
    SHX0_2[110] = SHX10_2
    SHX0_2[111] = SHX11_2
    SHX0_2[112] = SHX12_2
    SHX0_2[113] = SHX13_2
    SHX0_2[114] = SHX14_2
    SHX0_2[115] = SHX15_2
    SHX0_2[116] = SHX16_2
    SHX0_2[117] = SHX17_2
    SHX0_2[118] = SHX18_2
    SHX0_2[119] = SHX19_2
    SHX0_2[120] = SHX20_2
    SHX0_2[121] = SHX21_2
    SHX0_2[122] = SHX22_2
    SHX0_2[123] = SHX23_2
    SHX0_2[124] = SHX24_2
    SHX1_2 = 1
    SHX2_2 = #SHX0_2
    SHX3_2 = 1
    for SHX4_2 = SHX1_2, SHX2_2, SHX3_2 do
      SHX5_2 = ToggleUsePickupsForPlayer
      SHX6_2 = PlayerId
      SHX6_2 = SHX6_2()
      SHX7_2 = GetHashKey
      SHX8_2 = SHX0_2[SHX4_2]
      SHX7_2 = SHX7_2(SHX8_2)
      SHX8_2 = false
      SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    end
  end
  SHX47_1(SHX48_1)
end
SHX47_1 = SHX3_1
SHX48_1 = exports
SHX49_1 = "InvokeCPlayer"
function SHX50_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = SHX11_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX23_1
  SHX3_2 = SHX3_2[SHX2_2]
  if SHX3_2 ~= SHX0_2 then
    SHX3_2 = SHX0_1
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.detection
    SHX5_2 = "antiCheatBypass"
    SHX6_2 = {}
    SHX7_2 = {}
    SHX8_2 = "Attempting to run InvokeCPlayer with an invalid key."
    SHX7_2[1] = SHX8_2
    SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2)
    return
  end
  SHX3_2 = type
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  if "string" == SHX3_2 then
    SHX3_2 = SHX47_1
    SHX3_2 = SHX3_2[SHX1_2]
    if nil ~= SHX3_2 then
      goto SHX_LABEL_30
    end
  end
  SHX3_2 = "INVALID_METHOD"
  return SHX3_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_30:: outside nested blocks until all 'goto SHX_LABEL_30' can see it
  ::SHX_LABEL_30::
  SHX3_2 = SHX47_1
  SHX3_2 = SHX3_2[SHX1_2]
  SHX4_2 = SHX47_1
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = ...
  return SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
end
SHX48_1(SHX49_1, SHX50_1)
SHX48_1 = SHX2_1
SHX49_1 = exports
SHX50_1 = "InvokeCRPC"
function SHX51_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = SHX11_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX23_1
  SHX3_2 = SHX3_2[SHX2_2]
  if SHX3_2 ~= SHX0_2 then
    SHX3_2 = SHX0_1
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.detection
    SHX5_2 = "antiCheatBypass"
    SHX6_2 = {}
    SHX7_2 = {}
    SHX8_2 = "Attempting to run InvokeCRPC with an invalid key."
    SHX7_2[1] = SHX8_2
    SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2)
    return
  end
  SHX3_2 = type
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  if "string" == SHX3_2 then
    SHX3_2 = SHX48_1
    SHX3_2 = SHX3_2[SHX1_2]
    if nil ~= SHX3_2 then
      goto SHX_LABEL_30
    end
  end
  SHX3_2 = "INVALID_METHOD"
  return SHX3_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_30:: outside nested blocks until all 'goto SHX_LABEL_30' can see it
  ::SHX_LABEL_30::
  SHX3_2 = SHX48_1
  SHX3_2 = SHX3_2[SHX1_2]
  SHX4_2 = SHX48_1
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = ...
  return SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
end
SHX49_1(SHX50_1, SHX51_1)
