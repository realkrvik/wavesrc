-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1, SHX21_1, SHX22_1, SHX23_1, SHX24_1, SHX25_1, SHX26_1, SHX27_1, SHX28_1, SHX29_1, SHX30_1, SHX31_1, SHX32_1, SHX33_1, SHX34_1, SHX35_1
SHX0_1 = GetCurrentResourceName
SHX0_1 = SHX0_1()
if "ReaperV4" == SHX0_1 then
  return
end
SHX0_1 = msgpack
SHX1_1 = print
SHX2_1 = Citizen
SHX2_1 = SHX2_1.PointerValueInt
SHX2_1 = SHX2_1()
SHX3_1 = Citizen
SHX3_1 = SHX3_1.PointerValueFloat
SHX3_1 = SHX3_1()
SHX4_1 = Citizen
SHX4_1 = SHX4_1.PointerValueVector
SHX4_1 = SHX4_1()
SHX5_1 = Citizen
SHX5_1 = SHX5_1.ReturnResultAnyway
SHX5_1 = SHX5_1()
SHX6_1 = Citizen
SHX6_1 = SHX6_1.ResultAsInteger
SHX6_1 = SHX6_1()
SHX7_1 = Citizen
SHX7_1 = SHX7_1.ResultAsFloat
SHX7_1 = SHX7_1()
SHX8_1 = Citizen
SHX8_1 = SHX8_1.ResultAsLong
SHX8_1 = SHX8_1()
SHX9_1 = Citizen
SHX9_1 = SHX9_1.ResultAsString
SHX9_1 = SHX9_1()
SHX10_1 = Citizen
SHX10_1 = SHX10_1.ResultAsVector
SHX10_1 = SHX10_1()
SHX11_1 = Citizen
SHX11_1 = SHX11_1.ResultAsObject2
SHX12_1 = SHX0_1.unpack
SHX11_1 = SHX11_1(SHX12_1)
SHX12_1 = Citizen
SHX12_1 = SHX12_1.InvokeNative
SHX13_1 = Citizen
SHX13_1 = SHX13_1.PointerValueIntInitialized
SHX14_1 = Citizen
SHX14_1 = SHX14_1.PointerValueFloatInitialized
SHX15_1 = Citizen
SHX15_1 = SHX15_1.InvokeNative2
SHX16_1 = Citizen
SHX16_1 = SHX16_1.GetNative
SHX17_1 = _G
SHX18_1 = rawget
SHX19_1 = rawset
SHX20_1 = Citizen
SHX20_1 = SHX20_1.LoadNative
SHX21_1 = load
SHX22_1 = SHX0_1.pack
SHX23_1 = tostring
SHX24_1 = type
function SHX25_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  if 0 == SHX0_2 or not SHX0_2 then
    SHX1_2 = nil
    return SHX1_2
  end
  SHX1_2 = SHX23_1
  SHX2_2 = SHX0_2
  return SHX1_2(SHX2_2)
end
function SHX26_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = SHX22_1
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = SHX1_2
  SHX3_2 = #SHX1_2
  return SHX2_2, SHX3_2
end
function SHX27_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = SHX17_1.type
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if "string" == SHX1_2 then
    SHX1_2 = SHX17_1.GetHashKey
    SHX2_2 = SHX0_2
    return SHX1_2(SHX2_2)
  end
  return SHX0_2
end
function SHX28_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = SHX17_1.Citizen
  SHX1_2 = SHX1_2.GetFunctionReference
  SHX2_2 = SHX0_2
  return SHX1_2(SHX2_2)
end
SHX29_1 = setmetatable
SHX30_1 = {}
SHX31_1 = {}
function SHX32_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX3_2 = SHX17_1
  SHX3_2[SHX1_2] = SHX2_2
  SHX3_2 = SHX19_1
  SHX4_2 = SHX0_2
  SHX5_2 = SHX1_2
  SHX6_2 = SHX2_2
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
end
SHX31_1.__newindex = SHX32_1
SHX29_1 = SHX29_1(SHX30_1, SHX31_1)
SHX30_1 = {}
SHX30_1.Global = SHX29_1
SHX30_1._mfr = SHX28_1
SHX30_1._obj = SHX26_1
SHX30_1._ch = SHX27_1
SHX30_1._ts = SHX25_1
SHX30_1.msgpack = SHX0_1
SHX30_1.rs = SHX19_1
SHX30_1._i = SHX2_1
SHX30_1._f = SHX3_1
SHX30_1._v = SHX4_1
SHX30_1._r = SHX5_1
SHX30_1._ri = SHX6_1
SHX30_1._rf = SHX7_1
SHX30_1._rl = SHX8_1
SHX30_1._s = SHX9_1
SHX30_1._rv = SHX10_1
SHX30_1._ro = SHX11_1
SHX30_1._in = SHX12_1
SHX30_1._in2 = SHX15_1
SHX30_1._gn = SHX16_1
SHX30_1._ii = SHX13_1
SHX30_1._fi = SHX14_1
SHX30_1.print = SHX1_1
SHX31_1 = {}
SHX32_1 = setmetatable
SHX33_1 = _G
SHX34_1 = {}
function SHX35_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX2_2 = SHX18_1
  SHX3_2 = SHX0_2
  SHX4_2 = SHX1_2
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if not SHX2_2 then
    SHX3_2 = SHX31_1
    SHX3_2 = SHX3_2[SHX1_2]
    if not SHX3_2 then
      SHX3_2 = SHX20_1
      SHX4_2 = SHX1_2
      SHX3_2 = SHX3_2(SHX4_2)
      if SHX3_2 then
        SHX4_2 = SHX24_1
        SHX5_2 = SHX3_2
        SHX4_2 = SHX4_2(SHX5_2)
        if "function" == SHX4_2 then
          SHX4_2 = SHX19_1
          SHX5_2 = SHX0_2
          SHX6_2 = SHX1_2
          SHX7_2 = SHX3_2
          SHX4_2(SHX5_2, SHX6_2, SHX7_2)
          SHX2_2 = SHX3_2
        else
          SHX4_2 = SHX21_1
          SHX5_2 = SHX3_2
          SHX6_2 = "@"
          SHX7_2 = SHX1_2
          SHX8_2 = ".lua"
          SHX6_2 = SHX6_2 .. SHX7_2 .. SHX8_2
          SHX7_2 = "t"
          SHX8_2 = SHX30_1
          SHX4_2, SHX5_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
          if SHX4_2 then
            SHX6_2 = SHX4_2
            SHX6_2()
            SHX6_2 = _G
            SHX6_2 = SHX6_2[SHX1_2]
            if SHX6_2 then
              SHX7_2 = _G
              function SHX8_2(...)
                -- [AI CLEANUP] Decompiled Lua - Fix these:
                -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
                -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
                -- 3. Replace goto/label with while/repeat-until where possible
                -- 4. Remove decompiler comments, add meaningful ones
                -- 5. Fix indentation and formatting
                
                local SHX0_3, SHX1_3, SHX2_3
                SHX0_3 = SHX1_1
                SHX1_3 = SHX1_2
                SHX2_3 = ...
                SHX0_3(SHX1_3, SHX2_3)
                SHX0_3 = SHX6_2
                SHX1_3, SHX2_3 = ...
                return SHX0_3(SHX1_3, SHX2_3)
              end
              SHX7_2[SHX1_2] = SHX8_2
            end
            SHX7_2 = SHX18_1
            SHX8_2 = SHX0_2
            SHX9_2 = SHX1_2
            SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
            SHX2_2 = SHX7_2
          else
            SHX6_2 = SHX1_1
            SHX7_2 = "no chunk"
            SHX8_2 = SHX5_2
            SHX6_2(SHX7_2, SHX8_2)
          end
        end
      else
        SHX4_2 = SHX31_1
        SHX4_2[SHX1_2] = true
      end
    end
  end
  return SHX2_2
end
SHX34_1.__index = SHX35_1
SHX32_1(SHX33_1, SHX34_1)
