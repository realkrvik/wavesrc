-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = Weapons
Weapons = SHX0_1
SHX0_1 = nil
SHX1_1 = nil
SHX2_1 = nil
SHX3_1 = false
SHX4_1 = {}
SHX5_1 = false
SHX6_1 = GetConvar
SHX7_1 = "reaper_beta_weapon_protection"
SHX8_1 = "true"
SHX6_1 = SHX6_1(SHX7_1, SHX8_1)
SHX6_1 = "true" == SHX6_1
SHX7_1 = {}
SHX8_1 = 2725352035
SHX7_1[SHX8_1] = true
SHX8_1 = {}
SHX9_1 = GetHashKey
SHX10_1 = "weapon_stungun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_dagger"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_bat"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_battleaxe"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_knuckle"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_bottle"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_crowbar"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_flashlight"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_golfclub"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_hammer"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_hatchet"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_knife"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_machete"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_nightstick"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_wrench"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_poolcue"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_stone_hatchet"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_switchblade"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_appistol"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_ceramicpistol"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_combatpistol"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_doubleaction"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_flaregun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_gadgetpistol"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_heavypistol"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_revolver"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_revolver_mk2"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_marksmanpistol"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_navyrevolver"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_pistol"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_pistol50"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_pistol_mk2"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_snspistol"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_snspistol_mk2"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_stungun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_raypistol"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_vintagepistol"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_assaultsmg"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_combatpdw"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_machinepistol"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_microsmg"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_minismg"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_smg"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_smg_mk2"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_raycarbine"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_assaultshotgun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_bullpupshotgun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_combatshotgun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_dbshotgun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_heavyshotgun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_musket"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_pumpshotgun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_pumpshotgun_mk2"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_sawnoffshotgun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_autoshotgun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_advancedrifle"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_assaultrifle"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_assaultrifle_mk2"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_bullpuprifle"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_bullpuprifle_mk2"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_carbinerifle"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_carbinerifle_mk2"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_compactrifle"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_militaryrifle"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_specialcarbine"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_specialcarbine_mk2"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_combatmg"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_combatmg_mk2"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_gusenberg"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_mg"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_heavysniper"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_heavysniper_mk2"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_marksmanrifle"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_marksmanrifle_mk2"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_sniperrifle"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_compactlauncher"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_firework"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_grenadelauncher"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_grenadelauncher_smoke"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_hominglauncher"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_minigun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_railgun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_rpg"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "weapon_rayminigun"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = 3219281620
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "WEAPON_FALL"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = 3452007600
SHX8_1[SHX9_1] = true
SHX9_1 = GetHashKey
SHX10_1 = "WEAPON_EXPLOSION"
SHX9_1 = SHX9_1(SHX10_1)
SHX8_1[SHX9_1] = true
SHX9_1 = 539292904
SHX8_1[SHX9_1] = true
SHX9_1 = 849905853
SHX8_1[SHX9_1] = true
SHX9_1 = pairs
SHX10_1 = WeaponsList
SHX10_1 = SHX10_1.KnownWeaponHashes
SHX9_1, SHX10_1, SHX11_1, SHX12_1 = SHX9_1(SHX10_1)
for SHX13_1, SHX14_1 in SHX9_1, SHX10_1, SHX11_1, SHX12_1 do
  SHX8_1[SHX13_1] = SHX14_1
end
SHX9_1 = newParser
SHX9_1 = SHX9_1()
function SHX10_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX3_2 = {}
  SHX4_2 = xpcall
  function SHX5_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3
    SHX0_3 = SHX9_1
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.ParseXmlText
    SHX2_3 = SHX0_2
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
    SHX1_3 = SHX0_3.CWeaponInfoBlob
    if nil == SHX1_3 then
      SHX1_3 = SHX3_2
      return SHX1_3
    end
    SHX1_3 = SHX0_3.CWeaponInfoBlob
    if SHX1_3 then
      SHX1_3 = SHX0_3.CWeaponInfoBlob
      SHX1_3 = SHX1_3.Infos
      if SHX1_3 then
        SHX1_3 = SHX0_3.CWeaponInfoBlob
        SHX1_3 = SHX1_3.Infos
        SHX1_3 = SHX1_3.Item
        if SHX1_3 then
          SHX1_3 = SHX0_3.CWeaponInfoBlob
          SHX1_3 = SHX1_3.Infos
          SHX1_3 = SHX1_3.Item
          SHX1_3 = SHX1_3[1]
          if SHX1_3 then
            SHX1_3 = pairs
            SHX2_3 = SHX0_3.CWeaponInfoBlob
            SHX2_3 = SHX2_3.Infos
            SHX2_3 = SHX2_3.Item
            SHX1_3, SHX2_3, SHX3_3, SHX4_3 = SHX1_3(SHX2_3)
            for SHX5_3, SHX6_3 in SHX1_3, SHX2_3, SHX3_3, SHX4_3 do
              SHX7_3 = type
              SHX8_3 = SHX6_3.Infos
              SHX8_3 = SHX8_3.Item
              SHX7_3 = SHX7_3(SHX8_3)
              if "table" == SHX7_3 then
                SHX7_3 = pairs
                SHX8_3 = SHX6_3.Infos
                SHX8_3 = SHX8_3.Item
                SHX7_3, SHX8_3, SHX9_3, SHX10_3 = SHX7_3(SHX8_3)
                for SHX11_3, SHX12_3 in SHX7_3, SHX8_3, SHX9_3, SHX10_3 do
                  SHX13_3 = type
                  SHX14_3 = SHX12_3
                  SHX13_3 = SHX13_3(SHX14_3)
                  if "table" == SHX13_3 then
                    SHX13_3 = pairs
                    SHX14_3 = SHX12_3
                    SHX13_3, SHX14_3, SHX15_3, SHX16_3 = SHX13_3(SHX14_3)
                    for SHX17_3, SHX18_3 in SHX13_3, SHX14_3, SHX15_3, SHX16_3 do
                      if "Name" == SHX17_3 then
                        SHX19_3 = table
                        SHX19_3 = SHX19_3.insert
                        SHX20_3 = SHX3_2
                        SHX22_3 = SHX18_3
                        SHX21_3 = SHX18_3.value
                        SHX21_3, SHX22_3 = SHX21_3(SHX22_3)
                        SHX19_3(SHX20_3, SHX21_3, SHX22_3)
                      end
                    end
                  end
                end
              end
              SHX7_3 = SHX6_3.Infos
              if SHX7_3 then
                SHX7_3 = SHX6_3.Infos
                SHX7_3 = SHX7_3.Item
                if SHX7_3 then
                  SHX7_3 = SHX6_3.Infos
                  SHX7_3 = SHX7_3.Item
                  SHX7_3 = SHX7_3.Name
                  if SHX7_3 then
                    SHX7_3 = table
                    SHX7_3 = SHX7_3.insert
                    SHX8_3 = SHX3_2
                    SHX9_3 = SHX6_3.Infos
                    SHX9_3 = SHX9_3.Item
                    SHX9_3 = SHX9_3.Name
                    SHX10_3 = SHX9_3
                    SHX9_3 = SHX9_3.value
                    SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX9_3(SHX10_3)
                    SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
                  end
                end
              end
            end
        end
      end
    end
    else
      SHX1_3 = table
      SHX1_3 = SHX1_3.insert
      SHX2_3 = SHX3_2
      SHX3_3 = SHX0_3.CWeaponInfoBlob
      SHX3_3 = SHX3_3.Infos
      SHX3_3 = SHX3_3.Item
      SHX3_3 = SHX3_3.Infos
      SHX3_3 = SHX3_3.Item
      SHX3_3 = SHX3_3.Name
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.value
      SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX3_3(SHX4_3)
      SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
    end
  end
  function SHX6_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX1_3 = Logger
    SHX2_3 = SHX1_3
    SHX1_3 = SHX1_3.log
    SHX3_3 = "(^3E1^7) Failed to load weapon data from ^3data_file 'WEAPONINFO_FILE' '%s'^7 defined in the resource ^3%s^7"
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.format
    SHX5_3 = SHX1_2
    SHX6_3 = SHX2_2
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    SHX4_3 = "error"
    SHX1_3(SHX2_3, SHX3_3, SHX4_3)
  end
  SHX4_2(SHX5_2, SHX6_2)
  return SHX3_2
end
SHX11_1 = table
SHX11_1 = SHX11_1.copy
SHX12_1 = SHX8_1
SHX11_1 = SHX11_1(SHX12_1)
SHX12_1 = RPC
SHX13_1 = SHX12_1
SHX12_1 = SHX12_1.on
SHX14_1 = "configUpdated"
function SHX15_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX1_2 = Settings
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.get
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = {}
  SHX11_1 = SHX2_2
  SHX2_2 = table
  SHX2_2 = SHX2_2.copy
  SHX3_2 = SHX8_1
  SHX2_2 = SHX2_2(SHX3_2)
  SHX11_1 = SHX2_2
  SHX2_2 = SHX1_2.weaponRules
  SHX0_1 = SHX2_2
  SHX2_2 = GetConvar
  SHX3_2 = "reaper_beta_weapon_protections"
  SHX4_2 = "true"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = "true" == SHX2_2
  SHX3_1 = SHX2_2
  SHX2_2 = GetConvar
  SHX3_2 = "reaper_beta_weapon_protection"
  SHX4_2 = "true"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = "true" == SHX2_2
  SHX6_1 = SHX2_2
  SHX2_2 = pairs
  SHX3_2 = SHX0_1.autoAntiWeaponSpawn
  SHX3_2 = SHX3_2.ignoredWeapons
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX8_2 = tostring
    SHX9_2 = GetHashKey
    SHX10_2 = SHX7_2
    SHX9_2, SHX10_2 = SHX9_2(SHX10_2)
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
    SHX9_2 = SHX7_1
    SHX9_2[SHX8_2] = true
  end
  SHX2_2 = {}
  SHX1_1 = SHX2_2
  SHX2_2 = pairs
  SHX3_2 = SHX1_2.weaponRules
  SHX3_2 = SHX3_2.blacklistedWeapons
  SHX3_2 = SHX3_2.weapons
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX8_2 = tostring
    SHX9_2 = GetHashKey
    SHX10_2 = SHX7_2
    SHX9_2, SHX10_2 = SHX9_2(SHX10_2)
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
    SHX9_2 = SHX1_1
    SHX10_2 = SHX0_1.blacklistedWeapons
    SHX10_2 = SHX10_2.action
    SHX9_2[SHX8_2] = SHX10_2
  end
  SHX2_2 = GetConvar
  SHX3_2 = "reaper_force_hit_reg"
  SHX4_2 = "false"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = "true" == SHX2_2
  SHX2_1 = SHX2_2
  SHX2_2 = SHX1_2.weaponRules
  SHX2_2 = SHX2_2.hitRegIgnoredWeapons
  if not SHX2_2 then
    SHX2_2 = {}
  end
  SHX4_1 = SHX2_2
  SHX2_2 = pairs
  SHX3_2 = SHX1_2.weaponRules
  SHX3_2 = SHX3_2.knownWeaponHashes
  if not SHX3_2 then
    SHX3_2 = {}
  end
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX8_2 = SHX11_1
    SHX8_2[SHX7_2] = true
  end
  SHX2_2 = GetConvar
  SHX3_2 = "reaper_beta_anti_spoof_kill"
  SHX4_2 = "false"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = "true" == SHX2_2
  SHX5_1 = SHX2_2
end
SHX12_1(SHX13_1, SHX14_1, SHX15_1)
SHX12_1 = GetHashKey
SHX13_1 = "WEAPON_UNARMED"
SHX12_1 = SHX12_1(SHX13_1)
SHX13_1 = GetHashKey
SHX14_1 = "WEAPON_STUNGUN"
SHX13_1 = SHX13_1(SHX14_1)
SHX14_1 = {}
SHX15_1 = RPC
SHX16_1 = SHX15_1
SHX15_1 = SHX15_1.on
SHX17_1 = "reaperReady"
function SHX18_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2
  SHX0_2 = json
  SHX0_2 = SHX0_2.decode
  SHX1_2 = HTTP
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.await
  SHX3_2 = "https://api.reaperac.com/api/v1/data/weapon_names"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = SHX1_2.body
  if not SHX1_2 then
    SHX1_2 = "{}"
  end
  SHX0_2 = SHX0_2(SHX1_2)
  SHX14_1 = SHX0_2
  SHX0_2 = Cache
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.set
  SHX2_2 = "weapon_names"
  SHX3_2 = SHX14_1
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
end
SHX15_1(SHX16_1, SHX17_1, SHX18_1)
function SHX15_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = 2147483647
  if SHX0_2 > SHX1_2 then
    SHX0_2 = SHX0_2 - 4294967296
  end
  return SHX0_2
end
SHX16_1 = RPC
SHX17_1 = SHX16_1
SHX16_1 = SHX16_1.on
SHX18_1 = "reaperStarted"
function SHX19_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "giveWeaponEvent"
  function SHX3_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = CancelEvent
    SHX0_3()
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "removeAllWeaponsEvent"
  function SHX3_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = CancelEvent
    SHX0_3()
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "removeWeaponEvent"
  function SHX3_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = CancelEvent
    SHX0_3()
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = IniParser
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.parseFile
  SHX2_2 = "WeaponsList.ini"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.onLocal
  SHX3_2 = "weaponDamageEvent"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3
    SHX2_3 = SHX6_1
    if SHX2_3 then
      SHX2_3 = Player
      SHX3_3 = SHX0_3
      SHX2_3 = SHX2_3(SHX3_3)
      if nil == SHX2_3 then
        SHX3_3 = CancelEvent
        return SHX3_3()
      end
      SHX3_3 = NetworkGetEntityFromNetworkId
      SHX4_3 = SHX1_3.hitGlobalId
      SHX3_3 = SHX3_3(SHX4_3)
      SHX4_3 = IsPedAPlayer
      SHX5_3 = SHX3_3
      SHX4_3 = SHX4_3(SHX5_3)
      if not SHX4_3 then
        return
      end
      SHX4_3 = Player
      SHX5_3 = NetworkGetEntityOwner
      SHX6_3 = SHX3_3
      SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX5_3(SHX6_3)
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
      if not SHX4_3 then
        SHX5_3 = CancelEvent
        return SHX5_3()
      end
      SHX5_3 = SHX15_1
      SHX6_3 = SHX1_3.weaponType
      SHX5_3 = SHX5_3(SHX6_3)
      SHX6_3 = Weapons
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.getWeaponData
      SHX8_3 = tostring
      SHX9_3 = SHX5_3
      SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX8_3(SHX9_3)
      SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
      SHX7_3 = false
      if nil == SHX6_3 then
        SHX8_3 = SHX0_2
        SHX8_3 = SHX8_3[SHX5_3]
        if nil == SHX8_3 then
          SHX7_3 = true
        end
      end
      SHX8_3 = SHX1_3.willKill
      if SHX8_3 then
        SHX9_3 = SHX2_3
        SHX8_3 = SHX2_3.NewLog
        SHX10_3 = "^3%s^7 (^3id:%s^7) just killed ^3%s^7 (id:^3%s^7) with ^3%s^7"
        SHX11_3 = SHX10_3
        SHX10_3 = SHX10_3.format
        SHX13_3 = SHX2_3
        SHX12_3 = SHX2_3.getName
        SHX12_3 = SHX12_3(SHX13_3)
        SHX14_3 = SHX2_3
        SHX13_3 = SHX2_3.getId
        SHX13_3 = SHX13_3(SHX14_3)
        SHX15_3 = SHX4_3
        SHX14_3 = SHX4_3.getName
        SHX14_3 = SHX14_3(SHX15_3)
        SHX16_3 = SHX4_3
        SHX15_3 = SHX4_3.getId
        SHX15_3 = SHX15_3(SHX16_3)
        SHX16_3 = tostring
        SHX17_3 = SHX1_3.weaponType
        SHX16_3 = SHX16_3(SHX17_3)
        SHX17_3 = SHX14_1
        SHX16_3 = SHX17_3[SHX16_3]
        if not SHX16_3 then
          SHX16_3 = SHX1_3.weaponType
        end
        SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
        SHX11_3 = "info"
        SHX12_3 = "weapons"
        SHX13_3 = {}
        SHX15_3 = SHX4_3
        SHX14_3 = SHX4_3.getIdentifier
        SHX16_3 = "license"
        SHX14_3 = SHX14_3(SHX15_3, SHX16_3)
        SHX13_3.player_killed = SHX14_3
        SHX15_3 = SHX4_3
        SHX14_3 = SHX4_3.getId
        SHX14_3 = SHX14_3(SHX15_3)
        SHX13_3.player_killed_id = SHX14_3
        SHX15_3 = SHX2_3
        SHX14_3 = SHX2_3.getId
        SHX14_3 = SHX14_3(SHX15_3)
        SHX13_3.killer_id = SHX14_3
        SHX13_3.damage_data = SHX1_3
        SHX14_3 = SHX0_1.logKills
        SHX14_3 = not SHX14_3
        SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
      end
      SHX8_3 = SHX0_1.logWeaponData
      if SHX8_3 then
        SHX8_3 = SHX11_1
        SHX8_3 = SHX8_3[SHX5_3]
        SHX1_3.weapons_list = SHX8_3
        SHX8_3 = tostring
        SHX9_3 = SHX5_3
        SHX8_3 = SHX8_3(SHX9_3)
        SHX9_3 = SHX7_1
        SHX8_3 = SHX9_3[SHX8_3]
        SHX1_3.ignored_weapon = SHX8_3
        SHX8_3 = SHX0_1.verifyWeaponDamage
        SHX1_3.verify = SHX8_3
        SHX8_3 = SHX2_3.private
        SHX8_3 = SHX8_3.state
        SHX9_3 = "reaper_"
        SHX10_3 = SHX5_3
        SHX9_3 = SHX9_3 .. SHX10_3
        SHX8_3 = SHX8_3[SHX9_3]
        SHX1_3.has_state_weapon = SHX8_3
        SHX9_3 = SHX2_3
        SHX8_3 = SHX2_3.NewLog
        SHX10_3 = "^3%s^7 (^3id:%s^7) just hit ^3%s^7 (id:^3%s^7) with ^3%s^7 (^3custom:%s^7)"
        SHX11_3 = SHX10_3
        SHX10_3 = SHX10_3.format
        SHX13_3 = SHX2_3
        SHX12_3 = SHX2_3.getName
        SHX12_3 = SHX12_3(SHX13_3)
        SHX14_3 = SHX2_3
        SHX13_3 = SHX2_3.getId
        SHX13_3 = SHX13_3(SHX14_3)
        SHX15_3 = SHX4_3
        SHX14_3 = SHX4_3.getName
        SHX14_3 = SHX14_3(SHX15_3)
        SHX16_3 = SHX4_3
        SHX15_3 = SHX4_3.getId
        SHX15_3 = SHX15_3(SHX16_3)
        SHX16_3 = json
        SHX16_3 = SHX16_3.encode
        SHX17_3 = SHX1_3
        SHX16_3 = SHX16_3(SHX17_3)
        SHX17_3 = SHX7_3
        SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3)
        SHX11_3 = "info"
        SHX12_3 = "weapons"
        SHX13_3 = {}
        SHX13_3.damage_data = SHX1_3
        SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3)
      end
      SHX8_3 = tostring
      SHX9_3 = SHX5_3
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = SHX1_1
      SHX8_3 = SHX9_3[SHX8_3]
      if SHX8_3 then
        SHX9_3 = SHX2_3
        SHX8_3 = SHX2_3.NewLog
        SHX10_3 = "3%s^7 (^3id:%s^7) just killed ^3%s^7 (id:^3%s^7) with a blacklisted weapon. Weapon: ^3%s^7"
        SHX11_3 = SHX10_3
        SHX10_3 = SHX10_3.format
        SHX13_3 = SHX2_3
        SHX12_3 = SHX2_3.getName
        SHX12_3 = SHX12_3(SHX13_3)
        SHX14_3 = SHX2_3
        SHX13_3 = SHX2_3.getId
        SHX13_3 = SHX13_3(SHX14_3)
        SHX15_3 = SHX4_3
        SHX14_3 = SHX4_3.getName
        SHX14_3 = SHX14_3(SHX15_3)
        SHX16_3 = SHX4_3
        SHX15_3 = SHX4_3.getId
        SHX15_3 = SHX15_3(SHX16_3)
        SHX16_3 = tostring
        SHX17_3 = SHX1_3.weaponType
        SHX16_3 = SHX16_3(SHX17_3)
        SHX17_3 = SHX14_1
        SHX16_3 = SHX17_3[SHX16_3]
        if not SHX16_3 then
          SHX16_3 = SHX1_3.weaponType
        end
        SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
        SHX11_3 = "info"
        SHX12_3 = "weapons"
        SHX13_3 = {}
        SHX13_3.damage_data = SHX1_3
        SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3)
        SHX8_3 = RPC
        SHX9_3 = SHX8_3
        SHX8_3 = SHX8_3.emitLocal
        SHX10_3 = "Reaper:NewDetection"
        SHX11_3 = {}
        SHX11_3.type = "blacklistedWeapon"
        SHX12_3 = {}
        SHX12_3.weapon = SHX5_3
        SHX11_3.data = SHX12_3
        SHX12_3 = {}
        SHX13_3 = tostring
        SHX14_3 = SHX5_3
        SHX13_3 = SHX13_3(SHX14_3)
        SHX14_3 = SHX14_1
        SHX13_3 = SHX14_3[SHX13_3]
        if not SHX13_3 then
          SHX13_3 = SHX5_3
        end
        SHX12_3[1] = SHX13_3
        SHX11_3.params = SHX12_3
        SHX13_3 = SHX2_3
        SHX12_3 = SHX2_3.getId
        SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX12_3(SHX13_3)
        SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
        SHX8_3 = CancelEvent
        SHX8_3()
      end
      if 849905853 == SHX5_3 then
        SHX8_3 = CancelEvent
        SHX8_3()
        SHX9_3 = SHX2_3
        SHX8_3 = SHX2_3.newDetection
        SHX10_3 = "antiSpoofKill"
        SHX11_3 = {}
        SHX12_3 = {}
        SHX13_3 = "Type 4"
        SHX12_3[1] = SHX13_3
        return SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3)
      end
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getWeapon
      SHX8_3 = SHX8_3(SHX9_3)
      if -1569615261 == SHX5_3 then
        SHX9_3 = GetDistanceBetweenCoords
        SHX11_3 = SHX2_3
        SHX10_3 = SHX2_3.getCoords
        SHX10_3 = SHX10_3(SHX11_3)
        SHX12_3 = SHX4_3
        SHX11_3 = SHX4_3.getCoords
        SHX11_3 = SHX11_3(SHX12_3)
        SHX12_3 = true
        SHX9_3 = SHX9_3(SHX10_3, SHX11_3, SHX12_3)
        if SHX9_3 >= 10 then
          SHX9_3 = CancelEvent
          SHX9_3()
          SHX10_3 = SHX2_3
          SHX9_3 = SHX2_3.NewLog
          SHX11_3 = "The damage done by ^3%s^7 (^3id:%s^7) to ^3%s^7 (^3id:%s^7) with a ^3%s^7 (^3%s^7) while holding ^3%s^7 (^3%s^7) was blocked. Custom Weapon: %s"
          SHX12_3 = SHX11_3
          SHX11_3 = SHX11_3.format
          SHX14_3 = SHX2_3
          SHX13_3 = SHX2_3.getName
          SHX13_3 = SHX13_3(SHX14_3)
          SHX15_3 = SHX2_3
          SHX14_3 = SHX2_3.getId
          SHX14_3 = SHX14_3(SHX15_3)
          SHX16_3 = SHX4_3
          SHX15_3 = SHX4_3.getName
          SHX15_3 = SHX15_3(SHX16_3)
          SHX17_3 = SHX4_3
          SHX16_3 = SHX4_3.getId
          SHX16_3 = SHX16_3(SHX17_3)
          SHX17_3 = SHX6_3.Name
          if not SHX17_3 then
            SHX17_3 = SHX5_3
          end
          SHX18_3 = SHX5_3
          SHX19_3 = Weapons
          SHX20_3 = SHX19_3
          SHX19_3 = SHX19_3.getWeaponName
          SHX21_3 = SHX8_3
          SHX19_3 = SHX19_3(SHX20_3, SHX21_3)
          SHX20_3 = SHX8_3
          SHX21_3 = SHX7_3
          SHX11_3 = SHX11_3(SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3)
          SHX12_3 = "warn"
          SHX13_3 = "weapons"
          SHX14_3 = {}
          SHX14_3.damage_data = SHX1_3
          return SHX9_3(SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
        end
      end
      SHX9_3 = SHX0_1.verifyWeaponDamage
      if SHX9_3 and SHX8_3 ~= SHX5_3 and false == SHX7_3 then
        SHX9_3 = CancelEvent
        SHX9_3()
        SHX10_3 = SHX2_3
        SHX9_3 = SHX2_3.NewLog
        SHX11_3 = "The damage done by ^3%s^7 (^3id:%s^7) to ^3%s^7 (^3id:%s^7) with a ^3%s^7 (^3%s^7) while holding ^3%s^7 (^3%s^7) was blocked."
        SHX12_3 = SHX11_3
        SHX11_3 = SHX11_3.format
        SHX14_3 = SHX2_3
        SHX13_3 = SHX2_3.getName
        SHX13_3 = SHX13_3(SHX14_3)
        SHX15_3 = SHX2_3
        SHX14_3 = SHX2_3.getId
        SHX14_3 = SHX14_3(SHX15_3)
        SHX16_3 = SHX4_3
        SHX15_3 = SHX4_3.getName
        SHX15_3 = SHX15_3(SHX16_3)
        SHX17_3 = SHX4_3
        SHX16_3 = SHX4_3.getId
        SHX16_3 = SHX16_3(SHX17_3)
        SHX17_3 = SHX6_3.Name
        if not SHX17_3 then
          SHX17_3 = SHX5_3
        end
        SHX18_3 = SHX5_3
        SHX19_3 = Weapons
        SHX20_3 = SHX19_3
        SHX19_3 = SHX19_3.getWeaponName
        SHX21_3 = SHX8_3
        SHX19_3 = SHX19_3(SHX20_3, SHX21_3)
        SHX20_3 = SHX8_3
        SHX11_3 = SHX11_3(SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3)
        SHX12_3 = "warn"
        SHX13_3 = "weapons"
        SHX14_3 = {}
        SHX14_3.damage_data = SHX1_3
        return SHX9_3(SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
      end
      if false == SHX7_3 then
        SHX9_3 = SHX1_3.willKill
        if SHX9_3 and SHX4_3 then
          SHX10_3 = SHX2_3
          SHX9_3 = SHX2_3.emit
          SHX11_3 = "ReaperV4:CheckWeaponDistance"
          SHX12_3 = SHX5_3
          SHX14_3 = SHX2_3
          SHX13_3 = SHX2_3.getCoords
          SHX13_3 = SHX13_3(SHX14_3)
          SHX15_3 = SHX4_3
          SHX14_3 = SHX4_3.getCoords
          SHX14_3 = SHX14_3(SHX15_3)
          SHX15_3 = SHX6_3.Name
          if not SHX15_3 then
            SHX15_3 = SHX5_3
          end
          SHX9_3(SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3)
        end
      end
      SHX9_3 = SHX11_1
      SHX9_3 = SHX9_3[SHX5_3]
      if not SHX9_3 then
        SHX9_3 = SHX2_1
        if not SHX9_3 then
          goto SHX_LABEL_935
        end
      end
      SHX9_3 = SHX0_1.hitReg
      if not (SHX9_3 and SHX4_3) then
        goto SHX_LABEL_935
      end
      SHX9_3 = SHX1_3.hitComponent
      if 20 == SHX9_3 then
        SHX9_3 = SHX12_1
        if SHX5_3 ~= SHX9_3 then
          SHX9_3 = SHX13_1
          if SHX5_3 ~= SHX9_3 then
            SHX10_3 = SHX4_3
            SHX9_3 = SHX4_3.isInvincible
            SHX9_3 = SHX9_3(SHX10_3)
            if not SHX9_3 then
              SHX9_3 = tostring
              SHX10_3 = SHX5_3
              SHX9_3 = SHX9_3(SHX10_3)
              SHX10_3 = SHX4_1
              SHX9_3 = SHX10_3[SHX9_3]
              if not SHX9_3 then
                goto SHX_LABEL_342
              end
            end
          end
        end
      end
      return
      -- [FIX IF ERROR] Move ::SHX_LABEL_342:: outside nested blocks until all 'goto SHX_LABEL_342' can see it
      ::SHX_LABEL_342::
      SHX10_3 = SHX4_3
      SHX9_3 = SHX4_3.setPedConfig
      SHX11_3 = 33
      SHX12_3 = true
      SHX9_3(SHX10_3, SHX11_3, SHX12_3)
      SHX9_3 = SetPedToRagdoll
      SHX11_3 = SHX4_3
      SHX10_3 = SHX4_3.getPed
      SHX10_3 = SHX10_3(SHX11_3)
      SHX11_3 = 1
      SHX12_3 = 1
      SHX13_3 = 0
      SHX14_3 = false
      SHX15_3 = false
      SHX16_3 = false
      SHX9_3(SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
      SHX9_3 = Wait
      SHX10_3 = 1
      SHX9_3(SHX10_3)
      SHX10_3 = SHX4_3
      SHX9_3 = SHX4_3.setPedConfig
      SHX11_3 = 33
      SHX12_3 = false
      SHX9_3(SHX10_3, SHX11_3, SHX12_3)
    else
      SHX2_3 = SHX1_3.weaponType
      if 3219281620 == SHX2_3 then
        SHX1_3.weaponType = -1075685676
      end
      SHX2_3 = Player
      SHX3_3 = SHX0_3
      SHX2_3 = SHX2_3(SHX3_3)
      if nil == SHX2_3 then
        SHX3_3 = CancelEvent
        return SHX3_3()
      end
      SHX3_3 = NetworkGetEntityFromNetworkId
      SHX4_3 = SHX1_3.hitGlobalId
      SHX3_3 = SHX3_3(SHX4_3)
      SHX4_3 = IsPedAPlayer
      SHX5_3 = SHX3_3
      SHX4_3 = SHX4_3(SHX5_3)
      if not SHX4_3 then
        return
      end
      SHX4_3 = Player
      SHX5_3 = NetworkGetEntityOwner
      SHX6_3 = SHX3_3
      SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX5_3(SHX6_3)
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
      if not SHX4_3 then
        return
      end
      SHX6_3 = SHX2_3
      SHX5_3 = SHX2_3.getWeapon
      SHX5_3 = SHX5_3(SHX6_3)
      SHX7_3 = SHX1_3.weaponType
      SHX6_3 = SHX11_1
      SHX6_3 = SHX6_3[SHX7_3]
      if nil == SHX6_3 then
        SHX6_3 = GetConvar
        SHX7_3 = "reaper_block_unknown_weapons"
        SHX8_3 = "false"
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
        if "true" == SHX6_3 then
          SHX6_3 = CancelEvent
          SHX6_3()
          SHX6_3 = Logger
          SHX7_3 = SHX6_3
          SHX6_3 = SHX6_3.log
          SHX8_3 = "The damage done by ^3%s^7 (^3id:%s^7) to ^3%s^7 (^3id:%s^7) with a ^3%s^7 was blocked due to the weapon hash being unknown"
          SHX9_3 = SHX8_3
          SHX8_3 = SHX8_3.format
          SHX11_3 = SHX2_3
          SHX10_3 = SHX2_3.getName
          SHX10_3 = SHX10_3(SHX11_3)
          SHX12_3 = SHX2_3
          SHX11_3 = SHX2_3.getId
          SHX11_3 = SHX11_3(SHX12_3)
          SHX13_3 = SHX4_3
          SHX12_3 = SHX4_3.getName
          SHX12_3 = SHX12_3(SHX13_3)
          SHX14_3 = SHX4_3
          SHX13_3 = SHX4_3.getId
          SHX13_3 = SHX13_3(SHX14_3)
          SHX14_3 = tostring
          SHX15_3 = SHX1_3.weaponType
          SHX14_3 = SHX14_3(SHX15_3)
          SHX15_3 = SHX14_1
          SHX14_3 = SHX15_3[SHX14_3]
          if not SHX14_3 then
            SHX14_3 = SHX1_3.weaponType
          end
          SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
          SHX9_3 = "warn"
          SHX6_3(SHX7_3, SHX8_3, SHX9_3)
          return
        end
      end
      SHX6_3 = SHX1_3.willKill
      if SHX6_3 then
        SHX6_3 = SHX0_1.logKills
        if SHX6_3 then
          SHX6_3 = Logger
          SHX7_3 = SHX6_3
          SHX6_3 = SHX6_3.log
          SHX8_3 = "3%s^7 (^3id:%s^7) just killed ^3%s^7 (^3%s^7) with ^3%s^7"
          SHX9_3 = SHX8_3
          SHX8_3 = SHX8_3.format
          SHX11_3 = SHX2_3
          SHX10_3 = SHX2_3.getName
          SHX10_3 = SHX10_3(SHX11_3)
          SHX12_3 = SHX2_3
          SHX11_3 = SHX2_3.getId
          SHX11_3 = SHX11_3(SHX12_3)
          SHX13_3 = SHX4_3
          SHX12_3 = SHX4_3.getName
          SHX12_3 = SHX12_3(SHX13_3)
          SHX14_3 = SHX4_3
          SHX13_3 = SHX4_3.getId
          SHX13_3 = SHX13_3(SHX14_3)
          SHX14_3 = tostring
          SHX15_3 = SHX1_3.weaponType
          SHX14_3 = SHX14_3(SHX15_3)
          SHX15_3 = SHX14_1
          SHX14_3 = SHX15_3[SHX14_3]
          if not SHX14_3 then
            SHX14_3 = SHX1_3.weaponType
          end
          SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
          SHX9_3 = "info"
          SHX6_3(SHX7_3, SHX8_3, SHX9_3)
        end
      end
      SHX6_3 = SHX1_3.weaponType
      if 849905853 == SHX6_3 then
        SHX6_3 = RPC
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.emitLocal
        SHX8_3 = "Reaper:NewDetection"
        SHX9_3 = {}
        SHX9_3.type = "antiSpoofKill"
        SHX9_3.data = SHX1_3
        SHX10_3 = {}
        SHX11_3 = "Type 3"
        SHX10_3[1] = SHX11_3
        SHX9_3.params = SHX10_3
        SHX11_3 = SHX2_3
        SHX10_3 = SHX2_3.getId
        SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX10_3(SHX11_3)
        SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
      end
      SHX6_3 = SHX0_1.logWeaponData
      if SHX6_3 then
        SHX7_3 = SHX1_3.weaponType
        SHX6_3 = SHX11_1
        SHX6_3 = SHX6_3[SHX7_3]
        SHX1_3.weapons_list = SHX6_3
        SHX6_3 = tostring
        SHX7_3 = SHX1_3.weaponType
        SHX6_3 = SHX6_3(SHX7_3)
        SHX7_3 = SHX7_1
        SHX6_3 = SHX7_3[SHX6_3]
        SHX1_3.ignored_weapon = SHX6_3
        SHX6_3 = SHX0_1.verifyWeaponDamage
        SHX1_3.verify = SHX6_3
        SHX6_3 = SHX2_3.private
        SHX6_3 = SHX6_3.state
        SHX7_3 = "reaper_"
        SHX8_3 = SHX1_3.weaponType
        SHX7_3 = SHX7_3 .. SHX8_3
        SHX6_3 = SHX6_3[SHX7_3]
        SHX1_3.has_state_weapon = SHX6_3
        SHX6_3 = Logger
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.log
        SHX8_3 = "^3%s^7 (^3id:%s^7) just hit ^3%s^7 (^3%s^7) with ^3%s^7"
        SHX9_3 = SHX8_3
        SHX8_3 = SHX8_3.format
        SHX11_3 = SHX2_3
        SHX10_3 = SHX2_3.getName
        SHX10_3 = SHX10_3(SHX11_3)
        SHX12_3 = SHX2_3
        SHX11_3 = SHX2_3.getId
        SHX11_3 = SHX11_3(SHX12_3)
        SHX13_3 = SHX4_3
        SHX12_3 = SHX4_3.getName
        SHX12_3 = SHX12_3(SHX13_3)
        SHX14_3 = SHX4_3
        SHX13_3 = SHX4_3.getId
        SHX13_3 = SHX13_3(SHX14_3)
        SHX14_3 = json
        SHX14_3 = SHX14_3.encode
        SHX15_3 = SHX1_3
        SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX14_3(SHX15_3)
        SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
        SHX9_3 = "info"
        SHX6_3(SHX7_3, SHX8_3, SHX9_3)
      end
      SHX6_3 = SHX0_1.verifyWeaponDamage
      if SHX6_3 then
        SHX7_3 = SHX1_3.weaponType
        SHX6_3 = SHX11_1
        SHX6_3 = SHX6_3[SHX7_3]
        if SHX6_3 then
          SHX6_3 = tostring
          SHX7_3 = SHX1_3.weaponType
          SHX6_3 = SHX6_3(SHX7_3)
          SHX7_3 = SHX7_1
          SHX6_3 = SHX7_3[SHX6_3]
          if nil == SHX6_3 then
            SHX6_3 = SHX1_3.weaponType
            if SHX6_3 ~= SHX5_3 then
              SHX6_3 = CancelEvent
              SHX6_3()
              if SHX4_3 then
                SHX6_3 = GetConvar
                SHX7_3 = "reaper_ban_weapon_verification_fail"
                SHX8_3 = "false"
                SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
                if "true" == SHX6_3 then
                  SHX6_3 = RPC
                  SHX7_3 = SHX6_3
                  SHX6_3 = SHX6_3.emitLocal
                  SHX8_3 = "Reaper:NewDetection"
                  SHX9_3 = {}
                  SHX9_3.type = "antiSpoofKill"
                  SHX10_3 = {}
                  SHX11_3 = SHX1_3.weaponType
                  SHX10_3.weapon = SHX11_3
                  SHX9_3.data = SHX10_3
                  SHX10_3 = {}
                  SHX11_3 = "Type 1"
                  SHX10_3[1] = SHX11_3
                  SHX9_3.params = SHX10_3
                  SHX11_3 = SHX2_3
                  SHX10_3 = SHX2_3.getId
                  SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX10_3(SHX11_3)
                  SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
                else
                  SHX6_3 = Logger
                  SHX7_3 = SHX6_3
                  SHX6_3 = SHX6_3.log
                  SHX8_3 = "The damage done by ^3%s^7 (^3id:%s^7) to ^3%s^7 (^3id:%s^7) with a ^3%s^7 was blocked"
                  SHX9_3 = SHX8_3
                  SHX8_3 = SHX8_3.format
                  SHX11_3 = SHX2_3
                  SHX10_3 = SHX2_3.getName
                  SHX10_3 = SHX10_3(SHX11_3)
                  SHX12_3 = SHX2_3
                  SHX11_3 = SHX2_3.getId
                  SHX11_3 = SHX11_3(SHX12_3)
                  SHX13_3 = SHX4_3
                  SHX12_3 = SHX4_3.getName
                  SHX12_3 = SHX12_3(SHX13_3)
                  SHX14_3 = SHX4_3
                  SHX13_3 = SHX4_3.getId
                  SHX13_3 = SHX13_3(SHX14_3)
                  SHX14_3 = tostring
                  SHX15_3 = SHX1_3.weaponType
                  SHX14_3 = SHX14_3(SHX15_3)
                  SHX15_3 = SHX14_1
                  SHX14_3 = SHX15_3[SHX14_3]
                  if not SHX14_3 then
                    SHX14_3 = SHX1_3.weaponType
                  end
                  SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
                  SHX9_3 = "warn"
                  SHX6_3(SHX7_3, SHX8_3, SHX9_3)
                end
              end
              return
            end
          end
        end
      end
      SHX7_3 = SHX1_3.weaponType
      SHX6_3 = SHX11_1
      SHX6_3 = SHX6_3[SHX7_3]
      if SHX6_3 then
        SHX7_3 = SHX2_3
        SHX6_3 = SHX2_3.getWeapon
        SHX6_3 = SHX6_3(SHX7_3)
        SHX7_3 = SHX1_3.weaponType
        if SHX6_3 ~= SHX7_3 then
          SHX6_3 = CancelEvent
          SHX6_3()
        end
      end
      SHX6_3 = SHX3_1
      if SHX6_3 then
        SHX6_3 = SHX1_3.weaponType
        if 3452007600 == SHX6_3 then
          SHX6_3 = SHX1_3.silenced
          if SHX6_3 then
            SHX6_3 = SHX1_3.hitComponent
            if 0 == SHX6_3 then
              SHX6_3 = SHX1_3.damageFlags
              if 16 == SHX6_3 then
                SHX6_3 = SHX1_3.weaponDamage
                if 0 == SHX6_3 then
                  SHX6_3 = CancelEvent
                  SHX6_3()
                  SHX6_3 = RPC
                  SHX7_3 = SHX6_3
                  SHX6_3 = SHX6_3.emitLocal
                  SHX8_3 = "Reaper:NewDetection"
                  SHX9_3 = {}
                  SHX9_3.type = "antiSpoofPunch"
                  SHX9_3.data = SHX1_3
                  SHX10_3 = {}
                  SHX11_3 = "Type 1"
                  SHX10_3[1] = SHX11_3
                  SHX9_3.params = SHX10_3
                  SHX11_3 = SHX2_3
                  SHX10_3 = SHX2_3.getId
                  SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX10_3(SHX11_3)
                  SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
                end
              end
            end
          end
        end
        SHX6_3 = SHX1_3.weaponType
        if 1834887169 == SHX6_3 then
          SHX6_3 = SHX1_3.weaponDamage
          if 16384 == SHX6_3 then
            SHX6_3 = SHX1_3.damageFlags
            if 2642962 == SHX6_3 then
              SHX6_3 = SHX1_3.actionResultId
              if 1537 == SHX6_3 then
                SHX6_3 = CancelEvent
                SHX6_3()
                SHX6_3 = RPC
                SHX7_3 = SHX6_3
                SHX6_3 = SHX6_3.emitLocal
                SHX8_3 = "Reaper:NewDetection"
                SHX9_3 = {}
                SHX9_3.type = "antiRagdollPlayers"
                SHX9_3.data = SHX1_3
                SHX10_3 = {}
                SHX9_3.params = SHX10_3
                SHX11_3 = SHX2_3
                SHX10_3 = SHX2_3.getId
                SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX10_3(SHX11_3)
                SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
              end
            end
          end
        end
        SHX6_3 = SHX1_3.weaponType
        if 2725352035 == SHX6_3 then
          SHX6_3 = SHX1_3.localPosX
          if 0 == SHX6_3 then
            SHX6_3 = SHX1_3.damageFlags
            if 522 == SHX6_3 then
              SHX6_3 = SHX1_3.weaponDamage
              if 16 == SHX6_3 then
                SHX6_3 = SHX1_3.hitComponent
                if 10 == SHX6_3 then
                  SHX6_3 = CancelEvent
                  SHX6_3()
                  SHX6_3 = RPC
                  SHX7_3 = SHX6_3
                  SHX6_3 = SHX6_3.emitLocal
                  SHX8_3 = "Reaper:NewDetection"
                  SHX9_3 = {}
                  SHX9_3.type = "antiSpoofPunch"
                  SHX9_3.data = SHX1_3
                  SHX10_3 = {}
                  SHX11_3 = "Type 2"
                  SHX10_3[1] = SHX11_3
                  SHX9_3.params = SHX10_3
                  SHX11_3 = SHX2_3
                  SHX10_3 = SHX2_3.getId
                  SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX10_3(SHX11_3)
                  SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
                end
              end
            end
          end
        end
        SHX6_3 = SHX1_3.weaponType
        if 2725352035 == SHX6_3 then
          SHX6_3 = SHX1_3.localPosX
          if 0 == SHX6_3 then
            SHX6_3 = SHX1_3.damageFlags
            if 454 == SHX6_3 then
              SHX6_3 = SHX1_3.weaponDamage
              if 0 == SHX6_3 then
                SHX6_3 = SHX1_3.hitComponent
                if 19 == SHX6_3 then
                  SHX6_3 = SHX1_3.actionResultId
                  if 32770 == SHX6_3 then
                    SHX6_3 = SHX1_3.f112_1
                    if 1 ~= SHX6_3 then
                      SHX6_3 = SHX1_3.f112_1
                      if 0 ~= SHX6_3 then
                        SHX6_3 = CancelEvent
                        SHX6_3()
                        SHX6_3 = GetDistanceBetweenCoords
                        SHX8_3 = SHX4_3
                        SHX7_3 = SHX4_3.getCoords
                        SHX7_3 = SHX7_3(SHX8_3)
                        SHX9_3 = SHX2_3
                        SHX8_3 = SHX2_3.getCoords
                        SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX8_3(SHX9_3)
                        SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
                        SHX1_3.distance = SHX6_3
                        SHX6_3 = RPC
                        SHX7_3 = SHX6_3
                        SHX6_3 = SHX6_3.emitLocal
                        SHX8_3 = "Reaper:NewDetection"
                        SHX9_3 = {}
                        SHX9_3.type = "antiSpoofKill"
                        SHX9_3.data = SHX1_3
                        SHX10_3 = {}
                        SHX11_3 = "Type 2"
                        SHX10_3[1] = SHX11_3
                        SHX9_3.params = SHX10_3
                        SHX11_3 = SHX2_3
                        SHX10_3 = SHX2_3.getId
                        SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX10_3(SHX11_3)
                        SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
                      end
                    end
                  end
                end
              end
            end
          end
        end
      end
      SHX6_3 = tostring
      SHX7_3 = SHX5_3
      SHX6_3 = SHX6_3(SHX7_3)
      SHX7_3 = SHX1_1
      SHX6_3 = SHX7_3[SHX6_3]
      if SHX6_3 then
        SHX6_3 = RPC
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.emitLocal
        SHX8_3 = "Reaper:NewDetection"
        SHX9_3 = {}
        SHX9_3.type = "blacklistedWeapon"
        SHX10_3 = {}
        SHX10_3.weapon = SHX5_3
        SHX9_3.data = SHX10_3
        SHX10_3 = {}
        SHX11_3 = tostring
        SHX12_3 = SHX5_3
        SHX11_3 = SHX11_3(SHX12_3)
        SHX12_3 = SHX14_1
        SHX11_3 = SHX12_3[SHX11_3]
        if not SHX11_3 then
          SHX11_3 = SHX5_3
        end
        SHX10_3[1] = SHX11_3
        SHX9_3.params = SHX10_3
        SHX11_3 = SHX2_3
        SHX10_3 = SHX2_3.getId
        SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX10_3(SHX11_3)
        SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
        SHX6_3 = CancelEvent
        SHX6_3()
      end
      SHX7_3 = SHX1_3.weaponType
      SHX6_3 = SHX11_1
      SHX6_3 = SHX6_3[SHX7_3]
      if SHX6_3 then
        SHX6_3 = SHX1_3.willKill
        if SHX6_3 and SHX4_3 then
          SHX7_3 = SHX2_3
          SHX6_3 = SHX2_3.emit
          SHX8_3 = "ReaperV4:CheckWeaponDistance"
          SHX9_3 = SHX1_3.weaponType
          SHX10_3 = nil
          SHX11_3 = nil
          SHX12_3 = tostring
          SHX13_3 = SHX1_3.weaponType
          SHX12_3 = SHX12_3(SHX13_3)
          SHX13_3 = SHX14_1
          SHX12_3 = SHX13_3[SHX12_3]
          if not SHX12_3 then
            SHX12_3 = SHX1_3.weaponType
          end
          SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3)
        end
      end
      SHX7_3 = SHX1_3.weaponType
      SHX6_3 = SHX11_1
      SHX6_3 = SHX6_3[SHX7_3]
      if SHX6_3 then
        SHX6_3 = SHX1_3.willKill
        if SHX6_3 and SHX4_3 then
          SHX6_3 = SHX5_1
          if SHX6_3 then
            SHX7_3 = SHX2_3
            SHX6_3 = SHX2_3.getCoords
            SHX6_3 = SHX6_3(SHX7_3)
            SHX8_3 = SHX4_3
            SHX7_3 = SHX4_3.getCoords
            SHX7_3 = SHX7_3(SHX8_3)
            SHX8_3 = GetDistanceBetweenCoords
            SHX9_3 = SHX6_3
            SHX10_3 = SHX7_3
            SHX11_3 = false
            SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3)
            SHX10_3 = SHX2_3
            SHX9_3 = SHX2_3.getCoordsInFront
            SHX11_3 = SHX8_3
            SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
            SHX10_3 = GetDistanceBetweenCoords
            SHX11_3 = SHX9_3
            SHX12_3 = SHX7_3
            SHX13_3 = false
            SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
            if SHX10_3 > 1.0 then
              SHX10_3 = Logger
              SHX11_3 = SHX10_3
              SHX10_3 = SHX10_3.log
              SHX12_3 = "^3%s^7 (^3id:%s^7) was not aiming at ^3%s^7 (^3id:%s^7) when doing damage with (^3weapon:%s^7). Offset: ^3%s^7"
              SHX13_3 = SHX12_3
              SHX12_3 = SHX12_3.format
              SHX15_3 = SHX4_3
              SHX14_3 = SHX4_3.getName
              SHX14_3 = SHX14_3(SHX15_3)
              SHX16_3 = SHX4_3
              SHX15_3 = SHX4_3.getId
              SHX15_3 = SHX15_3(SHX16_3)
              SHX17_3 = SHX2_3
              SHX16_3 = SHX2_3.getName
              SHX16_3 = SHX16_3(SHX17_3)
              SHX18_3 = SHX2_3
              SHX17_3 = SHX2_3.getId
              SHX17_3 = SHX17_3(SHX18_3)
              SHX18_3 = SHX1_3.weaponType
              SHX19_3 = GetDistanceBetweenCoords
              SHX20_3 = SHX9_3
              SHX21_3 = SHX7_3
              SHX22_3 = false
              SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX19_3(SHX20_3, SHX21_3, SHX22_3)
              SHX12_3 = SHX12_3(SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
              SHX13_3 = "info"
              SHX10_3(SHX11_3, SHX12_3, SHX13_3)
            end
          end
        end
      end
      SHX7_3 = SHX1_3.weaponType
      SHX6_3 = SHX11_1
      SHX6_3 = SHX6_3[SHX7_3]
      if not SHX6_3 then
        SHX6_3 = SHX2_1
        if not SHX6_3 then
          goto SHX_LABEL_935
        end
      end
      SHX6_3 = SHX0_1.hitReg
      if SHX6_3 and SHX4_3 then
        SHX6_3 = SHX1_3.hitComponent
        if 20 == SHX6_3 then
          SHX6_3 = SHX1_3.weaponType
          SHX7_3 = SHX12_1
          if SHX6_3 ~= SHX7_3 then
            SHX6_3 = SHX1_3.weaponType
            SHX7_3 = SHX13_1
            if SHX6_3 ~= SHX7_3 then
              SHX7_3 = SHX4_3
              SHX6_3 = SHX4_3.isInvincible
              SHX6_3 = SHX6_3(SHX7_3)
              if not SHX6_3 then
                SHX6_3 = tostring
                SHX7_3 = SHX1_3.weaponType
                SHX6_3 = SHX6_3(SHX7_3)
                SHX7_3 = SHX4_1
                SHX6_3 = SHX7_3[SHX6_3]
                if not SHX6_3 then
                  goto SHX_LABEL_892
                end
              end
            end
          end
        end
        return
        -- [FIX IF ERROR] Move ::SHX_LABEL_892:: outside nested blocks until all 'goto SHX_LABEL_892' can see it
        ::SHX_LABEL_892::
        SHX7_3 = SHX4_3
        SHX6_3 = SHX4_3.setPedConfig
        SHX8_3 = 33
        SHX9_3 = true
        SHX6_3(SHX7_3, SHX8_3, SHX9_3)
        SHX6_3 = SetPedToRagdoll
        SHX8_3 = SHX4_3
        SHX7_3 = SHX4_3.getPed
        SHX7_3 = SHX7_3(SHX8_3)
        SHX8_3 = 1
        SHX9_3 = 1
        SHX10_3 = 0
        SHX11_3 = false
        SHX12_3 = false
        SHX13_3 = false
        SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3)
        SHX6_3 = Wait
        SHX7_3 = 1
        SHX6_3(SHX7_3)
        SHX7_3 = SHX4_3
        SHX6_3 = SHX4_3.setPedConfig
        SHX8_3 = 33
        SHX9_3 = false
        SHX6_3(SHX7_3, SHX8_3, SHX9_3)
        SHX6_3 = GetConvar
        SHX7_3 = "reaper_hit_reg_log"
        SHX8_3 = "false"
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
        if "true" == SHX6_3 then
          SHX6_3 = Logger
          SHX7_3 = SHX6_3
          SHX6_3 = SHX6_3.log
          SHX8_3 = "hit reg damage applied to ^3%s^7 (^3id:%s^7) by ^3%s^7 (^3id:%s^7) with (^3weapon:%s^7)"
          SHX9_3 = SHX8_3
          SHX8_3 = SHX8_3.format
          SHX11_3 = SHX4_3
          SHX10_3 = SHX4_3.getName
          SHX10_3 = SHX10_3(SHX11_3)
          SHX12_3 = SHX4_3
          SHX11_3 = SHX4_3.getId
          SHX11_3 = SHX11_3(SHX12_3)
          SHX13_3 = SHX2_3
          SHX12_3 = SHX2_3.getName
          SHX12_3 = SHX12_3(SHX13_3)
          SHX14_3 = SHX2_3
          SHX13_3 = SHX2_3.getId
          SHX13_3 = SHX13_3(SHX14_3)
          SHX14_3 = SHX1_3.weaponType
          SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
          SHX9_3 = "info"
          SHX6_3(SHX7_3, SHX8_3, SHX9_3)
        end
      end
    end
    -- [FIX IF ERROR] Move ::SHX_LABEL_935:: outside nested blocks until all 'goto SHX_LABEL_935' can see it
    ::SHX_LABEL_935::
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.onNet
  SHX3_2 = "Reaper:GiveWeaponToPed"
  function SHX4_2(SHX0_3, SHX1_3, ...)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    SHX2_3 = source
    if 0 == SHX0_3 then
      return
    end
    SHX3_3 = GetConvar
    SHX4_3 = "reaper_GiveWeaponToPed_networked"
    SHX5_3 = "false"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if "false" == SHX3_3 then
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "%s (id:%s) just attempted to give (%s) to %s (id:%s) but the convar reaper_GiveWeaponToPed_networked is false"
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.format
      SHX7_3 = GetPlayerName
      SHX8_3 = SHX2_3
      SHX7_3 = SHX7_3(SHX8_3)
      SHX8_3 = SHX2_3
      SHX9_3 = tostring
      SHX10_3 = SHX1_3
      SHX9_3 = SHX9_3(SHX10_3)
      SHX10_3 = SHX14_1
      SHX9_3 = SHX10_3[SHX9_3]
      if not SHX9_3 then
        SHX9_3 = SHX1_3
      end
      SHX10_3 = GetPlayerName
      SHX11_3 = SHX0_3
      SHX10_3 = SHX10_3(SHX11_3)
      SHX11_3 = SHX0_3
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
      SHX6_3 = "debug"
      SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      SHX3_3 = 0
      return SHX3_3
    end
    SHX3_3 = Logger
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.log
    SHX5_3 = "%s (id:%s) just gave a weapon (%s) to %s (id:%s)"
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.format
    SHX7_3 = GetPlayerName
    SHX8_3 = SHX2_3
    SHX7_3 = SHX7_3(SHX8_3)
    SHX8_3 = SHX2_3
    SHX9_3 = tostring
    SHX10_3 = SHX1_3
    SHX9_3 = SHX9_3(SHX10_3)
    SHX10_3 = SHX14_1
    SHX9_3 = SHX10_3[SHX9_3]
    if not SHX9_3 then
      SHX9_3 = SHX1_3
    end
    SHX10_3 = GetPlayerName
    SHX11_3 = SHX0_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX11_3 = SHX0_3
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    SHX6_3 = "debug"
    SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    SHX3_3 = TriggerClientEvent
    SHX4_3 = "Reaper:GiveWeaponToPed"
    SHX5_3 = SHX0_3
    SHX6_3 = SHX1_3
    SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = ...
    SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = GetConvar
  SHX2_2 = "reaper_use_custom_weapons"
  SHX3_2 = "true"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  if "true" == SHX1_2 then
    SHX1_2 = {}
    while true do
      SHX2_2 = Resources
      SHX3_2 = SHX2_2
      SHX2_2 = SHX2_2.loaded
      SHX2_2 = SHX2_2(SHX3_2)
      if false ~= SHX2_2 then
        break
      end
      SHX2_2 = Logger
      SHX3_2 = SHX2_2
      SHX2_2 = SHX2_2.log
      SHX4_2 = "Waiting for resources to fully load..."
      SHX5_2 = "warn"
      SHX2_2(SHX3_2, SHX4_2, SHX5_2)
      SHX2_2 = Wait
      SHX3_2 = 1000
      SHX2_2(SHX3_2)
    end
    SHX2_2 = pairs
    SHX3_2 = GetAllResources
    SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2 = SHX3_2()
    SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2)
    for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
      SHX9_2 = SHX7_2
      SHX8_2 = SHX7_2.isWeaponsResource
      SHX8_2 = SHX8_2(SHX9_2)
      if SHX8_2 then
        SHX8_2 = 0
        SHX10_2 = SHX7_2
        SHX9_2 = SHX7_2.getDataFile
        SHX11_2 = "WEAPONINFO_FILE"
        SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
        SHX10_2 = pairs
        SHX11_2 = SHX9_2
        SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX10_2(SHX11_2)
        for SHX14_2, SHX15_2 in SHX10_2, SHX11_2, SHX12_2, SHX13_2 do
          SHX16_2 = exports
          SHX16_2 = SHX16_2.ReaperV4
          SHX17_2 = SHX16_2
          SHX16_2 = SHX16_2.GetFilePaths
          SHX19_2 = SHX7_2
          SHX18_2 = SHX7_2.getName
          SHX18_2 = SHX18_2(SHX19_2)
          SHX19_2 = SHX15_2
          SHX16_2 = SHX16_2(SHX17_2, SHX18_2, SHX19_2)
          SHX17_2 = #SHX16_2
          if 0 == SHX17_2 then
            SHX17_2 = Logger
            SHX18_2 = SHX17_2
            SHX17_2 = SHX17_2.log
            SHX19_2 = "(^3E2^7) Failed to load weapon data from ^3data_file 'WEAPONINFO_FILE' '%s'^7 defined in the resource ^3%s^7"
            SHX20_2 = SHX19_2
            SHX19_2 = SHX19_2.format
            SHX21_2 = SHX15_2
            SHX23_2 = SHX7_2
            SHX22_2 = SHX7_2.getName
            SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2 = SHX22_2(SHX23_2)
            SHX19_2 = SHX19_2(SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2)
            SHX20_2 = "error"
            SHX17_2(SHX18_2, SHX19_2, SHX20_2)
          else
            SHX17_2 = pairs
            SHX18_2 = SHX16_2
            SHX17_2, SHX18_2, SHX19_2, SHX20_2 = SHX17_2(SHX18_2)
            for SHX21_2, SHX22_2 in SHX17_2, SHX18_2, SHX19_2, SHX20_2 do
              SHX23_2 = LoadResourceFile
              SHX25_2 = SHX7_2
              SHX24_2 = SHX7_2.getName
              SHX24_2 = SHX24_2(SHX25_2)
              SHX25_2 = SHX22_2
              SHX23_2 = SHX23_2(SHX24_2, SHX25_2)
              if nil == SHX23_2 then
                SHX24_2 = Logger
                SHX25_2 = SHX24_2
                SHX24_2 = SHX24_2.log
                SHX26_2 = "(^3E3^7) Failed to load weapon data from ^3data_file 'WEAPONINFO_FILE' '%s'^7 defined in the resource ^3%s^7"
                SHX27_2 = SHX26_2
                SHX26_2 = SHX26_2.format
                SHX28_2 = SHX15_2
                SHX30_2 = SHX7_2
                SHX29_2 = SHX7_2.getName
                SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2 = SHX29_2(SHX30_2)
                SHX26_2 = SHX26_2(SHX27_2, SHX28_2, SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2)
                SHX27_2 = "error"
                SHX24_2(SHX25_2, SHX26_2, SHX27_2)
              else
                SHX24_2 = SHX10_1
                SHX25_2 = SHX23_2
                SHX26_2 = SHX22_2
                SHX28_2 = SHX7_2
                SHX27_2 = SHX7_2.getName
                SHX27_2, SHX28_2, SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2 = SHX27_2(SHX28_2)
                SHX24_2 = SHX24_2(SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2)
                SHX25_2 = pairs
                SHX26_2 = SHX24_2
                SHX25_2, SHX26_2, SHX27_2, SHX28_2 = SHX25_2(SHX26_2)
                for SHX29_2, SHX30_2 in SHX25_2, SHX26_2, SHX27_2, SHX28_2 do
                  SHX8_2 = SHX8_2 + 1
                  SHX31_2 = table
                  SHX31_2 = SHX31_2.insert
                  SHX32_2 = SHX1_2
                  SHX33_2 = SHX30_2
                  SHX31_2(SHX32_2, SHX33_2)
                end
              end
            end
          end
        end
        SHX10_2 = Logger
        SHX11_2 = SHX10_2
        SHX10_2 = SHX10_2.log
        SHX12_2 = "Successfully loaded ^3%s^7 custom weapon(s) from the resource ^3%s^7"
        SHX13_2 = SHX12_2
        SHX12_2 = SHX12_2.format
        SHX14_2 = SHX8_2
        SHX16_2 = SHX7_2
        SHX15_2 = SHX7_2.getName
        SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2 = SHX15_2(SHX16_2)
        SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2)
        SHX13_2 = "info"
        SHX10_2(SHX11_2, SHX12_2, SHX13_2)
      end
    end
    SHX2_2 = #SHX1_2
    if 0 ~= SHX2_2 then
      SHX2_2 = HTTP
      SHX3_2 = SHX2_2
      SHX2_2 = SHX2_2.await
      SHX4_2 = "https://api.reaperac.com/api/v1/servers/%s/weapons"
      SHX5_2 = SHX4_2
      SHX4_2 = SHX4_2.format
      SHX6_2 = Cache
      SHX7_2 = SHX6_2
      SHX6_2 = SHX6_2.get
      SHX8_2 = "dbId"
      SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2 = SHX6_2(SHX7_2, SHX8_2)
      SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2, SHX31_2, SHX32_2, SHX33_2)
      SHX5_2 = "POST"
      SHX6_2 = json
      SHX6_2 = SHX6_2.encode
      SHX7_2 = {}
      SHX7_2.weapons = SHX1_2
      SHX8_2 = Cache
      SHX9_2 = SHX8_2
      SHX8_2 = SHX8_2.get
      SHX10_2 = "secret"
      SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
      SHX7_2.secret = SHX8_2
      SHX6_2 = SHX6_2(SHX7_2)
      SHX7_2 = {}
      SHX7_2["Content-Type"] = "application/json"
      SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
      SHX3_2 = SHX2_2.status
      if 200 ~= SHX3_2 then
        SHX3_2 = Logger
        SHX4_2 = SHX3_2
        SHX3_2 = SHX3_2.log
        SHX5_2 = "Failed to upload custom weapons list to ^3api.reaperac.com^7. The server responded with the status code ^3%s^7"
        SHX6_2 = SHX5_2
        SHX5_2 = SHX5_2.format
        SHX7_2 = SHX2_2.status
        SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
        SHX6_2 = "error"
        SHX3_2(SHX4_2, SHX5_2, SHX6_2)
      end
    end
    SHX2_2 = pairs
    SHX3_2 = SHX1_2
    SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
    for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
      SHX8_2 = GetHashKey
      SHX9_2 = SHX7_2
      SHX8_2 = SHX8_2(SHX9_2)
      SHX9_2 = SHX11_1
      SHX9_2[SHX8_2] = true
      SHX9_2 = tostring
      SHX10_2 = SHX8_2
      SHX9_2 = SHX9_2(SHX10_2)
      SHX10_2 = SHX14_1
      SHX10_2[SHX9_2] = SHX7_2
      SHX9_2 = Logger
      SHX10_2 = SHX9_2
      SHX9_2 = SHX9_2.log
      SHX11_2 = "^3%s^7 (^3%s^7) was just added as a custom weapon"
      SHX12_2 = SHX11_2
      SHX11_2 = SHX11_2.format
      SHX13_2 = SHX7_2
      SHX14_2 = SHX8_2
      SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2)
      SHX12_2 = "debug"
      SHX9_2(SHX10_2, SHX11_2, SHX12_2)
    end
    SHX2_2 = Cache
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.set
    SHX4_2 = "weapons_list"
    SHX5_2 = SHX11_1
    SHX2_2(SHX3_2, SHX4_2, SHX5_2)
    SHX2_2 = Cache
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.set
    SHX4_2 = "weapon_names"
    SHX5_2 = SHX14_1
    SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  end
end
SHX16_1(SHX17_1, SHX18_1, SHX19_1)
