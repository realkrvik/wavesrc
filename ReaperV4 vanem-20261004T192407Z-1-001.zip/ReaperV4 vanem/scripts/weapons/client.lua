-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1, SHX21_1, SHX22_1, SHX23_1, SHX24_1, SHX25_1, SHX26_1
SHX0_1 = Security
SHX1_1 = Logger
SHX2_1 = RPC
SHX3_1 = Player
SHX4_1 = NUI
SHX5_1 = Weapons
SHX7_1 = SHX1_1
SHX6_1 = SHX1_1.log
SHX8_1 = "scripts/weapons/client.lua loaded"
SHX9_1 = "debug"
SHX6_1(SHX7_1, SHX8_1, SHX9_1)
SHX6_1 = GiveWeaponToPed
SHX7_1 = PlayerPedId
SHX8_1 = GetMaxRangeOfCurrentPedWeapon
SHX9_1 = GetDistanceBetweenCoords
SHX10_1 = GetAmmoInPedWeapon
SHX11_1 = RemoveWeaponFromPed
SHX12_1 = tostring
SHX13_1 = GetHashKey
SHX14_1 = HasPedGotWeaponComponent
SHX15_1 = RemoveWeaponComponentFromPed
SHX16_1 = GetLabelText
SHX17_1 = GetSelectedPedWeapon
SHX18_1 = GetWeaponDamageModifier
SHX19_1 = GetLockonDistanceOfCurrentPedWeapon
SHX20_1 = SetPlayerLockon
SHX21_1 = SetPlayerLockonRangeOverride
SHX22_1 = GetWeaponDamageType
SHX24_1 = SHX2_1
SHX23_1 = SHX2_1.register
SHX25_1 = "Reaper:GiveWeaponToPed"
function SHX26_1(...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2
  SHX0_2 = SHX6_1
  SHX1_2 = SHX7_1
  SHX1_2 = SHX1_2()
  SHX2_2 = ...
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = true
  return SHX0_2
end
SHX23_1(SHX24_1, SHX25_1, SHX26_1)
SHX24_1 = SHX2_1
SHX23_1 = SHX2_1.register
SHX25_1 = "get_weapon_damage_type"
function SHX26_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = SHX22_1
  SHX2_2 = SHX0_2
  return SHX1_2(SHX2_2)
end
SHX23_1(SHX24_1, SHX25_1, SHX26_1)
SHX24_1 = SHX2_1
SHX23_1 = SHX2_1.onNet
SHX25_1 = "ReaperV4:CheckWeaponDistance"
function SHX26_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX4_2 = SHX8_1
  SHX5_2 = SHX3_1
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.getPed
  SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX5_2(SHX6_2)
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  SHX5_2 = SHX9_1
  SHX6_2 = SHX2_2
  SHX7_2 = SHX1_2
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX6_2 = SHX3_1
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.currentWeapon
  SHX6_2 = SHX6_2(SHX7_2)
  if SHX6_2 == SHX0_2 then
    SHX6_2 = SHX4_2 + 20
    if SHX5_2 > SHX6_2 and SHX4_2 > 20 then
      SHX6_2 = SHX1_1
      SHX7_2 = SHX6_2
      SHX6_2 = SHX6_2.log
      SHX8_2 = "%s just did damage over %s with a max range of %s"
      SHX9_2 = SHX8_2
      SHX8_2 = SHX8_2.format
      SHX10_2 = SHX0_2
      SHX11_2 = SHX5_2
      SHX12_2 = SHX4_2
      SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2)
      SHX9_2 = "debug"
      SHX6_2(SHX7_2, SHX8_2, SHX9_2)
      SHX6_2 = SHX0_1
      SHX7_2 = SHX6_2
      SHX6_2 = SHX6_2.detection
      SHX8_2 = "maxKillDistance"
      SHX9_2 = {}
      SHX9_2.range = SHX5_2
      SHX9_2.max_range = SHX4_2
      SHX9_2.weapon = SHX0_2
      SHX10_2 = {}
      SHX11_2 = SHX5_2
      SHX10_2[1] = SHX11_2
      SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
    end
  end
  SHX6_2 = SHX3_1
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.get
  SHX8_2 = "config"
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  if SHX6_2 then
    SHX6_2 = SHX3_1
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.get
    SHX8_2 = "config"
    SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
    SHX7_2 = SHX12_1
    SHX8_2 = SHX0_1
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.hash
    SHX10_2 = "antiWeaponSpawn"
    SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX8_2(SHX9_2, SHX10_2)
    SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
    SHX6_2 = SHX6_2[SHX7_2]
    if SHX6_2 then
      SHX6_2 = SHX3_1
      SHX7_2 = SHX6_2
      SHX6_2 = SHX6_2.get
      SHX8_2 = "Weapon:"
      SHX9_2 = SHX0_2
      SHX8_2 = SHX8_2 .. SHX9_2
      SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
      if nil == SHX6_2 then
        SHX6_2 = SHX3_1
        SHX7_2 = SHX6_2
        SHX6_2 = SHX6_2.get
        SHX8_2 = "config"
        SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
        SHX7_2 = SHX12_1
        SHX8_2 = SHX0_1
        SHX9_2 = SHX8_2
        SHX8_2 = SHX8_2.hash
        SHX10_2 = "antiWeaponSpawnIgnoredWeapons"
        SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX8_2(SHX9_2, SHX10_2)
        SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
        SHX6_2 = SHX6_2[SHX7_2]
        SHX7_2 = SHX12_1
        SHX8_2 = SHX0_2
        SHX7_2 = SHX7_2(SHX8_2)
        SHX6_2 = SHX6_2[SHX7_2]
        if nil == SHX6_2 then
          SHX6_2 = SHX1_1
          SHX7_2 = SHX6_2
          SHX6_2 = SHX6_2.log
          SHX8_2 = "%s just did damage but they shouldnt have this weapon"
          SHX9_2 = SHX8_2
          SHX8_2 = SHX8_2.format
          SHX10_2 = SHX0_2
          SHX11_2 = SHX5_2
          SHX12_2 = SHX4_2
          SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2)
          SHX9_2 = "debug"
          SHX6_2(SHX7_2, SHX8_2, SHX9_2)
          SHX6_2 = SHX0_1
          SHX7_2 = SHX6_2
          SHX6_2 = SHX6_2.detection
          SHX8_2 = "antiWeaponSpawn"
          SHX9_2 = {}
          SHX10_2 = SHX3_2 or SHX10_2
          if not SHX3_2 then
            SHX10_2 = SHX0_2
          end
          SHX11_2 = 2
          SHX9_2[1] = SHX10_2
          SHX9_2[2] = SHX11_2
          SHX10_2 = {}
          SHX10_2.method = 3
          SHX10_2.server_reported_weapon = SHX0_2
          SHX11_2 = SHX3_1
          SHX12_2 = SHX11_2
          SHX11_2 = SHX11_2.currentWeapon
          SHX11_2 = SHX11_2(SHX12_2)
          SHX10_2.player_reported_weapon = SHX11_2
          SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
        end
      end
    end
  end
end
SHX23_1(SHX24_1, SHX25_1, SHX26_1)
SHX24_1 = SHX2_1
SHX23_1 = SHX2_1.on
SHX25_1 = "reaperReady"
function SHX26_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX0_2 = SHX3_1
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX2_2 = "gameType"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX1_2 = SHX13_1
  SHX2_2 = "WEAPON_UNARMED"
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.addDetection
  SHX4_2 = {}
  SHX4_2.time = 2000
  SHX4_2.detection = "antiWeaponSpawn"
  function SHX5_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = SHX11_1
    SHX3_3 = SHX7_1
    SHX3_3 = SHX3_3()
    SHX4_3 = SHX1_3[1]
    SHX2_3(SHX3_3, SHX4_3)
  end
  SHX4_2.detected = SHX5_2
  function SHX5_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX0_3 = SHX7_1
    SHX0_3 = SHX0_3()
    SHX1_3 = SHX3_1
    SHX2_3 = SHX1_3
    SHX1_3 = SHX1_3.getCurrentWeapon
    SHX1_3 = SHX1_3(SHX2_3)
    SHX2_3 = SHX0_2
    if "gta5" == SHX2_3 then
      SHX2_3 = SHX10_1
      SHX3_3 = SHX0_3
      SHX4_3 = SHX1_3
      SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
      SHX2_3 = 0 ~= SHX2_3
      SHX3_3 = SHX5_1
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.getWeaponName
      SHX5_3 = SHX1_3
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if not SHX3_3 then
        SHX3_3 = SHX1_3
      end
      SHX4_3 = SHX2_3
      SHX5_3 = {}
      SHX6_3 = SHX3_3
      SHX5_3[1] = SHX6_3
      SHX6_3 = {}
      SHX7_3 = SHX1_3
      SHX6_3.method = 2
      SHX6_3[1] = SHX7_3
      return SHX4_3, SHX5_3, SHX6_3
    else
      SHX2_3 = SHX0_2
      if "rdr3" == SHX2_3 then
        SHX2_3 = SHX5_1
        SHX3_3 = SHX2_3
        SHX2_3 = SHX2_3.getWeaponName
        SHX4_3 = SHX1_3
        SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
        if not SHX2_3 then
          SHX2_3 = SHX1_3
        end
        SHX3_3 = SHX10_1
        SHX4_3 = SHX0_3
        SHX5_3 = SHX1_3
        SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
        SHX3_3 = 0 ~= SHX3_3
        SHX4_3 = SHX3_3
        SHX5_3 = {}
        SHX6_3 = SHX2_3
        SHX5_3[1] = SHX6_3
        SHX6_3 = {}
        SHX7_3 = SHX1_3
        SHX6_3.method = 2
        SHX6_3[1] = SHX7_3
        return SHX4_3, SHX5_3, SHX6_3
      end
    end
  end
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.addDetection
  SHX4_2 = {}
  SHX4_2.time = 2000
  SHX4_2.detection = "blacklistedWeapon"
  SHX4_2.disableVerify = true
  function SHX5_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX0_3 = SHX7_1
    SHX0_3 = SHX0_3()
    SHX1_3 = SHX12_1
    SHX2_3 = SHX17_1
    SHX3_3 = SHX0_3
    SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3 = SHX2_3(SHX3_3)
    SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
    SHX2_3 = SHX3_1
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.get
    SHX4_3 = "config"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
    SHX3_3 = SHX12_1
    SHX4_3 = SHX0_1
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.hash
    SHX6_3 = "blacklistedWeapon"
    SHX4_3, SHX5_3, SHX6_3, SHX7_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3)
    SHX2_3 = SHX2_3[SHX3_3]
    SHX3_3 = SHX2_3[SHX1_3]
    if nil ~= SHX3_3 then
      SHX3_3 = SHX5_1
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.getWeaponName
      SHX5_3 = SHX1_3
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if not SHX3_3 then
        SHX3_3 = SHX1_3
      end
      SHX4_3 = SHX11_1
      SHX5_3 = SHX0_3
      SHX6_3 = tonumber
      SHX7_3 = SHX1_3
      SHX6_3, SHX7_3 = SHX6_3(SHX7_3)
      SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      SHX4_3 = true
      SHX5_3 = {}
      SHX6_3 = SHX3_3
      SHX5_3[1] = SHX6_3
      return SHX4_3, SHX5_3
    end
    SHX3_3 = false
    return SHX3_3
  end
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.addDetection
  SHX4_2 = {}
  SHX4_2.time = 10000
  SHX4_2.detection = "antiWeaponComponentModifier"
  function SHX5_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX2_3 = SHX15_1
    SHX3_3 = SHX7_1
    SHX3_3 = SHX3_3()
    SHX4_3 = SHX1_3.current_weapon
    SHX5_3 = SHX1_3.component_hash
    SHX2_3(SHX3_3, SHX4_3, SHX5_3)
  end
  SHX4_2.detected = SHX5_2
  function SHX5_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3
    SHX0_3 = SHX7_1
    SHX0_3 = SHX0_3()
    SHX1_3 = SHX3_1
    SHX2_3 = SHX1_3
    SHX1_3 = SHX1_3.getCurrentWeapon
    SHX1_3 = SHX1_3(SHX2_3)
    SHX2_3 = SHX5_1
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.getWeaponComponents
    SHX4_3 = SHX1_3
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
    if nil == SHX2_3 then
      SHX3_3 = false
      return SHX3_3
    end
    SHX3_3 = pairs
    SHX4_3 = SHX2_3
    SHX3_3, SHX4_3, SHX5_3, SHX6_3 = SHX3_3(SHX4_3)
    for SHX7_3, SHX8_3 in SHX3_3, SHX4_3, SHX5_3, SHX6_3 do
      SHX9_3 = SHX13_1
      SHX10_3 = SHX8_3.HashKey
      SHX9_3 = SHX9_3(SHX10_3)
      SHX10_3 = SHX14_1
      SHX11_3 = SHX0_3
      SHX12_3 = SHX1_3
      SHX13_3 = SHX9_3
      SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
      SHX11_3 = SHX8_3.IsDefault
      if false == SHX11_3 and SHX10_3 then
        SHX11_3 = SHX3_1
        SHX12_3 = SHX11_3
        SHX11_3 = SHX11_3.get
        SHX13_3 = "weapon_%s_component_%s"
        SHX14_3 = SHX13_3
        SHX13_3 = SHX13_3.format
        SHX15_3 = SHX1_3
        SHX16_3 = SHX9_3
        SHX13_3 = SHX13_3(SHX14_3, SHX15_3, SHX16_3)
        SHX14_3 = false
        SHX11_3 = SHX11_3(SHX12_3, SHX13_3, SHX14_3)
        if false == SHX11_3 then
          SHX11_3 = true
          SHX12_3 = {}
          SHX13_3 = SHX5_1
          SHX14_3 = SHX13_3
          SHX13_3 = SHX13_3.getWeaponName
          SHX15_3 = SHX1_3
          SHX13_3 = SHX13_3(SHX14_3, SHX15_3)
          if not SHX13_3 then
            SHX13_3 = SHX1_3
          end
          SHX14_3 = SHX16_1
          SHX15_3 = SHX8_3.NameGXT
          SHX14_3 = SHX14_3(SHX15_3)
          if not SHX14_3 then
            SHX14_3 = SHX8_3.NameGXT
          end
          SHX12_3[1] = SHX13_3
          SHX12_3[2] = SHX14_3
          SHX13_3 = {}
          SHX13_3.current_weapon = SHX1_3
          SHX13_3.component_hash = SHX9_3
          return SHX11_3, SHX12_3, SHX13_3
        end
      end
    end
  end
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.addDetection
  SHX4_2 = {}
  SHX4_2.time = 2000
  SHX4_2.detection = "antiWeaponModifier"
  function SHX5_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3
    SHX0_3 = SHX7_1
    SHX0_3 = SHX0_3()
    SHX1_3 = SHX17_1
    SHX2_3 = SHX0_3
    SHX1_3 = SHX1_3(SHX2_3)
    SHX2_3 = SHX18_1
    SHX3_3 = SHX1_3
    SHX2_3 = SHX2_3(SHX3_3)
    if 0 ~= SHX1_3 then
      SHX3_3 = SHX10_1
      SHX4_3 = SHX0_3
      SHX5_3 = SHX1_3
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if 0 ~= SHX3_3 then
        SHX3_3 = SHX3_1
        SHX4_3 = SHX3_3
        SHX3_3 = SHX3_3.get
        SHX5_3 = "WeaponDamage:"
        SHX6_3 = SHX1_3
        SHX5_3 = SHX5_3 .. SHX6_3
        SHX6_3 = 1.0
        SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3)
        if SHX2_3 > SHX3_3 then
          SHX3_3 = true
          SHX4_3 = {}
          SHX5_3 = "Weapon Modifier: %s"
          SHX6_3 = SHX5_3
          SHX5_3 = SHX5_3.format
          SHX7_3 = SHX2_3
          SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX5_3(SHX6_3, SHX7_3)
          SHX4_3[1] = SHX5_3
          SHX4_3[2] = SHX6_3
          SHX4_3[3] = SHX7_3
          SHX4_3[4] = SHX8_3
          SHX4_3[5] = SHX9_3
          SHX5_3 = {}
          SHX5_3.type = "weapon"
          SHX5_3.weaponModifier = SHX2_3
          SHX6_3 = SHX3_1
          SHX7_3 = SHX6_3
          SHX6_3 = SHX6_3.get
          SHX8_3 = "WeaponDamage:"
          SHX9_3 = SHX1_3
          SHX8_3 = SHX8_3 .. SHX9_3
          SHX9_3 = 1.0
          SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3)
          SHX5_3.known_value = SHX6_3
          return SHX3_3, SHX4_3, SHX5_3
        end
      end
    end
    SHX3_3 = false
    return SHX3_3
  end
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.addDetection
  SHX4_2 = {}
  SHX4_2.time = 2000
  SHX4_2.detection = "antiAimAssistRpf"
  function SHX5_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX0_3 = SHX7_1
    SHX0_3 = SHX0_3()
    SHX1_3 = SHX3_1
    SHX2_3 = SHX1_3
    SHX1_3 = SHX1_3.getCurrentWeapon
    SHX1_3 = SHX1_3(SHX2_3)
    if 0 ~= SHX1_3 then
      SHX2_3 = SHX1_2
      if SHX1_3 ~= SHX2_3 then
        SHX2_3 = SHX19_1
        SHX3_3 = SHX0_3
        SHX2_3 = SHX2_3(SHX3_3)
        SHX3_3 = 500.0
        if SHX2_3 > SHX3_3 then
          SHX3_3 = PlayerId
          SHX3_3 = SHX3_3()
          SHX4_3 = SHX20_1
          SHX5_3 = SHX3_3
          SHX6_3 = false
          SHX4_3(SHX5_3, SHX6_3)
          SHX4_3 = SHX21_1
          SHX5_3 = SHX3_3
          SHX6_3 = -1.0
          SHX4_3(SHX5_3, SHX6_3)
        end
      end
    end
  end
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
end
SHX23_1(SHX24_1, SHX25_1, SHX26_1)
