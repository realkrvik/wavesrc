-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = Falcon
Falcon = SHX0_1
SHX0_1 = Falcon
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.new
SHX2_1 = "EventsReceived"
SHX3_1 = {}
SHX3_1.max_history_size = 60
SHX3_1.interval_seconds = 60
SHX3_1.track_subtypes = true
SHX3_1.track_sources = true
SHX0_1 = SHX0_1(SHX1_1, SHX2_1, SHX3_1)
SHX1_1 = Falcon
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.new
SHX3_1 = "EventsSent"
SHX4_1 = {}
SHX4_1.max_history_size = 60
SHX4_1.interval_seconds = 60
SHX4_1.track_subtypes = true
SHX4_1.track_sources = true
SHX1_1 = SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX2_1 = AddEventHandler
SHX3_1 = "EventMonitor:BatchUpdate"
function SHX4_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2
  if not SHX0_2 then
    return
  end
  SHX1_2 = SHX0_2.events_received
  if SHX1_2 then
    SHX1_2 = pairs
    SHX2_2 = SHX0_2.events_received
    SHX1_2, SHX2_2, SHX3_2, SHX4_2 = SHX1_2(SHX2_2)
    for SHX5_2, SHX6_2 in SHX1_2, SHX2_2, SHX3_2, SHX4_2 do
      SHX7_2 = 1
      SHX8_2 = SHX6_2
      SHX9_2 = 1
      for SHX10_2 = SHX7_2, SHX8_2, SHX9_2 do
        SHX11_2 = SHX0_1
        SHX12_2 = SHX11_2
        SHX11_2 = SHX11_2.track
        SHX13_2 = SHX5_2
        SHX14_2 = nil
        SHX15_2 = false
        SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2)
      end
    end
  end
  SHX1_2 = SHX0_2.events_sent
  if SHX1_2 then
    SHX1_2 = pairs
    SHX2_2 = SHX0_2.events_sent
    SHX1_2, SHX2_2, SHX3_2, SHX4_2 = SHX1_2(SHX2_2)
    for SHX5_2, SHX6_2 in SHX1_2, SHX2_2, SHX3_2, SHX4_2 do
      SHX7_2 = 1
      SHX8_2 = SHX6_2
      SHX9_2 = 1
      for SHX10_2 = SHX7_2, SHX8_2, SHX9_2 do
        SHX11_2 = SHX1_1
        SHX12_2 = SHX11_2
        SHX11_2 = SHX11_2.track
        SHX13_2 = SHX5_2
        SHX14_2 = nil
        SHX15_2 = false
        SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2)
      end
    end
  end
  SHX1_2 = SHX0_2.resources_received
  if SHX1_2 then
    SHX1_2 = pairs
    SHX2_2 = SHX0_2.resources_received
    SHX1_2, SHX2_2, SHX3_2, SHX4_2 = SHX1_2(SHX2_2)
    for SHX5_2, SHX6_2 in SHX1_2, SHX2_2, SHX3_2, SHX4_2 do
      SHX7_2 = 1
      SHX8_2 = SHX6_2
      SHX9_2 = 1
      for SHX10_2 = SHX7_2, SHX8_2, SHX9_2 do
        SHX11_2 = SHX0_1
        SHX12_2 = SHX11_2
        SHX11_2 = SHX11_2.track
        SHX13_2 = nil
        SHX14_2 = SHX5_2
        SHX15_2 = false
        SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2)
      end
    end
  end
  SHX1_2 = SHX0_2.resources_sent
  if SHX1_2 then
    SHX1_2 = pairs
    SHX2_2 = SHX0_2.resources_sent
    SHX1_2, SHX2_2, SHX3_2, SHX4_2 = SHX1_2(SHX2_2)
    for SHX5_2, SHX6_2 in SHX1_2, SHX2_2, SHX3_2, SHX4_2 do
      SHX7_2 = 1
      SHX8_2 = SHX6_2
      SHX9_2 = 1
      for SHX10_2 = SHX7_2, SHX8_2, SHX9_2 do
        SHX11_2 = SHX1_1
        SHX12_2 = SHX11_2
        SHX11_2 = SHX11_2.track
        SHX13_2 = nil
        SHX14_2 = SHX5_2
        SHX15_2 = false
        SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2)
      end
    end
  end
end
SHX2_1(SHX3_1, SHX4_1)
SHX3_1 = SHX0_1
SHX2_1 = SHX0_1.registerHTTPEndpoints
SHX4_1 = "/events/received"
SHX2_1(SHX3_1, SHX4_1)
SHX3_1 = SHX1_1
SHX2_1 = SHX1_1.registerHTTPEndpoints
SHX4_1 = "/events/sent"
SHX2_1(SHX3_1, SHX4_1)
SHX2_1 = HTTP
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.listen
SHX4_1 = "/events/stats"
function SHX5_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.getStatistics
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SHX1_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getStatistics
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX6_2 = {}
  SHX7_2 = {}
  SHX8_2 = SHX2_2.current_interval
  SHX8_2 = SHX8_2.timestamp
  SHX7_2.timestamp = SHX8_2
  SHX8_2 = SHX2_2.current_interval
  SHX8_2 = SHX8_2.count
  SHX7_2.received = SHX8_2
  SHX8_2 = SHX3_2.current_interval
  SHX8_2 = SHX8_2.count
  SHX7_2.sent = SHX8_2
  SHX8_2 = SHX2_2.current_interval
  SHX8_2 = SHX8_2.elapsed_seconds
  SHX7_2.elapsed_seconds = SHX8_2
  SHX6_2.current_minute = SHX7_2
  SHX7_2 = {}
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.count
  SHX7_2.received = SHX8_2
  SHX8_2 = SHX3_2.totals
  SHX8_2 = SHX8_2.count
  SHX7_2.sent = SHX8_2
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.uptime_seconds
  SHX7_2.uptime_seconds = SHX8_2
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.uptime_minutes
  SHX7_2.uptime_minutes = SHX8_2
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.uptime_hours
  SHX7_2.uptime_hours = SHX8_2
  SHX6_2.totals = SHX7_2
  SHX7_2 = {}
  SHX8_2 = SHX2_2.averages
  SHX8_2 = SHX8_2.per_minute
  SHX7_2.received_per_minute = SHX8_2
  SHX8_2 = SHX3_2.averages
  SHX8_2 = SHX8_2.per_minute
  SHX7_2.sent_per_minute = SHX8_2
  SHX8_2 = SHX2_2.averages
  SHX8_2 = SHX8_2.per_second
  SHX7_2.received_per_second = SHX8_2
  SHX8_2 = SHX3_2.averages
  SHX8_2 = SHX8_2.per_second
  SHX7_2.sent_per_second = SHX8_2
  SHX6_2.averages = SHX7_2
  SHX7_2 = {}
  SHX8_2 = SHX2_2.last_intervals
  SHX8_2 = SHX8_2.count
  SHX7_2.received = SHX8_2
  SHX8_2 = SHX3_2.last_intervals
  SHX8_2 = SHX8_2.count
  SHX7_2.sent = SHX8_2
  SHX8_2 = SHX2_2.last_intervals
  SHX8_2 = SHX8_2.avg_per_interval
  SHX7_2.received_per_minute = SHX8_2
  SHX8_2 = SHX3_2.last_intervals
  SHX8_2 = SHX8_2.avg_per_interval
  SHX7_2.sent_per_minute = SHX8_2
  SHX6_2.last_5_minutes = SHX7_2
  SHX7_2 = SHX2_2.top_subtypes
  SHX6_2.top_events_received = SHX7_2
  SHX7_2 = SHX3_2.top_subtypes
  SHX6_2.top_events_sent = SHX7_2
  SHX7_2 = SHX2_2.top_sources
  SHX6_2.top_resources_received = SHX7_2
  SHX7_2 = SHX3_2.top_sources
  SHX6_2.top_resources_sent = SHX7_2
  SHX7_2 = SHX2_2.history
  SHX6_2.history_received = SHX7_2
  SHX7_2 = SHX3_2.history
  SHX6_2.history_sent = SHX7_2
  SHX5_2.data = SHX6_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX2_1(SHX3_1, SHX4_1, SHX5_1)
SHX2_1 = HTTP
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.listen
SHX4_1 = "/events/summary"
function SHX5_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.getSummary
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SHX1_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSummary
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX6_2 = {}
  SHX7_2 = SHX2_2.total_count
  SHX6_2.total_received = SHX7_2
  SHX7_2 = SHX3_2.total_count
  SHX6_2.total_sent = SHX7_2
  SHX7_2 = SHX2_2.uptime_minutes
  SHX6_2.uptime_minutes = SHX7_2
  SHX7_2 = SHX2_2.current_interval_count
  SHX6_2.current_minute_received = SHX7_2
  SHX7_2 = SHX3_2.current_interval_count
  SHX6_2.current_minute_sent = SHX7_2
  SHX7_2 = SHX2_2.avg_per_minute
  SHX6_2.avg_received_per_minute = SHX7_2
  SHX7_2 = SHX3_2.avg_per_minute
  SHX6_2.avg_sent_per_minute = SHX7_2
  SHX5_2.data = SHX6_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX2_1(SHX3_1, SHX4_1, SHX5_1)
SHX2_1 = HTTP
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.listen
SHX4_1 = "/events/breakdown"
function SHX5_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX2_2 = tonumber
  SHX3_2 = SHX0_2.query
  SHX3_2 = SHX3_2.limit
  SHX2_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX2_2 = 20
  end
  SHX3_2 = SHX0_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSubtypeBreakdown
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX1_1
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.getSubtypeBreakdown
  SHX6_2 = SHX2_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = SHX0_1
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.getSourceBreakdown
  SHX7_2 = SHX2_2
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX6_2 = SHX1_1
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.getSourceBreakdown
  SHX8_2 = SHX2_2
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = SHX1_2.send
  SHX8_2 = {}
  SHX8_2.success = true
  SHX9_2 = {}
  SHX10_2 = SHX3_2.top_subtypes
  SHX9_2.top_events_received = SHX10_2
  SHX10_2 = SHX4_2.top_subtypes
  SHX9_2.top_events_sent = SHX10_2
  SHX10_2 = SHX5_2.top_sources
  SHX9_2.top_resources_received = SHX10_2
  SHX10_2 = SHX6_2.top_sources
  SHX9_2.top_resources_sent = SHX10_2
  SHX10_2 = SHX3_2.total_unique_subtypes
  SHX9_2.total_unique_events_received = SHX10_2
  SHX10_2 = SHX4_2.total_unique_subtypes
  SHX9_2.total_unique_events_sent = SHX10_2
  SHX10_2 = SHX5_2.total_unique_sources
  SHX9_2.total_unique_resources_received = SHX10_2
  SHX10_2 = SHX6_2.total_unique_sources
  SHX9_2.total_unique_resources_sent = SHX10_2
  SHX8_2.data = SHX9_2
  SHX9_2 = os
  SHX9_2 = SHX9_2.time
  SHX9_2 = SHX9_2()
  SHX8_2.timestamp = SHX9_2
  SHX7_2(SHX8_2)
end
SHX2_1(SHX3_1, SHX4_1, SHX5_1)
SHX2_1 = HTTP
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.listen
SHX4_1 = "/events/event"
function SHX5_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = SHX0_2.query
  SHX2_2 = SHX2_2.name
  if not SHX2_2 then
    SHX3_2 = SHX1_2.status
    SHX4_2 = 400
    SHX3_2 = SHX3_2(SHX4_2)
    SHX3_2 = SHX3_2.send
    SHX4_2 = {}
    SHX4_2.success = false
    SHX4_2.error = "Missing 'name' query parameter"
    SHX3_2(SHX4_2)
    return
  end
  SHX3_2 = SHX0_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSubtypeDetails
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX1_1
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.getSubtypeDetails
  SHX6_2 = SHX2_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = SHX1_2.send
  SHX6_2 = {}
  SHX6_2.success = true
  SHX7_2 = {}
  SHX7_2.event_name = SHX2_2
  if SHX3_2 then
    SHX8_2 = SHX3_2.count
    if SHX8_2 then
      goto SHX_LABEL_36
    end
  end
  SHX8_2 = 0
  -- [FIX IF ERROR] Move ::SHX_LABEL_36:: outside nested blocks until all 'goto SHX_LABEL_36' can see it
  ::SHX_LABEL_36::
  SHX7_2.received_count = SHX8_2
  if SHX4_2 then
    SHX8_2 = SHX4_2.count
    if SHX8_2 then
      goto SHX_LABEL_43
    end
  end
  SHX8_2 = 0
  -- [FIX IF ERROR] Move ::SHX_LABEL_43:: outside nested blocks until all 'goto SHX_LABEL_43' can see it
  ::SHX_LABEL_43::
  SHX7_2.sent_count = SHX8_2
  SHX6_2.data = SHX7_2
  SHX7_2 = os
  SHX7_2 = SHX7_2.time
  SHX7_2 = SHX7_2()
  SHX6_2.timestamp = SHX7_2
  SHX5_2(SHX6_2)
end
SHX2_1(SHX3_1, SHX4_1, SHX5_1)
SHX2_1 = HTTP
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.listen
SHX4_1 = "/events/resource"
function SHX5_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = SHX0_2.query
  SHX2_2 = SHX2_2.name
  if not SHX2_2 then
    SHX3_2 = SHX1_2.status
    SHX4_2 = 400
    SHX3_2 = SHX3_2(SHX4_2)
    SHX3_2 = SHX3_2.send
    SHX4_2 = {}
    SHX4_2.success = false
    SHX4_2.error = "Missing 'name' query parameter"
    SHX3_2(SHX4_2)
    return
  end
  SHX3_2 = SHX0_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSourceDetails
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX1_1
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.getSourceDetails
  SHX6_2 = SHX2_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = SHX1_2.send
  SHX6_2 = {}
  SHX6_2.success = true
  SHX7_2 = {}
  SHX7_2.resource_name = SHX2_2
  if SHX3_2 then
    SHX8_2 = SHX3_2.total_count
    if SHX8_2 then
      goto SHX_LABEL_36
    end
  end
  SHX8_2 = 0
  -- [FIX IF ERROR] Move ::SHX_LABEL_36:: outside nested blocks until all 'goto SHX_LABEL_36' can see it
  ::SHX_LABEL_36::
  SHX7_2.received_count = SHX8_2
  if SHX4_2 then
    SHX8_2 = SHX4_2.total_count
    if SHX8_2 then
      goto SHX_LABEL_43
    end
  end
  SHX8_2 = 0
  -- [FIX IF ERROR] Move ::SHX_LABEL_43:: outside nested blocks until all 'goto SHX_LABEL_43' can see it
  ::SHX_LABEL_43::
  SHX7_2.sent_count = SHX8_2
  SHX6_2.data = SHX7_2
  SHX7_2 = os
  SHX7_2 = SHX7_2.time
  SHX7_2 = SHX7_2()
  SHX6_2.timestamp = SHX7_2
  SHX5_2(SHX6_2)
end
SHX2_1(SHX3_1, SHX4_1, SHX5_1)
SHX2_1 = Command
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.add
SHX4_1 = {}
SHX4_1.command = "eventstats"
function SHX5_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.getStatistics
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SHX1_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getStatistics
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "=== Event Statistics ==="
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Total Events Received: ^3%d^7"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.count
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Total Events Sent: ^3%d^7"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX3_2.totals
  SHX8_2 = SHX8_2.count
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Server Uptime: ^3%d^7 minutes (^3%s^7 hours)"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.uptime_minutes
  SHX9_2 = SHX2_2.totals
  SHX9_2 = SHX9_2.uptime_hours
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Current Minute - Received: ^3%d^7, Sent: ^3%d^7"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX2_2.current_interval
  SHX8_2 = SHX8_2.count
  SHX9_2 = SHX3_2.current_interval
  SHX9_2 = SHX9_2.count
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Average per Minute - Received: ^3%s^7, Sent: ^3%s^7"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX2_2.averages
  SHX8_2 = SHX8_2.per_minute
  SHX9_2 = SHX3_2.averages
  SHX9_2 = SHX9_2.per_minute
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Last 5 Minutes - Received: ^3%d^7, Sent: ^3%d^7"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX2_2.last_intervals
  SHX8_2 = SHX8_2.count
  SHX9_2 = SHX3_2.last_intervals
  SHX9_2 = SHX9_2.count
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = ""
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "=== Top 10 Events Received ==="
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = ipairs
  SHX5_2 = SHX2_2.top_subtypes
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
  for SHX8_2, SHX9_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
    if SHX8_2 > 10 then
      break
    end
    SHX10_2 = Logger
    SHX11_2 = SHX10_2
    SHX10_2 = SHX10_2.log
    SHX12_2 = "^3#%d^7 - %s: ^3%d^7 times"
    SHX13_2 = SHX12_2
    SHX12_2 = SHX12_2.format
    SHX14_2 = SHX8_2
    SHX15_2 = SHX9_2.name
    SHX16_2 = SHX9_2.count
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2)
    SHX13_2 = "info"
    SHX10_2(SHX11_2, SHX12_2, SHX13_2)
  end
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = ""
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "=== Top 10 Events Sent ==="
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = ipairs
  SHX5_2 = SHX3_2.top_subtypes
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
  for SHX8_2, SHX9_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
    if SHX8_2 > 10 then
      break
    end
    SHX10_2 = Logger
    SHX11_2 = SHX10_2
    SHX10_2 = SHX10_2.log
    SHX12_2 = "^3#%d^7 - %s: ^3%d^7 times"
    SHX13_2 = SHX12_2
    SHX12_2 = SHX12_2.format
    SHX14_2 = SHX8_2
    SHX15_2 = SHX9_2.name
    SHX16_2 = SHX9_2.count
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2)
    SHX13_2 = "info"
    SHX10_2(SHX11_2, SHX12_2, SHX13_2)
  end
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = ""
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "=== Top 10 Resources (Received) ==="
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = ipairs
  SHX5_2 = SHX2_2.top_sources
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
  for SHX8_2, SHX9_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
    if SHX8_2 > 10 then
      break
    end
    SHX10_2 = Logger
    SHX11_2 = SHX10_2
    SHX10_2 = SHX10_2.log
    SHX12_2 = "^3#%d^7 - %s: ^3%d^7 events"
    SHX13_2 = SHX12_2
    SHX12_2 = SHX12_2.format
    SHX14_2 = SHX8_2
    SHX15_2 = SHX9_2.id
    SHX16_2 = SHX9_2.count
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2)
    SHX13_2 = "info"
    SHX10_2(SHX11_2, SHX12_2, SHX13_2)
  end
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = ""
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "=== Top 10 Resources (Sent) ==="
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = ipairs
  SHX5_2 = SHX3_2.top_sources
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
  for SHX8_2, SHX9_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
    if SHX8_2 > 10 then
      break
    end
    SHX10_2 = Logger
    SHX11_2 = SHX10_2
    SHX10_2 = SHX10_2.log
    SHX12_2 = "^3#%d^7 - %s: ^3%d^7 events"
    SHX13_2 = SHX12_2
    SHX12_2 = SHX12_2.format
    SHX14_2 = SHX8_2
    SHX15_2 = SHX9_2.id
    SHX16_2 = SHX9_2.count
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2)
    SHX13_2 = "info"
    SHX10_2(SHX11_2, SHX12_2, SHX13_2)
  end
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = ""
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = GetConvar
  SHX5_2 = "web_baseUrl"
  SHX6_2 = "http://your-server-ip:30120"
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = Logger
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.log
  SHX7_2 = "Access full stats at: ^3https://%s/ReaperV4/events/stats^7"
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.format
  SHX9_2 = SHX4_2
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX8_2 = "info"
  SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX5_2 = Logger
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.log
  SHX7_2 = "Access breakdown at: ^3https://%s/ReaperV4/events/breakdown^7"
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.format
  SHX9_2 = SHX4_2
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX8_2 = "info"
  SHX5_2(SHX6_2, SHX7_2, SHX8_2)
end
SHX4_1.callback = SHX5_1
SHX4_1.hidden = false
SHX5_1 = {}
SHX6_1 = "Manage Server"
SHX5_1[1] = SHX6_1
SHX4_1.permissions = SHX5_1
SHX2_1(SHX3_1, SHX4_1)
SHX2_1 = Logger
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.log
SHX4_1 = "Event monitoring system initialized (Falcon-powered)"
SHX5_1 = "info"
SHX2_1(SHX3_1, SHX4_1, SHX5_1)
SHX2_1 = Logger
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.log
SHX4_1 = "Access event stats at ^3/ReaperV4/events/stats^7 or ^3/ReaperV4/events/summary^7"
SHX5_1 = "debug"
SHX2_1(SHX3_1, SHX4_1, SHX5_1)
