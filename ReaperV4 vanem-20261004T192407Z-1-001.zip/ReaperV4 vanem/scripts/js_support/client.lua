-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1
SHX0_1 = Security
SHX1_1 = Logger
SHX2_1 = Player
SHX3_1 = table
SHX3_1 = SHX3_1.insert
SHX4_1 = LocalPlayer
SHX4_1 = SHX4_1.state
SHX5_1 = GetConvar
SHX6_1 = TriggerServerEvent
SHX7_1 = TriggerLatentServerEvent
SHX8_1 = TriggerEvent
SHX9_1 = GetInvokingResource
SHX10_1 = GetGameTimer
SHX11_1 = tostring
SHX12_1 = exports
SHX13_1 = "TriggerServerEvent"
function SHX14_1(SHX0_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX1_2 = SHX9_1
  SHX1_2 = SHX1_2()
  SHX2_2 = SHX5_1
  SHX3_2 = "reaper_allow_js_events"
  SHX4_2 = "false"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if "false" == SHX2_2 then
    SHX2_2 = SHX1_1
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.log
    SHX4_2 = "The resource ^3%s^7 attempted to trigger the event ^3%s^7 with ^3exports.ReaperV4:TriggerServerEvent^7 but the convar ^3reaper_allow_js_events^7 was set to false"
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.format
    SHX6_2 = SHX1_2
    SHX7_2 = SHX0_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX5_2 = "info"
    return SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  end
  SHX2_2 = SHX6_1
  SHX3_2 = SHX0_2
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = ...
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
end
SHX12_1(SHX13_1, SHX14_1)
SHX12_1 = exports
SHX13_1 = "TriggerLatentServerEvent"
function SHX14_1(SHX0_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX1_2 = SHX9_1
  SHX1_2 = SHX1_2()
  SHX2_2 = SHX5_1
  SHX3_2 = "reaper_allow_js_events"
  SHX4_2 = "false"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if "false" == SHX2_2 then
    SHX2_2 = SHX1_1
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.log
    SHX4_2 = "The resource ^3%s^7 attempted to trigger the event ^3%s^7 with ^3exports.ReaperV4:TriggerServerEvent^7 but the convar ^3reaper_allow_js_events^7 was set to false"
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.format
    SHX6_2 = SHX1_2
    SHX7_2 = SHX0_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX5_2 = "info"
    return SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  end
  SHX2_2 = SHX7_1
  SHX3_2 = SHX0_2
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = ...
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
end
SHX12_1(SHX13_1, SHX14_1)
SHX12_1 = exports
SHX13_1 = "TriggerEvent"
function SHX14_1(SHX0_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX1_2 = SHX9_1
  SHX1_2 = SHX1_2()
  SHX2_2 = SHX5_1
  SHX3_2 = "reaper_allow_js_events"
  SHX4_2 = "false"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if "false" == SHX2_2 then
    SHX2_2 = SHX1_1
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.log
    SHX4_2 = "The resource ^3%s^7 attempted to trigger the event ^3%s^7 with ^3exports.ReaperV4:TriggerServerEvent^7 but the convar ^3reaper_allow_js_events^7 was set to false"
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.format
    SHX6_2 = SHX1_2
    SHX7_2 = SHX0_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX5_2 = "info"
    return SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  end
  SHX2_2 = SHX8_1
  SHX3_2 = SHX0_2
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = ...
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
end
SHX12_1(SHX13_1, SHX14_1)
SHX12_1 = exports
SHX13_1 = "SetStateJs"
function SHX14_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX2_2 = SHX5_1
  SHX3_2 = "reaper_allow_js_events"
  SHX4_2 = "false"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if "false" == SHX2_2 then
    return
  end
  SHX2_2 = SHX9_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX10_1
  SHX3_2 = SHX3_2()
  SHX4_2 = SHX2_1
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.set
  SHX6_2 = SHX0_2
  SHX7_2 = SHX1_2
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = SHX4_1
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.set
  SHX6_2 = "reaper:"
  SHX7_2 = SHX0_1
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.hash
  SHX9_2 = SHX0_2
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX6_2 = SHX6_2 .. SHX7_2
  SHX7_2 = {}
  SHX8_2 = SHX0_1
  SHX9_2 = SHX8_2
  SHX8_2 = SHX8_2.hash
  SHX10_2 = SHX0_2
  SHX11_2 = SHX11_1
  SHX12_2 = SHX1_2
  SHX11_2 = SHX11_2(SHX12_2)
  SHX12_2 = SHX3_2
  SHX10_2 = SHX10_2 .. SHX11_2 .. SHX12_2
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  SHX7_2.key = SHX8_2
  SHX7_2.key2 = SHX3_2
  SHX7_2.key3 = SHX1_2
  SHX7_2.eventName = SHX0_2
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = SHX3_1
  SHX5_2 = StateRecorder
  SHX6_2 = {}
  SHX6_2.index = SHX0_2
  SHX6_2.value = SHX1_2
  SHX6_2.invoking_resource = SHX2_2
  SHX6_2.path = "js_invoke"
  SHX6_2.time = SHX3_2
  SHX4_2(SHX5_2, SHX6_2)
end
SHX12_1(SHX13_1, SHX14_1)
