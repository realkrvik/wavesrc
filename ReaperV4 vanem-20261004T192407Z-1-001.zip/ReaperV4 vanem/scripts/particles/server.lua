-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = false
SHX1_1 = false
SHX2_1 = false
SHX3_1 = false
SHX4_1 = false
SHX5_1 = {}
SHX6_1 = {}
SHX7_1 = RPC
SHX8_1 = SHX7_1
SHX7_1 = SHX7_1.on
SHX9_1 = "configUpdated"
function SHX10_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX0_2 = Settings
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX0_2 = SHX0_2(SHX1_2)
  SHX1_2 = SHX0_2.particleRules
  SHX1_2 = SHX1_2.particleWhitelistEnabled
  SHX0_1 = SHX1_2
  SHX1_2 = SHX0_2.particleRules
  SHX1_2 = SHX1_2.autoParticleWhitelist
  SHX1_1 = SHX1_2
  SHX1_2 = SHX0_2.particleRules
  SHX1_2 = SHX1_2.blockAllParticles
  SHX2_1 = SHX1_2
  SHX1_2 = SHX0_2.particleRules
  SHX1_2 = SHX1_2.logParticlesToConsole
  SHX3_1 = SHX1_2
  SHX1_2 = pairs
  SHX2_2 = SHX0_2.particleRules
  SHX2_2 = SHX2_2.whitelisted
  SHX1_2, SHX2_2, SHX3_2, SHX4_2 = SHX1_2(SHX2_2)
  for SHX5_2, SHX6_2 in SHX1_2, SHX2_2, SHX3_2, SHX4_2 do
    SHX7_2 = tonumber
    SHX8_2 = SHX6_2
    SHX7_2 = SHX7_2(SHX8_2)
    if nil == SHX7_2 then
      SHX7_2 = GetHashKey
      SHX8_2 = SHX6_2
      SHX7_2 = SHX7_2(SHX8_2)
      SHX6_2 = SHX7_2
    end
    SHX7_2 = tostring
    SHX8_2 = SHX6_2
    SHX7_2 = SHX7_2(SHX8_2)
    SHX8_2 = SHX5_1
    SHX8_2[SHX7_2] = true
  end
  SHX1_2 = SHX0_2.particleRules
  SHX1_2 = SHX1_2.nonWhitelistedParticleAction
  SHX4_1 = SHX1_2
  SHX1_2 = SHX0_2.particleRules
  SHX1_2 = SHX1_2.blacklisted
  SHX6_1 = SHX1_2
  SHX1_2 = SHX0_2.particleRules
  SHX1_2 = SHX1_2.particleRatelimits
  particleRatelimits = SHX1_2
  SHX1_2 = SetConvarReplicated
  SHX2_2 = "auto_particle_whitelist"
  SHX3_2 = tostring
  SHX4_2 = SHX1_1
  if not SHX4_2 then
    SHX4_2 = false
  end
  SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX3_2(SHX4_2)
  SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
end
SHX7_1(SHX8_1, SHX9_1, SHX10_1)
SHX7_1 = RPC
SHX8_1 = SHX7_1
SHX7_1 = SHX7_1.on
SHX9_1 = "reaperStarted"
function SHX10_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX0_2 = Cache
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX2_2 = "gameType"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.onNet
  SHX3_2 = "ptFxEvent"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3
    SHX2_3 = CancelEvent
    SHX2_3()
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = CancelEvent
      return SHX3_3()
    end
    SHX3_3 = SHX2_1
    if SHX3_3 then
      SHX3_3 = CancelEvent
      SHX3_3()
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.NewLog
    SHX5_3 = "^3%s^7 (^3id:%s^7) just spawned a new particle. Particle hash: ^3%s"
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.format
    SHX8_3 = SHX2_3
    SHX7_3 = SHX2_3.getName
    SHX7_3 = SHX7_3(SHX8_3)
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getId
    SHX8_3 = SHX8_3(SHX9_3)
    SHX9_3 = SHX1_3.effectHash
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX6_3 = "info"
    SHX7_3 = "particles"
    SHX8_3 = {}
    SHX9_3 = SHX3_1
    SHX9_3 = not SHX9_3
    SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.getMeta
    SHX5_3 = "whitelisted_particle_"
    SHX6_3 = SHX1_3.effectHash
    SHX5_3 = SHX5_3 .. SHX6_3
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if nil == SHX3_3 then
      SHX3_3 = GetGameTimer
      SHX3_3 = SHX3_3()
      SHX5_3 = SHX2_3
      SHX4_3 = SHX2_3.getMeta
      SHX6_3 = "whitelist_particle_temp"
      SHX7_3 = 0
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      SHX3_3 = SHX3_3 - SHX4_3
      SHX4_3 = 10000
      if SHX3_3 < SHX4_3 then
        SHX4_3 = SHX2_3
        SHX3_3 = SHX2_3.setMeta
        SHX5_3 = "whitelisted_particle_"
        SHX6_3 = SHX1_3.effectHash
        SHX5_3 = SHX5_3 .. SHX6_3
        SHX6_3 = true
        SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      end
    end
    SHX3_3 = SHX0_1
    if SHX3_3 then
      SHX3_3 = tostring
      SHX4_3 = SHX1_3.effectHash
      SHX3_3 = SHX3_3(SHX4_3)
      SHX4_3 = SHX5_1
      SHX3_3 = SHX4_3[SHX3_3]
      if nil == SHX3_3 then
        SHX4_3 = SHX2_3
        SHX3_3 = SHX2_3.getMeta
        SHX5_3 = "whitelisted_particle_"
        SHX6_3 = SHX1_3.effectHash
        SHX5_3 = SHX5_3 .. SHX6_3
        SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
        if nil == SHX3_3 then
          SHX3_3 = CancelEvent
          SHX3_3()
          SHX3_3 = RPC
          SHX4_3 = SHX3_3
          SHX3_3 = SHX3_3.emitLocal
          SHX5_3 = "Reaper:NewDetection"
          SHX6_3 = {}
          SHX6_3.type = "particleWhitelist"
          SHX7_3 = {}
          SHX8_3 = SHX1_3.effectHash
          SHX7_3.effectHash = SHX8_3
          SHX6_3.data = SHX7_3
          SHX7_3 = {}
          SHX8_3 = SHX1_3.effectHash
          SHX7_3[1] = SHX8_3
          SHX6_3.params = SHX7_3
          SHX6_3.action = "Ban Player"
          SHX8_3 = SHX2_3
          SHX7_3 = SHX2_3.getId
          SHX7_3, SHX8_3, SHX9_3 = SHX7_3(SHX8_3)
          return SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
        end
      end
    end
    SHX4_3 = SHX1_3.effectHash
    SHX3_3 = SHX6_1
    SHX3_3 = SHX3_3[SHX4_3]
    if SHX3_3 then
      SHX3_3 = CancelEvent
      SHX3_3()
      SHX3_3 = RPC
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.emitLocal
      SHX5_3 = "Reaper:NewDetection"
      SHX6_3 = {}
      SHX6_3.type = "blacklistedParticle"
      SHX7_3 = {}
      SHX8_3 = SHX1_3.effectHash
      SHX7_3.effectHash = SHX8_3
      SHX6_3.data = SHX7_3
      SHX7_3 = {}
      SHX8_3 = SHX1_3.effectHash
      SHX7_3[1] = SHX8_3
      SHX6_3.params = SHX7_3
      SHX7_3 = SHX4_1
      SHX6_3.action = SHX7_3
      SHX8_3 = SHX2_3
      SHX7_3 = SHX2_3.getId
      SHX7_3, SHX8_3, SHX9_3 = SHX7_3(SHX8_3)
      return SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    end
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.register
  SHX3_2 = "requestParticleSpawn"
  function SHX4_2(SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3
    SHX5_3 = Player
    SHX6_3 = SHX0_3
    SHX5_3 = SHX5_3(SHX6_3)
    if nil == SHX5_3 then
      SHX6_3 = false
      return SHX6_3
    end
    SHX6_3 = SHX1_1
    if false == SHX6_3 then
      SHX6_3 = false
      return SHX6_3
    end
    SHX6_3 = ExecutionCheck
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.execution_valid
    SHX9_3 = SHX5_3
    SHX8_3 = SHX5_3.getId
    SHX8_3 = SHX8_3(SHX9_3)
    SHX9_3 = "StartNetworkedParticleFx"
    SHX10_3 = SHX3_3
    SHX11_3 = SHX2_3
    SHX12_3 = SHX4_3
    SHX13_3 = SHX1_3 or SHX13_3
    if not SHX1_3 then
      SHX13_3 = "0"
    end
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3)
    if false == SHX6_3 then
      SHX6_3 = false
      return SHX6_3
    end
    SHX7_3 = SHX5_3
    SHX6_3 = SHX5_3.setMeta
    SHX8_3 = "whitelist_particle_temp"
    SHX9_3 = GetGameTimer
    SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3 = SHX9_3()
    SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
    SHX7_3 = SHX5_3
    SHX6_3 = SHX5_3.NewLog
    SHX8_3 = "^3%s^7 (^3id:%s^7) just requested to spawn a particle (^3%s^7) from (^3%s^7) (^3%s^7)"
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.format
    SHX11_3 = SHX5_3
    SHX10_3 = SHX5_3.getName
    SHX10_3 = SHX10_3(SHX11_3)
    SHX12_3 = SHX5_3
    SHX11_3 = SHX5_3.getId
    SHX11_3 = SHX11_3(SHX12_3)
    SHX12_3 = SHX1_3
    SHX13_3 = SHX2_3
    SHX14_3 = SHX3_3
    SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
    SHX9_3 = "debug"
    SHX10_3 = "particles"
    SHX11_3 = {}
    SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    SHX6_3 = true
    return SHX6_3
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
SHX7_1(SHX8_1, SHX9_1, SHX10_1)
