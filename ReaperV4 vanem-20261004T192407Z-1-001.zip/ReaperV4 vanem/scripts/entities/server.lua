-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1, SHX21_1, SHX22_1, SHX23_1, SHX24_1, SHX25_1, SHX26_1, SHX27_1, SHX28_1, SHX29_1, SHX30_1, SHX31_1, SHX32_1, SHX33_1, SHX34_1, SHX35_1, SHX36_1, SHX37_1, SHX38_1, SHX39_1, SHX40_1, SHX41_1, SHX42_1, SHX43_1, SHX44_1, SHX45_1, SHX46_1, SHX47_1, SHX48_1, SHX49_1, SHX50_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = ExecutionCheck
ExecutionCheck = SHX0_1
SHX0_1 = Security
Security = SHX0_1
SHX0_1 = Falcon
Falcon = SHX0_1
SHX0_1 = tonumber
SHX1_1 = GetConvar
SHX2_1 = "buildNumber"
SHX3_1 = "0"
SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1, SHX21_1, SHX22_1, SHX23_1, SHX24_1, SHX25_1, SHX26_1, SHX27_1, SHX28_1, SHX29_1, SHX30_1, SHX31_1, SHX32_1, SHX33_1, SHX34_1, SHX35_1, SHX36_1, SHX37_1, SHX38_1, SHX39_1, SHX40_1, SHX41_1, SHX42_1, SHX43_1, SHX44_1, SHX45_1, SHX46_1, SHX47_1, SHX48_1, SHX49_1, SHX50_1 = SHX1_1(SHX2_1, SHX3_1)
SHX0_1 = SHX0_1(SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1, SHX21_1, SHX22_1, SHX23_1, SHX24_1, SHX25_1, SHX26_1, SHX27_1, SHX28_1, SHX29_1, SHX30_1, SHX31_1, SHX32_1, SHX33_1, SHX34_1, SHX35_1, SHX36_1, SHX37_1, SHX38_1, SHX39_1, SHX40_1, SHX41_1, SHX42_1, SHX43_1, SHX44_1, SHX45_1, SHX46_1, SHX47_1, SHX48_1, SHX49_1, SHX50_1)
SHX1_1 = 15553
SHX0_1 = Logger
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.customArtifacts
SHX0_1 = SHX0_1 >= SHX1_1 and SHX0_1
SHX1_1 = GetConvar
SHX2_1 = "gamename"
SHX3_1 = "gta5"
SHX1_1 = SHX1_1(SHX2_1, SHX3_1)
SHX2_1 = GetEntityModel
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = DoesEntityExist
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if not SHX1_2 then
    return
  end
  SHX1_2 = SHX2_1
  SHX2_2 = SHX0_2
  return SHX1_2(SHX2_2)
end
SHX4_1 = false
SHX5_1 = false
SHX6_1 = false
SHX7_1 = false
SHX8_1 = false
SHX9_1 = false
SHX10_1 = false
SHX11_1 = -1
SHX12_1 = -1
SHX13_1 = ""
SHX14_1 = false
SHX15_1 = false
SHX16_1 = false
SHX17_1 = {}
SHX18_1 = {}
SHX19_1 = {}
SHX20_1 = GetConvar
SHX21_1 = "reaper_auto_patch_npc_plates"
SHX22_1 = "true"
SHX20_1 = SHX20_1(SHX21_1, SHX22_1)
SHX20_1 = "true" == SHX20_1
SHX21_1 = GetConvar
SHX22_1 = "reaper_block_model_0"
SHX23_1 = "false"
SHX21_1 = SHX21_1(SHX22_1, SHX23_1)
SHX21_1 = "true" == SHX21_1
SHX22_1 = "Log Player"
SHX23_1 = false
SHX24_1 = false
SHX25_1 = false
SHX26_1 = {}
SHX27_1 = {}
SHX28_1 = {}
SHX29_1 = 1931904776
SHX28_1[SHX29_1] = true
SHX29_1 = GetHashKey
SHX30_1 = "p_parachute_s"
SHX29_1 = SHX29_1(SHX30_1)
SHX28_1[SHX29_1] = true
SHX29_1 = GetHashKey
SHX30_1 = "p_parachute1_mp_dec"
SHX29_1 = SHX29_1(SHX30_1)
SHX28_1[SHX29_1] = true
SHX29_1 = GetHashKey
SHX30_1 = "p_parachute1_s"
SHX29_1 = SHX29_1(SHX30_1)
SHX28_1[SHX29_1] = true
SHX29_1 = GetHashKey
SHX30_1 = "p_parachute1_mp_s"
SHX29_1 = SHX29_1(SHX30_1)
SHX28_1[SHX29_1] = true
SHX29_1 = GetHashKey
SHX30_1 = "p_parachute1_sp_dec"
SHX29_1 = SHX29_1(SHX30_1)
SHX28_1[SHX29_1] = true
SHX29_1 = GetHashKey
SHX30_1 = "prop_v_parachute"
SHX29_1 = SHX29_1(SHX30_1)
SHX28_1[SHX29_1] = true
SHX29_1 = GetHashKey
SHX30_1 = "p_parachute_fallen_s"
SHX29_1 = SHX29_1(SHX30_1)
SHX28_1[SHX29_1] = true
SHX29_1 = GetHashKey
SHX30_1 = "p_parachute_s_shop"
SHX29_1 = SHX29_1(SHX30_1)
SHX28_1[SHX29_1] = true
SHX29_1 = GetHashKey
SHX30_1 = "prop_parachute"
SHX29_1 = SHX29_1(SHX30_1)
SHX28_1[SHX29_1] = true
SHX29_1 = GetHashKey
SHX30_1 = "p_parachute1_sp_s"
SHX29_1 = SHX29_1(SHX30_1)
SHX28_1[SHX29_1] = true
SHX29_1 = GetHashKey
SHX30_1 = "hei_bio_heist_parachute"
SHX29_1 = SHX29_1(SHX30_1)
SHX28_1[SHX29_1] = true
SHX29_1 = GetHashKey
SHX30_1 = "hei_p_parachute_s_female"
SHX29_1 = SHX29_1(SHX30_1)
SHX28_1[SHX29_1] = true
SHX29_1 = GetHashKey
SHX30_1 = "hei_prison_heist_parachute"
SHX29_1 = SHX29_1(SHX30_1)
SHX28_1[SHX29_1] = true
SHX29_1 = {}
SHX30_1 = {}
SHX31_1 = {}
function SHX32_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2
  if 1 == SHX1_2 then
    SHX2_2 = tostring
    SHX3_2 = SHX0_2
    SHX2_2 = SHX2_2(SHX3_2)
    SHX3_2 = SHX29_1
    SHX2_2 = SHX3_2[SHX2_2]
    return SHX2_2
  elseif 2 == SHX1_2 then
    SHX2_2 = tostring
    SHX3_2 = SHX0_2
    SHX2_2 = SHX2_2(SHX3_2)
    SHX3_2 = SHX30_1
    SHX2_2 = SHX3_2[SHX2_2]
    return SHX2_2
  elseif 3 == SHX1_2 then
    SHX2_2 = tostring
    SHX3_2 = SHX0_2
    SHX2_2 = SHX2_2(SHX3_2)
    SHX3_2 = SHX31_1
    SHX2_2 = SHX3_2[SHX2_2]
    return SHX2_2
  end
  SHX2_2 = nil
  return SHX2_2
end
function SHX33_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX1_2 = SHX3_1
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if nil == SHX1_2 then
    SHX2_2 = nil
    return SHX2_2
  end
  SHX2_2 = GetEntityType
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SHX32_1
  SHX4_2 = SHX1_2
  SHX5_2 = SHX2_2
  return SHX3_2(SHX4_2, SHX5_2)
end
function SHX34_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  if 1 == SHX0_2 then
    SHX1_2 = "ped"
    return SHX1_2
  elseif 2 == SHX0_2 then
    SHX1_2 = "vehicle"
    return SHX1_2
  elseif 3 == SHX0_2 then
    SHX1_2 = "object"
    return SHX1_2
  end
  SHX1_2 = "UNKNOWN_ENTITY_TYPE"
  return SHX1_2
end
SHX35_1 = CreateThread
function SHX36_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX0_2 = IniParser
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.parseFile
  SHX2_2 = "PedList.ini"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX1_2 = IniParser
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.parseFile
  SHX3_2 = "VehicleList.ini"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX2_2 = IniParser
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.parseFile
  SHX4_2 = "ObjectList.ini"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX3_2 = pairs
  SHX4_2 = SHX0_2
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
  for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    SHX9_2 = tostring
    SHX10_2 = GetHashKey
    SHX11_2 = SHX7_2
    SHX10_2, SHX11_2 = SHX10_2(SHX11_2)
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
    SHX10_2 = SHX29_1
    SHX10_2[SHX9_2] = SHX7_2
  end
  SHX3_2 = pairs
  SHX4_2 = SHX1_2
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
  for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    SHX9_2 = tostring
    SHX10_2 = GetHashKey
    SHX11_2 = SHX7_2
    SHX10_2, SHX11_2 = SHX10_2(SHX11_2)
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
    SHX10_2 = SHX30_1
    SHX10_2[SHX9_2] = SHX7_2
  end
  SHX3_2 = pairs
  SHX4_2 = SHX2_2
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
  for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    SHX9_2 = tostring
    SHX10_2 = SHX8_2
    SHX9_2 = SHX9_2(SHX10_2)
    SHX10_2 = SHX31_1
    SHX10_2[SHX9_2] = SHX7_2
  end
end
SHX35_1(SHX36_1)
SHX35_1 = {}
entity_tracker = SHX35_1
SHX35_1 = Falcon
SHX36_1 = SHX35_1
SHX35_1 = SHX35_1.new
SHX37_1 = "Entities"
SHX38_1 = {}
SHX38_1.max_history_size = 60
SHX38_1.interval_seconds = 60
SHX38_1.track_subtypes = true
SHX38_1.track_sources = true
SHX35_1 = SHX35_1(SHX36_1, SHX37_1, SHX38_1)
SHX36_1 = Falcon
SHX37_1 = SHX36_1
SHX36_1 = SHX36_1.new
SHX38_1 = "EntityResources"
SHX39_1 = {}
SHX39_1.max_history_size = 60
SHX39_1.interval_seconds = 60
SHX39_1.track_subtypes = true
SHX39_1.track_sources = true
SHX36_1 = SHX36_1(SHX37_1, SHX38_1, SHX39_1)
function SHX37_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  SHX2_2 = tostring
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2)
  if 1 == SHX1_2 then
    SHX3_2 = SHX29_1
    SHX3_2 = SHX3_2[SHX2_2]
    if SHX3_2 then
      SHX3_2 = SHX29_1
      SHX3_2 = SHX3_2[SHX2_2]
      return SHX3_2
  end
  else
    if 2 == SHX1_2 then
      SHX3_2 = SHX30_1
      SHX3_2 = SHX3_2[SHX2_2]
      if SHX3_2 then
        SHX3_2 = SHX30_1
        SHX3_2 = SHX3_2[SHX2_2]
        return SHX3_2
    end
    elseif 3 == SHX1_2 then
      SHX3_2 = SHX31_1
      SHX3_2 = SHX3_2[SHX2_2]
      if SHX3_2 then
        SHX3_2 = SHX31_1
        SHX3_2 = SHX3_2[SHX2_2]
        return SHX3_2
      end
    end
  end
  SHX3_2 = "Model_"
  SHX4_2 = SHX0_2
  SHX3_2 = SHX3_2 .. SHX4_2
  return SHX3_2
end
SHX38_1 = "/entities"
SHX39_1 = SHX35_1
SHX40_1 = HTTP
SHX41_1 = SHX40_1
SHX40_1 = SHX40_1.listen
SHX42_1 = SHX38_1
SHX43_1 = "/summary"
SHX42_1 = SHX42_1 .. SHX43_1
function SHX43_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX2_2 = SHX39_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.getSummary
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SHX1_2.send
  SHX4_2 = {}
  SHX4_2.success = true
  SHX4_2.data = SHX2_2
  SHX5_2 = os
  SHX5_2 = SHX5_2.time
  SHX5_2 = SHX5_2()
  SHX4_2.timestamp = SHX5_2
  SHX3_2(SHX4_2)
end
SHX40_1(SHX41_1, SHX42_1, SHX43_1)
SHX40_1 = HTTP
SHX41_1 = SHX40_1
SHX40_1 = SHX40_1.listen
SHX42_1 = SHX38_1
SHX43_1 = "/subtypes"
SHX42_1 = SHX42_1 .. SHX43_1
function SHX43_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = tonumber
  SHX3_2 = SHX0_2.query
  SHX3_2 = SHX3_2.limit
  SHX2_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX2_2 = 20
  end
  SHX3_2 = SHX39_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSubtypeBreakdown
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX5_2.data = SHX3_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX40_1(SHX41_1, SHX42_1, SHX43_1)
SHX40_1 = HTTP
SHX41_1 = SHX40_1
SHX40_1 = SHX40_1.listen
SHX42_1 = SHX38_1
SHX43_1 = "/subtype"
SHX42_1 = SHX42_1 .. SHX43_1
function SHX43_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX0_2.query
  SHX2_2 = SHX2_2.name
  if not SHX2_2 then
    SHX2_2 = SHX0_2.query
    SHX2_2 = SHX2_2.type
  end
  if not SHX2_2 then
    SHX3_2 = SHX1_2.status
    SHX4_2 = 400
    SHX3_2 = SHX3_2(SHX4_2)
    SHX3_2 = SHX3_2.send
    SHX4_2 = {}
    SHX4_2.success = false
    SHX4_2.error = "Missing 'name' or 'type' query parameter"
    SHX3_2(SHX4_2)
    return
  end
  SHX3_2 = SHX39_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSubtypeDetails
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  if not SHX3_2 then
    SHX4_2 = SHX1_2.status
    SHX5_2 = 404
    SHX4_2 = SHX4_2(SHX5_2)
    SHX4_2 = SHX4_2.send
    SHX5_2 = {}
    SHX5_2.success = false
    SHX5_2.error = "Subtype not found"
    SHX4_2(SHX5_2)
    return
  end
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX5_2.data = SHX3_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX40_1(SHX41_1, SHX42_1, SHX43_1)
SHX40_1 = HTTP
SHX41_1 = SHX40_1
SHX40_1 = SHX40_1.listen
SHX42_1 = SHX38_1
SHX43_1 = "/sources"
SHX42_1 = SHX42_1 .. SHX43_1
function SHX43_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = tonumber
  SHX3_2 = SHX0_2.query
  SHX3_2 = SHX3_2.limit
  SHX2_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX2_2 = 20
  end
  SHX3_2 = SHX39_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSourceBreakdown
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX5_2.data = SHX3_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX40_1(SHX41_1, SHX42_1, SHX43_1)
SHX40_1 = HTTP
SHX41_1 = SHX40_1
SHX40_1 = SHX40_1.listen
SHX42_1 = SHX38_1
SHX43_1 = "/source"
SHX42_1 = SHX42_1 .. SHX43_1
function SHX43_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX0_2.query
  SHX2_2 = SHX2_2.id
  if not SHX2_2 then
    SHX3_2 = SHX1_2.status
    SHX4_2 = 400
    SHX3_2 = SHX3_2(SHX4_2)
    SHX3_2 = SHX3_2.send
    SHX4_2 = {}
    SHX4_2.success = false
    SHX4_2.error = "Missing 'id' query parameter"
    SHX3_2(SHX4_2)
    return
  end
  SHX3_2 = SHX39_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSourceDetails
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  if not SHX3_2 then
    SHX4_2 = SHX1_2.status
    SHX5_2 = 404
    SHX4_2 = SHX4_2(SHX5_2)
    SHX4_2 = SHX4_2.send
    SHX5_2 = {}
    SHX5_2.success = false
    SHX5_2.error = "Source not found"
    SHX4_2(SHX5_2)
    return
  end
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX5_2.data = SHX3_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX40_1(SHX41_1, SHX42_1, SHX43_1)
SHX40_1 = HTTP
SHX41_1 = SHX40_1
SHX40_1 = SHX40_1.listen
SHX42_1 = SHX38_1
SHX43_1 = "/stats"
SHX42_1 = SHX42_1 .. SHX43_1
function SHX43_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = SHX35_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.getStatistics
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SHX36_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getStatistics
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = {}
  SHX4_2.name = "Entity Monitoring"
  SHX5_2 = {}
  SHX6_2 = SHX2_2.current_interval
  SHX5_2.current_interval = SHX6_2
  SHX6_2 = SHX2_2.totals
  SHX5_2.totals = SHX6_2
  SHX6_2 = SHX2_2.averages
  SHX5_2.averages = SHX6_2
  SHX6_2 = SHX2_2.last_intervals
  SHX5_2.last_intervals = SHX6_2
  SHX6_2 = SHX2_2.top_sources
  SHX5_2.top_players = SHX6_2
  SHX6_2 = SHX2_2.top_subtypes
  SHX5_2.top_entity_models = SHX6_2
  SHX6_2 = SHX2_2.history
  SHX5_2.history = SHX6_2
  SHX4_2.by_player = SHX5_2
  SHX5_2 = {}
  SHX6_2 = SHX3_2.current_interval
  SHX5_2.current_interval = SHX6_2
  SHX6_2 = SHX3_2.totals
  SHX5_2.totals = SHX6_2
  SHX6_2 = SHX3_2.averages
  SHX5_2.averages = SHX6_2
  SHX6_2 = SHX3_2.last_intervals
  SHX5_2.last_intervals = SHX6_2
  SHX6_2 = SHX3_2.top_sources
  SHX5_2.top_resources = SHX6_2
  SHX6_2 = SHX3_2.top_subtypes
  SHX5_2.top_entity_models = SHX6_2
  SHX6_2 = SHX3_2.history
  SHX5_2.history = SHX6_2
  SHX4_2.by_resource = SHX5_2
  SHX5_2 = SHX1_2.send
  SHX6_2 = {}
  SHX6_2.success = true
  SHX6_2.data = SHX4_2
  SHX7_2 = os
  SHX7_2 = SHX7_2.time
  SHX7_2 = SHX7_2()
  SHX6_2.timestamp = SHX7_2
  SHX5_2(SHX6_2)
end
SHX40_1(SHX41_1, SHX42_1, SHX43_1)
SHX41_1 = SHX36_1
SHX40_1 = SHX36_1.registerHTTPEndpoints
SHX42_1 = "/entities/by-resource"
SHX40_1(SHX41_1, SHX42_1)
SHX40_1 = HTTP
SHX41_1 = SHX40_1
SHX40_1 = SHX40_1.listen
SHX42_1 = "/entities/types"
function SHX43_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX35_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.getStatistics
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = {}
  SHX4_2 = SHX2_2.totals
  SHX4_2 = SHX4_2.count
  SHX3_2.total_entities = SHX4_2
  SHX4_2 = SHX2_2.totals
  SHX4_2 = SHX4_2.blocked
  SHX3_2.total_blocked = SHX4_2
  SHX4_2 = SHX2_2.totals
  SHX4_2 = SHX4_2.unique_subtypes
  SHX3_2.unique_models = SHX4_2
  SHX4_2 = SHX2_2.totals
  SHX4_2 = SHX4_2.unique_sources
  SHX3_2.unique_players = SHX4_2
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX5_2.data = SHX3_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX40_1(SHX41_1, SHX42_1, SHX43_1)
SHX40_1 = HTTP
SHX41_1 = SHX40_1
SHX40_1 = SHX40_1.listen
SHX42_1 = "/entities/players"
function SHX43_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2
  SHX2_2 = tonumber
  SHX3_2 = SHX0_2.query
  SHX3_2 = SHX3_2.limit
  SHX2_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX2_2 = 20
  end
  SHX3_2 = SHX35_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSourceBreakdown
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = {}
  SHX5_2 = ipairs
  SHX6_2 = SHX3_2.top_sources
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2)
  for SHX9_2, SHX10_2 in SHX5_2, SHX6_2, SHX7_2, SHX8_2 do
    SHX11_2 = Player
    SHX12_2 = tonumber
    SHX13_2 = SHX10_2.id
    SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2 = SHX12_2(SHX13_2)
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2)
    SHX12_2 = table
    SHX12_2 = SHX12_2.insert
    SHX13_2 = SHX4_2
    SHX14_2 = {}
    SHX15_2 = SHX10_2.id
    SHX14_2.player_id = SHX15_2
    if SHX11_2 then
      SHX16_2 = SHX11_2
      SHX15_2 = SHX11_2.getName
      SHX15_2 = SHX15_2(SHX16_2)
      if SHX15_2 then
        goto SHX_LABEL_37
      end
    end
    SHX15_2 = "Unknown"
    -- [FIX IF ERROR] Move ::SHX_LABEL_37:: outside nested blocks until all 'goto SHX_LABEL_37' can see it
    ::SHX_LABEL_37::
    SHX14_2.player_name = SHX15_2
    SHX15_2 = SHX10_2.count
    SHX14_2.entities_spawned = SHX15_2
    SHX15_2 = SHX10_2.blocked
    if not SHX15_2 then
      SHX15_2 = 0
    end
    SHX14_2.entities_blocked = SHX15_2
    SHX12_2(SHX13_2, SHX14_2)
  end
  SHX5_2 = SHX1_2.send
  SHX6_2 = {}
  SHX6_2.success = true
  SHX7_2 = {}
  SHX7_2.top_players = SHX4_2
  SHX8_2 = SHX3_2.total_unique_sources
  SHX7_2.total_unique_players = SHX8_2
  SHX6_2.data = SHX7_2
  SHX7_2 = os
  SHX7_2 = SHX7_2.time
  SHX7_2 = SHX7_2()
  SHX6_2.timestamp = SHX7_2
  SHX5_2(SHX6_2)
end
SHX40_1(SHX41_1, SHX42_1, SHX43_1)
SHX40_1 = HTTP
SHX41_1 = SHX40_1
SHX40_1 = SHX40_1.listen
SHX42_1 = "/entities/resources"
function SHX43_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = tonumber
  SHX3_2 = SHX0_2.query
  SHX3_2 = SHX3_2.limit
  SHX2_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX2_2 = 20
  end
  SHX3_2 = SHX36_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSourceBreakdown
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX6_2 = {}
  SHX7_2 = SHX3_2.top_sources
  SHX6_2.top_resources = SHX7_2
  SHX7_2 = SHX3_2.total_unique_sources
  SHX6_2.total_unique_resources = SHX7_2
  SHX5_2.data = SHX6_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX40_1(SHX41_1, SHX42_1, SHX43_1)
SHX40_1 = HTTP
SHX41_1 = SHX40_1
SHX40_1 = SHX40_1.listen
SHX42_1 = "/entities/resource"
function SHX43_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = SHX0_2.query
  SHX2_2 = SHX2_2.name
  if not SHX2_2 then
    SHX3_2 = SHX1_2.status
    SHX4_2 = 400
    SHX3_2 = SHX3_2(SHX4_2)
    SHX3_2 = SHX3_2.send
    SHX4_2 = {}
    SHX4_2.success = false
    SHX4_2.error = "Missing 'name' query parameter"
    SHX3_2(SHX4_2)
    return
  end
  SHX3_2 = SHX36_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSourceDetails
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  if not SHX3_2 then
    SHX4_2 = SHX1_2.status
    SHX5_2 = 404
    SHX4_2 = SHX4_2(SHX5_2)
    SHX4_2 = SHX4_2.send
    SHX5_2 = {}
    SHX5_2.success = false
    SHX5_2.error = "Resource not found"
    SHX4_2(SHX5_2)
    return
  end
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX6_2 = {}
  SHX6_2.resource_name = SHX2_2
  SHX7_2 = SHX3_2.total_count
  SHX6_2.total_entities = SHX7_2
  SHX7_2 = SHX3_2.blocked
  if not SHX7_2 then
    SHX7_2 = 0
  end
  SHX6_2.total_blocked = SHX7_2
  SHX7_2 = SHX3_2.subtypes
  SHX6_2.entity_models = SHX7_2
  SHX5_2.data = SHX6_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX40_1(SHX41_1, SHX42_1, SHX43_1)
SHX40_1 = Command
SHX41_1 = SHX40_1
SHX40_1 = SHX40_1.add
SHX42_1 = {}
SHX42_1.command = "entitystats"
function SHX43_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2
  SHX0_2 = SHX35_1
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.getStatistics
  SHX0_2 = SHX0_2(SHX1_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "=== Entity Statistics (Falcon) ==="
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Total Entities: ^3%d^7 (Blocked: ^3%d^7 / %s)"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX0_2.totals
  SHX5_2 = SHX5_2.count
  SHX6_2 = SHX0_2.totals
  SHX6_2 = SHX6_2.blocked
  SHX7_2 = SHX0_2.totals
  SHX7_2 = SHX7_2.block_rate
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Uptime: ^3%d^7 minutes | Avg: ^3%s^7/min"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX0_2.totals
  SHX5_2 = SHX5_2.uptime_minutes
  SHX6_2 = SHX0_2.averages
  SHX6_2 = SHX6_2.per_minute
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Unique Models: ^3%d^7 | Unique Players: ^3%d^7"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX0_2.totals
  SHX5_2 = SHX5_2.unique_subtypes
  SHX6_2 = SHX0_2.totals
  SHX6_2 = SHX6_2.unique_sources
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = ""
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "=== Top 10 Entity Models ==="
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = ipairs
  SHX2_2 = SHX0_2.top_subtypes
  SHX1_2, SHX2_2, SHX3_2, SHX4_2 = SHX1_2(SHX2_2)
  for SHX5_2, SHX6_2 in SHX1_2, SHX2_2, SHX3_2, SHX4_2 do
    if SHX5_2 > 10 then
      break
    end
    SHX7_2 = Logger
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.log
    SHX9_2 = "^3#%d^7 - %s: ^3%d^7 spawns (^3%d^7 blocked)"
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.format
    SHX11_2 = SHX5_2
    SHX12_2 = SHX6_2.name
    SHX13_2 = SHX6_2.count
    SHX14_2 = SHX6_2.blocked
    if not SHX14_2 then
      SHX14_2 = 0
    end
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
    SHX10_2 = "info"
    SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  end
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = ""
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "=== Top 10 Players ==="
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = ipairs
  SHX2_2 = SHX0_2.top_sources
  SHX1_2, SHX2_2, SHX3_2, SHX4_2 = SHX1_2(SHX2_2)
  for SHX5_2, SHX6_2 in SHX1_2, SHX2_2, SHX3_2, SHX4_2 do
    if SHX5_2 > 10 then
      break
    end
    SHX7_2 = Player
    SHX8_2 = tonumber
    SHX9_2 = SHX6_2.id
    SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2 = SHX8_2(SHX9_2)
    SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2)
    if SHX7_2 then
      SHX9_2 = SHX7_2
      SHX8_2 = SHX7_2.getName
      SHX8_2 = SHX8_2(SHX9_2)
      if SHX8_2 then
        goto SHX_LABEL_105
      end
    end
    SHX8_2 = "Unknown"
    -- [FIX IF ERROR] Move ::SHX_LABEL_105:: outside nested blocks until all 'goto SHX_LABEL_105' can see it
    ::SHX_LABEL_105::
    SHX9_2 = Logger
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.log
    SHX11_2 = "^3#%d^7 - %s (ID: ^3%s^7): ^3%d^7 entities"
    SHX12_2 = SHX11_2
    SHX11_2 = SHX11_2.format
    SHX13_2 = SHX5_2
    SHX14_2 = SHX8_2
    SHX15_2 = SHX6_2.id
    SHX16_2 = SHX6_2.count
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2)
    SHX12_2 = "info"
    SHX9_2(SHX10_2, SHX11_2, SHX12_2)
  end
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = ""
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "API: ^3/ReaperV4/entities/stats^7 | ^3/ReaperV4/entities/summary^7"
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
SHX42_1.callback = SHX43_1
SHX42_1.hidden = false
SHX43_1 = {}
SHX44_1 = "Manage Server"
SHX43_1[1] = SHX44_1
SHX42_1.permissions = SHX43_1
SHX40_1(SHX41_1, SHX42_1)
SHX40_1 = CreateThread
function SHX41_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  while true do
    SHX0_2 = Wait
    SHX1_2 = 60000
    SHX0_2(SHX1_2)
    SHX0_2 = SHX35_1
    SHX1_2 = SHX0_2
    SHX0_2 = SHX0_2.getStatistics
    SHX0_2 = SHX0_2(SHX1_2)
    SHX1_2 = SHX0_2.totals
    SHX1_2 = SHX1_2.uptime_minutes
    if SHX1_2 > 10 then
      SHX1_2 = SHX0_2.current_interval
      SHX1_2 = SHX1_2.count
      SHX2_2 = math
      SHX2_2 = SHX2_2.max
      SHX3_2 = SHX0_2.current_interval
      SHX3_2 = SHX3_2.elapsed_seconds
      SHX4_2 = 1
      SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
      SHX1_2 = SHX1_2 / SHX2_2
      SHX2_2 = tonumber
      SHX3_2 = SHX0_2.averages
      SHX3_2 = SHX3_2.per_second
      SHX2_2 = SHX2_2(SHX3_2)
      if not SHX2_2 then
        SHX2_2 = 0
      end
      if SHX2_2 > 0 then
        SHX3_2 = SHX2_2 * 5
        if SHX1_2 > SHX3_2 then
          SHX3_2 = Logger
          SHX4_2 = SHX3_2
          SHX3_2 = SHX3_2.log
          SHX5_2 = "^1ENTITY ALERT: Spawn rate %.2fx above average! (Current: %.2f/sec, Avg: %.2f/sec)^7"
          SHX6_2 = SHX5_2
          SHX5_2 = SHX5_2.format
          SHX7_2 = SHX1_2 / SHX2_2
          SHX8_2 = SHX1_2
          SHX9_2 = SHX2_2
          SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2)
          SHX6_2 = "warn"
          SHX3_2(SHX4_2, SHX5_2, SHX6_2)
        end
      end
      SHX3_2 = SHX0_2.totals
      SHX3_2 = SHX3_2.count
      if SHX3_2 > 0 then
        SHX3_2 = SHX0_2.totals
        SHX3_2 = SHX3_2.blocked
        SHX4_2 = SHX0_2.totals
        SHX4_2 = SHX4_2.count
        SHX3_2 = SHX3_2 / SHX4_2
        SHX3_2 = SHX3_2 * 100
        if SHX3_2 then
          goto SHX_LABEL_60
        end
      end
      SHX3_2 = 0
      -- [FIX IF ERROR] Move ::SHX_LABEL_60:: outside nested blocks until all 'goto SHX_LABEL_60' can see it
      ::SHX_LABEL_60::
      if SHX3_2 > 50 then
        SHX4_2 = Logger
        SHX5_2 = SHX4_2
        SHX4_2 = SHX4_2.log
        SHX6_2 = "^1ENTITY ALERT: High block rate: %.2f%% of entities blocked^7"
        SHX7_2 = SHX6_2
        SHX6_2 = SHX6_2.format
        SHX8_2 = SHX3_2
        SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
        SHX7_2 = "warn"
        SHX4_2(SHX5_2, SHX6_2, SHX7_2)
      end
    end
  end
end
SHX40_1(SHX41_1)
SHX40_1 = RPC
SHX41_1 = SHX40_1
SHX40_1 = SHX40_1.on
SHX42_1 = "reaperReady"
function SHX43_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX0_2 = Logger
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.log
  SHX2_2 = "Entity monitoring system initialized (Falcon-powered)"
  SHX3_2 = "info"
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = pairs
  SHX1_2 = json
  SHX1_2 = SHX1_2.decode
  SHX2_2 = HTTP
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.await
  SHX4_2 = "https://api.reaperac.com/api/v1/data/blacklistedentities"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2.body
  if not SHX2_2 then
    SHX2_2 = "{}"
  end
  SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX1_2(SHX2_2)
  SHX0_2, SHX1_2, SHX2_2, SHX3_2 = SHX0_2(SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  for SHX4_2, SHX5_2 in SHX0_2, SHX1_2, SHX2_2, SHX3_2 do
    SHX6_2 = tonumber
    SHX7_2 = SHX4_2
    SHX6_2 = SHX6_2(SHX7_2)
    if nil == SHX6_2 then
      SHX6_2 = GetHashKey
      SHX7_2 = SHX4_2
      SHX6_2 = SHX6_2(SHX7_2)
      SHX4_2 = SHX6_2
    end
    SHX6_2 = tostring
    SHX7_2 = SHX4_2
    SHX6_2 = SHX6_2(SHX7_2)
    SHX7_2 = SHX26_1
    SHX7_2[SHX6_2] = SHX5_2
  end
  SHX0_2 = pairs
  SHX1_2 = json
  SHX1_2 = SHX1_2.decode
  SHX2_2 = HTTP
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.await
  SHX4_2 = "https://api.reaperac.com/api/v1/data/blacklistedspawnpaths"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2.body
  if not SHX2_2 then
    SHX2_2 = "{}"
  end
  SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX1_2(SHX2_2)
  SHX0_2, SHX1_2, SHX2_2, SHX3_2 = SHX0_2(SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  for SHX4_2, SHX5_2 in SHX0_2, SHX1_2, SHX2_2, SHX3_2 do
    SHX6_2 = SHX5_2.type
    if "entity" == SHX6_2 then
      SHX6_2 = table
      SHX6_2 = SHX6_2.insert
      SHX7_2 = SHX27_1
      SHX8_2 = SHX5_2
      SHX6_2(SHX7_2, SHX8_2)
    end
  end
end
SHX40_1(SHX41_1, SHX42_1, SHX43_1)
SHX40_1 = json
SHX40_1 = SHX40_1.decode
SHX41_1 = LoadResourceFile
SHX42_1 = "ReaperV4"
SHX43_1 = "cache/auto_whitelisted_entities.json"
SHX41_1 = SHX41_1(SHX42_1, SHX43_1)
if not SHX41_1 then
  SHX41_1 = "{}"
end
SHX40_1 = SHX40_1(SHX41_1)
SHX41_1 = json
SHX41_1 = SHX41_1.decode
SHX42_1 = LoadResourceFile
SHX43_1 = "ReaperV4"
SHX44_1 = "cache/ai_blocked_entities.json"
SHX42_1 = SHX42_1(SHX43_1, SHX44_1)
if not SHX42_1 then
  SHX42_1 = "{}"
end
SHX41_1 = SHX41_1(SHX42_1)
SHX42_1 = json
SHX42_1 = SHX42_1.decode
SHX43_1 = LoadResourceFile
SHX44_1 = "ReaperV4"
SHX45_1 = "cache/ai_resource_first_seen.json"
SHX43_1 = SHX43_1(SHX44_1, SHX45_1)
if not SHX43_1 then
  SHX43_1 = "{}"
end
SHX42_1 = SHX42_1(SHX43_1)
SHX43_1 = CreateThread
function SHX44_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX0_2 = nil
  SHX1_2 = nil
  SHX2_2 = nil
  while true do
    SHX3_2 = Wait
    SHX4_2 = 60000
    SHX3_2(SHX4_2)
    SHX3_2 = json
    SHX3_2 = SHX3_2.encode
    SHX4_2 = SHX40_1
    SHX3_2 = SHX3_2(SHX4_2)
    SHX4_2 = Security
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.hash
    SHX6_2 = SHX3_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 ~= SHX0_2 then
      SHX0_2 = SHX4_2
      SHX5_2 = SaveResourceFile
      SHX6_2 = "ReaperV4"
      SHX7_2 = "cache/auto_whitelisted_entities.json"
      SHX8_2 = SHX3_2
      SHX9_2 = #SHX3_2
      SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2)
    end
    SHX5_2 = json
    SHX5_2 = SHX5_2.encode
    SHX6_2 = SHX41_1
    SHX5_2 = SHX5_2(SHX6_2)
    SHX6_2 = Security
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.hash
    SHX8_2 = SHX5_2
    SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
    if SHX6_2 ~= SHX1_2 then
      SHX1_2 = SHX6_2
      SHX7_2 = SaveResourceFile
      SHX8_2 = "ReaperV4"
      SHX9_2 = "cache/ai_blocked_entities.json"
      SHX10_2 = SHX5_2
      SHX11_2 = #SHX5_2
      SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2)
    end
    SHX7_2 = json
    SHX7_2 = SHX7_2.encode
    SHX8_2 = SHX42_1
    SHX7_2 = SHX7_2(SHX8_2)
    SHX8_2 = Security
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.hash
    SHX10_2 = SHX7_2
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
    if SHX8_2 ~= SHX2_2 then
      SHX2_2 = SHX8_2
      SHX9_2 = SaveResourceFile
      SHX10_2 = "ReaperV4"
      SHX11_2 = "cache/ai_resource_first_seen.json"
      SHX12_2 = SHX7_2
      SHX13_2 = #SHX7_2
      SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2)
    end
  end
end
SHX43_1(SHX44_1)
SHX43_1 = Command
SHX44_1 = SHX43_1
SHX43_1 = SHX43_1.add
SHX45_1 = {}
SHX45_1.command = "ai_whitelist"
SHX45_1.description = "Force whitelist an entity blocked through Reapers AI Anti Entity Spawner"
function SHX46_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2
  SHX2_2 = SHX1_2[2]
  SHX3_2 = SHX1_2[3]
  SHX4_2 = SHX1_2[4]
  if not (SHX2_2 and SHX3_2) or not SHX4_2 then
    SHX5_2 = Logger
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.log
    SHX7_2 = "Usage: reaper ai_whitelist <resource> <executionId> <path>"
    SHX8_2 = "error"
    SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    SHX5_2 = Logger
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.log
    SHX7_2 = "Example: reaper ai_whitelist qb-core abc123 client/functions.lua:456"
    SHX8_2 = "info"
    SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    return
  end
  SHX5_2 = tostring
  SHX6_2 = Security
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.hash
  SHX8_2 = SHX2_2
  SHX9_2 = "97ae7727-b78e47fc-075ea9de-c852f7da-44587eed"
  SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2)
  SHX6_2 = tostring
  SHX7_2 = SHX3_2
  SHX8_2 = ":"
  SHX9_2 = SHX4_2
  SHX7_2 = SHX7_2 .. SHX8_2 .. SHX9_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX7_2 = SHX2_2
  SHX8_2 = ":"
  SHX9_2 = SHX3_2
  SHX10_2 = ":"
  SHX11_2 = SHX4_2
  SHX7_2 = SHX7_2 .. SHX8_2 .. SHX9_2 .. SHX10_2 .. SHX11_2
  SHX8_2 = SHX41_1
  SHX8_2 = SHX8_2[SHX7_2]
  if not SHX8_2 then
    SHX9_2 = Logger
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.log
    SHX11_2 = "Usage: reaper ai_whitelist <resource> <executionId> <path>"
    SHX12_2 = "error"
    SHX9_2(SHX10_2, SHX11_2, SHX12_2)
    return
  end
  SHX9_2 = SHX40_1
  SHX9_2 = SHX9_2[SHX5_2]
  if nil == SHX9_2 then
    SHX9_2 = SHX40_1
    SHX10_2 = {}
    SHX9_2[SHX5_2] = SHX10_2
  end
  SHX9_2 = SHX40_1
  SHX9_2 = SHX9_2[SHX5_2]
  SHX9_2[SHX6_2] = 4
  SHX9_2 = SHX41_1
  SHX9_2[SHX7_2] = nil
  SHX9_2 = json
  SHX9_2 = SHX9_2.encode
  SHX10_2 = SHX40_1
  SHX9_2 = SHX9_2(SHX10_2)
  SHX10_2 = SaveResourceFile
  SHX11_2 = "ReaperV4"
  SHX12_2 = "cache/auto_whitelisted_entities.json"
  SHX13_2 = SHX9_2
  SHX14_2 = #SHX9_2
  SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2)
  SHX10_2 = Logger
  SHX11_2 = SHX10_2
  SHX10_2 = SHX10_2.log
  SHX12_2 = "Successfully whitelisted entity spawn path: ^3%s^7 -> ^3%s:%s^7"
  SHX13_2 = SHX12_2
  SHX12_2 = SHX12_2.format
  SHX14_2 = SHX2_2
  SHX15_2 = SHX3_2
  SHX16_2 = SHX4_2
  SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2)
  SHX13_2 = "info"
  SHX10_2(SHX11_2, SHX12_2, SHX13_2)
end
SHX45_1.callback = SHX46_1
SHX45_1.hidden = false
SHX46_1 = {}
SHX47_1 = "Update Config"
SHX46_1[1] = SHX47_1
SHX45_1.permissions = SHX46_1
SHX43_1(SHX44_1, SHX45_1)
SHX43_1 = Command
SHX44_1 = SHX43_1
SHX43_1 = SHX43_1.add
SHX45_1 = {}
SHX45_1.command = "ai_whitelist_remove"
SHX45_1.description = "Remove a whitelisted spawn location through Reapers Ai Anti Entity Spawner"
function SHX46_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2
  SHX2_2 = SHX1_2[2]
  SHX3_2 = SHX1_2[3]
  SHX4_2 = SHX1_2[4]
  if not (SHX2_2 and SHX3_2) or not SHX4_2 then
    SHX5_2 = Logger
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.log
    SHX7_2 = "Usage: reaper ai_whitelist_remove <resource> <executionId> <path>"
    SHX8_2 = "error"
    SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    return
  end
  SHX5_2 = tostring
  SHX6_2 = Security
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.hash
  SHX8_2 = SHX2_2
  SHX9_2 = "97ae7727-b78e47fc-075ea9de-c852f7da-44587eed"
  SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
  SHX6_2 = tostring
  SHX7_2 = SHX3_2
  SHX8_2 = ":"
  SHX9_2 = SHX4_2
  SHX7_2 = SHX7_2 .. SHX8_2 .. SHX9_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX7_2 = SHX40_1
  SHX7_2 = SHX7_2[SHX5_2]
  if SHX7_2 then
    SHX7_2 = SHX40_1
    SHX7_2 = SHX7_2[SHX5_2]
    SHX7_2 = SHX7_2[SHX6_2]
    if SHX7_2 then
      SHX7_2 = SHX40_1
      SHX7_2 = SHX7_2[SHX5_2]
      SHX7_2[SHX6_2] = nil
      SHX7_2 = next
      SHX8_2 = SHX40_1
      SHX8_2 = SHX8_2[SHX5_2]
      SHX7_2 = SHX7_2(SHX8_2)
      if nil == SHX7_2 then
        SHX7_2 = SHX40_1
        SHX7_2[SHX5_2] = nil
      end
      SHX7_2 = json
      SHX7_2 = SHX7_2.encode
      SHX8_2 = SHX40_1
      SHX7_2 = SHX7_2(SHX8_2)
      SHX8_2 = SaveResourceFile
      SHX9_2 = "ReaperV4"
      SHX10_2 = "cache/auto_whitelisted_entities.json"
      SHX11_2 = SHX7_2
      SHX12_2 = #SHX7_2
      SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2)
      SHX8_2 = Logger
      SHX9_2 = SHX8_2
      SHX8_2 = SHX8_2.log
      SHX10_2 = "Successfully removed whitelisted path: ^3%s^7 -> ^3%s:%s^7"
      SHX11_2 = SHX10_2
      SHX10_2 = SHX10_2.format
      SHX12_2 = SHX2_2
      SHX13_2 = SHX3_2
      SHX14_2 = SHX4_2
      SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2)
      SHX11_2 = "info"
      SHX8_2(SHX9_2, SHX10_2, SHX11_2)
  end
  else
    SHX7_2 = Logger
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.log
    SHX9_2 = "Path not found in whitelist: ^3%s^7 -> ^3%s:%s^7"
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.format
    SHX11_2 = SHX2_2
    SHX12_2 = SHX3_2
    SHX13_2 = SHX4_2
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2)
    SHX10_2 = "warn"
    SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  end
end
SHX45_1.callback = SHX46_1
SHX45_1.hidden = false
SHX46_1 = {}
SHX47_1 = "Update Config"
SHX46_1[1] = SHX47_1
SHX45_1.permissions = SHX46_1
SHX43_1(SHX44_1, SHX45_1)
SHX43_1 = false
SHX44_1 = json
SHX44_1 = SHX44_1.decode
SHX45_1 = LoadResourceFile
SHX46_1 = "ReaperV4"
SHX47_1 = "cache/entities.json"
SHX45_1 = SHX45_1(SHX46_1, SHX47_1)
if not SHX45_1 then
  SHX45_1 = "{}"
end
SHX44_1 = SHX44_1(SHX45_1)
SHX45_1 = {}
SHX46_1 = RPC
SHX47_1 = SHX46_1
SHX46_1 = SHX46_1.onLocal
SHX48_1 = "ProAddon:AddWhitelister"
function SHX49_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = tostring
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = SHX45_1
  SHX2_2[SHX1_2] = true
end
SHX46_1(SHX47_1, SHX48_1, SHX49_1)
SHX46_1 = RPC
SHX47_1 = SHX46_1
SHX46_1 = SHX46_1.on
SHX48_1 = "ProAddon:RefreshEntities"
function SHX49_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2
  SHX0_2 = json
  SHX0_2 = SHX0_2.decode
  SHX1_2 = LoadResourceFile
  SHX2_2 = "ReaperV4"
  SHX3_2 = "cache/entities.json"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  if not SHX1_2 then
    SHX1_2 = "{}"
  end
  SHX0_2 = SHX0_2(SHX1_2)
  SHX44_1 = SHX0_2
end
SHX46_1(SHX47_1, SHX48_1, SHX49_1)
SHX46_1 = RPC
SHX47_1 = SHX46_1
SHX46_1 = SHX46_1.on
SHX48_1 = "configUpdated"
function SHX49_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX1_2 = Settings
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.get
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = SHX1_2.AdvancedExecutionCheck
  SHX43_1 = SHX2_2
  SHX2_2 = SHX1_2.entityRules
  SHX2_2 = SHX2_2.npcEntities
  SHX14_1 = SHX2_2
  SHX2_2 = SHX1_2.entityRules
  SHX2_2 = SHX2_2.entityWhitelist
  SHX2_2 = SHX2_2.enabled
  SHX15_1 = SHX2_2
  SHX2_2 = SHX1_2.underAttackMode
  SHX4_1 = SHX2_2
  SHX2_2 = SetConvar
  SHX3_2 = "reaper_log_spawned_entities_to_file"
  SHX4_2 = tostring
  SHX5_2 = SHX1_2.entityRules
  SHX5_2 = SHX5_2.logEntitiesToFile
  if not SHX5_2 then
    SHX5_2 = false
  end
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX4_2(SHX5_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  SHX2_2 = GetConvarInt
  SHX3_2 = "reaper_log_spawned_entities_to_file_filter_pop"
  SHX4_2 = "-1"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX11_1 = SHX2_2
  SHX2_2 = GetConvarInt
  SHX3_2 = "reaper_log_spawned_entities_to_file_filter_type"
  SHX4_2 = "-1"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX12_1 = SHX2_2
  SHX2_2 = GetConvar
  SHX3_2 = "reaper_log_spawned_entities_to_file_filter_resource"
  SHX4_2 = ""
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX13_1 = SHX2_2
  SHX2_2 = {}
  SHX17_1 = SHX2_2
  SHX2_2 = pairs
  SHX3_2 = SHX1_2.entityRules
  SHX3_2 = SHX3_2.entityWhitelist
  SHX3_2 = SHX3_2.allowedEntities
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX8_2 = tonumber
    SHX9_2 = SHX7_2
    SHX8_2 = SHX8_2(SHX9_2)
    if not SHX8_2 then
      SHX8_2 = GetHashKey
      SHX9_2 = SHX7_2
      SHX8_2 = SHX8_2(SHX9_2)
    end
    SHX9_2 = SHX17_1
    SHX9_2[SHX8_2] = true
  end
  SHX2_2 = pairs
  SHX3_2 = SHX28_1
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX8_2 = SHX17_1
    SHX8_2[SHX6_2] = SHX7_2
  end
  SHX2_2 = SHX1_1
  if "rdr3" == SHX2_2 then
    SHX2_2 = SHX14_1
    if false == SHX2_2 then
      SHX2_2 = Logger
      SHX3_2 = SHX2_2
      SHX2_2 = SHX2_2.log
      SHX4_2 = "Please note ^3NPC Peds/Vehicles^7 was disabled in the config. This may cause performance issue if you do not disable them in your code also"
      SHX5_2 = "warn"
      SHX2_2(SHX3_2, SHX4_2, SHX5_2)
    end
  end
  SHX2_2 = {}
  SHX18_1 = SHX2_2
  SHX2_2 = pairs
  SHX3_2 = SHX1_2.entityRules
  SHX3_2 = SHX3_2.entityBlacklist
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX8_2 = table
    SHX8_2 = SHX8_2.unpack
    SHX9_2 = string
    SHX9_2 = SHX9_2.split
    SHX10_2 = SHX7_2
    SHX11_2 = "="
    SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX9_2(SHX10_2, SHX11_2)
    SHX8_2, SHX9_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
    SHX10_2 = tostring
    SHX11_2 = tonumber
    SHX12_2 = SHX8_2
    SHX11_2 = SHX11_2(SHX12_2)
    if not SHX11_2 then
      SHX11_2 = GetHashKey
      SHX12_2 = SHX8_2
      SHX11_2 = SHX11_2(SHX12_2)
    end
    SHX10_2 = SHX10_2(SHX11_2)
    SHX11_2 = SHX18_1
    SHX12_2 = {}
    SHX13_2 = SHX9_2 or SHX13_2
    if not SHX9_2 then
      SHX13_2 = "none"
    end
    SHX12_2.action = SHX13_2
    SHX12_2.model = SHX8_2
    SHX11_2[SHX10_2] = SHX12_2
  end
  SHX2_2 = SHX1_2.entityRules
  SHX2_2 = SHX2_2.logRestrictedEntitiesToConsole
  SHX8_1 = SHX2_2
  SHX2_2 = SHX1_2.entityRules
  SHX2_2 = SHX2_2.logEntitiesToConsole
  SHX9_1 = SHX2_2
  SHX2_2 = GetConvar
  SHX3_2 = "reaper_log_spawned_entities_to_file"
  SHX4_2 = "false"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = "true" == SHX2_2
  SHX10_1 = SHX2_2
  SHX2_2 = SHX10_1
  if SHX2_2 then
    SHX2_2 = SHX14_1
    if SHX2_2 then
      SHX2_2 = false
      SHX10_1 = SHX2_2
      SHX2_2 = Logger
      SHX3_2 = SHX2_2
      SHX2_2 = SHX2_2.log
      SHX4_2 = "^3reaper_log_spawned_entities_to_file^7 can not be used when ^3NPC Entities^7 is enabled."
      SHX5_2 = "error"
      SHX2_2(SHX3_2, SHX4_2, SHX5_2)
    end
  end
  SHX2_2 = SHX1_2.entityRules
  SHX2_2 = SHX2_2.autoEntityBlacklist
  SHX16_1 = SHX2_2
  SHX2_2 = SetRoutingBucketPopulationEnabled
  SHX3_2 = 0
  SHX4_2 = SHX14_1
  SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SetConvarReplicated
  SHX3_2 = "reaper_onesync_population"
  SHX4_2 = tostring
  SHX5_2 = SHX14_1
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX4_2(SHX5_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  SHX2_2 = SHX1_2.generalRules
  SHX2_2 = SHX2_2.antiEntityExploits
  if SHX2_2 then
    SHX2_2 = System
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.getOs
    SHX2_2 = SHX2_2(SHX3_2)
    if "Windows" ~= SHX2_2 then
      SHX2_2 = Logger
      SHX3_2 = SHX2_2
      SHX2_2 = SHX2_2.log
      SHX4_2 = "^3Anti Entity Exploits^7 is enabled but is unable to be used. This option can only be used on ^3windows^7 servers."
      SHX5_2 = "warn"
      SHX2_2(SHX3_2, SHX4_2, SHX5_2)
      SHX2_2 = SHX1_2.generalRules
      SHX2_2.antiEntityExploits = false
    end
  end
  SHX2_2 = SHX1_2.generalRules
  SHX2_2 = SHX2_2.antiEntityExploits
  if SHX2_2 then
    SHX2_2 = Logger
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.customArtifacts
    SHX2_2 = SHX2_2(SHX3_2)
    if false == SHX2_2 then
      SHX2_2 = SHX1_2.generalRules
      SHX2_2.antiEntityExploits = false
      SHX2_2 = Logger
      SHX3_2 = SHX2_2
      SHX2_2 = SHX2_2.log
      SHX4_2 = "^3Anti Entity Exploits^7 is enabled but is unable to be used. This option can only be used when running our custom artifacts."
      SHX5_2 = "warn"
      SHX2_2(SHX3_2, SHX4_2, SHX5_2)
    end
  end
  SHX2_2 = SHX1_2.entityRules
  SHX2_2 = SHX2_2.entityWhitelist
  SHX2_2 = SHX2_2.ai_auto_whitelist
  SHX24_1 = SHX2_2
  SHX2_2 = SHX1_2.entityRules
  SHX2_2 = SHX2_2.entityWhitelist
  SHX2_2 = SHX2_2.ai_auto_whitelist_block
  SHX25_1 = SHX2_2
  SHX2_2 = SHX1_2.entityRules
  SHX2_2 = SHX2_2.entityWhitelist
  SHX2_2 = SHX2_2.autoWhitelist
  SHX6_1 = SHX2_2
  SHX2_2 = SetConvarReplicated
  SHX3_2 = "reaper_auto_entity_whitelist"
  SHX4_2 = tostring
  SHX5_2 = SHX6_1
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX4_2(SHX5_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  SHX2_2 = SHX1_2.entityRules
  SHX2_2 = SHX2_2.entityWhitelist
  SHX2_2 = SHX2_2.whitelistStrictMode
  SHX5_1 = SHX2_2
  SHX2_2 = SHX1_2.generalRules
  SHX2_2 = SHX2_2.antiEntityExploits
  SHX7_1 = SHX2_2
  SHX2_2 = SetConvarReplicated
  SHX3_2 = "anti_entity_exploits"
  SHX4_2 = tostring
  SHX5_2 = SHX7_1
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX4_2(SHX5_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  SHX2_2 = SetConvar
  SHX3_2 = "sv_filterRequestControl"
  SHX4_2 = "4"
  SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = GetConvar
  SHX3_2 = "reaper_auto_patch_npc_plates"
  SHX4_2 = "false"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = "true" == SHX2_2
  SHX20_1 = SHX2_2
  SHX2_2 = GetConvar
  SHX3_2 = "reaper_block_model_0"
  SHX4_2 = "false"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = "true" == SHX2_2
  SHX21_1 = SHX2_2
  SHX2_2 = SHX1_2.entityRules
  SHX2_2 = SHX2_2.maxEntitySpawnDistance
  SHX2_2 = SHX2_2.max_distance
  SHX22_1 = SHX2_2
  SHX2_2 = SHX1_2.entityRules
  SHX2_2 = SHX2_2.maxEntitySpawnDistance
  SHX2_2 = SHX2_2.enabled
  SHX23_1 = SHX2_2
end
SHX46_1(SHX47_1, SHX48_1, SHX49_1)
SHX46_1 = RPC
SHX47_1 = SHX46_1
SHX46_1 = SHX46_1.register
SHX48_1 = "requestControl"
function SHX49_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2
  SHX5_2 = SHX7_1
  if false == SHX5_2 then
    SHX5_2 = false
    return SHX5_2
  end
  SHX5_2 = Player
  SHX6_2 = SHX0_2
  SHX5_2 = SHX5_2(SHX6_2)
  if nil == SHX5_2 then
    return
  end
  SHX6_2 = NetworkGetEntityFromNetworkId
  SHX7_2 = SHX1_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX7_2 = DoesEntityExist
  SHX8_2 = SHX6_2
  SHX7_2 = SHX7_2(SHX8_2)
  if not SHX7_2 then
    SHX7_2 = false
    return SHX7_2
  end
  SHX7_2 = ExecutionCheck
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.execution_valid
  SHX10_2 = SHX5_2
  SHX9_2 = SHX5_2.getId
  SHX9_2 = SHX9_2(SHX10_2)
  SHX10_2 = "NetworkRequestControlOfEntity"
  SHX11_2 = SHX3_2
  SHX12_2 = SHX2_2
  SHX13_2 = SHX4_2
  SHX14_2 = SHX3_1
  SHX15_2 = SHX6_2
  SHX14_2 = SHX14_2(SHX15_2)
  if not SHX14_2 then
    SHX14_2 = "invalid_entity"
  end
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
  if false == SHX7_2 then
    SHX7_2 = false
    return SHX7_2
  end
  SHX8_2 = SHX5_2
  SHX7_2 = SHX5_2.NewLog
  SHX9_2 = "^3%s^7 (^3id:%s^7) just requested control of the (^3net:%s^7) from ^3%s:%s^7"
  SHX10_2 = SHX9_2
  SHX9_2 = SHX9_2.format
  SHX12_2 = SHX5_2
  SHX11_2 = SHX5_2.getName
  SHX11_2 = SHX11_2(SHX12_2)
  SHX13_2 = SHX5_2
  SHX12_2 = SHX5_2.getId
  SHX12_2 = SHX12_2(SHX13_2)
  SHX13_2 = SHX1_2
  SHX14_2 = SHX4_2
  SHX15_2 = SHX2_2
  SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
  SHX10_2 = "info"
  SHX11_2 = "entities"
  SHX12_2 = {}
  SHX13_2 = true
  SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  SHX7_2 = NetworkSetEntityOwner
  SHX8_2 = SHX6_2
  SHX10_2 = SHX5_2
  SHX9_2 = SHX5_2.getId
  SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2 = SHX9_2(SHX10_2)
  SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
  SHX7_2 = true
  return SHX7_2
end
SHX46_1(SHX47_1, SHX48_1, SHX49_1)
SHX46_1 = RPC
SHX47_1 = SHX46_1
SHX46_1 = SHX46_1.onLocal
SHX48_1 = "entityCreating"
function SHX49_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2
  SHX1_2 = SHX3_1
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = GetEntityType
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = NetworkGetEntityOwner
  SHX4_2 = SHX0_2
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = GetEntityPopulationType
  SHX5_2 = SHX0_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = Player
  SHX6_2 = SHX3_2
  SHX5_2 = SHX5_2(SHX6_2)
  if nil == SHX5_2 then
    SHX6_2 = CancelEvent
    return SHX6_2()
  end
  SHX6_2 = SHX4_1
  if SHX6_2 then
    SHX6_2 = CancelEvent
    SHX6_2()
    SHX6_2 = Logger
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.log
    SHX8_2 = "[UAM] An entity was just created by ^3%s ^7(^3id:%s^7) was blocked. Data: (^3model:%s^7) (^3netId:%s^7) (^3type:%s^7) (^3pop:%s^7) (^3coords:%s^7) (^3%s^7)"
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.format
    SHX11_2 = SHX5_2
    SHX10_2 = SHX5_2.getName
    SHX10_2 = SHX10_2(SHX11_2)
    SHX12_2 = SHX5_2
    SHX11_2 = SHX5_2.getId
    SHX11_2 = SHX11_2(SHX12_2)
    SHX12_2 = SHX1_2
    SHX13_2 = NetworkGetNetworkIdFromEntity
    SHX14_2 = SHX0_2
    SHX13_2 = SHX13_2(SHX14_2)
    SHX14_2 = SHX2_2
    SHX15_2 = SHX4_2
    SHX16_2 = GetEntityCoords
    SHX17_2 = SHX0_2
    SHX16_2 = SHX16_2(SHX17_2)
    SHX17_2 = "{}"
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
    SHX9_2 = "info"
    return SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  end
  if nil == SHX1_2 then
    return
  end
  SHX6_2 = SHX0_1
  if SHX6_2 then
    SHX6_2 = GetEntityTypeRaw
    SHX7_2 = SHX0_2
    SHX6_2 = SHX6_2(SHX7_2)
    if 7 == SHX6_2 or 8 == SHX6_2 then
      SHX7_2 = CancelEvent
      return SHX7_2()
    end
  elseif 0 == SHX2_2 and 0 == SHX4_2 and 0 == SHX1_2 then
    SHX6_2 = CancelEvent
    return SHX6_2()
  end
  SHX6_2 = SHX1_1
  if "gta5" == SHX6_2 and 0 == SHX1_2 then
    SHX6_2 = SHX21_1
    if SHX6_2 then
      SHX6_2 = CancelEvent
      SHX6_2()
    end
    return
  end
  SHX6_2 = tostring
  SHX7_2 = SHX1_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX7_2 = SHX18_1
  SHX6_2 = SHX7_2[SHX6_2]
  if SHX6_2 then
    SHX6_2 = CancelEvent
    SHX6_2()
    SHX6_2 = SHX37_1
    SHX7_2 = SHX1_2
    SHX8_2 = SHX2_2
    SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
    SHX7_2 = GetInvokingResource
    SHX7_2 = SHX7_2()
    if not SHX7_2 then
      SHX7_2 = "unknown"
    end
    SHX8_2 = SHX35_1
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.track
    SHX10_2 = SHX6_2
    SHX11_2 = SHX3_2
    SHX12_2 = true
    SHX13_2 = {}
    SHX15_2 = SHX5_2
    SHX14_2 = SHX5_2.getName
    SHX14_2 = SHX14_2(SHX15_2)
    SHX13_2.player_name = SHX14_2
    SHX13_2.model_hash = SHX1_2
    SHX14_2 = SHX34_1
    SHX15_2 = SHX2_2
    SHX14_2 = SHX14_2(SHX15_2)
    SHX13_2.entity_type = SHX14_2
    SHX13_2.reason = "blacklisted_model"
    SHX13_2.resource = SHX7_2
    SHX14_2 = os
    SHX14_2 = SHX14_2.time
    SHX14_2 = SHX14_2()
    SHX13_2.timestamp = SHX14_2
    SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
    SHX8_2 = SHX36_1
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.track
    SHX10_2 = SHX6_2
    SHX11_2 = SHX7_2
    SHX12_2 = true
    SHX13_2 = {}
    SHX13_2.player_id = SHX3_2
    SHX15_2 = SHX5_2
    SHX14_2 = SHX5_2.getName
    SHX14_2 = SHX14_2(SHX15_2)
    SHX13_2.player_name = SHX14_2
    SHX13_2.model_hash = SHX1_2
    SHX14_2 = SHX34_1
    SHX15_2 = SHX2_2
    SHX14_2 = SHX14_2(SHX15_2)
    SHX13_2.entity_type = SHX14_2
    SHX13_2.reason = "blacklisted_model"
    SHX14_2 = os
    SHX14_2 = SHX14_2.time
    SHX14_2 = SHX14_2()
    SHX13_2.timestamp = SHX14_2
    SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
    SHX8_2 = RPC
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.emitLocal
    SHX10_2 = "Reaper:NewDetection"
    SHX11_2 = {}
    SHX11_2.type = "blacklistedEntity"
    SHX12_2 = {}
    SHX13_2 = tostring
    SHX14_2 = SHX1_2
    SHX13_2 = SHX13_2(SHX14_2)
    SHX14_2 = SHX18_1
    SHX13_2 = SHX14_2[SHX13_2]
    SHX13_2 = SHX13_2.model
    SHX12_2.model = SHX13_2
    SHX12_2.entityType = SHX2_2
    SHX12_2.popType = SHX4_2
    SHX11_2.data = SHX12_2
    SHX12_2 = {}
    SHX13_2 = tostring
    SHX14_2 = SHX1_2
    SHX13_2 = SHX13_2(SHX14_2)
    SHX14_2 = SHX18_1
    SHX13_2 = SHX14_2[SHX13_2]
    SHX13_2 = SHX13_2.model
    SHX12_2[1] = SHX13_2
    SHX11_2.params = SHX12_2
    SHX12_2 = tostring
    SHX13_2 = SHX1_2
    SHX12_2 = SHX12_2(SHX13_2)
    SHX13_2 = SHX18_1
    SHX12_2 = SHX13_2[SHX12_2]
    SHX12_2 = SHX12_2.action
    SHX11_2.action = SHX12_2
    SHX12_2 = SHX3_2
    return SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  end
  SHX6_2 = SHX16_1
  if SHX6_2 then
    SHX6_2 = tostring
    SHX7_2 = SHX1_2
    SHX6_2 = SHX6_2(SHX7_2)
    SHX7_2 = SHX26_1
    SHX6_2 = SHX7_2[SHX6_2]
    if SHX6_2 then
      SHX6_2 = SHX17_1
      SHX6_2 = SHX6_2[SHX1_2]
      if nil == SHX6_2 then
        SHX6_2 = CancelEvent
        SHX6_2()
        SHX6_2 = SHX37_1
        SHX7_2 = SHX1_2
        SHX8_2 = SHX2_2
        SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
        SHX7_2 = GetInvokingResource
        SHX7_2 = SHX7_2()
        if not SHX7_2 then
          SHX7_2 = "unknown"
        end
        SHX8_2 = SHX35_1
        SHX9_2 = SHX8_2
        SHX8_2 = SHX8_2.track
        SHX10_2 = SHX6_2
        SHX11_2 = SHX3_2
        SHX12_2 = true
        SHX13_2 = {}
        SHX15_2 = SHX5_2
        SHX14_2 = SHX5_2.getName
        SHX14_2 = SHX14_2(SHX15_2)
        SHX13_2.player_name = SHX14_2
        SHX13_2.model_hash = SHX1_2
        SHX14_2 = SHX34_1
        SHX15_2 = SHX2_2
        SHX14_2 = SHX14_2(SHX15_2)
        SHX13_2.entity_type = SHX14_2
        SHX13_2.reason = "auto_blacklisted"
        SHX13_2.resource = SHX7_2
        SHX14_2 = os
        SHX14_2 = SHX14_2.time
        SHX14_2 = SHX14_2()
        SHX13_2.timestamp = SHX14_2
        SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
        SHX8_2 = SHX36_1
        SHX9_2 = SHX8_2
        SHX8_2 = SHX8_2.track
        SHX10_2 = SHX6_2
        SHX11_2 = SHX7_2
        SHX12_2 = true
        SHX13_2 = {}
        SHX13_2.player_id = SHX3_2
        SHX15_2 = SHX5_2
        SHX14_2 = SHX5_2.getName
        SHX14_2 = SHX14_2(SHX15_2)
        SHX13_2.player_name = SHX14_2
        SHX13_2.model_hash = SHX1_2
        SHX14_2 = SHX34_1
        SHX15_2 = SHX2_2
        SHX14_2 = SHX14_2(SHX15_2)
        SHX13_2.entity_type = SHX14_2
        SHX13_2.reason = "auto_blacklisted"
        SHX14_2 = os
        SHX14_2 = SHX14_2.time
        SHX14_2 = SHX14_2()
        SHX13_2.timestamp = SHX14_2
        SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
        SHX8_2 = RPC
        SHX9_2 = SHX8_2
        SHX8_2 = SHX8_2.emitLocal
        SHX10_2 = "Reaper:NewDetection"
        SHX11_2 = {}
        SHX11_2.type = "autoBlacklistedEntity"
        SHX12_2 = {}
        SHX12_2.model = SHX1_2
        SHX12_2.entityType = SHX2_2
        SHX12_2.popType = SHX4_2
        SHX11_2.data = SHX12_2
        SHX12_2 = {}
        SHX13_2 = SHX1_2
        SHX12_2[1] = SHX13_2
        SHX11_2.params = SHX12_2
        SHX12_2 = tostring
        SHX13_2 = SHX1_2
        SHX12_2 = SHX12_2(SHX13_2)
        SHX13_2 = SHX26_1
        SHX12_2 = SHX13_2[SHX12_2]
        SHX11_2.action = SHX12_2
        SHX12_2 = SHX3_2
        return SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2)
      end
    end
  end
  SHX6_2 = GetDistanceBetweenCoords
  SHX8_2 = SHX5_2
  SHX7_2 = SHX5_2.getCoords
  SHX7_2 = SHX7_2(SHX8_2)
  SHX8_2 = GetEntityCoords
  SHX9_2 = SHX0_2
  SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2 = SHX8_2(SHX9_2)
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
  if 5 ~= SHX4_2 and 2 ~= SHX4_2 and 4 ~= SHX4_2 then
    SHX7_2 = SHX23_1
    if SHX7_2 then
      SHX7_2 = SHX22_1
      if SHX6_2 > SHX7_2 then
        SHX7_2 = SHX37_1
        SHX8_2 = SHX1_2
        SHX9_2 = SHX2_2
        SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
        SHX8_2 = GetInvokingResource
        SHX8_2 = SHX8_2()
        if not SHX8_2 then
          SHX8_2 = "unknown"
        end
        SHX9_2 = SHX35_1
        SHX10_2 = SHX9_2
        SHX9_2 = SHX9_2.track
        SHX11_2 = SHX7_2
        SHX12_2 = SHX3_2
        SHX13_2 = true
        SHX14_2 = {}
        SHX16_2 = SHX5_2
        SHX15_2 = SHX5_2.getName
        SHX15_2 = SHX15_2(SHX16_2)
        SHX14_2.player_name = SHX15_2
        SHX14_2.model_hash = SHX1_2
        SHX15_2 = SHX34_1
        SHX16_2 = SHX2_2
        SHX15_2 = SHX15_2(SHX16_2)
        SHX14_2.entity_type = SHX15_2
        SHX14_2.reason = "max_spawn_distance"
        SHX14_2.spawn_distance = SHX6_2
        SHX14_2.resource = SHX8_2
        SHX15_2 = os
        SHX15_2 = SHX15_2.time
        SHX15_2 = SHX15_2()
        SHX14_2.timestamp = SHX15_2
        SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
        SHX9_2 = SHX36_1
        SHX10_2 = SHX9_2
        SHX9_2 = SHX9_2.track
        SHX11_2 = SHX7_2
        SHX12_2 = SHX8_2
        SHX13_2 = true
        SHX14_2 = {}
        SHX14_2.player_id = SHX3_2
        SHX16_2 = SHX5_2
        SHX15_2 = SHX5_2.getName
        SHX15_2 = SHX15_2(SHX16_2)
        SHX14_2.player_name = SHX15_2
        SHX14_2.model_hash = SHX1_2
        SHX15_2 = SHX34_1
        SHX16_2 = SHX2_2
        SHX15_2 = SHX15_2(SHX16_2)
        SHX14_2.entity_type = SHX15_2
        SHX14_2.reason = "max_spawn_distance"
        SHX14_2.spawn_distance = SHX6_2
        SHX15_2 = os
        SHX15_2 = SHX15_2.time
        SHX15_2 = SHX15_2()
        SHX14_2.timestamp = SHX15_2
        SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
        SHX9_2 = RPC
        SHX10_2 = SHX9_2
        SHX9_2 = SHX9_2.emitLocal
        SHX11_2 = "Reaper:NewDetection"
        SHX12_2 = {}
        SHX12_2.type = "entityMaxSpawnDistance"
        SHX13_2 = {}
        SHX13_2.model = SHX1_2
        SHX13_2.entityType = SHX2_2
        SHX13_2.popType = SHX4_2
        SHX12_2.data = SHX13_2
        SHX13_2 = {}
        SHX14_2 = SHX1_2
        SHX15_2 = SHX6_2
        SHX13_2[1] = SHX14_2
        SHX13_2[2] = SHX15_2
        SHX12_2.params = SHX13_2
        SHX13_2 = SHX3_2
        SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2)
        SHX9_2 = CancelEvent
        return SHX9_2()
      end
    end
  end
  SHX7_2 = SHX19_1
  SHX7_2 = SHX7_2[SHX1_2]
  if SHX7_2 then
    SHX7_2 = GetGameTimer
    SHX7_2 = SHX7_2()
    SHX8_2 = SHX19_1
    SHX8_2 = SHX8_2[SHX1_2]
    SHX8_2 = SHX8_2.time
    SHX7_2 = SHX7_2 - SHX8_2
    SHX8_2 = 5000
    if SHX7_2 > SHX8_2 then
      SHX7_2 = SHX19_1
      SHX7_2[SHX1_2] = nil
    end
  end
  SHX7_2 = SHX15_1
  if SHX7_2 then
    SHX7_2 = SHX19_1
    SHX7_2 = SHX7_2[SHX1_2]
    if nil == SHX7_2 then
      SHX8_2 = SHX5_2
      SHX7_2 = SHX5_2.getMeta
      SHX9_2 = "%s:%s"
      SHX10_2 = SHX9_2
      SHX9_2 = SHX9_2.format
      SHX11_2 = SHX1_2
      SHX12_2 = SHX2_2
      SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2)
      SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
      if nil == SHX7_2 then
        SHX7_2 = SHX17_1
        SHX7_2 = SHX7_2[SHX1_2]
        if nil == SHX7_2 then
          SHX7_2 = false
          SHX8_2 = SHX14_1
          if true == SHX8_2 then
            if (1 ~= SHX2_2 or 5 ~= SHX4_2) and (1 ~= SHX2_2 or 4 ~= SHX4_2) then
              SHX8_2 = SHX1_1
              if ("rdr3" ~= SHX8_2 or 1 ~= SHX2_2 or 6 ~= SHX4_2) and (2 ~= SHX2_2 or 5 ~= SHX4_2) and (2 ~= SHX2_2 or 2 ~= SHX4_2) then
                SHX8_2 = SHX1_1
                if "rdr3" ~= SHX8_2 or 2 ~= SHX2_2 or 6 ~= SHX4_2 then
                  goto SHX_LABEL_448
                end
              end
            end
            SHX7_2 = true
          end
          -- [FIX IF ERROR] Move ::SHX_LABEL_448:: outside nested blocks until all 'goto SHX_LABEL_448' can see it
          ::SHX_LABEL_448::
          SHX8_2 = SHX5_1
          if SHX8_2 then
            SHX7_2 = false
          end
          if 0 == SHX4_2 and 1 == SHX2_2 then
            SHX7_2 = true
          end
          if false == SHX7_2 then
            SHX8_2 = CancelEvent
            SHX8_2()
            SHX8_2 = SHX37_1
            SHX9_2 = SHX1_2
            SHX10_2 = SHX2_2
            SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
            SHX9_2 = GetInvokingResource
            SHX9_2 = SHX9_2()
            if not SHX9_2 then
              SHX9_2 = "unknown"
            end
            SHX10_2 = SHX35_1
            SHX11_2 = SHX10_2
            SHX10_2 = SHX10_2.track
            SHX12_2 = SHX8_2
            SHX13_2 = SHX3_2
            SHX14_2 = true
            SHX15_2 = {}
            SHX17_2 = SHX5_2
            SHX16_2 = SHX5_2.getName
            SHX16_2 = SHX16_2(SHX17_2)
            SHX15_2.player_name = SHX16_2
            SHX15_2.model_hash = SHX1_2
            SHX16_2 = SHX34_1
            SHX17_2 = SHX2_2
            SHX16_2 = SHX16_2(SHX17_2)
            SHX15_2.entity_type = SHX16_2
            SHX15_2.reason = "no_whitelist_auth"
            SHX15_2.pop_type = SHX4_2
            SHX15_2.resource = SHX9_2
            SHX16_2 = os
            SHX16_2 = SHX16_2.time
            SHX16_2 = SHX16_2()
            SHX15_2.timestamp = SHX16_2
            SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
            SHX10_2 = SHX36_1
            SHX11_2 = SHX10_2
            SHX10_2 = SHX10_2.track
            SHX12_2 = SHX8_2
            SHX13_2 = SHX9_2
            SHX14_2 = true
            SHX15_2 = {}
            SHX15_2.player_id = SHX3_2
            SHX17_2 = SHX5_2
            SHX16_2 = SHX5_2.getName
            SHX16_2 = SHX16_2(SHX17_2)
            SHX15_2.player_name = SHX16_2
            SHX15_2.model_hash = SHX1_2
            SHX16_2 = SHX34_1
            SHX17_2 = SHX2_2
            SHX16_2 = SHX16_2(SHX17_2)
            SHX15_2.entity_type = SHX16_2
            SHX15_2.reason = "no_whitelist_auth"
            SHX15_2.pop_type = SHX4_2
            SHX16_2 = os
            SHX16_2 = SHX16_2.time
            SHX16_2 = SHX16_2()
            SHX15_2.timestamp = SHX16_2
            SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
            SHX10_2 = SHX8_1
            if SHX10_2 and 5 ~= SHX4_2 then
              SHX10_2 = Logger
              SHX11_2 = SHX10_2
              SHX10_2 = SHX10_2.log
              SHX12_2 = "^3entityCreating^7: An entity created by ^3%s^7 (^3id:%s^7) was deleted due to no auth. Data: (^3model:%s^7) (^3type:%s^7) (^3pop:%s^7)"
              SHX13_2 = SHX12_2
              SHX12_2 = SHX12_2.format
              SHX15_2 = SHX5_2
              SHX14_2 = SHX5_2.getName
              SHX14_2 = SHX14_2(SHX15_2)
              SHX16_2 = SHX5_2
              SHX15_2 = SHX5_2.getId
              SHX15_2 = SHX15_2(SHX16_2)
              SHX16_2 = SHX1_2
              SHX17_2 = SHX2_2
              SHX18_2 = SHX4_2
              SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
              SHX13_2 = "warn"
              SHX10_2(SHX11_2, SHX12_2, SHX13_2)
            end
            return
          end
        end
      end
    end
  end
end
SHX46_1(SHX47_1, SHX48_1, SHX49_1)
SHX46_1 = RPC
SHX47_1 = SHX46_1
SHX46_1 = SHX46_1.onLocal
SHX48_1 = "entityCreated"
function SHX49_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2
  SHX1_2 = DoesEntityExist
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if not SHX1_2 then
    return
  end
  SHX1_2 = GetEntityType
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = SHX3_1
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = tostring
  SHX4_2 = NetworkGetNetworkIdFromEntity
  SHX5_2 = SHX0_2
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2 = SHX4_2(SHX5_2)
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2)
  SHX4_2 = NetworkGetFirstEntityOwner
  SHX5_2 = SHX0_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = GetEntityPopulationType
  SHX6_2 = SHX0_2
  SHX5_2 = SHX5_2(SHX6_2)
  if 2 == SHX1_2 then
    SHX6_2 = GetVehicleNumberPlateText
    SHX7_2 = SHX0_2
    SHX6_2 = SHX6_2(SHX7_2)
    SHX7_2 = Entity
    SHX8_2 = SHX0_2
    SHX7_2 = SHX7_2(SHX8_2)
    SHX7_2 = SHX7_2.state
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.set
    SHX9_2 = "VehiclePlate"
    SHX10_2 = SHX6_2
    SHX11_2 = true
    SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2)
    if 5 == SHX5_2 or 2 == SHX5_2 then
      SHX7_2 = Entity
      SHX8_2 = SHX0_2
      SHX7_2 = SHX7_2(SHX8_2)
      SHX7_2 = SHX7_2.state
      SHX8_2 = SHX7_2
      SHX7_2 = SHX7_2.set
      SHX9_2 = "Reaper_NPC_Vehicle"
      SHX10_2 = true
      SHX11_2 = true
      SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2)
    end
  end
  SHX6_2 = Player
  SHX7_2 = SHX4_2
  SHX6_2 = SHX6_2(SHX7_2)
  if SHX6_2 then
    if SHX2_2 then
      SHX7_2 = nil
      SHX8_2 = SHX19_1
      SHX8_2 = SHX8_2[SHX2_2]
      if SHX8_2 then
        SHX8_2 = {}
        SHX8_2.type = "temp_allowed_entities"
        SHX9_2 = SHX19_1
        SHX9_2 = SHX9_2[SHX2_2]
        if not SHX9_2 then
          SHX9_2 = {}
        end
        SHX8_2.value = SHX9_2
        SHX8_2.creator = "random"
        SHX8_2.owner = SHX4_2
        SHX8_2.last_owner = SHX4_2
        SHX7_2 = SHX8_2
      else
        SHX9_2 = SHX6_2
        SHX8_2 = SHX6_2.getMeta
        SHX10_2 = "%s:%s"
        SHX11_2 = SHX10_2
        SHX10_2 = SHX10_2.format
        SHX12_2 = SHX2_2
        SHX13_2 = SHX1_2
        SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2)
        SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2)
        if SHX8_2 then
          SHX8_2 = {}
          SHX8_2.type = "player_requested"
          SHX10_2 = SHX6_2
          SHX9_2 = SHX6_2.getMeta
          SHX11_2 = "%s:%s"
          SHX12_2 = SHX11_2
          SHX11_2 = SHX11_2.format
          SHX13_2 = SHX2_2
          SHX14_2 = SHX1_2
          SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2)
          SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2)
          if not SHX9_2 then
            SHX9_2 = {}
          end
          SHX8_2.value = SHX9_2
          SHX8_2.creator = SHX4_2
          SHX8_2.owner = SHX4_2
          SHX8_2.last_owner = SHX4_2
          SHX7_2 = SHX8_2
        else
          SHX8_2 = SHX17_1
          SHX8_2 = SHX8_2[SHX2_2]
          if SHX8_2 then
            SHX8_2 = {}
            SHX8_2.type = "whitelisted_entities"
            SHX9_2 = {}
            SHX8_2.value = SHX9_2
            SHX8_2.creator = SHX4_2
            SHX8_2.owner = SHX4_2
            SHX8_2.last_owner = SHX4_2
            SHX7_2 = SHX8_2
          else
            SHX8_2 = {}
            SHX8_2.type = "unknown"
            SHX9_2 = {}
            SHX8_2.value = SHX9_2
            SHX8_2.creator = SHX4_2
            SHX8_2.owner = SHX4_2
            SHX8_2.last_owner = SHX4_2
            SHX7_2 = SHX8_2
          end
        end
      end
      SHX8_2 = entity_tracker
      SHX8_2[SHX3_2] = SHX7_2
      SHX8_2 = entity_tracker
      SHX8_2 = SHX8_2[SHX3_2]
      SHX9_2 = {}
      SHX10_2 = {}
      SHX10_2.from = nil
      SHX10_2.to = SHX4_2
      SHX11_2 = os
      SHX11_2 = SHX11_2.time
      SHX11_2 = SHX11_2()
      SHX10_2.timestamp = SHX11_2
      SHX9_2[1] = SHX10_2
      SHX8_2.ownership_history = SHX9_2
      SHX8_2 = SHX7_2.type
      if "player_requested" == SHX8_2 then
        SHX8_2 = SHX24_1
        if SHX8_2 then
          SHX8_2 = tostring
          SHX9_2 = Security
          SHX10_2 = SHX9_2
          SHX9_2 = SHX9_2.hash
          SHX11_2 = SHX7_2.value
          SHX11_2 = SHX11_2.resource
          SHX12_2 = "97ae7727-b78e47fc-075ea9de-c852f7da-44587eed"
          SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2)
          SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2)
          SHX9_2 = tostring
          SHX10_2 = SHX7_2.value
          SHX10_2 = SHX10_2.extendedExecutionId
          SHX11_2 = ":"
          SHX12_2 = SHX7_2.value
          SHX12_2 = SHX12_2.path
          SHX10_2 = SHX10_2 .. SHX11_2 .. SHX12_2
          SHX9_2 = SHX9_2(SHX10_2)
          SHX10_2 = SHX40_1
          SHX10_2 = SHX10_2[SHX8_2]
          SHX10_2 = SHX10_2[SHX9_2]
          if not SHX10_2 then
            SHX10_2 = 0
          end
          if SHX10_2 <= 3 then
            SHX10_2 = GetConvarInt
            SHX11_2 = "reaper_server_player_count"
            SHX12_2 = 0
            SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
            if SHX10_2 >= 10 then
              SHX11_2 = SHX6_2
              SHX10_2 = SHX6_2.NewLog
              SHX12_2 = "^3%s^7 (^3id:%s^7) just spawned ^3%s^7 from ^3%s^7 with an uncommon execution id. ID: ^3%s^7"
              SHX13_2 = SHX12_2
              SHX12_2 = SHX12_2.format
              SHX15_2 = SHX6_2
              SHX14_2 = SHX6_2.getName
              SHX14_2 = SHX14_2(SHX15_2)
              SHX16_2 = SHX6_2
              SHX15_2 = SHX6_2.getId
              SHX15_2 = SHX15_2(SHX16_2)
              SHX16_2 = SHX2_2
              SHX17_2 = "%s:%s"
              SHX18_2 = SHX17_2
              SHX17_2 = SHX17_2.format
              SHX19_2 = SHX7_2.value
              SHX19_2 = SHX19_2.resource
              SHX20_2 = SHX7_2.value
              SHX20_2 = SHX20_2.path
              SHX17_2 = SHX17_2(SHX18_2, SHX19_2, SHX20_2)
              SHX18_2 = SHX7_2.value
              SHX18_2 = SHX18_2.extendedExecutionId
              SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
              SHX13_2 = "warn"
              SHX14_2 = "uncommon_executions"
              SHX15_2 = {}
              SHX15_2.type = "entity"
              SHX15_2.tracker_data = SHX7_2
              SHX16_2 = true
              SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2)
            end
          end
        end
      end
    end
    if SHX2_2 then
      SHX7_2 = SHX37_1
      SHX8_2 = SHX2_2
      SHX9_2 = SHX1_2
      SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
      SHX8_2 = entity_tracker
      SHX8_2 = SHX8_2[SHX3_2]
      if SHX8_2 then
        SHX8_2 = entity_tracker
        SHX8_2 = SHX8_2[SHX3_2]
        SHX8_2 = SHX8_2.value
        SHX8_2 = SHX8_2.resource
        if SHX8_2 then
          goto SHX_LABEL_227
        end
      end
      SHX8_2 = "unknown"
      -- [FIX IF ERROR] Move ::SHX_LABEL_227:: outside nested blocks until all 'goto SHX_LABEL_227' can see it
      ::SHX_LABEL_227::
      SHX9_2 = SHX35_1
      SHX10_2 = SHX9_2
      SHX9_2 = SHX9_2.track
      SHX11_2 = SHX7_2
      SHX12_2 = SHX4_2
      SHX13_2 = false
      SHX14_2 = {}
      SHX16_2 = SHX6_2
      SHX15_2 = SHX6_2.getName
      SHX15_2 = SHX15_2(SHX16_2)
      SHX14_2.player_name = SHX15_2
      SHX14_2.model_hash = SHX2_2
      SHX15_2 = SHX34_1
      SHX16_2 = SHX1_2
      SHX15_2 = SHX15_2(SHX16_2)
      SHX14_2.entity_type = SHX15_2
      SHX14_2.pop_type = SHX5_2
      SHX14_2.resource = SHX8_2
      SHX15_2 = os
      SHX15_2 = SHX15_2.time
      SHX15_2 = SHX15_2()
      SHX14_2.timestamp = SHX15_2
      SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
      SHX9_2 = SHX36_1
      SHX10_2 = SHX9_2
      SHX9_2 = SHX9_2.track
      SHX11_2 = SHX7_2
      SHX12_2 = SHX8_2
      SHX13_2 = false
      SHX14_2 = {}
      SHX14_2.player_id = SHX4_2
      SHX16_2 = SHX6_2
      SHX15_2 = SHX6_2.getName
      SHX15_2 = SHX15_2(SHX16_2)
      SHX14_2.player_name = SHX15_2
      SHX14_2.model_hash = SHX2_2
      SHX15_2 = SHX34_1
      SHX16_2 = SHX1_2
      SHX15_2 = SHX15_2(SHX16_2)
      SHX14_2.entity_type = SHX15_2
      SHX14_2.pop_type = SHX5_2
      SHX15_2 = os
      SHX15_2 = SHX15_2.time
      SHX15_2 = SHX15_2()
      SHX14_2.timestamp = SHX15_2
      SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
    end
    if nil ~= SHX2_2 then
      SHX7_2 = GetEntityPopulationType
      SHX8_2 = SHX0_2
      SHX7_2 = SHX7_2(SHX8_2)
      SHX8_2 = SHX33_1
      SHX9_2 = SHX0_2
      SHX8_2 = SHX8_2(SHX9_2)
      if not SHX8_2 then
        SHX8_2 = SHX2_2
      end
      SHX9_2 = SHX34_1
      SHX10_2 = SHX1_2
      SHX9_2 = SHX9_2(SHX10_2)
      if 225514697 ~= SHX2_2 or 0 ~= SHX7_2 then
        SHX10_2 = SHX9_1
        if SHX10_2 then
          SHX10_2 = Logger
          SHX11_2 = SHX10_2
          SHX10_2 = SHX10_2.log
          SHX12_2 = "A %s was just created by ^3%s ^7(^3id:%s^7). Data: (^3model:%s^7) (^3netId:%s^7) (^3type:%s^7) (^3pop:%s^7) (^3coords:%s^7) (^3%s^7)"
          SHX13_2 = SHX12_2
          SHX12_2 = SHX12_2.format
          SHX14_2 = SHX9_2
          SHX16_2 = SHX6_2
          SHX15_2 = SHX6_2.getName
          SHX15_2 = SHX15_2(SHX16_2)
          SHX17_2 = SHX6_2
          SHX16_2 = SHX6_2.getId
          SHX16_2 = SHX16_2(SHX17_2)
          SHX17_2 = SHX8_2
          SHX18_2 = SHX3_2
          SHX19_2 = SHX1_2
          SHX20_2 = SHX7_2
          SHX21_2 = GetEntityCoords
          SHX22_2 = SHX0_2
          SHX21_2 = SHX21_2(SHX22_2)
          SHX22_2 = json
          SHX22_2 = SHX22_2.encode
          SHX23_2 = entity_tracker
          SHX23_2 = SHX23_2[SHX3_2]
          if not SHX23_2 then
            SHX23_2 = {}
          end
          SHX22_2, SHX23_2, SHX24_2 = SHX22_2(SHX23_2)
          SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2)
          SHX13_2 = "info"
          SHX10_2(SHX11_2, SHX12_2, SHX13_2)
        end
        if 1 == SHX1_2 and 4 ~= SHX7_2 and 5 ~= SHX7_2 or 2 == SHX1_2 and 5 ~= SHX7_2 and 2 ~= SHX7_2 or 3 == SHX1_2 then
          SHX11_2 = SHX6_2
          SHX10_2 = SHX6_2.NewLog
          SHX12_2 = "^3%s^7 (^3id:%s^7) just spawned a %s (^3model:%s^7) from ^3%s:%s^7"
          SHX13_2 = SHX12_2
          SHX12_2 = SHX12_2.format
          SHX15_2 = SHX6_2
          SHX14_2 = SHX6_2.getName
          SHX14_2 = SHX14_2(SHX15_2)
          SHX16_2 = SHX6_2
          SHX15_2 = SHX6_2.getId
          SHX15_2 = SHX15_2(SHX16_2)
          SHX16_2 = SHX9_2
          SHX17_2 = SHX8_2
          SHX18_2 = entity_tracker
          SHX18_2 = SHX18_2[SHX3_2]
          SHX18_2 = SHX18_2.value
          SHX18_2 = SHX18_2.resource
          if not SHX18_2 then
            SHX18_2 = "UNKNOWN_RESOURCE"
          end
          SHX19_2 = entity_tracker
          SHX19_2 = SHX19_2[SHX3_2]
          SHX19_2 = SHX19_2.value
          SHX19_2 = SHX19_2.path
          if not SHX19_2 then
            SHX19_2 = "UNKNOWN_PATH"
          end
          SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
          SHX13_2 = "info"
          SHX14_2 = "entities"
          SHX15_2 = {}
          SHX15_2.entity_type = SHX9_2
          SHX15_2.model_hash = SHX2_2
          SHX15_2.entity_model_name = SHX8_2
          SHX16_2 = entity_tracker
          SHX16_2 = SHX16_2[SHX3_2]
          SHX16_2 = SHX16_2.value
          SHX16_2 = SHX16_2.resource
          if not SHX16_2 then
            SHX16_2 = "UNKNOWN_RESOURCE"
          end
          SHX15_2.resource = SHX16_2
          SHX16_2 = entity_tracker
          SHX16_2 = SHX16_2[SHX3_2]
          SHX15_2.tacker_data = SHX16_2
          SHX16_2 = true
          SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2)
        end
      end
      SHX10_2 = SHX10_1
      if SHX10_2 then
        SHX10_2 = false
        SHX11_2 = SHX11_1
        if -1 ~= SHX11_2 then
          SHX11_2 = SHX11_1
          if SHX11_2 ~= SHX7_2 then
            goto SHX_LABEL_390
          end
        end
        SHX10_2 = true
        goto SHX_LABEL_412
        -- [FIX IF ERROR] Move ::SHX_LABEL_390:: outside nested blocks until all 'goto SHX_LABEL_390' can see it
        ::SHX_LABEL_390::
        SHX11_2 = SHX12_1
        if -1 ~= SHX11_2 then
          SHX11_2 = SHX12_1
          if SHX11_2 ~= SHX1_2 then
            goto SHX_LABEL_398
          end
        end
        SHX10_2 = true
        goto SHX_LABEL_412
        -- [FIX IF ERROR] Move ::SHX_LABEL_398:: outside nested blocks until all 'goto SHX_LABEL_398' can see it
        ::SHX_LABEL_398::
        SHX11_2 = SHX13_1
        if "" ~= SHX11_2 then
          SHX11_2 = entity_tracker
          SHX11_2 = SHX11_2[SHX3_2]
          if not SHX11_2 then
            goto SHX_LABEL_412
          end
          SHX11_2 = SHX13_1
          SHX12_2 = entity_tracker
          SHX12_2 = SHX12_2[SHX3_2]
          SHX12_2 = SHX12_2.resource
          if SHX11_2 ~= SHX12_2 then
            goto SHX_LABEL_412
          end
        end
        SHX10_2 = true
        -- [FIX IF ERROR] Move ::SHX_LABEL_412:: outside nested blocks until all 'goto SHX_LABEL_412' can see it
        ::SHX_LABEL_412::
        if SHX10_2 then
          SHX11_2 = Logger
          SHX12_2 = SHX11_2
          SHX11_2 = SHX11_2.log_to_file
          SHX13_2 = "spawned_entities.txt"
          SHX14_2 = "%s (license:%s). Data: (model:%s) (netId:%s) (type:%s) (pop:%s) (coords:%s) (%s)"
          SHX15_2 = SHX14_2
          SHX14_2 = SHX14_2.format
          SHX17_2 = SHX6_2
          SHX16_2 = SHX6_2.getName
          SHX16_2 = SHX16_2(SHX17_2)
          SHX18_2 = SHX6_2
          SHX17_2 = SHX6_2.getIdentifier
          SHX19_2 = "license"
          SHX17_2 = SHX17_2(SHX18_2, SHX19_2)
          SHX18_2 = SHX2_2
          SHX19_2 = SHX3_2
          SHX20_2 = SHX1_2
          SHX21_2 = SHX7_2
          SHX22_2 = GetEntityCoords
          SHX23_2 = SHX0_2
          SHX22_2 = SHX22_2(SHX23_2)
          SHX23_2 = json
          SHX23_2 = SHX23_2.encode
          SHX24_2 = entity_tracker
          SHX24_2 = SHX24_2[SHX3_2]
          if not SHX24_2 then
            SHX24_2 = {}
          end
          SHX23_2, SHX24_2 = SHX23_2(SHX24_2)
          SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2 = SHX14_2(SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2)
          SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2)
        end
      end
    end
  end
end
SHX46_1(SHX47_1, SHX48_1, SHX49_1)
SHX46_1 = {}
SHX47_1 = RPC
SHX48_1 = SHX47_1
SHX47_1 = SHX47_1.register
SHX49_1 = "requestSpawn"
function SHX50_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2
  SHX10_2 = SHX6_1
  if false == SHX10_2 then
    SHX10_2 = false
    return SHX10_2
  end
  SHX10_2 = Player
  SHX11_2 = SHX0_2
  SHX10_2 = SHX10_2(SHX11_2)
  if nil == SHX10_2 then
    return
  end
  SHX11_2 = SHX32_1
  SHX12_2 = SHX1_2
  SHX13_2 = SHX2_2
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
  if not SHX11_2 then
    SHX11_2 = SHX1_2
  end
  SHX12_2 = SHX34_1
  SHX13_2 = SHX2_2
  SHX12_2 = SHX12_2(SHX13_2)
  SHX14_2 = SHX10_2
  SHX13_2 = SHX10_2.NewLog
  SHX15_2 = "^3%s^7 (^3id:%s^7) just requested to spawn a %s (^3model:%s^7) from the resource ^3%s:%s^7 (^3%s^7)"
  SHX16_2 = SHX15_2
  SHX15_2 = SHX15_2.format
  SHX18_2 = SHX10_2
  SHX17_2 = SHX10_2.getName
  SHX17_2 = SHX17_2(SHX18_2)
  SHX19_2 = SHX10_2
  SHX18_2 = SHX10_2.getId
  SHX18_2 = SHX18_2(SHX19_2)
  SHX19_2 = SHX12_2
  SHX20_2 = SHX11_2
  SHX21_2 = SHX7_2
  SHX22_2 = SHX3_2
  SHX23_2 = SHX4_2
  SHX15_2 = SHX15_2(SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2)
  SHX16_2 = "info"
  SHX17_2 = "entities"
  SHX18_2 = {}
  SHX18_2.event = "requestSpawn"
  SHX18_2.resource = SHX7_2
  SHX18_2.inv_resource = SHX8_2
  SHX18_2.model = SHX1_2
  SHX18_2.executionId = SHX4_2
  SHX18_2.extendedExecutionId = SHX5_2
  SHX18_2.extra_data = SHX9_2
  SHX19_2 = true
  SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
  SHX13_2 = Security
  SHX14_2 = SHX13_2
  SHX13_2 = SHX13_2.hash
  SHX15_2 = SHX1_2
  SHX16_2 = SHX3_2
  SHX17_2 = SHX4_2
  SHX15_2 = SHX15_2 .. SHX16_2 .. SHX17_2
  SHX13_2 = SHX13_2(SHX14_2, SHX15_2)
  if SHX13_2 ~= SHX6_2 then
    SHX13_2 = RPC
    SHX14_2 = SHX13_2
    SHX13_2 = SHX13_2.emitLocal
    SHX15_2 = "Reaper:NewDetection"
    SHX16_2 = {}
    SHX16_2.type = "keyMissmatch"
    SHX17_2 = {}
    SHX17_2.model = SHX1_2
    SHX17_2.path = SHX3_2
    SHX17_2.executionId = SHX4_2
    SHX17_2.extendedExecutionId = SHX5_2
    SHX18_2 = SHX46_1
    SHX18_2 = SHX18_2[SHX3_2]
    SHX17_2.set = SHX18_2
    SHX16_2.data = SHX17_2
    SHX17_2 = {}
    SHX18_2 = "EntityRequest:1"
    SHX17_2[1] = SHX18_2
    SHX16_2.params = SHX17_2
    SHX16_2.action = "Ban Player"
    SHX18_2 = SHX10_2
    SHX17_2 = SHX10_2.getId
    SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2 = SHX17_2(SHX18_2)
    SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2)
    SHX13_2 = false
    return SHX13_2
  end
  SHX13_2 = SHX46_1
  SHX13_2 = SHX13_2[SHX3_2]
  if nil == SHX13_2 then
    SHX13_2 = nil
    SHX14_2 = pairs
    SHX15_2 = SHX27_1
    SHX14_2, SHX15_2, SHX16_2, SHX17_2 = SHX14_2(SHX15_2)
    for SHX18_2, SHX19_2 in SHX14_2, SHX15_2, SHX16_2, SHX17_2 do
      SHX20_2 = string
      SHX20_2 = SHX20_2.match
      SHX21_2 = SHX3_2
      SHX22_2 = SHX19_2.filter
      SHX20_2 = SHX20_2(SHX21_2, SHX22_2)
      if SHX20_2 then
        SHX13_2 = SHX19_2
        break
      end
    end
    SHX14_2 = SHX46_1
    SHX15_2 = SHX13_2 or SHX15_2
    if not SHX13_2 then
      SHX15_2 = false
    end
    SHX14_2[SHX3_2] = SHX15_2
  end
  SHX13_2 = SHX46_1
  SHX13_2 = SHX13_2[SHX3_2]
  if SHX13_2 then
    SHX13_2 = SHX46_1
    SHX13_2 = SHX13_2[SHX3_2]
    SHX13_2 = SHX13_2.action
    if SHX13_2 then
      SHX13_2 = RPC
      SHX14_2 = SHX13_2
      SHX13_2 = SHX13_2.emitLocal
      SHX15_2 = "Reaper:NewDetection"
      SHX16_2 = {}
      SHX16_2.type = "autoBlacklistedEntity"
      SHX17_2 = {}
      SHX17_2.model = SHX1_2
      SHX17_2.path = SHX3_2
      SHX17_2.executionId = SHX4_2
      SHX17_2.extendedExecutionId = SHX5_2
      SHX18_2 = SHX46_1
      SHX18_2 = SHX18_2[SHX3_2]
      SHX17_2.set = SHX18_2
      SHX16_2.data = SHX17_2
      SHX17_2 = {}
      SHX18_2 = SHX1_2
      SHX17_2[1] = SHX18_2
      SHX16_2.params = SHX17_2
      SHX17_2 = SHX46_1
      SHX17_2 = SHX17_2[SHX3_2]
      SHX17_2 = SHX17_2.action
      SHX16_2.action = SHX17_2
      SHX17_2 = "Attempting to spawn an entity. (Auto Execution Blacklist). Model: %s"
      SHX18_2 = SHX17_2
      SHX17_2 = SHX17_2.format
      SHX19_2 = SHX1_2
      SHX17_2 = SHX17_2(SHX18_2, SHX19_2)
      SHX16_2.reason = SHX17_2
      SHX18_2 = SHX10_2
      SHX17_2 = SHX10_2.getId
      SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2 = SHX17_2(SHX18_2)
      SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2)
      SHX13_2 = false
      return SHX13_2
    end
  end
  SHX13_2 = SHX16_1
  if SHX13_2 then
    SHX13_2 = tostring
    SHX14_2 = SHX1_2
    SHX13_2 = SHX13_2(SHX14_2)
    SHX14_2 = SHX26_1
    SHX13_2 = SHX14_2[SHX13_2]
    if SHX13_2 then
      SHX13_2 = tostring
      SHX14_2 = SHX1_2
      SHX13_2 = SHX13_2(SHX14_2)
      SHX14_2 = SHX17_1
      SHX13_2 = SHX14_2[SHX13_2]
      if nil == SHX13_2 then
        SHX13_2 = RPC
        SHX14_2 = SHX13_2
        SHX13_2 = SHX13_2.emitLocal
        SHX15_2 = "Reaper:NewDetection"
        SHX16_2 = {}
        SHX16_2.type = "autoBlacklistedEntity"
        SHX17_2 = {}
        SHX17_2.catch = "requestSpawn"
        SHX17_2.model = SHX1_2
        SHX17_2.path = SHX3_2
        SHX17_2.executionId = SHX4_2
        SHX17_2.extendedExecutionId = SHX5_2
        SHX18_2 = SHX46_1
        SHX18_2 = SHX18_2[SHX3_2]
        SHX17_2.set = SHX18_2
        SHX16_2.data = SHX17_2
        SHX17_2 = {}
        SHX18_2 = SHX1_2
        SHX17_2[1] = SHX18_2
        SHX16_2.params = SHX17_2
        SHX17_2 = tostring
        SHX18_2 = SHX1_2
        SHX17_2 = SHX17_2(SHX18_2)
        SHX18_2 = SHX26_1
        SHX17_2 = SHX18_2[SHX17_2]
        SHX16_2.action = SHX17_2
        SHX17_2 = "Attempting to spawn an entity. (Auto Entity Blacklist). Model: %s"
        SHX18_2 = SHX17_2
        SHX17_2 = SHX17_2.format
        SHX19_2 = SHX1_2
        SHX17_2 = SHX17_2(SHX18_2, SHX19_2)
        SHX16_2.reason = SHX17_2
        SHX18_2 = SHX10_2
        SHX17_2 = SHX10_2.getId
        SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2 = SHX17_2(SHX18_2)
        SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2)
        SHX13_2 = false
        return SHX13_2
      end
    end
  end
  SHX13_2 = SHX43_1
  if SHX13_2 then
    SHX13_2 = tostring
    SHX14_2 = SHX4_2
    SHX13_2 = SHX13_2(SHX14_2)
    SHX14_2 = SHX44_1
    SHX13_2 = SHX14_2[SHX13_2]
    if nil == SHX13_2 then
      SHX13_2 = tostring
      SHX15_2 = SHX10_2
      SHX14_2 = SHX10_2.getId
      SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2 = SHX14_2(SHX15_2)
      SHX13_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2)
      SHX14_2 = SHX45_1
      SHX13_2 = SHX14_2[SHX13_2]
      if not SHX13_2 then
        SHX13_2 = Cache
        SHX14_2 = SHX13_2
        SHX13_2 = SHX13_2.get
        SHX15_2 = "ProAddon:AutoWhitelist"
        SHX13_2 = SHX13_2(SHX14_2, SHX15_2)
        if true ~= SHX13_2 then
          SHX13_2 = Cache
          SHX14_2 = SHX13_2
          SHX13_2 = SHX13_2.get
          SHX15_2 = "ProAddon:AutoWhitelist:"
          SHX16_2 = SHX7_2
          SHX15_2 = SHX15_2 .. SHX16_2
          SHX13_2 = SHX13_2(SHX14_2, SHX15_2)
          if true ~= SHX13_2 then
            goto SHX_LABEL_286
          end
        end
      end
      SHX13_2 = tostring
      SHX14_2 = SHX4_2
      SHX13_2 = SHX13_2(SHX14_2)
      SHX14_2 = SHX44_1
      SHX15_2 = {}
      SHX15_2.type = "entity"
      SHX15_2.resource = SHX7_2
      SHX15_2.param = SHX1_2
      SHX15_2.path = SHX3_2
      SHX15_2.key = SHX4_2
      SHX15_2.extendedExecutionId = SHX5_2
      SHX14_2[SHX13_2] = SHX15_2
      SHX13_2 = json
      SHX13_2 = SHX13_2.encode
      SHX14_2 = SHX44_1
      SHX13_2 = SHX13_2(SHX14_2)
      SHX14_2 = SaveResourceFile
      SHX15_2 = "ReaperV4"
      SHX16_2 = "cache/entities.json"
      SHX17_2 = SHX13_2
      SHX18_2 = #SHX13_2
      SHX14_2(SHX15_2, SHX16_2, SHX17_2, SHX18_2)
      SHX15_2 = SHX10_2
      SHX14_2 = SHX10_2.NewLog
      SHX16_2 = "(^3CreateEntity('%s')^7) (^3%s^7) sent from (^3%s^7) by (^3%s^7) (^3id:%s^7) was auto whitelisted"
      SHX17_2 = SHX16_2
      SHX16_2 = SHX16_2.format
      SHX18_2 = SHX1_2
      SHX19_2 = SHX4_2
      SHX20_2 = SHX3_2
      SHX22_2 = SHX10_2
      SHX21_2 = SHX10_2.getName
      SHX21_2 = SHX21_2(SHX22_2)
      SHX23_2 = SHX10_2
      SHX22_2 = SHX10_2.getId
      SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2 = SHX22_2(SHX23_2)
      SHX16_2 = SHX16_2(SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2)
      SHX17_2 = "warn"
      SHX18_2 = "pro_addon"
      SHX19_2 = {}
      SHX19_2.resource = SHX7_2
      SHX19_2.model = SHX1_2
      SHX19_2.path = SHX3_2
      SHX19_2.executionId = SHX4_2
      SHX19_2.extendedExecutionId = SHX5_2
      SHX14_2(SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
      goto SHX_LABEL_303
      -- [FIX IF ERROR] Move ::SHX_LABEL_286:: outside nested blocks until all 'goto SHX_LABEL_286' can see it
      ::SHX_LABEL_286::
      SHX13_2 = RPC
      SHX14_2 = SHX13_2
      SHX13_2 = SHX13_2.emitLocal
      SHX15_2 = "Reaper:UnknownExecutionPath"
      SHX16_2 = {}
      SHX16_2.type = "entity"
      SHX16_2.resource = SHX7_2
      SHX16_2.param = SHX1_2
      SHX16_2.path = SHX3_2
      SHX16_2.key = SHX4_2
      SHX16_2.extendedExecutionId = SHX5_2
      SHX18_2 = SHX10_2
      SHX17_2 = SHX10_2.getId
      SHX17_2 = SHX17_2(SHX18_2)
      SHX16_2.source = SHX17_2
      SHX13_2(SHX14_2, SHX15_2, SHX16_2)
      SHX13_2 = false
      return SHX13_2
    end
  end
  -- [FIX IF ERROR] Move ::SHX_LABEL_303:: outside nested blocks until all 'goto SHX_LABEL_303' can see it
  ::SHX_LABEL_303::
  SHX13_2 = SHX24_1
  if SHX13_2 then
    SHX13_2 = tostring
    SHX14_2 = Security
    SHX15_2 = SHX14_2
    SHX14_2 = SHX14_2.hash
    SHX16_2 = SHX7_2
    SHX17_2 = "97ae7727-b78e47fc-075ea9de-c852f7da-44587eed"
    SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2 = SHX14_2(SHX15_2, SHX16_2, SHX17_2)
    SHX13_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2)
    SHX14_2 = tostring
    SHX15_2 = SHX5_2
    SHX16_2 = ":"
    SHX17_2 = SHX3_2
    SHX15_2 = SHX15_2 .. SHX16_2 .. SHX17_2
    SHX14_2 = SHX14_2(SHX15_2)
    SHX15_2 = SHX42_1
    SHX15_2 = SHX15_2[SHX7_2]
    if nil == SHX15_2 then
      SHX15_2 = SHX42_1
      SHX16_2 = os
      SHX16_2 = SHX16_2.time
      SHX16_2 = SHX16_2()
      SHX15_2[SHX7_2] = SHX16_2
    end
    SHX15_2 = SHX40_1
    SHX15_2 = SHX15_2[SHX13_2]
    if nil == SHX15_2 then
      SHX15_2 = SHX40_1
      SHX16_2 = {}
      SHX15_2[SHX13_2] = SHX16_2
    end
    SHX16_2 = SHX10_2
    SHX15_2 = SHX10_2.getMeta
    SHX17_2 = "ai_whitelist_"
    SHX18_2 = SHX14_2
    SHX17_2 = SHX17_2 .. SHX18_2
    SHX18_2 = false
    SHX15_2 = SHX15_2(SHX16_2, SHX17_2, SHX18_2)
    if false == SHX15_2 then
      SHX15_2 = SHX40_1
      SHX15_2 = SHX15_2[SHX13_2]
      SHX15_2 = SHX15_2[SHX14_2]
      if not SHX15_2 then
        SHX15_2 = Cache
        SHX16_2 = SHX15_2
        SHX15_2 = SHX15_2.get
        SHX17_2 = "ai_whitelist_"
        SHX18_2 = SHX14_2
        SHX17_2 = SHX17_2 .. SHX18_2
        SHX18_2 = 0
        SHX15_2 = SHX15_2(SHX16_2, SHX17_2, SHX18_2)
        if not (SHX15_2 <= 3) then
          goto SHX_LABEL_369
        end
      end
      SHX15_2 = SHX40_1
      SHX15_2 = SHX15_2[SHX13_2]
      SHX16_2 = SHX40_1
      SHX16_2 = SHX16_2[SHX13_2]
      SHX16_2 = SHX16_2[SHX14_2]
      if not SHX16_2 then
        SHX16_2 = 0
      end
      SHX16_2 = SHX16_2 + 1
      SHX15_2[SHX14_2] = SHX16_2
      -- [FIX IF ERROR] Move ::SHX_LABEL_369:: outside nested blocks until all 'goto SHX_LABEL_369' can see it
      ::SHX_LABEL_369::
      SHX16_2 = SHX10_2
      SHX15_2 = SHX10_2.setMeta
      SHX17_2 = "ai_whitelist_"
      SHX18_2 = SHX14_2
      SHX17_2 = SHX17_2 .. SHX18_2
      SHX18_2 = true
      SHX15_2(SHX16_2, SHX17_2, SHX18_2)
    end
    SHX15_2 = SHX40_1
    SHX15_2 = SHX15_2[SHX13_2]
    SHX15_2 = SHX15_2[SHX14_2]
    if not SHX15_2 then
      SHX15_2 = 0
    end
    if SHX15_2 <= 3 then
      SHX15_2 = os
      SHX15_2 = SHX15_2.time
      SHX15_2 = SHX15_2()
      SHX16_2 = SHX42_1
      SHX16_2 = SHX16_2[SHX7_2]
      if not SHX16_2 then
        SHX16_2 = 0
      end
      SHX15_2 = SHX15_2 - SHX16_2
      SHX16_2 = 10800
      if SHX15_2 < SHX16_2 then
        SHX17_2 = SHX10_2
        SHX16_2 = SHX10_2.NewLog
        SHX18_2 = "^3%s^7 (^3id:%s^7) just spawned a %s (^3%s^7) from (^3%s:%s^7) with an uncommon execution id (^3%s^7)"
        SHX19_2 = SHX18_2
        SHX18_2 = SHX18_2.format
        SHX21_2 = SHX10_2
        SHX20_2 = SHX10_2.getName
        SHX20_2 = SHX20_2(SHX21_2)
        SHX22_2 = SHX10_2
        SHX21_2 = SHX10_2.getId
        SHX21_2 = SHX21_2(SHX22_2)
        SHX22_2 = SHX12_2
        SHX23_2 = SHX11_2
        SHX24_2 = SHX7_2
        SHX25_2 = SHX3_2
        SHX26_2 = SHX5_2
        SHX18_2 = SHX18_2(SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2)
        SHX19_2 = "warn"
        SHX20_2 = "uncommon_executions"
        SHX21_2 = {}
        SHX21_2.type = "entity"
        SHX21_2.resource = SHX7_2
        SHX21_2.inv_resource = SHX8_2
        SHX21_2.param = SHX1_2
        SHX21_2.path = SHX3_2
        SHX21_2.key = SHX4_2
        SHX21_2.extendedExecutionId = SHX5_2
        SHX22_2 = SHX9_2 or SHX22_2
        if not SHX9_2 then
          SHX22_2 = "na"
        end
        SHX21_2.extra_data = SHX22_2
        SHX22_2 = true
        SHX16_2(SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2)
      else
        SHX16_2 = SHX25_1
        if SHX16_2 then
          SHX16_2 = SHX7_2
          SHX17_2 = ":"
          SHX18_2 = SHX5_2
          SHX19_2 = ":"
          SHX20_2 = SHX3_2
          SHX16_2 = SHX16_2 .. SHX17_2 .. SHX18_2 .. SHX19_2 .. SHX20_2
          SHX17_2 = SHX41_1
          SHX17_2 = SHX17_2[SHX16_2]
          if nil == SHX17_2 then
            SHX17_2 = SHX41_1
            SHX18_2 = {}
            SHX18_2.resource = SHX7_2
            SHX18_2.executionId = SHX5_2
            SHX18_2.path = SHX3_2
            SHX18_2.model = SHX1_2
            SHX18_2.count = 0
            SHX19_2 = os
            SHX19_2 = SHX19_2.time
            SHX19_2 = SHX19_2()
            SHX18_2.first_blocked = SHX19_2
            SHX20_2 = SHX10_2
            SHX19_2 = SHX10_2.getId
            SHX19_2 = SHX19_2(SHX20_2)
            SHX18_2.last_player_id = SHX19_2
            SHX17_2[SHX16_2] = SHX18_2
          end
          SHX17_2 = SHX41_1
          SHX17_2 = SHX17_2[SHX16_2]
          SHX18_2 = SHX41_1
          SHX18_2 = SHX18_2[SHX16_2]
          SHX18_2 = SHX18_2.count
          SHX18_2 = SHX18_2 + 1
          SHX17_2.count = SHX18_2
          SHX17_2 = SHX41_1
          SHX17_2 = SHX17_2[SHX16_2]
          SHX18_2 = os
          SHX18_2 = SHX18_2.time
          SHX18_2 = SHX18_2()
          SHX17_2.last_blocked = SHX18_2
          SHX17_2 = SHX41_1
          SHX17_2 = SHX17_2[SHX16_2]
          SHX19_2 = SHX10_2
          SHX18_2 = SHX10_2.getId
          SHX18_2 = SHX18_2(SHX19_2)
          SHX17_2.last_player_id = SHX18_2
          SHX18_2 = SHX10_2
          SHX17_2 = SHX10_2.NewLog
          SHX19_2 = "^3%s^7 (^3id:%s^7) just attempted to spawn a %s (^3%s^7) from (^3%s:%s^7) with an uncommon execution id (^3%s^7) and was blocked. ^1An uncommon execution key can be caused by a modification made to the script, the resource rarely spawns entities, you recently added the script, or the script is being abused by a cheat. If you know this entity spawn is legit, you can allow the spawn by running the following command: ^3reaper ai_whitelist %s %s %s^7"
          SHX20_2 = SHX19_2
          SHX19_2 = SHX19_2.format
          SHX22_2 = SHX10_2
          SHX21_2 = SHX10_2.getName
          SHX21_2 = SHX21_2(SHX22_2)
          SHX23_2 = SHX10_2
          SHX22_2 = SHX10_2.getId
          SHX22_2 = SHX22_2(SHX23_2)
          SHX23_2 = SHX12_2
          SHX24_2 = SHX11_2
          SHX25_2 = SHX7_2
          SHX26_2 = SHX3_2
          SHX27_2 = SHX5_2
          SHX28_2 = SHX7_2
          SHX29_2 = SHX5_2
          SHX30_2 = SHX3_2
          SHX19_2 = SHX19_2(SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2, SHX30_2)
          SHX20_2 = "warn"
          SHX21_2 = "uncommon_executions"
          SHX22_2 = {}
          SHX22_2.type = "entity"
          SHX22_2.resource = SHX7_2
          SHX22_2.inv_resource = SHX8_2
          SHX22_2.param = SHX1_2
          SHX22_2.path = SHX3_2
          SHX22_2.key = SHX4_2
          SHX22_2.extendedExecutionId = SHX5_2
          SHX23_2 = SHX9_2 or SHX23_2
          if not SHX9_2 then
            SHX23_2 = "na"
          end
          SHX22_2.extra_data = SHX23_2
          SHX23_2 = true
          SHX17_2(SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2)
          SHX17_2 = false
          return SHX17_2
        end
      end
    end
  end
  SHX13_2 = "CreatePed"
  if 2 == SHX2_2 then
    SHX13_2 = "CreateVehicle"
  elseif 3 == SHX2_2 then
    SHX13_2 = "CreateObject"
  end
  SHX14_2 = NativeRules
  SHX15_2 = SHX14_2
  SHX14_2 = SHX14_2.evaluateNative
  SHX16_2 = SHX13_2
  SHX17_2 = {}
  SHX18_2 = {}
  SHX18_2.resource = SHX7_2
  SHX18_2.path = SHX3_2
  SHX18_2.executionId = SHX4_2
  SHX18_2.extendedExecutionId = SHX5_2
  SHX17_2.req = SHX18_2
  SHX18_2 = {}
  SHX20_2 = SHX10_2
  SHX19_2 = SHX10_2.getId
  SHX19_2 = SHX19_2(SHX20_2)
  SHX18_2.player = SHX19_2
  SHX18_2.source = "client->server->cb"
  SHX17_2.origin = SHX18_2
  SHX14_2 = SHX14_2(SHX15_2, SHX16_2, SHX17_2)
  if false == SHX14_2 then
    SHX14_2 = false
    return SHX14_2
  end
  SHX15_2 = SHX10_2
  SHX14_2 = SHX10_2.setMeta
  SHX16_2 = "%s:%s"
  SHX17_2 = SHX16_2
  SHX16_2 = SHX16_2.format
  SHX18_2 = SHX1_2
  SHX19_2 = SHX2_2
  SHX16_2 = SHX16_2(SHX17_2, SHX18_2, SHX19_2)
  SHX17_2 = {}
  SHX17_2.type = "entity"
  SHX17_2.resource = SHX7_2
  SHX17_2.inv_resource = SHX8_2
  SHX17_2.param = SHX1_2
  SHX17_2.path = SHX3_2
  SHX17_2.key = SHX4_2
  SHX17_2.extendedExecutionId = SHX5_2
  SHX18_2 = SHX9_2 or SHX18_2
  if not SHX9_2 then
    SHX18_2 = "na"
  end
  SHX17_2.extra_data = SHX18_2
  SHX14_2(SHX15_2, SHX16_2, SHX17_2)
  SHX14_2 = true
  return SHX14_2
end
SHX47_1(SHX48_1, SHX49_1, SHX50_1)
SHX47_1 = RPC
SHX48_1 = SHX47_1
SHX47_1 = SHX47_1.register
SHX49_1 = "Reaper:TempAllowEntity"
function SHX50_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX2_2 = Player
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX0_2 = SHX2_2
  if SHX0_2 then
    SHX3_2 = SHX0_2
    SHX2_2 = SHX0_2.addDetection
    SHX4_2 = "ban"
    SHX5_2 = "Attempting to trigger Reaper:TempAllowEntity"
    SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  end
  SHX2_2 = false
  return SHX2_2
end
SHX47_1(SHX48_1, SHX49_1, SHX50_1)
SHX47_1 = exports
SHX48_1 = "tempAllowEntity"
function SHX49_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX2_2 = GetInvokingResource
  SHX2_2 = SHX2_2()
  if SHX0_2 then
    SHX3_2 = type
    SHX4_2 = SHX0_2
    SHX3_2 = SHX3_2(SHX4_2)
    if "string" == SHX3_2 then
      goto SHX_LABEL_17
    end
    SHX3_2 = type
    SHX4_2 = SHX0_2
    SHX3_2 = SHX3_2(SHX4_2)
    if "number" == SHX3_2 then
      goto SHX_LABEL_17
    end
  end
  SHX3_2 = true
  return SHX3_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_17:: outside nested blocks until all 'goto SHX_LABEL_17' can see it
  ::SHX_LABEL_17::
  SHX3_2 = SHX19_1
  SHX4_2 = {}
  SHX5_2 = GetGameTimer
  SHX5_2 = SHX5_2()
  SHX4_2.time = SHX5_2
  SHX5_2 = SHX2_2 or SHX5_2
  if not SHX2_2 then
    SHX5_2 = "unknown"
  end
  SHX4_2.resource = SHX5_2
  SHX4_2.path = SHX1_2
  SHX3_2[SHX0_2] = SHX4_2
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "^3%s^7 was just set as a temp allowed entity - %s"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX0_2
  SHX8_2 = json
  SHX8_2 = SHX8_2.encode
  SHX9_2 = SHX19_1
  SHX9_2 = SHX9_2[SHX0_2]
  SHX8_2, SHX9_2 = SHX8_2(SHX9_2)
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  SHX6_2 = "debug"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = true
  return SHX3_2
end
SHX47_1(SHX48_1, SHX49_1)
SHX47_1 = RPC
SHX48_1 = SHX47_1
SHX47_1 = SHX47_1.register
SHX49_1 = "requestEntityAttach"
function SHX50_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = NetworkGetEntityFromNetworkId
  SHX3_2 = SHX1_2.target
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = DoesEntityExist
  SHX4_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2)
  if not SHX3_2 then
    SHX3_2 = false
    return SHX3_2
  end
  SHX3_2 = GetResourceState
  SHX4_2 = SHX1_2.resource
  SHX3_2 = SHX3_2(SHX4_2)
  if "started" ~= SHX3_2 then
    SHX3_2 = false
    return SHX3_2
  end
  SHX3_2 = Entity
  SHX4_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2)
  SHX3_2 = SHX3_2.state
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.set
  SHX5_2 = "EntityAttachApproved"
  SHX6_2 = true
  SHX7_2 = true
  SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2)
  SHX3_2 = true
  return SHX3_2
end
SHX47_1(SHX48_1, SHX49_1, SHX50_1)
SHX47_1 = CreateThread
function SHX48_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  while true do
    SHX0_2 = Wait
    SHX1_2 = 50
    SHX0_2(SHX1_2)
    SHX0_2 = GetConvar
    SHX1_2 = "reaper_validate_entity_attachments"
    SHX2_2 = "true"
    SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
    if "true" == SHX0_2 then
      SHX0_2 = pairs
      SHX1_2 = GetAllEntities
      SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX1_2()
      SHX0_2, SHX1_2, SHX2_2, SHX3_2 = SHX0_2(SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
      for SHX4_2, SHX5_2 in SHX0_2, SHX1_2, SHX2_2, SHX3_2 do
        SHX6_2 = false
        SHX7_2 = DoesEntityExist
        SHX8_2 = SHX5_2
        SHX7_2 = SHX7_2(SHX8_2)
        if SHX7_2 then
          SHX7_2 = IsPedAPlayer
          SHX8_2 = SHX5_2
          SHX7_2 = SHX7_2(SHX8_2)
          if not SHX7_2 then
            SHX7_2 = GetEntityAttachedTo
            SHX8_2 = SHX5_2
            SHX7_2 = SHX7_2(SHX8_2)
            if 0 ~= SHX7_2 then
              SHX8_2 = IsPedAPlayer
              SHX9_2 = SHX7_2
              SHX8_2 = SHX8_2(SHX9_2)
              if SHX8_2 then
                SHX8_2 = Entity
                SHX9_2 = SHX5_2
                SHX8_2 = SHX8_2(SHX9_2)
                SHX8_2 = SHX8_2.state
                SHX8_2 = SHX8_2.EntityAttachApproved
                if nil == SHX8_2 then
                  SHX8_2 = entity_tracker
                  SHX9_2 = tostring
                  SHX10_2 = NetworkGetNetworkIdFromEntity
                  SHX11_2 = SHX5_2
                  SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX10_2(SHX11_2)
                  SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2)
                  SHX8_2 = SHX8_2[SHX9_2]
                  if SHX8_2 then
                    SHX9_2 = Player
                    SHX10_2 = SHX8_2.last_owner
                    SHX9_2 = SHX9_2(SHX10_2)
                    SHX10_2 = Player
                    SHX11_2 = NetworkGetEntityOwner
                    SHX12_2 = SHX7_2
                    SHX11_2, SHX12_2, SHX13_2 = SHX11_2(SHX12_2)
                    SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2)
                    if SHX9_2 and SHX10_2 then
                      SHX12_2 = SHX9_2
                      SHX11_2 = SHX9_2.getId
                      SHX11_2 = SHX11_2(SHX12_2)
                      SHX13_2 = SHX10_2
                      SHX12_2 = SHX10_2.getId
                      SHX12_2 = SHX12_2(SHX13_2)
                      if SHX11_2 ~= SHX12_2 then
                        SHX11_2 = CreateThread
                        function SHX12_2()
                          -- [AI CLEANUP] Decompiled Lua - Fix these:
                          -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
                          -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
                          -- 3. Replace goto/label with while/repeat-until where possible
                          -- 4. Remove decompiler comments, add meaningful ones
                          -- 5. Fix indentation and formatting
                          
                          local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
                          SHX0_3 = SHX10_2
                          SHX1_3 = SHX0_3
                          SHX0_3 = SHX0_3.NewLog
                          SHX2_3 = "The net entity ^3%s^7 that was attached to ^3%s^7 (^3id:%s^7) was deleted."
                          SHX3_3 = SHX2_3
                          SHX2_3 = SHX2_3.format
                          SHX4_3 = NetworkGetNetworkIdFromEntity
                          SHX5_3 = SHX5_2
                          SHX4_3 = SHX4_3(SHX5_3)
                          SHX5_3 = SHX10_2
                          SHX6_3 = SHX5_3
                          SHX5_3 = SHX5_3.getName
                          SHX5_3 = SHX5_3(SHX6_3)
                          SHX6_3 = SHX10_2
                          SHX7_3 = SHX6_3
                          SHX6_3 = SHX6_3.getId
                          SHX6_3, SHX7_3 = SHX6_3(SHX7_3)
                          SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
                          SHX3_3 = "warn"
                          SHX4_3 = "entity_attachments"
                          SHX5_3 = {}
                          SHX6_3 = SHX8_2
                          SHX5_3.entity_data = SHX6_3
                          SHX6_3 = SHX10_2
                          SHX7_3 = SHX6_3
                          SHX6_3 = SHX6_3.getScreenRecording
                          SHX6_3 = SHX6_3(SHX7_3)
                          SHX5_3.attached_to_pov = SHX6_3
                          SHX6_3 = true
                          SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
                        end
                        SHX11_2(SHX12_2)
                      end
                    end
                  end
                  SHX9_2 = DeleteEntity
                  SHX10_2 = SHX5_2
                  SHX9_2(SHX10_2)
                  SHX6_2 = true
                end
              end
            end
          end
        end
        if not SHX6_2 then
          SHX7_2 = Wait
          SHX8_2 = 50
          SHX7_2(SHX8_2)
        end
      end
    else
      SHX0_2 = Wait
      SHX1_2 = 5000
      SHX0_2(SHX1_2)
    end
  end
end
SHX47_1(SHX48_1)
SHX47_1 = RPC
SHX48_1 = SHX47_1
SHX47_1 = SHX47_1.register
SHX49_1 = "requestEntityInfo"
function SHX50_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  SHX2_2 = entity_tracker
  SHX3_2 = tostring
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  SHX2_2 = SHX2_2[SHX3_2]
  if SHX2_2 then
    SHX2_2.netId = SHX1_2
  end
  return SHX2_2
end
SHX47_1(SHX48_1, SHX49_1, SHX50_1)
SHX47_1 = RPC
SHX48_1 = SHX47_1
SHX47_1 = SHX47_1.onLocal
SHX49_1 = "entityOwnershipTransfer"
function SHX50_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2
  SHX3_2 = entity_tracker
  SHX4_2 = tostring
  SHX5_2 = SHX0_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX3_2 = SHX3_2[SHX4_2]
  if nil == SHX3_2 then
    SHX3_2 = GetConvar
    SHX4_2 = "reaper_log_unknown_entity_ownership_transfers"
    SHX5_2 = "false"
    SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
    if "true" == SHX3_2 then
      SHX3_2 = NetworkGetEntityFromNetworkId
      SHX4_2 = SHX0_2
      SHX3_2 = SHX3_2(SHX4_2)
      if 0 ~= SHX3_2 then
        SHX4_2 = warn
        SHX5_2 = "(netId:%s) (model:%s) (type:%s) (pop:%s) is an unknown entity, unable to set entity ownership data."
        SHX6_2 = SHX5_2
        SHX5_2 = SHX5_2.format
        SHX7_2 = SHX0_2
        SHX8_2 = SHX3_1
        SHX9_2 = SHX3_2
        SHX8_2 = SHX8_2(SHX9_2)
        SHX9_2 = GetEntityType
        SHX10_2 = SHX3_2
        SHX9_2 = SHX9_2(SHX10_2)
        SHX10_2 = GetEntityPopulationType
        SHX11_2 = SHX3_2
        SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2 = SHX10_2(SHX11_2)
        SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
        SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
      end
    end
    return
  end
  SHX3_2 = entity_tracker
  SHX4_2 = tostring
  SHX5_2 = SHX0_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX3_2 = SHX3_2[SHX4_2]
  SHX3_2.last_owner = SHX1_2
  SHX3_2 = entity_tracker
  SHX4_2 = tostring
  SHX5_2 = SHX0_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX3_2 = SHX3_2[SHX4_2]
  SHX3_2.owner = SHX2_2
  SHX3_2 = entity_tracker
  SHX4_2 = tostring
  SHX5_2 = SHX0_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX3_2 = SHX3_2[SHX4_2]
  SHX3_2 = SHX3_2.ownership_history
  if nil == SHX3_2 then
    SHX3_2 = entity_tracker
    SHX4_2 = tostring
    SHX5_2 = SHX0_2
    SHX4_2 = SHX4_2(SHX5_2)
    SHX3_2 = SHX3_2[SHX4_2]
    SHX4_2 = {}
    SHX3_2.ownership_history = SHX4_2
  end
  SHX3_2 = table
  SHX3_2 = SHX3_2.insert
  SHX4_2 = entity_tracker
  SHX5_2 = tostring
  SHX6_2 = SHX0_2
  SHX5_2 = SHX5_2(SHX6_2)
  SHX4_2 = SHX4_2[SHX5_2]
  SHX4_2 = SHX4_2.ownership_history
  SHX5_2 = {}
  SHX5_2.from = SHX1_2
  SHX5_2.to = SHX2_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX3_2(SHX4_2, SHX5_2)
  SHX3_2 = GetConvar
  SHX4_2 = "reaper_log_entity_ownership_changes"
  SHX5_2 = "false"
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  if "true" == SHX3_2 then
    SHX3_2 = Player
    SHX4_2 = SHX2_2
    SHX3_2 = SHX3_2(SHX4_2)
    SHX4_2 = Player
    SHX5_2 = SHX1_2
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX3_2 or nil == SHX4_2 then
      return
    end
    SHX5_2 = NetworkGetEntityFromNetworkId
    SHX6_2 = SHX0_2
    SHX5_2 = SHX5_2(SHX6_2)
    SHX6_2 = GetEntityType
    SHX7_2 = SHX5_2
    SHX6_2 = SHX6_2(SHX7_2)
    SHX7_2 = ""
    if 1 == SHX6_2 then
      SHX8_2 = "^3%s^7 (^3id:%s^7) was just transferred ownership of the ped (^3netId:%s^7) from ^3%s^7 (^3id:%s^7)"
      SHX9_2 = SHX8_2
      SHX8_2 = SHX8_2.format
      SHX11_2 = SHX3_2
      SHX10_2 = SHX3_2.getName
      SHX10_2 = SHX10_2(SHX11_2)
      SHX12_2 = SHX3_2
      SHX11_2 = SHX3_2.getId
      SHX11_2 = SHX11_2(SHX12_2)
      SHX12_2 = SHX0_2
      SHX14_2 = SHX4_2
      SHX13_2 = SHX4_2.getName
      SHX13_2 = SHX13_2(SHX14_2)
      SHX15_2 = SHX4_2
      SHX14_2 = SHX4_2.getId
      SHX14_2, SHX15_2 = SHX14_2(SHX15_2)
      SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
      SHX7_2 = SHX8_2
    elseif 2 == SHX6_2 then
      SHX8_2 = "^3%s^7 (^3id:%s^7) was just transferred ownership of the vehicle (^3netId:%s^7) from ^3%s^7 (^3id:%s^7)"
      SHX9_2 = SHX8_2
      SHX8_2 = SHX8_2.format
      SHX11_2 = SHX3_2
      SHX10_2 = SHX3_2.getName
      SHX10_2 = SHX10_2(SHX11_2)
      SHX12_2 = SHX3_2
      SHX11_2 = SHX3_2.getId
      SHX11_2 = SHX11_2(SHX12_2)
      SHX12_2 = SHX0_2
      SHX14_2 = SHX4_2
      SHX13_2 = SHX4_2.getName
      SHX13_2 = SHX13_2(SHX14_2)
      SHX15_2 = SHX4_2
      SHX14_2 = SHX4_2.getId
      SHX14_2, SHX15_2 = SHX14_2(SHX15_2)
      SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
      SHX7_2 = SHX8_2
    elseif 3 == SHX6_2 then
      SHX8_2 = "^3%s^7 (^3id:%s^7) was just transferred ownership of the object (^3netId:%s^7) from ^3%s^7 (^3id:%s^7)"
      SHX9_2 = SHX8_2
      SHX8_2 = SHX8_2.format
      SHX11_2 = SHX3_2
      SHX10_2 = SHX3_2.getName
      SHX10_2 = SHX10_2(SHX11_2)
      SHX12_2 = SHX3_2
      SHX11_2 = SHX3_2.getId
      SHX11_2 = SHX11_2(SHX12_2)
      SHX12_2 = SHX0_2
      SHX14_2 = SHX4_2
      SHX13_2 = SHX4_2.getName
      SHX13_2 = SHX13_2(SHX14_2)
      SHX15_2 = SHX4_2
      SHX14_2 = SHX4_2.getId
      SHX14_2, SHX15_2 = SHX14_2(SHX15_2)
      SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
      SHX7_2 = SHX8_2
    end
    if 1 == SHX6_2 then
      SHX8_2 = GetConvar
      SHX9_2 = "reaper_log_ped_ownership_changes_to_file"
      SHX10_2 = "false"
      SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
      if "true" == SHX8_2 then
        SHX8_2 = Logger
        SHX9_2 = SHX8_2
        SHX8_2 = SHX8_2.log_to_file
        SHX10_2 = "entities/ped_ownerships.log"
        SHX11_2 = SHX7_2
        SHX8_2(SHX9_2, SHX10_2, SHX11_2)
      end
    end
    if 2 == SHX6_2 then
      SHX8_2 = GetConvar
      SHX9_2 = "reaper_log_vehicle_ownership_changes_to_file"
      SHX10_2 = "false"
      SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
      if "true" == SHX8_2 then
        SHX8_2 = Logger
        SHX9_2 = SHX8_2
        SHX8_2 = SHX8_2.log_to_file
        SHX10_2 = "entities/vehicle_ownerships.log"
        SHX11_2 = SHX7_2
        SHX8_2(SHX9_2, SHX10_2, SHX11_2)
      end
    end
    if 3 == SHX6_2 then
      SHX8_2 = GetConvar
      SHX9_2 = "reaper_log_object_ownership_changes_to_file"
      SHX10_2 = "false"
      SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
      if "true" == SHX8_2 then
        SHX8_2 = Logger
        SHX9_2 = SHX8_2
        SHX8_2 = SHX8_2.log_to_file
        SHX10_2 = "entities/object_ownerships.log"
        SHX11_2 = SHX7_2
        SHX8_2(SHX9_2, SHX10_2, SHX11_2)
      end
    end
    SHX8_2 = Logger
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.log
    SHX10_2 = SHX7_2
    SHX11_2 = "info"
    SHX8_2(SHX9_2, SHX10_2, SHX11_2)
  end
end
SHX47_1(SHX48_1, SHX49_1, SHX50_1)
SHX47_1 = RPC
SHX48_1 = SHX47_1
SHX47_1 = SHX47_1.onNet
SHX49_1 = "Reaper:antiNPCVehicleAttach"
function SHX50_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2
  SHX1_2 = source
  SHX2_2 = NetworkGetEntityFromNetworkId
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = NetworkGetFirstEntityOwner
  SHX4_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = entity_tracker
  SHX5_2 = tostring
  SHX6_2 = SHX0_2
  SHX5_2 = SHX5_2(SHX6_2)
  SHX4_2 = SHX4_2[SHX5_2]
  if SHX4_2 then
    SHX4_2 = entity_tracker
    SHX5_2 = tostring
    SHX6_2 = SHX0_2
    SHX5_2 = SHX5_2(SHX6_2)
    SHX4_2 = SHX4_2[SHX5_2]
    SHX3_2 = SHX4_2.last_owner
  end
  if 0 == SHX2_2 then
    return
  end
  SHX4_2 = DeleteEntity
  SHX5_2 = SHX2_2
  SHX4_2(SHX5_2)
  SHX4_2 = Player
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = Player
  SHX6_2 = SHX3_2
  SHX5_2 = SHX5_2(SHX6_2)
  if nil == SHX4_2 then
    return
  end
  if nil == SHX5_2 then
    SHX6_2 = {}
    function SHX7_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3
      SHX0_3 = "Unknown"
      return SHX0_3
    end
    SHX6_2.getName = SHX7_2
    function SHX7_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3
      SHX0_3 = 0
      return SHX0_3
    end
    SHX6_2.getId = SHX7_2
    SHX5_2 = SHX6_2
  end
  SHX6_2 = Logger
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.log
  SHX8_2 = "(^3net:%s^7) was just deleted after being attached to ^3%s^7 (^3id:%s^7). The last owner was ^3%s^7 (^3id:%s^7)"
  SHX9_2 = SHX8_2
  SHX8_2 = SHX8_2.format
  SHX10_2 = SHX0_2
  SHX12_2 = SHX4_2
  SHX11_2 = SHX4_2.getName
  SHX11_2 = SHX11_2(SHX12_2)
  SHX13_2 = SHX4_2
  SHX12_2 = SHX4_2.getId
  SHX12_2 = SHX12_2(SHX13_2)
  SHX14_2 = SHX5_2
  SHX13_2 = SHX5_2.getName
  SHX13_2 = SHX13_2(SHX14_2)
  SHX15_2 = SHX5_2
  SHX14_2 = SHX5_2.getId
  SHX14_2, SHX15_2 = SHX14_2(SHX15_2)
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
  SHX9_2 = "warn"
  SHX6_2(SHX7_2, SHX8_2, SHX9_2)
end
SHX47_1(SHX48_1, SHX49_1, SHX50_1)
