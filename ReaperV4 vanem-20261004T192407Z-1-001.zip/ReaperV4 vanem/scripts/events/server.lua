-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = Falcon
Falcon = SHX0_1
SHX0_1 = Security
Security = SHX0_1
SHX0_1 = NativeRules
NativeRules = SHX0_1
SHX0_1 = nil
SHX1_1 = {}
SHX2_1 = RPC
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.on
SHX4_1 = "configUpdated"
function SHX5_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX0_2 = Settings
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX0_2 = SHX0_2(SHX1_2)
  SHX1_2 = Security
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.hash
  SHX3_2 = json
  SHX3_2 = SHX3_2.encode
  SHX4_2 = SHX0_2.event_rules
  SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX3_2(SHX4_2)
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  SHX2_2 = SHX0_1
  if SHX1_2 ~= SHX2_2 then
    SHX2_2 = {}
    SHX1_1 = SHX2_2
    SHX2_2 = {}
    SHX3_2 = pairs
    SHX4_2 = SHX0_2.event_rules
    SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
    for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
      SHX9_2 = SHX8_2.event
      SHX2_2[SHX9_2] = true
      SHX10_2 = SHX8_2.event
      SHX9_2 = SHX1_1
      SHX9_2 = SHX9_2[SHX10_2]
      if nil == SHX9_2 then
        SHX10_2 = SHX8_2.event
        SHX9_2 = SHX1_1
        SHX11_2 = {}
        SHX9_2[SHX10_2] = SHX11_2
      end
      SHX9_2 = table
      SHX9_2 = SHX9_2.insert
      SHX11_2 = SHX8_2.event
      SHX10_2 = SHX1_1
      SHX10_2 = SHX10_2[SHX11_2]
      SHX11_2 = SHX8_2
      SHX9_2(SHX10_2, SHX11_2)
      SHX9_2 = json
      SHX9_2 = SHX9_2.encode
      SHX10_2 = SHX2_2
      SHX9_2 = SHX9_2(SHX10_2)
      SHX10_2 = Security
      SHX11_2 = SHX10_2
      SHX10_2 = SHX10_2.hash
      SHX12_2 = SHX9_2
      SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
      SHX0_1 = SHX10_2
      SHX10_2 = SetConvar
      SHX11_2 = "reaper_event_rule_names"
      SHX12_2 = SHX9_2
      SHX10_2(SHX11_2, SHX12_2)
    end
  end
end
SHX2_1(SHX3_1, SHX4_1, SHX5_1)
SHX2_1 = exports
SHX3_1 = "EventRulesCheck"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX2_2 = SHX1_1
  SHX2_2 = SHX2_2[SHX0_2]
  if nil == SHX2_2 then
    SHX2_2 = true
    return SHX2_2
  end
  SHX2_2 = true
  SHX3_2 = pairs
  SHX4_2 = SHX1_1
  SHX4_2 = SHX4_2[SHX0_2]
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
  for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    SHX9_2 = NativeRules
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.evaluateRule
    SHX11_2 = SHX8_2
    SHX12_2 = SHX1_2
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2)
    if SHX9_2 then
      SHX10_2 = Player
      SHX11_2 = SHX1_2.source
      SHX10_2 = SHX10_2(SHX11_2)
      if nil ~= SHX10_2 then
        SHX11_2 = SHX8_2.action
        if "server_log" == SHX11_2 then
          SHX11_2 = CreateThread
          function SHX12_2()
            -- [AI CLEANUP] Decompiled Lua - Fix these:
            -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
            -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
            -- 3. Replace goto/label with while/repeat-until where possible
            -- 4. Remove decompiler comments, add meaningful ones
            -- 5. Fix indentation and formatting
            
            local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
            SHX0_3 = SHX10_2
            SHX1_3 = SHX0_3
            SHX0_3 = SHX0_3.NewLog
            SHX2_3 = "^3%s^7 (^3id:%s^7) just flagged the event rule ^3%s^7 while triggering the event ^3%s^7"
            SHX3_3 = SHX2_3
            SHX2_3 = SHX2_3.format
            SHX4_3 = SHX10_2
            SHX5_3 = SHX4_3
            SHX4_3 = SHX4_3.getName
            SHX4_3 = SHX4_3(SHX5_3)
            SHX5_3 = SHX10_2
            SHX6_3 = SHX5_3
            SHX5_3 = SHX5_3.getId
            SHX5_3 = SHX5_3(SHX6_3)
            SHX6_3 = SHX8_2.name
            SHX7_3 = SHX0_2
            SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
            SHX3_3 = "warn"
            SHX4_3 = "event_rules"
            SHX5_3 = {}
            SHX6_3 = SHX0_2
            SHX5_3.event_name = SHX6_3
            SHX6_3 = SHX1_2
            SHX5_3.data = SHX6_3
            SHX6_3 = true
            SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
          end
          SHX11_2(SHX12_2)
        else
          SHX2_2 = false
          SHX11_2 = CreateThread
          function SHX12_2()
            -- [AI CLEANUP] Decompiled Lua - Fix these:
            -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
            -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
            -- 3. Replace goto/label with while/repeat-until where possible
            -- 4. Remove decompiler comments, add meaningful ones
            -- 5. Fix indentation and formatting
            
            local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
            SHX0_3 = SHX10_2
            SHX1_3 = SHX0_3
            SHX0_3 = SHX0_3.newDetection
            SHX2_3 = "event_rule"
            SHX3_3 = {}
            SHX4_3 = SHX0_2
            SHX3_3.event_name = SHX4_3
            SHX4_3 = SHX1_2
            SHX3_3.data = SHX4_3
            SHX4_3 = {}
            SHX5_3 = SHX8_2.name
            SHX6_3 = SHX0_2
            SHX4_3[1] = SHX5_3
            SHX4_3[2] = SHX6_3
            SHX5_3 = SHX8_2.action
            SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3)
          end
          SHX11_2(SHX12_2)
        end
      end
    end
  end
  return SHX2_2
end
SHX2_1(SHX3_1, SHX4_1)
