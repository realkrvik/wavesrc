-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = {}
SHX1_1 = {}
SHX1_1.SERVER_STARTUP = "The server is still starting up! Please try connecting again in a few seconds."
SHX1_1.LEFT_SERVER = "^3%s^7 (^3id:%s^7) has left the server (^3%s^7)."
SHX1_1.VERIFYING_PLAYER = "Verifying player with reaperac.com..."
SHX1_1.CHECKING_PLAYER = [[

Checking if you are a banned player... Reaper AntiCheat is a third-party AntiCheat and is in no way affiliated with FiveM.


This server is protected by Reaper AntiCheat.
https://reaperac.com]]
SHX1_1.BLOCK_CONNECTIONS = [[

Reaper AntiCheat is a third-party AntiCheat and is in no way affiliated with FiveM.


This server has blocked new players from joining. Please try again later!
https://blog.reaperac.com/l/block-connections]]
SHX1_1.DISCORD_REQUIRED = [[

Reaper AntiCheat is a third-party AntiCheat and is in no way affiliated with FiveM.


Discord is Required to join this server! Please connect your Discord and try again.
https://blog.reaperac.com/l/discord-required]]
SHX1_1.STEAM_REQUIRED = [[

Reaper AntiCheat is a third-party AntiCheat and is in no way affiliated with FiveM.


Steam is Required to join this server! Please open Steam and try again.
https://blog.reaperac.com/l/steam-required]]
SHX1_1.CONNECTION_DUPLICATION = [[

Reaper AntiCheat is a third-party AntiCheat and is in no way affiliated with FiveM.


Your Rockstar license is already being used in this server. Please try connecting again in a few seconds!
https://blog.reaperac.com/l/connection-duplication]]
SHX1_1.BANNED_PLAYER = "^3%s^7 (^3license:%s^7) is a banned player and tried to join the server."
SHX1_1.PLAYER_CONNECTING = "^3%s^7 (^3id:%s^7) is now connecting to the server."
SHX1_1.ERROR = "Something went wrong! Please try joining again."
SHX0_1["en-US"] = SHX1_1
SHX1_1 = {}
SHX1_1.SERVER_STARTUP = "Der Server startet noch! Bitte warte noch ein paar Sekunden bis du dich verbinden kannst."
SHX1_1.LEFT_SERVER = "^3%s^7 (^3id:%s^7) hat den Server verlassen. (^3%s^7)."
SHX1_1.VERIFYING_PLAYER = "Verifiziere Spieler mit reaperac.com..."
SHX1_1.CHECKING_PLAYER = "\nChecke ob du gebannt bist... Reaper AntiCheat ist ein third-party AntiCheat und ist nicht affiliated mit FiveM.\n\n\nDieser Server ist vor Cheatern gesch\195\188tzt von Reaper AntiCheat\nhttps://reaperac.com"
SHX1_1.BLOCK_CONNECTIONS = "\nReaper AntiCheat ist ein third-party AntiCheat und ist nicht affiliated mit FiveM.\n\n\nDieser Server verhindert Verbindungen von neuen Spielern. Bitte versuche es sp\195\164ter erneut.\nhttps://blog.reaperac.com/l/block-connections"
SHX1_1.DISCORD_REQUIRED = "\nReaper AntiCheat ist ein third-party AntiCheat und ist nicht affiliated mit FiveM.\n\n\nDu ben\195\182tigst Discord um auf diesem Server Spielen zu k\195\182nnen, bitte verbinde dein Discord und versuche es erneut.\nhttps://blog.reaperac.com/l/discord-required"
SHX1_1.STEAM_REQUIRED = "\nReaper AntiCheat ist ein third-party AntiCheat und ist nicht affiliated mit FiveM.\n\n\nDu ben\195\182tigst Steam um auf diesem Server Spielen zu k\195\182nnen, bitte \195\182ffne Steam und versuche es erneut.\nhttps://blog.reaperac.com/l/steam-required"
SHX1_1.CONNECTION_DUPLICATION = [[

Reaper AntiCheat ist ein third-party AntiCheat und ist nicht affiliated mit FiveM.


Deine Rockstar Lizenz ist bereits auf dem Server. Bitte versuche es in ein paar Sekunden erneut.
https://blog.reaperac.com/l/connection-duplication]]
SHX1_1.BANNED_PLAYER = "^3%s^7 (^3license:%s^7) ist gebannt und versucht sich zu verbinden."
SHX1_1.PLAYER_CONNECTING = "^3%s^7 (^3id:%s^7) hat sich zum Server verbunden"
SHX1_1.ERROR = "Etwas ist schief gelaufen! Bitte versuche es erneut."
SHX0_1["de-DE"] = SHX1_1
SHX1_1 = {}
SHX1_1.SERVER_STARTUP = "\215\148\215\169\215\168\215\170 \215\162\215\147\215\153\215\153\215\159 \215\158\215\170\215\151\215\153\215\156! \215\145\215\145\215\167\215\169\215\148 \215\170\215\160\215\161\215\148 \215\156\215\148\215\170\215\151\215\145\215\168 \215\169\215\149\215\145 \215\145\215\162\215\149\215\147 \215\155\215\158\215\148 \215\169\215\160\215\153\215\149\215\170."
SHX1_1.LEFT_SERVER = "^3%s^7 (^3id:%s^7) \215\153\215\166\215\144 \215\158\215\148\215\169\215\168\215\170 (^3%s^7)."
SHX1_1.VERIFYING_PLAYER = "\215\158\215\144\215\158\215\170 \215\144\215\170 \215\148\215\169\215\151\215\167\215\159 \215\162\215\157 reaperac.com..."
SHX1_1.CHECKING_PLAYER = "\nC\215\148\215\158\215\162\215\168\215\155\215\170 \215\145\215\149\215\147\215\167\215\170 \215\162\215\157 \215\144\215\170\215\148 \215\145\215\145\215\144\215\159... Reaper AntiCheat \215\148\215\149\215\144 \215\144\215\160\215\152\215\153-\215\166'\215\153\215\152 \215\166\215\147 \215\169\215\156\215\153\215\169\215\153 \215\149\215\144\215\153\215\159 \215\156\215\149 \215\169\215\149\215\157 \215\167\215\169\215\168 \215\156-FiveM \215\148\215\169\215\168\215\170 \215\148\215\150\215\148 \215\158\215\149\215\146\215\159 \215\162\215\156 \215\153\215\147\215\153 Reaper AntiCheat.\nhttps://reaperac.com"
SHX1_1.BLOCK_CONNECTIONS = "\nReaper AntiCheat \215\148\215\149\215\144 \215\144\215\160\215\152\215\153-\215\166'\215\153\215\152 \215\169\215\156 \215\166\215\147 \215\169\215\156\215\153\215\169\215\153 \215\149\215\144\215\153\215\159 \215\156\215\149 \215\169\215\149\215\157 \215\167\215\169\215\168 \215\156-FiveM.\n\n\nThis server has blocked new players from joining. Please try again later!\nhttps://blog.reaperac.com/l/block-connections"
SHX1_1.DISCORD_REQUIRED = "\nReaper AntiCheat \215\148\215\149\215\144 \215\144\215\160\215\152\215\153-\215\166'\215\153\215\152 \215\169\215\156 \215\166\215\147 \215\169\215\156\215\153\215\169\215\153 \215\149\215\144\215\153\215\159 \215\156\215\149 \215\169\215\149\215\157 \215\167\215\169\215\168 \215\156-FiveM.\n\n\n\215\147\215\153\215\161\215\167\215\149\215\168\215\147 \215\147\215\168\215\149\215\169 \215\156\215\148\215\155\215\160\215\161 \215\156\215\169\215\168\215\170 \215\150\215\148! Please connect your Discord and try again.\nhttps://blog.reaperac.com/l/discord-required"
SHX1_1.STEAM_REQUIRED = "\nReaper AntiCheat \215\148\215\149\215\144 \215\144\215\160\215\152\215\153-\215\166'\215\153\215\152 \215\169\215\156 \215\166\215\147 \215\169\215\156\215\153\215\169\215\153 \215\149\215\144\215\153\215\159 \215\156\215\149 \215\169\215\149\215\157 \215\167\215\169\215\168 \215\156-FiveM.\n\n\n\215\161\215\152\215\153\215\157 \215\147\215\168\215\149\215\169 \215\156\215\148\215\155\215\160\215\161 \215\156\215\169\215\168\215\170 \215\150\215\148 \215\145\215\145\215\167\215\169\215\148 \215\170\215\164\215\170\215\151 \215\144\215\170 \215\148\215\161\215\152\215\153\215\157 \215\149\215\170\215\160\215\161\215\148 \215\169\215\149\215\145.\nhttps://blog.reaperac.com/l/steam-required"
SHX1_1.CONNECTION_DUPLICATION = "\nReaper AntiCheat \215\148\215\149\215\144 \215\144\215\160\215\152\215\153-\215\166'\215\153\215\152 \215\169\215\156 \215\166\215\147 \215\169\215\156\215\153\215\169\215\153 \215\149\215\144\215\153\215\159 \215\156\215\149 \215\169\215\149\215\157 \215\167\215\169\215\168 \215\156-FiveM.\n\n\n\215\148\215\168\215\153\215\169\215\153\215\149\215\159 \215\168\215\149\215\167\215\161\215\152\215\144\215\168 \215\169\215\156\215\154 \215\155\215\145\215\168 \215\145\215\169\215\153\215\158\215\149\215\169 \215\170\215\160\215\161\215\148 \215\156\215\148\215\155\215\160\215\161 \215\169\215\149\215\145 \215\145\215\162\215\149\215\147 \215\155\215\158\215\148 \215\169\215\160\215\153\215\149\215\170!\nhttps://blog.reaperac.com/l/connection-duplication"
SHX1_1.BANNED_PLAYER = "^3%s^7 (^3license:%s^7) \215\145\215\145\215\144\215\159 \215\149\215\160\215\153\215\161\215\148 \215\156\215\148\215\155\215\160\215\161 \215\156\215\169\215\168\215\170."
SHX1_1.PLAYER_CONNECTING = "^3%s^7 (^3id:%s^7) \215\158\215\170\215\151\215\145\215\168 \215\156\215\169\215\168\215\170."
SHX1_1.ERROR = "\215\158\215\169\215\148\215\149 \215\148\215\153\215\148 \215\169\215\146\215\149\215\153! \215\145\215\145\215\167\215\169\215\148 \215\170\215\160\215\161\215\148 \215\169\215\149\215\145."
SHX0_1["he-IL"] = SHX1_1
SHX1_1 = GetConvar
SHX2_1 = "locale"
SHX3_1 = "en-US"
SHX1_1 = SHX1_1(SHX2_1, SHX3_1)
SHX2_1 = SHX0_1[SHX1_1]
if not SHX2_1 then
  SHX2_1 = SHX0_1["en-US"]
end
SHX3_1 = SHX2_1.SERVER_STARTUP
SHX4_1 = false
SHX5_1 = false
SHX6_1 = false
SHX7_1 = false
SHX8_1 = false
SHX9_1 = false
SHX10_1 = {}
SHX11_1 = {}
SHX12_1 = {}
SHX13_1 = {}
SHX14_1 = RPC
SHX15_1 = SHX14_1
SHX14_1 = SHX14_1.on
SHX16_1 = "configUpdated"
function SHX17_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2
  SHX0_2 = Settings
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX0_2 = SHX0_2(SHX1_2)
  SHX1_2 = GetConvar
  SHX2_2 = "locale"
  SHX3_2 = "en-US"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX2_2 = SHX0_1
  SHX1_2 = SHX2_2[SHX1_2]
  if not SHX1_2 then
    SHX1_2 = SHX0_1["en-US"]
  end
  SHX2_1 = SHX1_2
  SHX1_2 = SHX0_2.blockConnections
  SHX4_1 = SHX1_2
  SHX1_2 = SHX0_2.generalRules
  SHX1_2 = SHX1_2.requireSteam
  SHX7_1 = SHX1_2
  SHX1_2 = SHX0_2.generalRules
  SHX1_2 = SHX1_2.requireDiscord
  SHX6_1 = SHX1_2
  SHX1_2 = SHX0_2.alerts
  SHX1_2 = SHX1_2.logConnections
  SHX8_1 = SHX1_2
  SHX1_2 = SHX0_2.alerts
  SHX1_2 = SHX1_2.logDisconnections
  SHX9_1 = SHX1_2
  SHX1_2 = SHX0_2.generalRules
  SHX1_2 = SHX1_2.antiConnectionDuplication
  SHX5_1 = SHX1_2
end
SHX14_1(SHX15_1, SHX16_1, SHX17_1)
SHX14_1 = RPC
SHX15_1 = SHX14_1
SHX14_1 = SHX14_1.on
SHX16_1 = "blockPlayers"
function SHX17_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX3_1 = SHX0_2
end
SHX14_1(SHX15_1, SHX16_1, SHX17_1)
SHX14_1 = RPC
SHX15_1 = SHX14_1
SHX14_1 = SHX14_1.onLocal
SHX16_1 = "playerDropped"
function SHX17_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX1_2 = source
  SHX2_2 = GetPlayerIdentifierByType
  SHX3_2 = SHX1_2
  SHX4_2 = "license"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.gsub
  SHX4_2 = "license:"
  SHX5_2 = ""
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.NewLog
  SHX5_2 = SHX2_1.LEFT_SERVER
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = GetPlayerName
  SHX8_2 = SHX1_2
  SHX7_2 = SHX7_2(SHX8_2)
  SHX8_2 = SHX1_2
  SHX9_2 = SHX0_2
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  SHX6_2 = "info"
  SHX7_2 = "player_drops"
  SHX8_2 = {}
  SHX8_2.identifier = SHX2_2
  SHX9_2 = SHX9_1
  SHX9_2 = not SHX9_2
  SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  SHX3_2 = table
  SHX3_2 = SHX3_2.insert
  SHX4_2 = SHX13_1
  SHX5_2 = {}
  SHX5_2.license = SHX2_2
  SHX5_2.reason = SHX0_2
  SHX3_2(SHX4_2, SHX5_2)
end
SHX14_1(SHX15_1, SHX16_1, SHX17_1)
SHX14_1 = RPC
SHX15_1 = SHX14_1
SHX14_1 = SHX14_1.onLocal
SHX16_1 = "playerConnecting"
function SHX17_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2
  SHX3_2 = source
  SHX4_2 = SHX2_2.defer
  SHX5_2 = SHX2_1.VERIFYING_PLAYER
  SHX4_2(SHX5_2)
  SHX4_2 = Wait
  SHX5_2 = 0
  SHX4_2(SHX5_2)
  SHX4_2 = SHX2_2.update
  SHX5_2 = SHX2_1.CHECKING_PLAYER
  SHX4_2(SHX5_2)
  SHX4_2 = SHX3_1
  if SHX4_2 then
    SHX4_2 = SHX2_2.update
    SHX5_2 = SHX3_1
    SHX4_2(SHX5_2)
    SHX4_2 = SHX2_2.done
    SHX5_2 = SHX3_1
    SHX4_2(SHX5_2)
    return
  end
  SHX4_2 = GetPlayerIdentifierByType
  SHX5_2 = SHX3_2
  SHX6_2 = "license"
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = GetPlayerIdentifierByType
  SHX6_2 = SHX3_2
  SHX7_2 = "license2"
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX6_2 = GetPlayerIdentifierByType
  SHX7_2 = SHX3_2
  SHX8_2 = "discord"
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = GetPlayerIdentifierByType
  SHX8_2 = SHX3_2
  SHX9_2 = "fivem"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX8_2 = GetPlayerIdentifierByType
  SHX9_2 = SHX3_2
  SHX10_2 = "steam"
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  SHX9_2 = GetPlayerIdentifierByType
  SHX10_2 = SHX3_2
  SHX11_2 = "ip"
  SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
  SHX10_2 = GetPlayerIdentifierByType
  SHX11_2 = SHX3_2
  SHX12_2 = "xbox"
  SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
  if SHX4_2 then
    SHX12_2 = SHX4_2
    SHX11_2 = SHX4_2.gsub
    SHX13_2 = "license:"
    SHX14_2 = ""
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2)
    SHX4_2 = SHX11_2
  end
  if SHX5_2 then
    SHX12_2 = SHX5_2
    SHX11_2 = SHX5_2.gsub
    SHX13_2 = "license2:"
    SHX14_2 = ""
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2)
    SHX5_2 = SHX11_2
  end
  if SHX6_2 then
    SHX12_2 = SHX6_2
    SHX11_2 = SHX6_2.gsub
    SHX13_2 = "discord:"
    SHX14_2 = ""
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2)
    SHX6_2 = SHX11_2
  end
  if SHX7_2 then
    SHX12_2 = SHX7_2
    SHX11_2 = SHX7_2.gsub
    SHX13_2 = "fivem:"
    SHX14_2 = ""
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2)
    SHX7_2 = SHX11_2
  end
  if SHX8_2 then
    SHX12_2 = SHX8_2
    SHX11_2 = SHX8_2.gsub
    SHX13_2 = "steam:"
    SHX14_2 = ""
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2)
    SHX8_2 = SHX11_2
  end
  if SHX9_2 then
    SHX12_2 = SHX9_2
    SHX11_2 = SHX9_2.gsub
    SHX13_2 = "ip:"
    SHX14_2 = ""
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2)
    SHX9_2 = SHX11_2
  end
  if SHX10_2 then
    SHX12_2 = SHX10_2
    SHX11_2 = SHX10_2.gsub
    SHX13_2 = "xbox:"
    SHX14_2 = ""
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2)
    SHX10_2 = SHX11_2
  end
  SHX11_2 = SHX4_1
  if SHX11_2 then
    SHX11_2 = SHX2_2.done
    SHX12_2 = SHX2_1.BLOCK_CONNECTIONS
    return SHX11_2(SHX12_2)
  end
  SHX11_2 = SHX6_1
  if SHX11_2 and nil == SHX6_2 then
    SHX11_2 = SHX2_2.done
    SHX12_2 = SHX2_1.DISCORD_REQUIRED
    return SHX11_2(SHX12_2)
  end
  SHX11_2 = SHX7_1
  if SHX11_2 and nil == SHX8_2 then
    SHX11_2 = SHX2_2.done
    SHX12_2 = SHX2_1.STEAM_REQUIRED
    return SHX11_2(SHX12_2)
  end
  SHX11_2 = SHX5_1
  if SHX11_2 then
    SHX11_2 = SHX11_1
    SHX11_2 = SHX11_2[SHX4_2]
    if SHX11_2 then
      SHX11_2 = SHX2_2.done
      SHX12_2 = SHX2_1.CONNECTION_DUPLICATION
      return SHX11_2(SHX12_2)
    end
  end
  SHX11_2 = Cache
  SHX12_2 = SHX11_2
  SHX11_2 = SHX11_2.get
  SHX13_2 = "awaiting_detection_upload:"
  SHX14_2 = SHX4_2
  SHX13_2 = SHX13_2 .. SHX14_2
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
  if SHX11_2 then
    SHX11_2 = SHX2_2.done
    SHX12_2 = "License already being used, please try connecting again in a few seconds."
    return SHX11_2(SHX12_2)
  end
  SHX11_2 = table
  SHX11_2 = SHX11_2.insert
  SHX12_2 = SHX12_1
  SHX13_2 = {}
  SHX13_2.deferrals = SHX2_2
  SHX13_2.license = SHX4_2
  SHX13_2.license2 = SHX5_2
  SHX13_2.discord = SHX6_2
  SHX13_2.steam = SHX8_2
  SHX13_2.fivem = SHX7_2
  SHX13_2.xbox = SHX10_2
  SHX13_2.ip = SHX9_2
  SHX13_2.name = SHX0_2
  SHX14_2 = GetPlayerGuid
  SHX15_2 = SHX3_2
  SHX14_2 = SHX14_2(SHX15_2)
  SHX13_2.guid = SHX14_2
  SHX11_2(SHX12_2, SHX13_2)
  SHX11_2 = Cache
  SHX12_2 = SHX11_2
  SHX11_2 = SHX11_2.get
  SHX13_2 = "statistics"
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
  SHX12_2 = SHX11_2.connections
  SHX12_2 = SHX12_2 + 1
  SHX11_2.connections = SHX12_2
  SHX12_2 = Cache
  SHX13_2 = SHX12_2
  SHX12_2 = SHX12_2.set
  SHX14_2 = "statistics"
  SHX15_2 = SHX11_2
  SHX12_2(SHX13_2, SHX14_2, SHX15_2)
  SHX12_2 = Logger
  SHX13_2 = SHX12_2
  SHX12_2 = SHX12_2.log
  SHX14_2 = "%s (license:%s) was added to the join queue"
  SHX15_2 = SHX14_2
  SHX14_2 = SHX14_2.format
  SHX16_2 = SHX0_2
  SHX17_2 = SHX4_2
  SHX14_2 = SHX14_2(SHX15_2, SHX16_2, SHX17_2)
  SHX15_2 = "debug"
  SHX12_2(SHX13_2, SHX14_2, SHX15_2)
end
SHX14_1(SHX15_1, SHX16_1, SHX17_1)
SHX14_1 = CreateThread
function SHX15_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  while true do
    SHX0_2 = Wait
    SHX1_2 = 5000
    SHX0_2(SHX1_2)
    SHX0_2 = SHX12_1
    SHX0_2 = #SHX0_2
    if 0 == SHX0_2 then
      SHX0_2 = SHX13_1
      SHX0_2 = #SHX0_2
      if 0 == SHX0_2 then
        goto SHX_LABEL_15
      end
    end
    SHX0_2 = CreateThread
    function SHX1_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3
      SHX0_3 = {}
      SHX1_3 = SHX12_1
      SHX2_3 = SHX13_1
      SHX3_3 = {}
      SHX12_1 = SHX3_3
      SHX3_3 = {}
      SHX13_1 = SHX3_3
      SHX3_3 = HTTP
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.await
      SHX5_3 = "https://api.reaperac.com/api/v1/servers/players/check"
      SHX6_3 = "POST"
      SHX7_3 = json
      SHX7_3 = SHX7_3.encode
      SHX8_3 = {}
      SHX9_3 = table
      SHX9_3 = SHX9_3.map
      SHX10_3 = SHX1_3
      function SHX11_3(SHX0_4)
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX1_4, SHX2_4, SHX3_4
        SHX2_4 = SHX0_4.license
        SHX1_4 = SHX0_3
        SHX3_4 = SHX0_4.deferrals
        SHX1_4[SHX2_4] = SHX3_4
        SHX1_4 = {}
        SHX2_4 = SHX0_4.license
        SHX1_4.license = SHX2_4
        SHX2_4 = SHX0_4.license2
        SHX1_4.license2 = SHX2_4
        SHX2_4 = SHX0_4.discord
        SHX1_4.discord = SHX2_4
        SHX2_4 = SHX0_4.steam
        SHX1_4.steam = SHX2_4
        SHX2_4 = SHX0_4.fivem
        SHX1_4.fivem = SHX2_4
        SHX2_4 = SHX0_4.name
        SHX1_4.name = SHX2_4
        SHX2_4 = SHX0_4.xbox
        SHX1_4.xbox = SHX2_4
        SHX2_4 = SHX0_4.ip
        SHX1_4.ip = SHX2_4
        return SHX1_4
      end
      SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
      SHX8_3.queue = SHX9_3
      SHX8_3.dropQueue = SHX2_3
      SHX9_3 = Cache
      SHX10_3 = SHX9_3
      SHX9_3 = SHX9_3.get
      SHX11_3 = "secret"
      SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
      SHX8_3.secret = SHX9_3
      SHX9_3 = Cache
      SHX10_3 = SHX9_3
      SHX9_3 = SHX9_3.get
      SHX11_3 = "serverId"
      SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
      SHX8_3.serverId = SHX9_3
      SHX7_3 = SHX7_3(SHX8_3)
      SHX8_3 = {}
      SHX8_3["Content-Type"] = "application/json"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX4_3 = json
      SHX4_3 = SHX4_3.decode
      SHX5_3 = SHX3_3.body
      if not SHX5_3 then
        SHX5_3 = "{ 'error': true }"
      end
      SHX4_3 = SHX4_3(SHX5_3)
      SHX5_3 = SHX3_3.status
      if 200 == SHX5_3 then
        SHX5_3 = SHX4_3.error
        if not SHX5_3 then
          goto SHX_LABEL_98
        end
      end
      SHX5_3 = pairs
      SHX6_3 = SHX1_3
      SHX5_3, SHX6_3, SHX7_3, SHX8_3 = SHX5_3(SHX6_3)
      for SHX9_3, SHX10_3 in SHX5_3, SHX6_3, SHX7_3, SHX8_3 do
        SHX11_3 = Logger
        SHX12_3 = SHX11_3
        SHX11_3 = SHX11_3.log
        SHX13_3 = "^3%s^7 (^3license:%s^7) was unable to be verified by ^3reaperac.com^7. The server responded with error code ^3%s"
        SHX14_3 = SHX13_3
        SHX13_3 = SHX13_3.format
        SHX15_3 = SHX10_3.name
        SHX16_3 = SHX10_3.license
        SHX17_3 = SHX3_3.status
        SHX13_3 = SHX13_3(SHX14_3, SHX15_3, SHX16_3, SHX17_3)
        SHX14_3 = "error"
        SHX11_3(SHX12_3, SHX13_3, SHX14_3)
        SHX11_3 = SHX10_3.deferrals
        SHX11_3 = SHX11_3.done
        SHX11_3()
        SHX12_3 = SHX10_3.license
        SHX11_3 = SHX10_1
        SHX13_3 = {}
        SHX13_3.joinTime = 0
        SHX14_3 = {}
        SHX13_3.flags = SHX14_3
        SHX13_3.firstSeen = 0
        SHX14_3 = {}
        SHX13_3.warnings = SHX14_3
        SHX14_3 = {}
        SHX13_3.kicks = SHX14_3
        SHX14_3 = {}
        SHX13_3.bans = SHX14_3
        SHX14_3 = SHX10_3.name
        SHX13_3.name = SHX14_3
        SHX14_3 = SHX10_3.license
        SHX13_3.license = SHX14_3
        SHX11_3[SHX12_3] = SHX13_3
      end
      return
      -- [FIX IF ERROR] Move ::SHX_LABEL_98:: outside nested blocks until all 'goto SHX_LABEL_98' can see it
      ::SHX_LABEL_98::
      SHX5_3 = pairs
      SHX6_3 = SHX4_3.response
      SHX5_3, SHX6_3, SHX7_3, SHX8_3 = SHX5_3(SHX6_3)
      for SHX9_3, SHX10_3 in SHX5_3, SHX6_3, SHX7_3, SHX8_3 do
        SHX11_3 = SHX10_3.reject
        if SHX11_3 then
          SHX11_3 = SHX10_3.license
          SHX11_3 = SHX0_3[SHX11_3]
          SHX11_3 = SHX11_3.done
          SHX12_3 = SHX10_3.reject
          SHX11_3(SHX12_3)
          SHX11_3 = Logger
          SHX12_3 = SHX11_3
          SHX11_3 = SHX11_3.NewLog
          SHX13_3 = SHX2_1.BANNED_PLAYER
          SHX14_3 = SHX13_3
          SHX13_3 = SHX13_3.format
          SHX15_3 = SHX10_3.name
          SHX16_3 = SHX10_3.license
          SHX13_3 = SHX13_3(SHX14_3, SHX15_3, SHX16_3)
          SHX14_3 = "info"
          SHX15_3 = "player_connects"
          SHX16_3 = {}
          SHX17_3 = SHX10_3.license
          SHX16_3.identifier = SHX17_3
          SHX11_3(SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
        else
          SHX11_3 = SHX10_3.license
          SHX11_3 = SHX0_3[SHX11_3]
          SHX11_3 = SHX11_3.done
          SHX11_3()
          SHX12_3 = SHX10_3.license
          SHX11_3 = SHX10_1
          SHX11_3[SHX12_3] = SHX10_3
        end
      end
    end
    SHX0_2(SHX1_2)
    -- [FIX IF ERROR] Move ::SHX_LABEL_15:: outside nested blocks until all 'goto SHX_LABEL_15' can see it
    ::SHX_LABEL_15::
  end
end
SHX14_1(SHX15_1)
SHX14_1 = RPC
SHX15_1 = SHX14_1
SHX14_1 = SHX14_1.onLocal
SHX16_1 = "Reaper:PlayerDropped"
function SHX17_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2
  if SHX1_2 then
    SHX2_2 = SHX11_1
    SHX2_2[SHX1_2] = nil
  end
end
SHX14_1(SHX15_1, SHX16_1, SHX17_1)
SHX14_1 = RPC
SHX15_1 = SHX14_1
SHX14_1 = SHX14_1.onLocal
SHX16_1 = "playerJoining"
function SHX17_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX0_2 = source
  SHX1_2 = Player
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if nil == SHX1_2 then
    return
  end
  SHX3_2 = SHX1_2
  SHX2_2 = SHX1_2.getIdentifier
  SHX4_2 = "license"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX3_2 = SHX10_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 then
    return
  end
  SHX4_2 = SHX11_1
  SHX4_2 = SHX4_2[SHX2_2]
  if SHX4_2 then
    SHX4_2 = SHX5_1
    if SHX4_2 then
      SHX4_2 = DropPlayer
      SHX5_2 = SHX0_2
      SHX6_2 = SHX2_1.CONNECTION_DUPLICATION
      SHX4_2(SHX5_2, SHX6_2)
  end
  else
    SHX4_2 = SHX11_1
    SHX4_2[SHX2_2] = true
  end
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.NewLog
  SHX6_2 = SHX2_1.PLAYER_CONNECTING
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX9_2 = SHX1_2
  SHX8_2 = SHX1_2.getName
  SHX8_2 = SHX8_2(SHX9_2)
  SHX10_2 = SHX1_2
  SHX9_2 = SHX1_2.getId
  SHX9_2, SHX10_2 = SHX9_2(SHX10_2)
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  SHX7_2 = "info"
  SHX8_2 = "player_connects"
  SHX9_2 = {}
  SHX10_2 = SHX8_1
  SHX10_2 = not SHX10_2
  SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.setMeta
  SHX6_2 = "joinTime"
  SHX7_2 = SHX3_2.joinTime
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.setMeta
  SHX6_2 = "flags"
  SHX7_2 = SHX3_2.flags
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.setMeta
  SHX6_2 = "firstSeen"
  SHX7_2 = SHX3_2.firstSeen
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.setMeta
  SHX6_2 = "warnings"
  SHX7_2 = SHX3_2.warnings
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.setMeta
  SHX6_2 = "kicks"
  SHX7_2 = SHX3_2.kicks
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.setMeta
  SHX6_2 = "bans"
  SHX7_2 = SHX3_2.bans
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.setMeta
  SHX6_2 = "RAGDOLL_REQUEST_EVENT"
  SHX7_2 = 0
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.setMeta
  SHX6_2 = "REQUEST_CONTROL_EVENT"
  SHX7_2 = 0
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.setMeta
  SHX6_2 = "REQUEST_PHONE_EXPLOSION_EVENT"
  SHX7_2 = 0
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.setMeta
  SHX6_2 = "NETWORK_PLAY_SOUND_EVENT"
  SHX7_2 = 0
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.hasPerm
  SHX6_2 = "Update Config"
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  if SHX4_2 then
    SHX5_2 = RPC
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.emitLocal
    SHX7_2 = "ProAddon:AddWhitelister"
    SHX8_2 = SHX0_2
    SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  end
  SHX5_2 = EmitPipe
  SHX6_2 = "Reaper:playerJoined"
  SHX7_2 = SHX1_2
  SHX5_2(SHX6_2, SHX7_2)
end
SHX14_1(SHX15_1, SHX16_1, SHX17_1)
SHX14_1 = RPC
SHX15_1 = SHX14_1
SHX14_1 = SHX14_1.register
SHX16_1 = "FetchData"
function SHX17_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX1_2 = Player
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if nil == SHX1_2 then
    SHX2_2 = "RESPONSE_FAILED"
    return SHX2_2
  end
  SHX3_2 = SHX1_2
  SHX2_2 = SHX1_2.getIdentifier
  SHX4_2 = "license"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX4_2 = SHX1_2
  SHX3_2 = SHX1_2.getIdentifier
  SHX5_2 = "steam"
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.getIdentifier
  SHX6_2 = "fivem"
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX6_2 = SHX1_2
  SHX5_2 = SHX1_2.getIdentifier
  SHX7_2 = "discord"
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX7_2 = SHX1_2
  SHX6_2 = SHX1_2.getIdentifier
  SHX8_2 = "ip"
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  if SHX2_2 then
    SHX7_2 = "license:"
    SHX8_2 = SHX2_2
    SHX7_2 = SHX7_2 .. SHX8_2
    SHX2_2 = SHX7_2
  end
  if SHX3_2 then
    SHX7_2 = "steam:"
    SHX8_2 = SHX3_2
    SHX7_2 = SHX7_2 .. SHX8_2
    SHX3_2 = SHX7_2
  end
  if SHX4_2 then
    SHX7_2 = "fivem:"
    SHX8_2 = SHX4_2
    SHX7_2 = SHX7_2 .. SHX8_2
    SHX4_2 = SHX7_2
  end
  if SHX5_2 then
    SHX7_2 = "discord:"
    SHX8_2 = SHX5_2
    SHX7_2 = SHX7_2 .. SHX8_2
    SHX5_2 = SHX7_2
  end
  if SHX6_2 then
    SHX7_2 = "ip:"
    SHX8_2 = SHX6_2
    SHX7_2 = SHX7_2 .. SHX8_2
    SHX6_2 = SHX7_2
  end
  SHX7_2 = json
  SHX7_2 = SHX7_2.encode
  SHX8_2 = {}
  SHX10_2 = SHX1_2
  SHX9_2 = SHX1_2.getGuid
  SHX9_2 = SHX9_2(SHX10_2)
  SHX8_2.guid = SHX9_2
  SHX9_2 = Cache
  SHX10_2 = SHX9_2
  SHX9_2 = SHX9_2.get
  SHX11_2 = "serverId"
  SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
  SHX8_2.serverId = SHX9_2
  SHX8_2.license = SHX2_2
  SHX8_2.steam = SHX3_2
  SHX8_2.fivem = SHX4_2
  SHX8_2.discord = SHX5_2
  SHX8_2.ip = SHX6_2
  SHX7_2 = SHX7_2(SHX8_2)
  SHX8_2 = {}
  SHX8_2.data = SHX7_2
  SHX9_2 = Security
  SHX10_2 = SHX9_2
  SHX9_2 = SHX9_2.hash
  SHX11_2 = SHX7_2
  SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
  SHX8_2.key = SHX9_2
  return SHX8_2
end
SHX14_1(SHX15_1, SHX16_1, SHX17_1)
