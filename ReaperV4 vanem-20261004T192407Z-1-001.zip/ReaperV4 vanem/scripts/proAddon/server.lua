-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = Logger
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.log
SHX2_1 = "scripts/proAddon/server.lua loaded"
SHX3_1 = "debug"
SHX0_1(SHX1_1, SHX2_1, SHX3_1)
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = json
SHX0_1 = SHX0_1.decode
SHX1_1 = LoadResourceFile
SHX2_1 = "ReaperV4"
SHX3_1 = "cache/unknownExecutionList.json"
SHX1_1 = SHX1_1(SHX2_1, SHX3_1)
if not SHX1_1 then
  SHX1_1 = "{}"
end
SHX0_1 = SHX0_1(SHX1_1)
SHX1_1 = json
SHX1_1 = SHX1_1.decode
SHX2_1 = LoadResourceFile
SHX3_1 = "ReaperV4"
SHX4_1 = "cache/executionlist.json"
SHX2_1 = SHX2_1(SHX3_1, SHX4_1)
if not SHX2_1 then
  SHX2_1 = "{}"
end
SHX1_1 = SHX1_1(SHX2_1)
ExecutionList = SHX1_1
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  if "true" == SHX0_2 then
    SHX1_2 = true
    return SHX1_2
  elseif "false" == SHX0_2 then
    SHX1_2 = false
    return SHX1_2
  else
    SHX1_2 = nil
    return SHX1_2
  end
end
SHX2_1 = Command
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.add
SHX4_1 = {}
SHX4_1.command = "execution"
function SHX5_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2
  SHX2_2 = SHX1_2[2]
  SHX3_2 = GetConvar
  SHX4_2 = "reaper_pro_addon_enabled"
  SHX5_2 = "false"
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  if "false" == SHX3_2 and "autowhitelist" ~= SHX2_2 then
    SHX3_2 = Logger
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.log
    SHX5_2 = "This command is only available for servers that have the Reaper Pro Addon"
    SHX6_2 = "error"
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  end
  if "add" == SHX2_2 then
    SHX3_2 = SHX1_2[3]
    SHX4_2 = SHX0_1
    SHX4_2 = SHX4_2[SHX3_2]
    if nil == SHX4_2 then
      SHX4_2 = Logger
      SHX5_2 = SHX4_2
      SHX4_2 = SHX4_2.log
      SHX6_2 = "You have provided an invalid execution ID!"
      SHX7_2 = "error"
      return SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    end
    SHX4_2 = SHX0_1
    SHX4_2 = SHX4_2[SHX3_2]
    SHX5_2 = SHX0_1
    SHX5_2[SHX3_2] = nil
    SHX5_2 = json
    SHX5_2 = SHX5_2.encode
    SHX6_2 = SHX0_1
    SHX5_2 = SHX5_2(SHX6_2)
    SHX6_2 = SaveResourceFile
    SHX7_2 = "ReaperV4"
    SHX8_2 = "cache/unknownExecutionList.json"
    SHX9_2 = SHX5_2
    SHX10_2 = #SHX5_2
    SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
    SHX6_2 = SHX4_2.type
    if "event" == SHX6_2 then
      SHX6_2 = json
      SHX6_2 = SHX6_2.decode
      SHX7_2 = LoadResourceFile
      SHX8_2 = "ReaperV4"
      SHX9_2 = "cache/events-"
      SHX10_2 = SHX4_2.resource
      SHX11_2 = ".json"
      SHX9_2 = SHX9_2 .. SHX10_2 .. SHX11_2
      SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
      if not SHX7_2 then
        SHX7_2 = "{}"
      end
      SHX6_2 = SHX6_2(SHX7_2)
      SHX7_2 = SHX4_2.key
      SHX6_2[SHX7_2] = SHX4_2
      SHX7_2 = json
      SHX7_2 = SHX7_2.encode
      SHX8_2 = SHX6_2
      SHX7_2 = SHX7_2(SHX8_2)
      SHX8_2 = SaveResourceFile
      SHX9_2 = "ReaperV4"
      SHX10_2 = "cache/events-"
      SHX11_2 = SHX4_2.resource
      SHX12_2 = ".json"
      SHX10_2 = SHX10_2 .. SHX11_2 .. SHX12_2
      SHX11_2 = SHX7_2
      SHX12_2 = #SHX7_2
      SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2)
      SHX8_2 = RPC
      SHX9_2 = SHX8_2
      SHX8_2 = SHX8_2.emitLocal
      SHX10_2 = "Reaper:ProAddonRefreshWhitelist"
      SHX11_2 = SHX4_2.resource
      SHX8_2(SHX9_2, SHX10_2, SHX11_2)
      SHX8_2 = Logger
      SHX9_2 = SHX8_2
      SHX8_2 = SHX8_2.log
      SHX10_2 = "^3%s ^7(^3%s^7) sent from ^3%s^7 was whitelisted."
      SHX11_2 = SHX10_2
      SHX10_2 = SHX10_2.format
      SHX12_2 = SHX4_2.param
      SHX13_2 = SHX4_2.key
      SHX14_2 = SHX4_2.path
      SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2)
      SHX11_2 = "info"
      SHX8_2(SHX9_2, SHX10_2, SHX11_2)
    else
      SHX6_2 = SHX4_2.type
      if "entity" == SHX6_2 then
        SHX6_2 = json
        SHX6_2 = SHX6_2.decode
        SHX7_2 = LoadResourceFile
        SHX8_2 = "ReaperV4"
        SHX9_2 = "cache/entities.json"
        SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
        if not SHX7_2 then
          SHX7_2 = "{}"
        end
        SHX6_2 = SHX6_2(SHX7_2)
        SHX7_2 = SHX4_2.key
        SHX6_2[SHX7_2] = SHX4_2
        SHX7_2 = json
        SHX7_2 = SHX7_2.encode
        SHX8_2 = SHX6_2
        SHX7_2 = SHX7_2(SHX8_2)
        SHX8_2 = SaveResourceFile
        SHX9_2 = "ReaperV4"
        SHX10_2 = "cache/entities.json"
        SHX11_2 = SHX7_2
        SHX12_2 = #SHX7_2
        SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2)
        SHX8_2 = Logger
        SHX9_2 = SHX8_2
        SHX8_2 = SHX8_2.log
        SHX10_2 = "^3%s ^7(^3%s^7) sent from ^3%s^7 was whitelisted."
        SHX11_2 = SHX10_2
        SHX10_2 = SHX10_2.format
        SHX12_2 = SHX4_2.param
        SHX13_2 = SHX4_2.key
        SHX14_2 = SHX4_2.path
        SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2)
        SHX11_2 = "info"
        SHX8_2(SHX9_2, SHX10_2, SHX11_2)
        SHX8_2 = RPC
        SHX9_2 = SHX8_2
        SHX8_2 = SHX8_2.emit
        SHX10_2 = "ProAddon:RefreshEntities"
        SHX8_2(SHX9_2, SHX10_2)
      else
        SHX6_2 = ExecutionCheck
        SHX7_2 = SHX6_2
        SHX6_2 = SHX6_2.add_execution
        SHX8_2 = SHX4_2
        SHX6_2(SHX7_2, SHX8_2)
      end
    end
    return
  end
  if "ignore" == SHX2_2 then
    SHX3_2 = SHX1_2[3]
    SHX4_2 = SHX0_1
    SHX4_2 = SHX4_2[SHX3_2]
    if nil == SHX4_2 then
      SHX4_2 = Logger
      SHX5_2 = SHX4_2
      SHX4_2 = SHX4_2.log
      SHX6_2 = "You have provided an invalid execution ID!"
      SHX7_2 = "error"
      return SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    end
    SHX4_2 = SHX0_1
    SHX4_2 = SHX4_2[SHX3_2]
    SHX5_2 = SHX0_1
    SHX5_2[SHX3_2] = nil
    SHX5_2 = json
    SHX5_2 = SHX5_2.encode
    SHX6_2 = SHX0_1
    SHX5_2 = SHX5_2(SHX6_2)
    SHX6_2 = SaveResourceFile
    SHX7_2 = "ReaperV4"
    SHX8_2 = "cache/unknownExecutionList.json"
    SHX9_2 = SHX5_2
    SHX10_2 = #SHX5_2
    SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
    SHX6_2 = Logger
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.log
    SHX8_2 = "^3%s ^7(^3%s^7) sent from ^3%s^7 was ignored."
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.format
    SHX10_2 = SHX4_2.param
    SHX11_2 = SHX4_2.key
    SHX12_2 = SHX4_2.path
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2)
    SHX9_2 = "info"
    return SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  end
  if "ignoreall" == SHX2_2 then
    SHX3_2 = {}
    SHX0_1 = SHX3_2
    SHX3_2 = json
    SHX3_2 = SHX3_2.encode
    SHX4_2 = SHX0_1
    SHX3_2 = SHX3_2(SHX4_2)
    SHX4_2 = SaveResourceFile
    SHX5_2 = "ReaperV4"
    SHX6_2 = "cache/unknownExecutionList.json"
    SHX7_2 = SHX3_2
    SHX8_2 = #SHX3_2
    SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
    SHX4_2 = Logger
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.log
    SHX6_2 = "Successfully cleared all unknown executions."
    SHX7_2 = "info"
    return SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  end
  if "clearwhitelist" == SHX2_2 then
    SHX3_2 = SHX1_2[3]
    if not SHX3_2 then
      SHX3_2 = "nil"
    end
    SHX4_2 = LoadResourceFile
    SHX5_2 = "ReaperV4"
    SHX6_2 = "cache/events-"
    SHX7_2 = SHX3_2
    SHX8_2 = ".json"
    SHX6_2 = SHX6_2 .. SHX7_2 .. SHX8_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if nil == SHX4_2 then
      SHX5_2 = Logger
      SHX6_2 = SHX5_2
      SHX5_2 = SHX5_2.log
      SHX7_2 = "You have provided an invalid resource name. ^3%s^7 is not a valid resource name"
      SHX8_2 = SHX7_2
      SHX7_2 = SHX7_2.format
      SHX9_2 = SHX3_2
      SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
      SHX8_2 = "error"
      return SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    end
    SHX5_2 = SaveResourceFile
    SHX6_2 = "ReaperV4"
    SHX7_2 = "cache/events-"
    SHX8_2 = SHX3_2
    SHX9_2 = ".json.bk"
    SHX7_2 = SHX7_2 .. SHX8_2 .. SHX9_2
    SHX8_2 = SHX4_2
    SHX9_2 = #SHX4_2
    SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2)
    SHX5_2 = json
    SHX5_2 = SHX5_2.encode
    SHX6_2 = {}
    SHX6_2.resource_name = SHX3_2
    SHX5_2 = SHX5_2(SHX6_2)
    SHX6_2 = SaveResourceFile
    SHX7_2 = "ReaperV4"
    SHX8_2 = "cache/events-"
    SHX9_2 = SHX3_2
    SHX10_2 = ".json"
    SHX8_2 = SHX8_2 .. SHX9_2 .. SHX10_2
    SHX9_2 = SHX5_2
    SHX10_2 = #SHX5_2
    SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
    SHX6_2 = RPC
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.emitLocal
    SHX8_2 = "Reaper:ProAddonRefreshWhitelist"
    SHX9_2 = SHX3_2
    SHX6_2(SHX7_2, SHX8_2, SHX9_2)
    SHX6_2 = Logger
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.log
    SHX8_2 = "Successfully cleared all whitelisted events for the resource ^3%s"
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.format
    SHX10_2 = SHX3_2
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
    SHX9_2 = "info"
    return SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  end
  if "remove" == SHX2_2 then
    SHX3_2 = SHX1_2[3]
    SHX4_2 = SHX1_2[4]
    SHX5_2 = SHX1_2[5]
    if "entity" == SHX3_2 then
      SHX6_2 = json
      SHX6_2 = SHX6_2.decode
      SHX7_2 = LoadResourceFile
      SHX8_2 = "ReaperV4"
      SHX9_2 = "cache/entities.json"
      SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
      if not SHX7_2 then
        SHX7_2 = "{}"
      end
      SHX6_2 = SHX6_2(SHX7_2)
      SHX7_2 = SHX6_2[SHX4_2]
      if nil == SHX7_2 then
        SHX8_2 = Logger
        SHX9_2 = SHX8_2
        SHX8_2 = SHX8_2.log
        SHX10_2 = "You have provided an invalid execution id. ^3%s^7 is not a valid id"
        SHX11_2 = SHX10_2
        SHX10_2 = SHX10_2.format
        SHX12_2 = SHX4_2
        SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
        SHX11_2 = "error"
        return SHX8_2(SHX9_2, SHX10_2, SHX11_2)
      end
      SHX6_2[SHX4_2] = nil
      SHX8_2 = json
      SHX8_2 = SHX8_2.encode
      SHX9_2 = SHX6_2
      SHX8_2 = SHX8_2(SHX9_2)
      SHX9_2 = SaveResourceFile
      SHX10_2 = "ReaperV4"
      SHX11_2 = "cache/entities.json"
      SHX12_2 = SHX8_2
      SHX13_2 = #SHX8_2
      SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2)
      SHX9_2 = RPC
      SHX10_2 = SHX9_2
      SHX9_2 = SHX9_2.emit
      SHX11_2 = "ProAddon:RefreshEntities"
      SHX9_2(SHX10_2, SHX11_2)
      SHX9_2 = Logger
      SHX10_2 = SHX9_2
      SHX9_2 = SHX9_2.log
      SHX11_2 = "^3%s ^7(^3%s^7) sent from ^3%s^7 was removed."
      SHX12_2 = SHX11_2
      SHX11_2 = SHX11_2.format
      SHX13_2 = SHX7_2.param
      SHX14_2 = SHX7_2.key
      SHX15_2 = SHX7_2.path
      SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2)
      SHX12_2 = "info"
      return SHX9_2(SHX10_2, SHX11_2, SHX12_2)
    elseif "event" == SHX3_2 then
      SHX6_2 = LoadResourceFile
      SHX7_2 = "ReaperV4"
      SHX8_2 = "cache/events-"
      SHX9_2 = SHX5_2
      SHX10_2 = ".json"
      SHX8_2 = SHX8_2 .. SHX9_2 .. SHX10_2
      SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
      if nil == SHX6_2 then
        SHX7_2 = Logger
        SHX8_2 = SHX7_2
        SHX7_2 = SHX7_2.log
        SHX9_2 = "You have provided an invalid resource name. ^3%s^7 is not a resource name"
        SHX10_2 = SHX9_2
        SHX9_2 = SHX9_2.format
        SHX11_2 = SHX4_2
        SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
        SHX10_2 = "error"
        return SHX7_2(SHX8_2, SHX9_2, SHX10_2)
      end
      SHX7_2 = json
      SHX7_2 = SHX7_2.decode
      SHX8_2 = SHX6_2
      SHX7_2 = SHX7_2(SHX8_2)
      SHX8_2 = SHX7_2[SHX4_2]
      if nil == SHX8_2 then
        SHX9_2 = Logger
        SHX10_2 = SHX9_2
        SHX9_2 = SHX9_2.log
        SHX11_2 = "You have provided an invalid execution id. ^3%s^7 is not a valid id"
        SHX12_2 = SHX11_2
        SHX11_2 = SHX11_2.format
        SHX13_2 = SHX4_2
        SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
        SHX12_2 = "error"
        return SHX9_2(SHX10_2, SHX11_2, SHX12_2)
      end
      SHX7_2[SHX4_2] = nil
      SHX9_2 = json
      SHX9_2 = SHX9_2.encode
      SHX10_2 = SHX7_2
      SHX9_2 = SHX9_2(SHX10_2)
      SHX10_2 = SaveResourceFile
      SHX11_2 = "ReaperV4"
      SHX12_2 = "cache/events-"
      SHX13_2 = SHX5_2
      SHX14_2 = ".json"
      SHX12_2 = SHX12_2 .. SHX13_2 .. SHX14_2
      SHX13_2 = SHX9_2
      SHX14_2 = #SHX9_2
      SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2)
      SHX10_2 = RPC
      SHX11_2 = SHX10_2
      SHX10_2 = SHX10_2.emitLocal
      SHX12_2 = "Reaper:ProAddonRefreshWhitelist"
      SHX13_2 = SHX8_2.resource
      SHX10_2(SHX11_2, SHX12_2, SHX13_2)
      SHX10_2 = Logger
      SHX11_2 = SHX10_2
      SHX10_2 = SHX10_2.log
      SHX12_2 = "^3%s ^7(^3%s^7) sent from ^3%s^7 was removed."
      SHX13_2 = SHX12_2
      SHX12_2 = SHX12_2.format
      SHX14_2 = SHX8_2.param
      SHX15_2 = SHX8_2.key
      SHX16_2 = SHX8_2.path
      SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2)
      SHX13_2 = "info"
      return SHX10_2(SHX11_2, SHX12_2, SHX13_2)
    elseif "other" == SHX3_2 then
      SHX6_2 = print
      SHX7_2 = "other"
      SHX6_2(SHX7_2)
    end
    SHX6_2 = Logger
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.log
    SHX8_2 = "Invalid command usage! Example: ^3reaper execution remove event|entity executionId resource|nil"
    SHX9_2 = "error"
    return SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  end
  if "info" == SHX2_2 then
    SHX3_2 = SHX1_2[3]
    SHX4_2 = SHX0_1
    SHX4_2 = SHX4_2[SHX3_2]
    if nil == SHX4_2 then
      SHX5_2 = Logger
      SHX6_2 = SHX5_2
      SHX5_2 = SHX5_2.log
      SHX7_2 = "You have provided an invalid execution ID!"
      SHX8_2 = "error"
      return SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    end
    SHX5_2 = SHX4_2.type
    if "event" == SHX5_2 then
      SHX5_2 = "TriggerServerEvent('"
      SHX6_2 = SHX4_2.param
      SHX7_2 = "')"
      SHX5_2 = SHX5_2 .. SHX6_2 .. SHX7_2
      if SHX5_2 then
        goto SHX_LABEL_425
      end
    end
    SHX5_2 = SHX4_2.type
    if "entity" == SHX5_2 then
      SHX5_2 = "CreateEntity('"
      SHX6_2 = SHX4_2.param
      SHX7_2 = "')"
      SHX5_2 = SHX5_2 .. SHX6_2 .. SHX7_2
      if SHX5_2 then
        goto SHX_LABEL_425
      end
    end
    SHX5_2 = SHX4_2.execution_type
    if not SHX5_2 then
      SHX5_2 = false
    end
    -- [FIX IF ERROR] Move ::SHX_LABEL_425:: outside nested blocks until all 'goto SHX_LABEL_425' can see it
    ::SHX_LABEL_425::
    SHX6_2 = Logger
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.log
    SHX8_2 = [[
The action ^3%s^7 from ^3%s^7 (^3%s^7) by ^3%s^7 (^3%s^7) was blocked due to it not being whitelisted

^2Code View:
^1-----------------------------------------------------------
^7%s^1-----------------------------------------------------------]]
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.format
    SHX10_2 = SHX5_2
    SHX11_2 = SHX4_2.path
    SHX12_2 = SHX4_2.key
    SHX13_2 = "Unknown"
    SHX14_2 = SHX4_2.player_license
    SHX15_2 = SHX4_2.code
    if not SHX15_2 then
      SHX15_2 = "The file path %s was not found\n"
      SHX16_2 = SHX15_2
      SHX15_2 = SHX15_2.format
      SHX17_2 = SHX4_2.path
      SHX15_2 = SHX15_2(SHX16_2, SHX17_2)
    end
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
    SHX9_2 = "warn"
    SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  end
  if "autowhitelist" == SHX2_2 then
    SHX3_2 = SHX1_2[3]
    SHX4_2 = SHX1_1
    SHX5_2 = SHX1_2[4]
    SHX4_2 = SHX4_2(SHX5_2)
    if true ~= SHX4_2 and false ~= SHX4_2 then
      SHX5_2 = Logger
      SHX6_2 = SHX5_2
      SHX5_2 = SHX5_2.log
      SHX7_2 = "Invalid command usage! Example: ^3reaper execution autowhitelist resource_name|all true|false"
      SHX8_2 = "error"
      return SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    end
    if "all" ~= SHX3_2 then
      SHX5_2 = GetResourceState
      SHX6_2 = SHX3_2
      SHX5_2 = SHX5_2(SHX6_2)
      if "started" ~= SHX5_2 then
        SHX5_2 = Logger
        SHX6_2 = SHX5_2
        SHX5_2 = SHX5_2.log
        SHX7_2 = "Invalid command usage! Example: ^3reaper execution autowhitelist resource_name|all true|false"
        SHX8_2 = "error"
        return SHX5_2(SHX6_2, SHX7_2, SHX8_2)
      end
    end
    SHX5_2 = RPC
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.emitLocal
    SHX7_2 = "Reaper:ProAddonAutoWhitelist"
    SHX8_2 = SHX3_2 or SHX8_2
    if not SHX3_2 then
      SHX8_2 = "all"
    end
    SHX9_2 = SHX4_2
    SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2)
    if "all" == SHX3_2 then
      SHX5_2 = Cache
      SHX6_2 = SHX5_2
      SHX5_2 = SHX5_2.set
      SHX7_2 = "ProAddon:AutoWhitelist"
      SHX8_2 = SHX4_2
      SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    else
      SHX5_2 = Cache
      SHX6_2 = SHX5_2
      SHX5_2 = SHX5_2.set
      SHX7_2 = "ProAddon:AutoWhitelist:"
      SHX8_2 = SHX3_2
      SHX7_2 = SHX7_2 .. SHX8_2
      SHX8_2 = SHX4_2
      SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    end
    SHX5_2 = Logger
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.log
    SHX7_2 = "Successfully set ^3autowhitelist^7 for the resource ^3%s^7 to ^3%s"
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.format
    SHX9_2 = SHX3_2
    SHX10_2 = SHX4_2
    SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2)
    SHX8_2 = "info"
    return SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  end
  if "refresh_executions_list" == SHX2_2 then
    SHX3_2 = ExecutionCheck
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.refresh_list
    SHX3_2(SHX4_2)
    SHX3_2 = Logger
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.log
    SHX5_2 = "Successfully refreshed executions_list.json"
    SHX6_2 = "info"
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  end
  if "addwhitelister" == SHX2_2 then
    SHX3_2 = Player
    SHX4_2 = tonumber
    SHX5_2 = SHX1_2[3]
    SHX4_2 = SHX4_2(SHX5_2)
    if not SHX4_2 then
      SHX4_2 = 0
    end
    SHX3_2 = SHX3_2(SHX4_2)
    if not SHX3_2 then
      SHX4_2 = Logger
      SHX5_2 = SHX4_2
      SHX4_2 = SHX4_2.log
      SHX6_2 = "Invalid command usage! Example: ^3reaper execution addwhitelister player_source"
      SHX7_2 = "error"
      return SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    end
    SHX4_2 = RPC
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.emitLocal
    SHX6_2 = "ProAddon:AddWhitelister"
    SHX8_2 = SHX3_2
    SHX7_2 = SHX3_2.getId
    SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = SHX7_2(SHX8_2)
    SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
    SHX4_2 = Logger
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.log
    SHX6_2 = "Successfully set ^3%s^7 (^3id:%s^7) as an auto whitelister"
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.format
    SHX9_2 = SHX3_2
    SHX8_2 = SHX3_2.getName
    SHX8_2 = SHX8_2(SHX9_2)
    SHX10_2 = SHX3_2
    SHX9_2 = SHX3_2.getId
    SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = SHX9_2(SHX10_2)
    SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
    SHX7_2 = "info"
    return SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  end
  if "tempallow" == SHX2_2 then
    SHX3_2 = SHX1_2[3]
    SHX4_2 = SHX1_1
    SHX5_2 = SHX1_2[4]
    SHX4_2 = SHX4_2(SHX5_2)
    if "all" ~= SHX3_2 then
      SHX5_2 = GetResourceState
      SHX6_2 = SHX3_2
      SHX5_2 = SHX5_2(SHX6_2)
      if "started" ~= SHX5_2 then
        SHX5_2 = Logger
        SHX6_2 = SHX5_2
        SHX5_2 = SHX5_2.log
        SHX7_2 = "Invalid command usage! Example: ^3reaper execution tempallow resource_name|all true|false"
        SHX8_2 = "error"
        return SHX5_2(SHX6_2, SHX7_2, SHX8_2)
      end
    end
    if true ~= SHX4_2 and false ~= SHX4_2 then
      SHX5_2 = Logger
      SHX6_2 = SHX5_2
      SHX5_2 = SHX5_2.log
      SHX7_2 = "Invalid command usage! Example: ^3reaper execution tempallow resource_name|all true|false"
      SHX8_2 = "error"
      return SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    end
    SHX5_2 = RPC
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.emitLocal
    SHX7_2 = "Reaper:ProAddonEnabled"
    SHX8_2 = SHX3_2
    SHX9_2 = SHX4_2
    SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2)
    SHX5_2 = Logger
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.log
    SHX7_2 = "Successfully set ^3tempallow^7 for the resource ^3%s^7 to ^3%s"
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.format
    SHX9_2 = SHX3_2
    SHX10_2 = SHX4_2
    SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2)
    SHX8_2 = "info"
    return SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  end
  if "help" == SHX2_2 then
    SHX3_2 = Logger
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.log
    SHX5_2 = [[
Execution Commands:
^3reaper execution tempallow resource_name true|false
reaper execution autowhitelist resource_name|all true|false
reaper execution addwhitelister player_source
reaper execution add executionId
reaper execution info executionId
reaper execution remove entity|event executionId resource|nil
reaper execution clearwhitelist resource_name]]
    SHX6_2 = "info"
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  end
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = [[
Invalid command usage! ^3%s^7 is not a valid command

^3reaper execution tempallow resource_name true|false
reaper execution autowhitelist resource_name|all true|false
reaper execution addwhitelister player_source
reaper execution add executionId
reaper execution info executionId
reaper execution remove entity|event executionId resource|nil
reaper execution clearwhitelist resource_name]]
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX2_2
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX6_2 = "error"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
end
SHX4_1.callback = SHX5_1
SHX4_1.description = "Pro Addon Commands"
SHX5_1 = {}
SHX6_1 = "Pro Addon"
SHX5_1[1] = SHX6_1
SHX4_1.permissions = SHX5_1
SHX5_1 = {}
SHX4_1.args = SHX5_1
SHX2_1(SHX3_1, SHX4_1)
SHX2_1 = RPC
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.onLocal
SHX4_1 = "Reaper:UnknownExecutionPath"
function SHX5_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2
  SHX1_2 = Player
  SHX2_2 = SHX0_2.source
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = tostring
  SHX3_2 = SHX0_2.key
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SHX0_1
  SHX2_2 = SHX3_2[SHX2_2]
  if nil == SHX2_2 then
    SHX2_2 = string
    SHX2_2 = SHX2_2.match
    SHX3_2 = SHX0_2.path
    SHX4_2 = "@@([^/]+)"
    SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
    SHX3_2 = SHX0_2.path
    if "=?:-1" ~= SHX3_2 then
      SHX3_2 = type
      SHX4_2 = SHX2_2
      SHX3_2 = SHX3_2(SHX4_2)
      if "string" == SHX3_2 then
        SHX3_2 = GetResourceState
        SHX4_2 = SHX2_2
        SHX3_2 = SHX3_2(SHX4_2)
        if "started" == SHX3_2 then
          SHX3_2 = string
          SHX3_2 = SHX3_2.split
          SHX4_2 = SHX0_2.path
          SHX5_2 = ":"
          SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
          SHX4_2 = string
          SHX4_2 = SHX4_2.replace
          SHX5_2 = SHX3_2[1]
          SHX6_2 = "@@"
          SHX7_2 = SHX2_2
          SHX8_2 = "/"
          SHX6_2 = SHX6_2 .. SHX7_2 .. SHX8_2
          SHX7_2 = ""
          SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
          SHX5_2 = tonumber
          SHX6_2 = SHX3_2[2]
          SHX5_2 = SHX5_2(SHX6_2)
          if not SHX5_2 then
            SHX5_2 = 0
          end
          SHX6_2 = Resources
          SHX7_2 = SHX6_2
          SHX6_2 = SHX6_2.getCodeNearLine
          SHX8_2 = SHX2_2
          SHX9_2 = SHX4_2
          SHX10_2 = SHX5_2
          SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
          if not SHX6_2 then
            SHX6_2 = ""
          end
          SHX0_2.code = SHX6_2
        end
      end
    end
    if SHX1_2 then
      SHX4_2 = SHX1_2
      SHX3_2 = SHX1_2.getName
      SHX3_2 = SHX3_2(SHX4_2)
      SHX0_2.player_name = SHX3_2
      SHX4_2 = SHX1_2
      SHX3_2 = SHX1_2.getIdentifier
      SHX5_2 = "license"
      SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
      SHX0_2.player_license = SHX3_2
    end
    SHX3_2 = tostring
    SHX4_2 = SHX0_2.key
    SHX3_2 = SHX3_2(SHX4_2)
    SHX4_2 = SHX0_1
    SHX4_2[SHX3_2] = SHX0_2
    SHX3_2 = json
    SHX3_2 = SHX3_2.encode
    SHX4_2 = SHX0_1
    SHX3_2 = SHX3_2(SHX4_2)
    SHX4_2 = SaveResourceFile
    SHX5_2 = "ReaperV4"
    SHX6_2 = "cache/unknownExecutionList.json"
    SHX7_2 = SHX3_2
    SHX8_2 = #SHX3_2
    SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  end
  if nil == SHX1_2 then
    return
  end
  SHX2_2 = SHX0_2.type
  if "event" == SHX2_2 then
    SHX2_2 = "TriggerServerEvent('"
    SHX3_2 = SHX0_2.param
    SHX4_2 = "')"
    SHX2_2 = SHX2_2 .. SHX3_2 .. SHX4_2
    if SHX2_2 then
      goto SHX_LABEL_108
    end
  end
  SHX2_2 = SHX0_2.type
  if "entity" == SHX2_2 then
    SHX2_2 = "CreateEntity('"
    SHX3_2 = SHX0_2.param
    SHX4_2 = "')"
    SHX2_2 = SHX2_2 .. SHX3_2 .. SHX4_2
    if SHX2_2 then
      goto SHX_LABEL_108
    end
  end
  SHX2_2 = SHX0_2.execution_type
  if not SHX2_2 then
    SHX2_2 = false
  end
  -- [FIX IF ERROR] Move ::SHX_LABEL_108:: outside nested blocks until all 'goto SHX_LABEL_108' can see it
  ::SHX_LABEL_108::
  SHX3_2 = GetConvar
  SHX4_2 = "reaper_ban_unwhitelisted_execution"
  SHX5_2 = "false"
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  if "true" == SHX3_2 and SHX2_2 then
    SHX3_2 = RPC
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.emitLocal
    SHX5_2 = "Reaper:NewDetection"
    SHX6_2 = {}
    SHX6_2.type = "unknownExecution"
    SHX6_2.data = SHX0_2
    SHX7_2 = {}
    SHX8_2 = SHX2_2
    SHX9_2 = SHX0_2.path
    SHX10_2 = SHX0_2.key
    SHX7_2[1] = SHX8_2
    SHX7_2[2] = SHX9_2
    SHX7_2[3] = SHX10_2
    SHX6_2.params = SHX7_2
    SHX6_2.action = "Ban Player"
    SHX8_2 = SHX1_2
    SHX7_2 = SHX1_2.getId
    SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2 = SHX7_2(SHX8_2)
    SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
  end
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = [[
The action ^3%s^7 from ^3%s^7 (^3%s^7) by ^3%s^7 (^3id:%s^7) was blocked due to it not being whitelisted

^2Code View:
^1-----------------------------------------------------------
^7%s^1-----------------------------------------------------------]]
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX2_2
  SHX8_2 = SHX0_2.path
  SHX9_2 = SHX0_2.key
  SHX11_2 = SHX1_2
  SHX10_2 = SHX1_2.getName
  SHX10_2 = SHX10_2(SHX11_2)
  SHX12_2 = SHX1_2
  SHX11_2 = SHX1_2.getId
  SHX11_2 = SHX11_2(SHX12_2)
  SHX12_2 = tostring
  SHX13_2 = SHX0_2.key
  SHX12_2 = SHX12_2(SHX13_2)
  SHX13_2 = SHX0_1
  SHX12_2 = SHX13_2[SHX12_2]
  SHX12_2 = SHX12_2.code
  if not SHX12_2 then
    SHX12_2 = "The file path %s was not found\n"
    SHX13_2 = SHX12_2
    SHX12_2 = SHX12_2.format
    SHX14_2 = SHX0_2.path
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
  end
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  SHX6_2 = "warn"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
end
SHX2_1(SHX3_1, SHX4_1, SHX5_1)
SHX2_1 = RPC
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.on
SHX4_1 = "configUpdated"
function SHX5_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX0_2 = Settings
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX0_2 = SHX0_2(SHX1_2)
  SHX1_2 = SetConvar
  SHX2_2 = "reaper_ban_unwhitelisted_execution"
  SHX3_2 = tostring
  SHX4_2 = SHX0_2.verifyNativeExecution
  if not SHX4_2 then
    SHX4_2 = GetConvar
    SHX5_2 = "reaper_ban_unwhitelisted_execution"
    SHX6_2 = "false"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    SHX4_2 = "true" == SHX4_2
  end
  SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2 = SHX3_2(SHX4_2)
  SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  SHX1_2 = SetConvarReplicated
  SHX2_2 = "reaper_pro_addon_enabled"
  SHX3_2 = tostring
  SHX4_2 = SHX0_2.AdvancedExecutionCheck
  SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2 = SHX3_2(SHX4_2)
  SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  SHX1_2 = Cache
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.get
  SHX3_2 = "raw_flagged_events"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  if SHX1_2 then
    SHX2_2 = json
    SHX2_2 = SHX2_2.decode
    SHX3_2 = SHX1_2
    SHX2_2 = SHX2_2(SHX3_2)
    SHX3_2 = pairs
    SHX4_2 = SHX0_2.keyLockedEvents
    if not SHX4_2 then
      SHX4_2 = {}
    end
    SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
    for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
      SHX9_2 = {}
      SHX9_2.log = "The event ^3EventName^7 from ^3ResourceName^7 has been marked as a key locked event."
      SHX9_2.key_lock = true
      SHX2_2[SHX7_2] = SHX9_2
    end
    SHX3_2 = json
    SHX3_2 = SHX3_2.encode
    SHX4_2 = SHX2_2
    SHX3_2 = SHX3_2(SHX4_2)
    SHX4_2 = LoadResourceFile
    SHX5_2 = "ReaperV4"
    SHX6_2 = "cache/flaggedEvents.json"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if not SHX4_2 then
      SHX4_2 = ""
    end
    SHX4_2 = #SHX4_2
    SHX5_2 = #SHX3_2
    if SHX4_2 ~= SHX5_2 then
      SHX4_2 = SaveResourceFile
      SHX5_2 = "ReaperV4"
      SHX6_2 = "cache/flaggedEvents.json"
      SHX7_2 = SHX3_2
      SHX8_2 = #SHX3_2
      SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
      SHX4_2 = RPC
      SHX5_2 = SHX4_2
      SHX4_2 = SHX4_2.emitLocal
      SHX6_2 = "Reaper:UpdateFlaggedEvents"
      SHX4_2(SHX5_2, SHX6_2)
    end
  end
end
SHX2_1(SHX3_1, SHX4_1, SHX5_1)
SHX2_1 = RPC
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.on
SHX4_1 = "reaperStarted"
function SHX5_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX0_2 = Settings
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX0_2 = SHX0_2(SHX1_2)
  SHX1_2 = HTTP
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.await
  SHX3_2 = "https://api.reaperac.com/api/v1/data/flaggedevents"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = SHX1_2.body
  if not SHX1_2 then
    SHX1_2 = "{}"
  end
  SHX2_2 = Cache
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.set
  SHX4_2 = "raw_flagged_events"
  SHX5_2 = SHX1_2
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = json
  SHX2_2 = SHX2_2.decode
  SHX3_2 = SHX1_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = pairs
  SHX4_2 = SHX0_2.keyLockedEvents
  if not SHX4_2 then
    SHX4_2 = {}
  end
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
  for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    SHX9_2 = {}
    SHX9_2.log = "The event ^3EventName^7 from ^3ResourceName^7 has been marked as a key locked event."
    SHX9_2.key_lock = true
    SHX2_2[SHX7_2] = SHX9_2
  end
  SHX3_2 = json
  SHX3_2 = SHX3_2.encode
  SHX4_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = LoadResourceFile
  SHX5_2 = "ReaperV4"
  SHX6_2 = "cache/flaggedEvents.json"
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  if not SHX4_2 then
    SHX4_2 = ""
  end
  SHX4_2 = #SHX4_2
  SHX5_2 = #SHX3_2
  if SHX4_2 ~= SHX5_2 then
    SHX4_2 = SaveResourceFile
    SHX5_2 = "ReaperV4"
    SHX6_2 = "cache/flaggedEvents.json"
    SHX7_2 = SHX3_2
    SHX8_2 = #SHX3_2
    SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
    SHX4_2 = RPC
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.emitLocal
    SHX6_2 = "Reaper:UpdateFlaggedEvents"
    SHX4_2(SHX5_2, SHX6_2)
  end
  SHX4_2 = GlobalState
  SHX4_2.ReaperStarted = true
end
SHX2_1(SHX3_1, SHX4_1, SHX5_1)
SHX2_1 = RPC
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.register
SHX4_1 = "check_custom_execution"
function SHX5_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2
  SHX6_2 = Player
  SHX7_2 = SHX0_2
  SHX6_2 = SHX6_2(SHX7_2)
  if nil == SHX6_2 then
    SHX7_2 = false
    return SHX7_2
  end
  SHX8_2 = SHX6_2
  SHX7_2 = SHX6_2.NewLog
  SHX9_2 = "^3%s^7 (^3id:%s^7) requested the check of ^3%s^7 for ^3%s^7 from the resource ^3%s^7 with the path of ^3%s^7 with a param of ^3%s^7"
  SHX10_2 = SHX9_2
  SHX9_2 = SHX9_2.format
  SHX12_2 = SHX6_2
  SHX11_2 = SHX6_2.getName
  SHX11_2 = SHX11_2(SHX12_2)
  SHX13_2 = SHX6_2
  SHX12_2 = SHX6_2.getId
  SHX12_2 = SHX12_2(SHX13_2)
  SHX13_2 = SHX4_2
  SHX14_2 = SHX2_2
  SHX15_2 = SHX1_2
  SHX16_2 = SHX3_2
  SHX17_2 = SHX5_2
  SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
  SHX10_2 = "debug"
  SHX11_2 = "execution_checks"
  SHX12_2 = {}
  SHX12_2.source = SHX0_2
  SHX12_2.resource = SHX1_2
  SHX12_2.execution_type = SHX2_2
  SHX12_2.path = SHX3_2
  SHX12_2.execution_id = SHX4_2
  SHX12_2.param = SHX5_2
  SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  SHX7_2 = ExecutionCheck
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.execution_valid
  SHX9_2 = SHX0_2
  SHX10_2 = SHX2_2
  SHX11_2 = SHX4_2
  SHX12_2 = SHX3_2
  SHX13_2 = SHX1_2
  SHX14_2 = SHX5_2 or SHX14_2
  if not SHX5_2 then
    SHX14_2 = ""
  end
  return SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
end
SHX2_1(SHX3_1, SHX4_1, SHX5_1)
SHX2_1 = exports
SHX3_1 = "VerifyExecution"
function SHX4_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2
  SHX3_2 = GetInvokingResource
  SHX3_2 = SHX3_2()
  SHX4_2 = Cache
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.get
  SHX6_2 = "VerifyExecution_"
  SHX7_2 = SHX1_2
  SHX6_2 = SHX6_2 .. SHX7_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  if SHX4_2 then
    SHX4_2 = Cache
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.get
    SHX6_2 = "VerifyExecution_"
    SHX7_2 = SHX1_2
    SHX6_2 = SHX6_2 .. SHX7_2
    return SHX4_2(SHX5_2, SHX6_2)
  end
  SHX4_2 = string
  SHX4_2 = SHX4_2.match
  SHX5_2 = SHX2_2
  SHX6_2 = "@@([^/]+)"
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = string
  SHX5_2 = SHX5_2.split
  SHX6_2 = SHX2_2
  SHX7_2 = ":"
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX6_2 = string
  SHX6_2 = SHX6_2.replace
  SHX7_2 = SHX5_2[1]
  SHX8_2 = "@@"
  SHX9_2 = SHX4_2
  SHX10_2 = "/"
  SHX8_2 = SHX8_2 .. SHX9_2 .. SHX10_2
  SHX9_2 = ""
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX7_2 = tonumber
  SHX8_2 = SHX5_2[2]
  SHX7_2 = SHX7_2(SHX8_2)
  if not SHX7_2 then
    SHX7_2 = 0
  end
  SHX8_2 = Resources
  SHX9_2 = SHX8_2
  SHX8_2 = SHX8_2.getCodeOnLine
  SHX10_2 = SHX4_2
  SHX11_2 = SHX6_2
  SHX12_2 = SHX7_2
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  if not SHX8_2 then
    SHX8_2 = ""
  end
  SHX9_2 = json
  SHX9_2 = SHX9_2.decode
  SHX10_2 = LoadResourceFile
  SHX11_2 = "ReaperV4"
  SHX12_2 = "pro_addon_event_lock-%s.json"
  SHX13_2 = SHX12_2
  SHX12_2 = SHX12_2.format
  SHX14_2 = SHX3_2
  SHX12_2, SHX13_2, SHX14_2, SHX15_2 = SHX12_2(SHX13_2, SHX14_2)
  SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
  if not SHX10_2 then
    SHX10_2 = "{}"
  end
  SHX9_2 = SHX9_2(SHX10_2)
  SHX10_2 = SHX9_2[SHX1_2]
  if nil == SHX10_2 then
    SHX10_2 = string
    SHX10_2 = SHX10_2.find
    SHX11_2 = SHX8_2
    SHX12_2 = string
    SHX12_2 = SHX12_2.replace
    SHX13_2 = SHX0_2
    SHX14_2 = "-"
    SHX15_2 = "%-"
    SHX12_2, SHX13_2, SHX14_2, SHX15_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2)
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
    if SHX10_2 then
      SHX10_2 = string
      SHX10_2 = SHX10_2.find
      SHX11_2 = SHX8_2
      SHX12_2 = "TriggerServerEvent"
      SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
      if SHX10_2 then
        SHX9_2[SHX1_2] = true
        SHX10_2 = tostring
        SHX11_2 = SHX9_2
        SHX10_2 = SHX10_2(SHX11_2)
        SHX11_2 = SaveResourceFile
        SHX12_2 = SHX3_2
        SHX13_2 = "pro_addon_event_lock-%s.json"
        SHX14_2 = SHX13_2
        SHX13_2 = SHX13_2.format
        SHX15_2 = SHX3_2
        SHX13_2 = SHX13_2(SHX14_2, SHX15_2)
        SHX14_2 = SHX10_2
        SHX15_2 = #SHX10_2
        SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2)
        SHX11_2 = Cache
        SHX12_2 = SHX11_2
        SHX11_2 = SHX11_2.set
        SHX13_2 = "VerifyExecution_"
        SHX14_2 = SHX1_2
        SHX13_2 = SHX13_2 .. SHX14_2
        SHX14_2 = true
        SHX11_2(SHX12_2, SHX13_2, SHX14_2)
        SHX11_2 = true
        return SHX11_2
      end
    end
  end
  SHX10_2 = Cache
  SHX11_2 = SHX10_2
  SHX10_2 = SHX10_2.set
  SHX12_2 = "VerifyExecution_"
  SHX13_2 = SHX1_2
  SHX12_2 = SHX12_2 .. SHX13_2
  SHX13_2 = false
  SHX10_2(SHX11_2, SHX12_2, SHX13_2)
  SHX10_2 = false
  return SHX10_2
end
SHX2_1(SHX3_1, SHX4_1)
