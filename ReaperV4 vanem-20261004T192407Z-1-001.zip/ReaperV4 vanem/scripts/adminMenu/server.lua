-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1
SHX0_1 = Logger
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.log
SHX2_1 = "scripts/adminMenu/server.lua loaded"
SHX3_1 = "debug"
SHX0_1(SHX1_1, SHX2_1, SHX3_1)
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = {}
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX2_2 = pairs
  SHX3_2 = SHX0_1
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX8_2 = RPC
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.emitNet
    SHX10_2 = SHX0_2
    SHX11_2 = SHX7_2.player
    SHX12_2 = SHX1_2
    SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  end
end
EmitPipe = SHX1_1
SHX1_1 = RPC
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.on
SHX3_1 = "reaperStarted"
function SHX4_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX0_2 = Logger
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.log
  SHX2_2 = "scripts/adminMenu/server.lua - reaper started"
  SHX3_2 = "debug"
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = table
  SHX0_2 = SHX0_2.filter
  SHX1_2 = Resources
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.getData
  SHX1_2 = SHX1_2(SHX2_2)
  function SHX2_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3
    SHX1_3 = SHX0_3.needs_protected
    return SHX1_3
  end
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.onNet
  SHX3_2 = "onResourceStart"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = source
    if "" ~= SHX0_3 then
      return
    end
    SHX0_3 = table
    SHX0_3 = SHX0_3.filter
    SHX1_3 = Resources
    SHX2_3 = SHX1_3
    SHX1_3 = SHX1_3.getData
    SHX1_3 = SHX1_3(SHX2_3)
    function SHX2_3(SHX0_4)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_4
      SHX1_4 = SHX0_4.needs_protected
      return SHX1_4
    end
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
    SHX0_2 = SHX0_3
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.onNet
  SHX3_2 = "onResourceStop"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = source
    if "" ~= SHX0_3 then
      return
    end
    SHX0_3 = table
    SHX0_3 = SHX0_3.filter
    SHX1_3 = Resources
    SHX2_3 = SHX1_3
    SHX1_3 = SHX1_3.getData
    SHX1_3 = SHX1_3(SHX2_3)
    function SHX2_3(SHX0_4)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_4
      SHX1_4 = SHX0_4.needs_protected
      return SHX1_4
    end
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
    SHX0_2 = SHX0_3
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.onLocal
  SHX3_2 = "Reaper:FlaggedEventFound"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX2_3 = Resource
    SHX3_3 = GetInvokingResource
    SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3 = SHX3_3()
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
    if nil == SHX2_3 then
      return
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.addVulnerability
    SHX5_3 = "The event %s is a known event abused by cheaters"
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.format
    SHX7_3 = SHX0_3
    SHX5_3, SHX6_3, SHX7_3 = SHX5_3(SHX6_3, SHX7_3)
    SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3)
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.onNet
  SHX3_2 = "Reaper:updateQuickActions"
  function SHX4_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX1_3 = source
    SHX2_3 = Player
    SHX3_3 = SHX1_3
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      return
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.hasPerm
    SHX5_3 = "Admin Menu"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if false == SHX3_3 then
      return
    end
    SHX3_3 = Logger
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.log
    SHX5_3 = "^3%s ^7(^3fivem:%s^7) has just updated the quick actions."
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.format
    SHX8_3 = SHX2_3
    SHX7_3 = SHX2_3.getName
    SHX7_3 = SHX7_3(SHX8_3)
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getIdentifier
    SHX10_3 = "fivem"
    SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
    SHX9_3 = SHX0_3
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX6_3 = "info"
    SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    SHX3_3 = json
    SHX3_3 = SHX3_3.decode
    SHX4_3 = SHX0_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX0_3 = SHX3_3
    SHX3_3 = Settings
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.get
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX0_3.devMode
    SHX3_3.devMode = SHX4_3
    SHX4_3 = SHX0_3.underAttackMode
    SHX3_3.underAttackMode = SHX4_3
    SHX4_3 = SHX0_3.blockConnections
    SHX3_3.blockConnections = SHX4_3
    SHX4_3 = Settings
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.set
    SHX6_3 = SHX3_3
    SHX4_3(SHX5_3, SHX6_3)
    SHX4_3 = RPC
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.emit
    SHX6_3 = "configUpdated"
    SHX4_3(SHX5_3, SHX6_3)
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.on
  SHX3_2 = "configUpdated"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
    SHX0_3 = Settings
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.get
    SHX0_3 = SHX0_3(SHX1_3)
    SHX1_3 = EmitPipe
    SHX2_3 = "Reaper:updateQuickActions"
    SHX3_3 = {}
    SHX4_3 = SHX0_3.devMode
    SHX3_3.devMode = SHX4_3
    SHX4_3 = SHX0_3.underAttackMode
    SHX3_3.underAttackMode = SHX4_3
    SHX4_3 = SHX0_3.blockConnections
    SHX3_3.blockConnections = SHX4_3
    SHX1_3(SHX2_3, SHX3_3)
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.onNet
  SHX3_2 = "Reaper:executeCommand"
  function SHX4_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX1_3 = source
    SHX2_3 = Player
    SHX3_3 = SHX1_3
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      return
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.hasPerm
    SHX5_3 = "Admin Menu"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if false == SHX3_3 then
      return
    end
    SHX3_3 = Logger
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.log
    SHX5_3 = "^3%s^7 (^3fivem:%s^7) has just executed a command. Command: ^3%s"
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.format
    SHX8_3 = SHX2_3
    SHX7_3 = SHX2_3.getName
    SHX7_3 = SHX7_3(SHX8_3)
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getIdentifier
    SHX10_3 = "fivem"
    SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
    SHX9_3 = SHX0_3
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX6_3 = "info"
    SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    SHX3_3 = string
    SHX3_3 = SHX3_3.starts
    SHX4_3 = SHX0_3
    SHX5_3 = "reaper"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if false == SHX3_3 then
      return
    end
    SHX4_3 = SHX0_3
    SHX3_3 = SHX0_3.gsub
    SHX5_3 = "reaper "
    SHX6_3 = ""
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    SHX4_3 = string
    SHX4_3 = SHX4_3.split
    SHX5_3 = SHX3_3
    SHX6_3 = " "
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX5_3 = Command
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.execute
    SHX7_3 = SHX4_3[1]
    SHX8_3 = SHX4_3
    SHX9_3 = SHX1_3
    SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3)
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.register
  SHX3_2 = "getMenuData"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3
    SHX2_3 = SHX0_3
    SHX3_3 = Player
    SHX4_3 = SHX2_3
    SHX3_3 = SHX3_3(SHX4_3)
    if nil == SHX3_3 then
      return
    end
    SHX5_3 = SHX3_3
    SHX4_3 = SHX3_3.hasPerm
    SHX6_3 = "Admin Menu"
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    if false == SHX4_3 then
      SHX4_3 = {}
      SHX4_3.error = true
      SHX4_3.message = "Player doesn't have access to admin menu"
      return SHX4_3
    end
    SHX5_3 = SHX3_3
    SHX4_3 = SHX3_3.getCfxInfo
    SHX4_3 = SHX4_3(SHX5_3)
    if nil ~= SHX4_3 then
      SHX5_3 = SHX4_3.cfxId
      if nil ~= SHX5_3 then
        goto SHX_LABEL_30
      end
    end
    SHX5_3 = {}
    SHX5_3.error = true
    SHX5_3.message = "You dont have Cfx.re connected to your FiveM!"
    return SHX5_3
    -- [FIX IF ERROR] Move ::SHX_LABEL_30:: outside nested blocks until all 'goto SHX_LABEL_30' can see it
    ::SHX_LABEL_30::
    SHX6_3 = SHX4_3.cfxId
    SHX5_3 = SHX0_1
    SHX7_3 = {}
    SHX9_3 = SHX3_3
    SHX8_3 = SHX3_3.getId
    SHX8_3 = SHX8_3(SHX9_3)
    SHX7_3.player = SHX8_3
    SHX5_3[SHX6_3] = SHX7_3
    SHX5_3 = "Staff"
    SHX6_3 = pairs
    SHX8_3 = SHX3_3
    SHX7_3 = SHX3_3.getPerms
    SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3 = SHX7_3(SHX8_3)
    SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3)
    for SHX10_3, SHX11_3 in SHX6_3, SHX7_3, SHX8_3, SHX9_3 do
      if "All Permissions" == SHX11_3 then
        SHX5_3 = "Administrator"
      end
    end
    SHX6_3 = {}
    SHX6_3.error = false
    SHX7_3 = json
    SHX7_3 = SHX7_3.encode
    SHX8_3 = {}
    SHX9_3 = Cache
    SHX10_3 = SHX9_3
    SHX9_3 = SHX9_3.get
    SHX11_3 = "version"
    SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
    SHX8_3.version = SHX9_3
    SHX9_3 = {}
    SHX9_3.key = nil
    SHX9_3.type = SHX5_3
    SHX10_3 = SHX4_3.cfxUsername
    SHX9_3.username = SHX10_3
    SHX10_3 = SHX4_3.cfxId
    SHX9_3.id = SHX10_3
    SHX9_3.profile = "https://reaperac.com/images/reaperLogo.png"
    SHX8_3.cfx = SHX9_3
    SHX9_3 = Cache
    SHX10_3 = SHX9_3
    SHX9_3 = SHX9_3.get
    SHX11_3 = "statistics"
    SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
    SHX8_3.statistics = SHX9_3
    SHX9_3 = {}
    SHX10_3 = Settings
    SHX11_3 = SHX10_3
    SHX10_3 = SHX10_3.get
    SHX10_3 = SHX10_3(SHX11_3)
    SHX10_3 = SHX10_3.devMode
    SHX9_3.devMode = SHX10_3
    SHX10_3 = Settings
    SHX11_3 = SHX10_3
    SHX10_3 = SHX10_3.get
    SHX10_3 = SHX10_3(SHX11_3)
    SHX10_3 = SHX10_3.underAttackMode
    SHX9_3.underAttackMode = SHX10_3
    SHX10_3 = Settings
    SHX11_3 = SHX10_3
    SHX10_3 = SHX10_3.get
    SHX10_3 = SHX10_3(SHX11_3)
    SHX10_3 = SHX10_3.blockConnections
    SHX9_3.blockConnections = SHX10_3
    SHX8_3.settings = SHX9_3
    SHX9_3 = Logger
    SHX10_3 = SHX9_3
    SHX9_3 = SHX9_3.getHistory
    SHX9_3 = SHX9_3(SHX10_3)
    SHX8_3.console = SHX9_3
    if SHX1_3 then
      SHX9_3 = table
      SHX9_3 = SHX9_3.filter
      SHX10_3 = Players
      SHX10_3 = SHX10_3()
      function SHX11_3(SHX0_4)
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX1_4
        SHX1_4 = SHX0_4.metadata
        if nil == SHX1_4 then
          SHX1_4 = false
          return SHX1_4
        end
        SHX1_4 = SHX0_4.metadata
        SHX1_4 = SHX1_4.flags
        return SHX1_4
      end
      SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
      if SHX9_3 then
        goto SHX_LABEL_111
      end
    end
    SHX9_3 = {}
    -- [FIX IF ERROR] Move ::SHX_LABEL_111:: outside nested blocks until all 'goto SHX_LABEL_111' can see it
    ::SHX_LABEL_111::
    SHX8_3.players = SHX9_3
    SHX9_3 = SHX0_2
    SHX8_3.resources = SHX9_3
    SHX7_3 = SHX7_3(SHX8_3)
    SHX6_3.data = SHX7_3
    return SHX6_3
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.bind
  function SHX3_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3
    SHX1_3 = EmitPipe
    SHX2_3 = "Reaper:consoleUpdate"
    SHX3_3 = SHX0_3
    SHX1_3(SHX2_3, SHX3_3)
  end
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.on
  SHX3_2 = "Reaper:SendConsoleMessage"
  function SHX4_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3
    SHX1_3 = EmitPipe
    SHX2_3 = "Reaper:consoleUpdate"
    SHX3_3 = SHX0_3
    SHX1_3(SHX2_3, SHX3_3)
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
