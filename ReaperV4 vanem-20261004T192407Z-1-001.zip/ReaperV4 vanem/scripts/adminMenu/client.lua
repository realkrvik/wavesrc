-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1, SHX21_1, SHX22_1, SHX23_1
SHX0_1 = Logger
SHX1_1 = RPC
SHX2_1 = NUI
SHX4_1 = SHX0_1
SHX3_1 = SHX0_1.log
SHX5_1 = "scripts/adminMenu/client.lua loaded"
SHX6_1 = "debug"
SHX3_1(SHX4_1, SHX5_1, SHX6_1)
SHX3_1 = RegisterKeyMapping
SHX4_1 = RegisterCommand
SHX5_1 = GetConvar
SHX6_1 = "reaper_gameType"
SHX7_1 = "unknown"
SHX5_1 = SHX5_1(SHX6_1, SHX7_1)
SHX6_1 = tostring
SHX7_1 = table
SHX7_1 = SHX7_1.unpack
SHX8_1 = json
SHX8_1 = SHX8_1.decode
SHX9_1 = json
SHX9_1 = SHX9_1.encode
SHX10_1 = GetEntityPlayerIsFreeAimingAt
SHX11_1 = PlayerId
SHX12_1 = NetworkGetEntityIsNetworked
SHX13_1 = NetworkGetNetworkIdFromEntity
SHX14_1 = CreateThread
SHX15_1 = true
SHX16_1 = nil
function SHX17_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX0_2 = SHX1_1
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.await
  SHX2_2 = "getMenuData"
  SHX3_2 = SHX15_1
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  if "RESPONSE_FAILED" == SHX0_2 then
    SHX1_2 = SHX0_1
    SHX2_2 = SHX1_2
    SHX1_2 = SHX1_2.log
    SHX3_2 = "Failed to check if the player is an admin. Server did not respond"
    SHX4_2 = "error"
    return SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  end
  SHX1_2 = SHX0_2.error
  if SHX1_2 then
    SHX1_2 = SHX0_1
    SHX2_2 = SHX1_2
    SHX1_2 = SHX1_2.log
    SHX3_2 = SHX0_2.message
    SHX4_2 = "error"
    return SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  end
  SHX1_2 = SHX8_1
  SHX2_2 = SHX0_2.data
  SHX1_2 = SHX1_2(SHX2_2)
  SHX0_2.data = SHX1_2
  SHX1_2 = SHX15_1
  if SHX1_2 then
    SHX1_2 = SHX0_2.data
    SHX1_2 = SHX1_2.players
    SHX16_1 = SHX1_2
    SHX1_2 = false
    SHX15_1 = SHX1_2
  else
    SHX1_2 = SHX0_2.data
    SHX2_2 = SHX16_1
    SHX1_2.players = SHX2_2
  end
  SHX1_2 = SHX2_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.open
  SHX3_2 = "Menu"
  SHX4_2 = SHX0_2.data
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = SHX0_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Admin menu opened"
  SHX4_2 = "debug"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
if "gta5" == SHX5_1 then
  SHX18_1 = SHX4_1
  SHX19_1 = "+reaper"
  SHX20_1 = SHX17_1
  SHX18_1(SHX19_1, SHX20_1)
  SHX18_1 = SHX4_1
  SHX19_1 = "-reaper"
  function SHX20_1()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_2, SHX1_2
  end
  SHX18_1(SHX19_1, SHX20_1)
  SHX18_1 = SHX3_1
  SHX19_1 = "+reaper"
  SHX20_1 = "Reaper Admin Menu"
  SHX21_1 = "keyboard"
  SHX22_1 = "DELETE"
  SHX18_1(SHX19_1, SHX20_1, SHX21_1, SHX22_1)
else
  SHX18_1 = SHX4_1
  SHX19_1 = "reaper_menu"
  SHX20_1 = SHX17_1
  SHX18_1(SHX19_1, SHX20_1)
end
SHX19_1 = SHX2_1
SHX18_1 = SHX2_1.on
SHX20_1 = "close"
function SHX21_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  SHX2_2 = SHX2_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.close
  SHX4_2 = "Menu"
  SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX1_2
  SHX3_2 = true
  SHX2_2(SHX3_2)
end
SHX18_1(SHX19_1, SHX20_1, SHX21_1)
SHX19_1 = SHX2_1
SHX18_1 = SHX2_1.on
SHX20_1 = "quickActions"
function SHX21_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX2_2 = SHX1_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.emitNet
  SHX4_2 = "Reaper:updateQuickActions"
  SHX5_2 = SHX0_2
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = SHX1_2
  SHX3_2 = true
  SHX2_2(SHX3_2)
end
SHX18_1(SHX19_1, SHX20_1, SHX21_1)
SHX19_1 = SHX1_1
SHX18_1 = SHX1_1.onNet
SHX20_1 = "Reaper:updateQuickActions"
function SHX21_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX1_2 = SHX0_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Reaper:updateQuickActions event recivied from the server. Payload %s"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX9_1
  SHX6_2 = SHX0_2
  SHX5_2, SHX6_2 = SHX5_2(SHX6_2)
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX4_2 = "debug"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = SHX2_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.send
  SHX3_2 = "updateQuickActions"
  SHX4_2 = SHX0_2
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
SHX18_1(SHX19_1, SHX20_1, SHX21_1)
SHX19_1 = SHX1_1
SHX18_1 = SHX1_1.onNet
SHX20_1 = "Reaper:statisticsChange"
function SHX21_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = SHX2_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.send
  SHX3_2 = "updateStatistics"
  SHX4_2 = SHX0_2
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
SHX18_1(SHX19_1, SHX20_1, SHX21_1)
SHX19_1 = SHX1_1
SHX18_1 = SHX1_1.onNet
SHX20_1 = "Reaper:newNotification"
function SHX21_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
end
SHX18_1(SHX19_1, SHX20_1, SHX21_1)
SHX19_1 = SHX2_1
SHX18_1 = SHX2_1.on
SHX20_1 = "executeCommand"
function SHX21_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX2_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.send
  SHX4_2 = "updateConsole"
  SHX5_2 = "    -> "
  SHX6_2 = SHX0_2
  SHX5_2 = SHX5_2 .. SHX6_2
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = SHX1_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.emitNet
  SHX4_2 = "Reaper:executeCommand"
  SHX5_2 = SHX0_2
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = SHX1_2
  SHX3_2 = true
  SHX2_2(SHX3_2)
end
SHX18_1(SHX19_1, SHX20_1, SHX21_1)
SHX19_1 = SHX1_1
SHX18_1 = SHX1_1.onNet
SHX20_1 = "Reaper:consoleUpdate"
function SHX21_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX1_2 = SHX0_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Console message received from server. Message: %s"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX0_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = "debug"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = SHX2_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.send
  SHX3_2 = "updateConsole"
  SHX4_2 = SHX0_2
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
SHX18_1(SHX19_1, SHX20_1, SHX21_1)
SHX19_1 = SHX1_1
SHX18_1 = SHX1_1.onNet
SHX20_1 = "Reaper:playerJoined"
function SHX21_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = "id:"
  SHX2_2 = SHX0_2.source
  SHX1_2 = SHX1_2 .. SHX2_2
  SHX2_2 = SHX16_1
  SHX2_2[SHX1_2] = SHX0_2
  SHX1_2 = SHX2_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.send
  SHX3_2 = "playerJoined"
  SHX4_2 = SHX0_2
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
SHX18_1(SHX19_1, SHX20_1, SHX21_1)
SHX19_1 = SHX1_1
SHX18_1 = SHX1_1.onNet
SHX20_1 = "Reaper:playerLeft"
function SHX21_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX2_2 = SHX0_2
  SHX1_2 = SHX0_2.split
  SHX3_2 = ":"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = SHX1_2[2]
  SHX2_2 = table
  SHX2_2 = SHX2_2.filter
  SHX3_2 = SHX16_1
  function SHX4_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3
    SHX1_3 = SHX6_1
    SHX2_3 = SHX0_3.source
    SHX1_3 = SHX1_3(SHX2_3)
    SHX2_3 = SHX6_1
    SHX3_3 = SHX1_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX1_3 = SHX1_3 ~= SHX2_3
    return SHX1_3
  end
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX16_1 = SHX2_2
  SHX2_2 = SHX2_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.send
  SHX4_2 = "playerLeft"
  SHX5_2 = SHX0_2
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
end
SHX18_1(SHX19_1, SHX20_1, SHX21_1)
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX1_2 = SetTextScale
  SHX2_2 = 0.3
  SHX3_2 = 0.3
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = SetTextFont
  SHX2_2 = 0
  SHX1_2(SHX2_2)
  SHX1_2 = SetTextColour
  SHX2_2 = 255
  SHX3_2 = 255
  SHX4_2 = 255
  SHX5_2 = 255
  SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2)
  SHX1_2 = SetTextDropshadow
  SHX2_2 = 0
  SHX3_2 = 0
  SHX4_2 = 0
  SHX5_2 = 0
  SHX6_2 = 255
  SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  SHX1_2 = SetTextDropShadow
  SHX1_2()
  SHX1_2 = SetTextOutline
  SHX1_2()
  SHX1_2 = AddTextEntry
  SHX2_2 = "test"
  SHX3_2 = SHX0_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = SetTextEntry
  SHX2_2 = "test"
  SHX3_2 = SHX0_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = SetTextCentre
  SHX2_2 = 1
  SHX1_2(SHX2_2)
  SHX1_2 = DrawText
  SHX2_2 = 0.5
  SHX3_2 = 0.5
  SHX1_2(SHX2_2, SHX3_2)
end
SHX19_1 = false
SHX21_1 = SHX1_1
SHX20_1 = SHX1_1.onNet
SHX22_1 = "Reaper:ToggleEntityInfo"
function SHX23_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX19_1
  SHX0_2 = not SHX0_2
  SHX19_1 = SHX0_2
  SHX0_2 = SHX14_1
  function SHX1_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3
    SHX0_3 = {}
    while true do
      SHX1_3 = SHX19_1
      if not SHX1_3 then
        break
      end
      SHX1_3 = SHX10_1
      SHX2_3 = SHX11_1
      SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX2_3()
      SHX1_3, SHX2_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
      if SHX1_3 then
        SHX3_3 = SHX12_1
        SHX4_3 = SHX2_3
        SHX3_3 = SHX3_3(SHX4_3)
        if SHX3_3 then
          SHX3_3 = SHX13_1
          SHX4_3 = SHX2_3
          SHX3_3 = SHX3_3(SHX4_3)
          SHX4_3 = SHX0_3[SHX3_3]
          if nil == SHX4_3 then
            SHX4_3 = SHX9_1
            SHX5_3 = {}
            SHX5_3.net_id = SHX3_3
            SHX6_3 = SHX1_1
            SHX7_3 = SHX6_3
            SHX6_3 = SHX6_3.await
            SHX8_3 = "requestEntityInfo"
            SHX9_3 = SHX3_3
            SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3)
            if not SHX6_3 then
              SHX6_3 = "unknown"
            end
            SHX5_3.spawn_data = SHX6_3
            SHX4_3 = SHX4_3(SHX5_3)
            SHX0_3[SHX3_3] = SHX4_3
          end
          SHX4_3 = SHX18_1
          SHX5_3 = SHX0_3[SHX3_3]
          SHX4_3(SHX5_3)
          SHX4_3 = print
          SHX5_3 = SHX0_3[SHX3_3]
          SHX4_3(SHX5_3)
        else
          SHX3_3 = SHX18_1
          SHX4_3 = "This entity was created by %s is not networked (only you see this entity)"
          SHX5_3 = SHX4_3
          SHX4_3 = SHX4_3.format
          SHX6_3 = GetEntityScript
          SHX7_3 = SHX2_3
          SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX6_3(SHX7_3)
          SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
          SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
        end
      end
      SHX3_3 = Wait
      SHX4_3 = 1
      SHX3_3(SHX4_3)
    end
  end
  SHX0_2(SHX1_2)
end
SHX20_1(SHX21_1, SHX22_1, SHX23_1)
