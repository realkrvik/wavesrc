-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1
SHX0_1 = HTTP
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.listen
SHX2_1 = "/stream-view/start"
function SHX3_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX2_2 = json
  SHX2_2 = SHX2_2.decode
  SHX3_2 = SHX0_2.body
  SHX2_2 = SHX2_2(SHX3_2)
  if nil == SHX2_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = {}
    SHX4_2.error = true
    SHX4_2.message = "Invalid Body"
    return SHX3_2(SHX4_2)
  end
  SHX3_2 = Player
  SHX4_2 = SHX2_2.target
  if not SHX4_2 then
    SHX4_2 = 0
  end
  SHX3_2 = SHX3_2(SHX4_2)
  if not SHX3_2 then
    SHX4_2 = SHX1_2.send
    SHX5_2 = {}
    SHX5_2.error = true
    SHX5_2.message = "invalid target"
    return SHX4_2(SHX5_2)
  end
  SHX5_2 = SHX3_2
  SHX4_2 = SHX3_2.getGuid
  SHX4_2 = SHX4_2(SHX5_2)
  SHX6_2 = SHX3_2
  SHX5_2 = SHX3_2.rpc_await
  SHX7_2 = "stream_cast_request"
  SHX8_2 = {}
  SHX9_2 = SHX4_2
  SHX8_2[1] = SHX9_2
  SHX9_2 = 3
  SHX10_2 = 5000
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  if "RESPONSE_FAILED" == SHX5_2 then
    SHX6_2 = SHX1_2.send
    SHX7_2 = {}
    SHX7_2.error = true
    SHX7_2.message = "client did not respond with session"
    return SHX6_2(SHX7_2)
  end
  SHX6_2 = SHX1_2.send
  SHX7_2 = json
  SHX7_2 = SHX7_2.encode
  SHX8_2 = {}
  SHX8_2.error = false
  SHX8_2.response = SHX4_2
  SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX7_2(SHX8_2)
  SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
end
SHX0_1(SHX1_1, SHX2_1, SHX3_1)
