-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = Falcon
Falcon = SHX0_1
SHX0_1 = Falcon
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.new
SHX2_1 = "Explosions"
SHX3_1 = {}
SHX3_1.max_history_size = 60
SHX3_1.interval_seconds = 60
SHX3_1.track_subtypes = true
SHX3_1.track_sources = true
SHX0_1 = SHX0_1(SHX1_1, SHX2_1, SHX3_1)
SHX1_1 = {}
SHX1_1.GRENADE = 0
SHX1_1.GRENADELAUNCHER = 1
SHX1_1.STICKYBOMB = 2
SHX1_1.MOLOTOV = 3
SHX1_1.ROCKET = 4
SHX1_1.TANKSHELL = 5
SHX1_1.HI_OCTANE = 6
SHX1_1.CAR = 7
SHX1_1.PLANE = 8
SHX1_1.PETROL_PUMP = 9
SHX1_1.BIKE = 10
SHX1_1.DIR_STEAM = 11
SHX1_1.DIR_FLAME = 12
SHX1_1.DIR_WATER_HYDRANT = 13
SHX1_1.DIR_GAS_CANISTER = 14
SHX1_1.BOAT = 15
SHX1_1.SHIP_DESTROY = 16
SHX1_1.TRUCK = 17
SHX1_1.BULLET = 18
SHX1_1.SMOKEGRENADELAUNCHER = 19
SHX1_1.SMOKEGRENADE = 20
SHX1_1.BZGAS = 21
SHX1_1.FLARE = 22
SHX1_1.GAS_CANISTER = 23
SHX1_1.EXTINGUISHER = 24
SHX1_1.EXP_TAG_TRAIN = 26
SHX1_1.EXP_TAG_BARREL = 27
SHX1_1.EXP_TAG_PROPANE = 28
SHX1_1.EXP_TAG_BLIMP = 29
SHX1_1.EXP_TAG_DIR_FLAME_EXPLODE = 30
SHX1_1.EXP_TAG_TANKER = 31
SHX1_1.PLANE_ROCKET = 32
SHX1_1.EXP_TAG_VEHICLE_BULLET = 33
SHX1_1.EXP_TAG_GAS_TANK = 34
SHX1_1.EXP_TAG_BIRD_CRAP = 35
SHX1_1.EXP_TAG_RAILGUN = 36
SHX1_1.EXP_TAG_BLIMP2 = 37
SHX1_1.EXP_TAG_FIREWORK = 38
SHX1_1.EXP_TAG_SNOWBALL = 39
SHX1_1.EXP_TAG_PROXMINE = 40
SHX1_1.EXP_TAG_VALKYRIE_CANNON = 41
SHX1_1.EXP_TAG_AIR_DEFENCE = 42
SHX1_1.EXP_TAG_PIPEBOMB = 43
SHX1_1.EXP_TAG_VEHICLEMINE = 44
SHX1_1.EXP_TAG_EXPLOSIVEAMMO = 45
SHX1_1.EXP_TAG_APCSHELL = 46
SHX1_1.EXP_TAG_BOMB_CLUSTER = 47
SHX1_1.EXP_TAG_BOMB_GAS = 48
SHX1_1.EXP_TAG_BOMB_INCENDIARY = 49
SHX1_1.EXP_TAG_BOMB_STANDARD = 50
SHX1_1.EXP_TAG_TORPEDO = 51
SHX1_1.EXP_TAG_TORPEDO_UNDERWATER = 52
SHX1_1.EXP_TAG_BOMBUSHKA_CANNON = 53
SHX1_1.EXP_TAG_BOMB_CLUSTER_SECONDARY = 54
SHX1_1.EXP_TAG_HUNTER_BARRAGE = 55
SHX1_1.EXP_TAG_HUNTER_CANNON = 56
SHX1_1.EXP_TAG_ROGUE_CANNON = 57
SHX1_1.EXP_TAG_MINE_UNDERWATER = 58
SHX1_1.EXP_TAG_ORBITAL_CANNON = 59
SHX1_1.EXP_TAG_BOMB_STANDARD_WIDE = 60
SHX1_1.EXP_TAG_EXPLOSIVEAMMO_SHOTGUN = 61
SHX1_1.EXP_TAG_OPPRESSOR2_CANNON = 62
SHX1_1.EXP_TAG_MORTAR_KINETIC = 63
SHX1_1.EXP_TAG_VEHICLEMINE_KINETIC = 64
SHX1_1.EXP_TAG_VEHICLEMINE_EMP = 65
SHX1_1.EXP_TAG_VEHICLEMINE_SPIKE = 66
SHX1_1.EXP_TAG_VEHICLEMINE_SLICK = 67
SHX1_1.EXP_TAG_VEHICLEMINE_TAR = 68
SHX1_1.EXP_TAG_SCRIPT_DRONE = 69
SHX1_1.EXP_TAG_RAYGUN = 70
SHX1_1.EXP_TAG_BURIEDMINE = 71
SHX1_1.EXP_TAG_SCRIPT_MISSILE = 72
SHX1_1.EXP_TAG_RCTANK_ROCKET = 73
SHX1_1.EXP_TAG_BOMB_WATER = 74
SHX1_1.EXP_TAG_BOMB_WATER_SECONDARY = 75
SHX1_1.EXP_TAG_FLASHGRENADE = 78
SHX1_1.EXP_TAG_STUNGRENADE = 79
SHX1_1.EXP_TAG_SCRIPT_MISSILE_LARGE = 81
SHX1_1.EXP_TAG_SUBMARINE_BIG = 82
SHX2_1 = false
SHX3_1 = false
SHX4_1 = false
SHX5_1 = false
SHX6_1 = false
SHX7_1 = false
SHX8_1 = {}
SHX9_1 = {}
SHX10_1 = false
SHX11_1 = 0
SHX12_1 = nil
SHX13_1 = 0
SHX14_1 = RPC
SHX15_1 = SHX14_1
SHX14_1 = SHX14_1.on
SHX16_1 = "configUpdated"
function SHX17_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX0_2 = Settings
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX0_2 = SHX0_2(SHX1_2)
  SHX1_2 = Cache
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.get
  SHX3_2 = "gameType"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX2_2 = SHX0_2.explosionRules
  SHX2_2 = SHX2_2.logExplosionsToConsole
  SHX2_1 = SHX2_2
  SHX2_2 = SHX0_2.explosionRules
  SHX2_2 = SHX2_2.blockAllExplosions
  SHX3_1 = SHX2_2
  SHX2_2 = SHX0_2.explosionRules
  SHX2_2 = SHX2_2.blockInaudibleExplosions
  SHX4_1 = SHX2_2
  SHX2_2 = SHX0_2.explosionRules
  SHX2_2 = SHX2_2.blockInvisibleExplosions
  SHX5_1 = SHX2_2
  SHX2_2 = SHX0_2.explosionRules
  SHX2_2 = SHX2_2.blockUnknownExplosions
  SHX6_1 = SHX2_2
  SHX2_2 = GetConvar
  SHX3_2 = "reaper_auto_explosion_whitelist"
  SHX4_2 = "false"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = "true" == SHX2_2
  SHX7_1 = SHX2_2
  SHX2_2 = SetConvar
  SHX3_2 = "sv_enableNetworkedPhoneExplosions"
  SHX4_2 = tostring
  SHX5_2 = SHX3_1
  SHX5_2 = not SHX5_2
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX4_2(SHX5_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  SHX2_2 = json
  SHX2_2 = SHX2_2.encode
  SHX3_2 = SHX8_1
  SHX2_2 = SHX2_2(SHX3_2)
  SHX2_2 = #SHX2_2
  if 2 == SHX2_2 then
    SHX2_2 = json
    SHX2_2 = SHX2_2.decode
    SHX3_2 = HTTP
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.await
    SHX5_2 = "https://api.reaperac.com/api/v1/data/explosions?game="
    SHX6_2 = SHX1_2
    SHX5_2 = SHX5_2 .. SHX6_2
    SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
    SHX3_2 = SHX3_2.body
    if not SHX3_2 then
      SHX3_2 = "{}"
    end
    SHX2_2 = SHX2_2(SHX3_2)
    SHX8_1 = SHX2_2
  end
  SHX2_2 = {}
  SHX9_1 = SHX2_2
  SHX2_2 = pairs
  SHX3_2 = SHX0_2.explosionRules
  SHX3_2 = SHX3_2.blacklisted
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX8_2 = tostring
    SHX9_2 = SHX7_2.type
    SHX8_2 = SHX8_2(SHX9_2)
    SHX9_2 = SHX9_1
    SHX9_2 = SHX9_2[SHX8_2]
    if nil == SHX9_2 then
      SHX9_2 = SHX9_1
      SHX10_2 = {}
      SHX9_2[SHX8_2] = SHX10_2
    end
    SHX9_2 = table
    SHX9_2 = SHX9_2.insert
    SHX10_2 = SHX9_1
    SHX10_2 = SHX10_2[SHX8_2]
    SHX11_2 = {}
    SHX12_2 = SHX7_2.action
    SHX11_2.action = SHX12_2
    SHX9_2(SHX10_2, SHX11_2)
  end
end
SHX14_1(SHX15_1, SHX16_1, SHX17_1)
function SHX14_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = tostring
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = SHX8_1
  SHX1_2 = SHX2_2[SHX1_2]
  if not SHX1_2 then
    SHX1_2 = "Type_"
    SHX2_2 = tostring
    SHX3_2 = SHX0_2
    SHX2_2 = SHX2_2(SHX3_2)
    SHX1_2 = SHX1_2 .. SHX2_2
  end
  return SHX1_2
end
SHX15_1 = RPC
SHX16_1 = SHX15_1
SHX15_1 = SHX15_1.on
SHX17_1 = "reaperStarted"
function SHX18_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX0_2 = Cache
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX2_2 = "gameType"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Explosion monitoring system initialized (Falcon-powered)"
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.onLocal
  SHX3_2 = "explosionEvent"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3
    SHX2_3 = SHX1_3.explosionType
    if 13 == SHX2_3 then
      SHX2_3 = Cache
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.set
      SHX4_3 = "last_water_hydrant_hit"
      SHX5_3 = GetGameTimer
      SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3 = SHX5_3()
      SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3)
    end
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX0_3 = SHX2_3
    if nil == SHX0_3 then
      SHX2_3 = CancelEvent
      return SHX2_3()
    end
    SHX2_3 = tostring
    SHX3_3 = SHX1_3.explosionType
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX8_1
    SHX2_3 = SHX3_3[SHX2_3]
    if not SHX2_3 then
      SHX2_3 = SHX1_3.explosionType
    end
    SHX3_3 = false
    SHX4_3 = SHX3_1
    if not SHX4_3 then
      SHX5_3 = SHX0_3
      SHX4_3 = SHX0_3.getMeta
      SHX6_3 = "explosion_ratelimit"
      SHX7_3 = 0
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      if not (SHX4_3 > 0) then
        goto SHX_LABEL_40
      end
    end
    SHX4_3 = CancelEvent
    SHX4_3()
    SHX3_3 = true
    -- [FIX IF ERROR] Move ::SHX_LABEL_40:: outside nested blocks until all 'goto SHX_LABEL_40' can see it
    ::SHX_LABEL_40::
    SHX5_3 = SHX0_3
    SHX4_3 = SHX0_3.NewLog
    SHX6_3 = "^3%s ^7(^3id:%s^7) just spawned a new explosion. Explosion Type: ^3%s^7"
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.format
    SHX9_3 = SHX0_3
    SHX8_3 = SHX0_3.getName
    SHX8_3 = SHX8_3(SHX9_3)
    SHX10_3 = SHX0_3
    SHX9_3 = SHX0_3.getId
    SHX9_3 = SHX9_3(SHX10_3)
    SHX10_3 = SHX2_3
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
    SHX7_3 = "info"
    SHX8_3 = "explosions"
    SHX9_3 = {}
    SHX9_3.explosionName = SHX2_3
    SHX10_3 = SHX1_3.explosionType
    SHX9_3.explosionType = SHX10_3
    SHX10_3 = SHX2_1
    SHX10_3 = not SHX10_3
    SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
    SHX4_3 = SHX6_1
    if SHX4_3 then
      SHX4_3 = tostring
      SHX5_3 = SHX1_3.explosionType
      SHX4_3 = SHX4_3(SHX5_3)
      SHX5_3 = SHX8_1
      SHX4_3 = SHX5_3[SHX4_3]
      if nil == SHX4_3 then
        SHX4_3 = CancelEvent
        SHX4_3()
        SHX3_3 = true
        SHX5_3 = SHX0_3
        SHX4_3 = SHX0_3.NewLog
        SHX6_3 = "^3%s ^7(^3id:%s^7) just spawned an unknown explosion. Hash: ^3%s^7"
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.format
        SHX9_3 = SHX0_3
        SHX8_3 = SHX0_3.getName
        SHX8_3 = SHX8_3(SHX9_3)
        SHX10_3 = SHX0_3
        SHX9_3 = SHX0_3.getId
        SHX9_3 = SHX9_3(SHX10_3)
        SHX10_3 = SHX1_3.explosionType
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
        SHX7_3 = "info"
        SHX8_3 = "explosion"
        SHX9_3 = {}
        SHX9_3.explosionName = SHX2_3
        SHX10_3 = SHX1_3.explosionType
        SHX9_3.explosionType = SHX10_3
        SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
      end
    end
    SHX4_3 = SHX1_3.isInvisible
    if SHX4_3 then
      SHX4_3 = SHX5_1
      if SHX4_3 then
        SHX4_3 = CancelEvent
        SHX4_3()
        SHX3_3 = true
        SHX5_3 = SHX0_3
        SHX4_3 = SHX0_3.NewLog
        SHX6_3 = "^3%s ^7(^3id:%s^7) just spawned an invisible explosion. Explosion Type: ^3%s^7"
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.format
        SHX9_3 = SHX0_3
        SHX8_3 = SHX0_3.getName
        SHX8_3 = SHX8_3(SHX9_3)
        SHX10_3 = SHX0_3
        SHX9_3 = SHX0_3.getId
        SHX9_3 = SHX9_3(SHX10_3)
        SHX10_3 = SHX2_3
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
        SHX7_3 = "info"
        SHX8_3 = "explosion"
        SHX9_3 = {}
        SHX9_3.explosionName = SHX2_3
        SHX10_3 = SHX1_3.explosionType
        SHX9_3.explosionType = SHX10_3
        SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
      end
    end
    SHX4_3 = SHX1_3.isAudible
    if false == SHX4_3 then
      SHX4_3 = SHX4_1
      if SHX4_3 then
        SHX4_3 = CancelEvent
        SHX4_3()
        SHX3_3 = true
        SHX5_3 = SHX0_3
        SHX4_3 = SHX0_3.NewLog
        SHX6_3 = "^3%s ^7(^3id:%s^7) just spawned an inaudible explosion. Explosion Type: ^3%s^7"
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.format
        SHX9_3 = SHX0_3
        SHX8_3 = SHX0_3.getName
        SHX8_3 = SHX8_3(SHX9_3)
        SHX10_3 = SHX0_3
        SHX9_3 = SHX0_3.getId
        SHX9_3 = SHX9_3(SHX10_3)
        SHX10_3 = SHX2_3
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
        SHX7_3 = "info"
        SHX8_3 = "explosion"
        SHX9_3 = {}
        SHX9_3.explosionName = SHX2_3
        SHX10_3 = SHX1_3.explosionType
        SHX9_3.explosionType = SHX10_3
        SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
      end
    end
    SHX4_3 = SHX7_1
    if SHX4_3 then
      SHX4_3 = WeaponsList
      SHX4_3 = SHX4_3.ExplosiveWeapons
      SHX5_3 = SHX1_3.explosionType
      SHX5_3 = SHX4_3[SHX5_3]
      if SHX5_3 then
        SHX7_3 = SHX0_3
        SHX6_3 = SHX0_3.getWeapon
        SHX6_3 = SHX6_3(SHX7_3)
        SHX6_3 = SHX5_3[SHX6_3]
        if nil == SHX6_3 then
          SHX6_3 = CancelEvent
          SHX6_3()
          SHX3_3 = true
          SHX7_3 = SHX0_3
          SHX6_3 = SHX0_3.NewLog
          SHX8_3 = "^3%s ^7(^3id:%s^7) attempted to spawn an explosion without authorization. Explosion Type: ^3%s^7"
          SHX9_3 = SHX8_3
          SHX8_3 = SHX8_3.format
          SHX11_3 = SHX0_3
          SHX10_3 = SHX0_3.getName
          SHX10_3 = SHX10_3(SHX11_3)
          SHX12_3 = SHX0_3
          SHX11_3 = SHX0_3.getId
          SHX11_3 = SHX11_3(SHX12_3)
          SHX12_3 = SHX2_3
          SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3)
          SHX9_3 = "warn"
          SHX10_3 = "explosion"
          SHX11_3 = {}
          SHX11_3.explosionName = SHX2_3
          SHX12_3 = SHX1_3.explosionType
          SHX11_3.explosionType = SHX12_3
          SHX11_3.explosionEvent = SHX1_3
          SHX13_3 = SHX0_3
          SHX12_3 = SHX0_3.getWeapon
          SHX12_3 = SHX12_3(SHX13_3)
          SHX11_3.current_weapon = SHX12_3
          SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
        end
      else
        SHX6_3 = CancelEvent
        SHX6_3()
        SHX3_3 = true
      end
    end
    SHX4_3 = pairs
    SHX5_3 = tostring
    SHX6_3 = SHX1_3.explosionType
    SHX5_3 = SHX5_3(SHX6_3)
    SHX6_3 = SHX9_1
    SHX5_3 = SHX6_3[SHX5_3]
    if not SHX5_3 then
      SHX5_3 = {}
    end
    SHX4_3, SHX5_3, SHX6_3, SHX7_3 = SHX4_3(SHX5_3)
    for SHX8_3, SHX9_3 in SHX4_3, SHX5_3, SHX6_3, SHX7_3 do
      SHX10_3 = CancelEvent
      SHX10_3()
      SHX3_3 = true
      SHX10_3 = SHX9_3.action
      if "none" ~= SHX10_3 then
        SHX10_3 = RPC
        SHX11_3 = SHX10_3
        SHX10_3 = SHX10_3.emitLocal
        SHX12_3 = "Reaper:NewDetection"
        SHX13_3 = {}
        SHX13_3.type = "blacklistedExplosion"
        SHX14_3 = {}
        SHX14_3.rule = SHX9_3
        SHX15_3 = SHX1_3.explosionType
        SHX14_3.explosion = SHX15_3
        SHX14_3.name = SHX2_3
        SHX13_3.data = SHX14_3
        SHX14_3 = {}
        SHX15_3 = SHX2_3
        SHX14_3[1] = SHX15_3
        SHX13_3.params = SHX14_3
        SHX14_3 = SHX9_3.action
        SHX13_3.action = SHX14_3
        SHX15_3 = SHX0_3
        SHX14_3 = SHX0_3.getId
        SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3 = SHX14_3(SHX15_3)
        SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3)
      end
    end
    SHX4_3 = SHX0_1
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.track
    SHX6_3 = SHX14_1
    SHX7_3 = SHX1_3.explosionType
    SHX6_3 = SHX6_3(SHX7_3)
    SHX8_3 = SHX0_3
    SHX7_3 = SHX0_3.getId
    SHX7_3 = SHX7_3(SHX8_3)
    SHX8_3 = SHX3_3
    SHX9_3 = {}
    SHX11_3 = SHX0_3
    SHX10_3 = SHX0_3.getName
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.player_name = SHX10_3
    SHX10_3 = SHX1_3.explosionType
    SHX9_3.explosion_type_id = SHX10_3
    SHX10_3 = os
    SHX10_3 = SHX10_3.time
    SHX10_3 = SHX10_3()
    SHX9_3.timestamp = SHX10_3
    SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX4_3 = GetConvar
    SHX5_3 = "reaper_auto_ai_explosions"
    SHX6_3 = "false"
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX4_3 = "true" == SHX4_3
    if SHX4_3 then
      SHX5_3 = os
      SHX5_3 = SHX5_3.time
      SHX5_3 = SHX5_3()
      SHX6_3 = nil
      SHX7_3 = SHX13_1
      if SHX5_3 ~= SHX7_3 then
        SHX7_3 = SHX0_1
        SHX8_3 = SHX7_3
        SHX7_3 = SHX7_3.getStatistics
        SHX7_3 = SHX7_3(SHX8_3)
        SHX6_3 = SHX7_3
        SHX12_1 = SHX6_3
        SHX13_1 = SHX5_3
      else
        SHX6_3 = SHX12_1
      end
      if SHX6_3 then
        SHX7_3 = SHX6_3.totals
        SHX7_3 = SHX7_3.uptime_minutes
        if SHX7_3 > 10 then
          SHX7_3 = SHX6_3.averages
          SHX7_3 = SHX7_3.last_2_min
          if not SHX7_3 then
            SHX7_3 = 0
          end
          SHX8_3 = SHX6_3.averages
          SHX8_3 = SHX8_3.median_last_hour
          if not SHX8_3 then
            SHX8_3 = 0
          end
          SHX9_3 = SHX6_3.current_interval
          SHX9_3 = SHX9_3.count
          SHX10_3 = math
          SHX10_3 = SHX10_3.min
          SHX11_3 = 2
          SHX12_3 = SHX6_3.history
          SHX12_3 = #SHX12_3
          if not SHX12_3 then
            SHX12_3 = 0
          end
          SHX10_3 = SHX10_3(SHX11_3, SHX12_3)
          SHX11_3 = math
          SHX11_3 = SHX11_3.max
          SHX12_3 = 1
          SHX13_3 = SHX6_3.history
          SHX13_3 = #SHX13_3
          if not SHX13_3 then
            SHX13_3 = 0
          end
          SHX13_3 = SHX13_3 - SHX10_3
          SHX13_3 = SHX13_3 + 1
          SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
          SHX12_3 = SHX6_3.history
          SHX12_3 = #SHX12_3
          if not SHX12_3 then
            SHX12_3 = 0
          end
          SHX13_3 = 1
          for SHX14_3 = SHX11_3, SHX12_3, SHX13_3 do
            SHX15_3 = SHX6_3.history
            SHX15_3 = SHX15_3[SHX14_3]
            SHX15_3 = SHX15_3.count
            if not SHX15_3 then
              SHX15_3 = 0
            end
            SHX9_3 = SHX9_3 + SHX15_3
          end
          SHX11_3 = 0
          if SHX8_3 > 0 then
            SHX12_3 = math
            SHX12_3 = SHX12_3.ceil
            SHX13_3 = math
            SHX13_3 = SHX13_3.min
            SHX14_3 = 2
            SHX15_3 = math
            SHX15_3 = SHX15_3.max
            SHX16_3 = 1
            SHX17_3 = SHX10_3 + 1
            SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3 = SHX15_3(SHX16_3, SHX17_3)
            SHX13_3 = SHX13_3(SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3)
            SHX13_3 = SHX8_3 * SHX13_3
            SHX12_3 = SHX12_3(SHX13_3)
            SHX13_3 = math
            SHX13_3 = SHX13_3.max
            SHX14_3 = 0
            SHX15_3 = SHX12_3 - SHX9_3
            SHX15_3 = SHX15_3 + 1
            SHX13_3 = SHX13_3(SHX14_3, SHX15_3)
            SHX11_3 = SHX13_3
          end
          SHX12_3 = "^2"
          SHX13_3 = "SAFE"
          if SHX7_3 > SHX8_3 then
            SHX12_3 = "^1"
            SHX13_3 = "BLOCKING"
          elseif SHX11_3 <= 5 then
            SHX12_3 = "^3"
            SHX13_3 = "WARNING"
          end
          SHX14_3 = Logger
          SHX15_3 = SHX14_3
          SHX14_3 = SHX14_3.log
          SHX16_3 = string
          SHX16_3 = SHX16_3.format
          SHX17_3 = "%s[Falcon AI] %s^7 | 2min avg: ^3%.2f^7/min | Hour median: ^3%.2f^7/min | Ratio: ^3%.2fx^7 | Until block: ^3%d^7 explosions"
          SHX18_3 = SHX12_3
          SHX19_3 = SHX13_3
          SHX20_3 = SHX7_3
          SHX21_3 = SHX8_3
          if SHX8_3 > 0 then
            SHX22_3 = SHX7_3 / SHX8_3
            if SHX22_3 then
              goto SHX_LABEL_382
            end
          end
          SHX22_3 = 0
          -- [FIX IF ERROR] Move ::SHX_LABEL_382:: outside nested blocks until all 'goto SHX_LABEL_382' can see it
          ::SHX_LABEL_382::
          SHX23_3 = SHX11_3
          SHX16_3 = SHX16_3(SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3)
          SHX17_3 = "info"
          SHX14_3(SHX15_3, SHX16_3, SHX17_3)
          if SHX8_3 > 0 and SHX7_3 > SHX8_3 then
            SHX14_3 = SHX10_1
            if not SHX14_3 then
              SHX14_3 = Logger
              SHX15_3 = SHX14_3
              SHX14_3 = SHX14_3.log
              SHX16_3 = "^1EXPLOSION ALERT: Last 2min avg (%.2f/min) exceeds hourly median (%.2f/min) by %.2fx!^7"
              SHX17_3 = SHX16_3
              SHX16_3 = SHX16_3.format
              SHX18_3 = SHX7_3
              SHX19_3 = SHX8_3
              SHX20_3 = SHX7_3 / SHX8_3
              SHX16_3 = SHX16_3(SHX17_3, SHX18_3, SHX19_3, SHX20_3)
              SHX17_3 = "warn"
              SHX14_3(SHX15_3, SHX16_3, SHX17_3)
              SHX14_3 = true
              SHX3_1 = SHX14_3
              SHX14_3 = true
              SHX10_1 = SHX14_3
              SHX14_3 = 0
              SHX11_1 = SHX14_3
              SHX14_3 = SetConvar
              SHX15_3 = "sv_enableNetworkedPhoneExplosions"
              SHX16_3 = "false"
              SHX14_3(SHX15_3, SHX16_3)
              SHX14_3 = Logger
              SHX15_3 = SHX14_3
              SHX14_3 = SHX14_3.log
              SHX16_3 = "^1[Falcon AI] INSTANTLY disabled all explosions due to spike detection (median-based)^7"
              SHX17_3 = "warn"
              SHX14_3(SHX15_3, SHX16_3, SHX17_3)
              SHX14_3 = RPC
              SHX15_3 = SHX14_3
              SHX14_3 = SHX14_3.emitLocal
              SHX16_3 = "Falcon:ExplosionAutoBlock"
              SHX17_3 = {}
              SHX17_3.reason = "anomaly_detected"
              SHX17_3.avg_2_min = SHX7_3
              SHX17_3.median_hour = SHX8_3
              SHX18_3 = SHX7_3 / SHX8_3
              SHX17_3.rate_multiplier = SHX18_3
              SHX17_3.action = "blocked"
              SHX17_3.response_time = "instant"
              SHX14_3(SHX15_3, SHX16_3, SHX17_3)
            end
            SHX14_3 = 0
            SHX11_1 = SHX14_3
          end
      end
      else
        SHX7_3 = Logger
        SHX8_3 = SHX7_3
        SHX7_3 = SHX7_3.log
        SHX9_3 = string
        SHX9_3 = SHX9_3.format
        SHX10_3 = "^6[Falcon AI] WARMING UP^7 | Uptime: ^3%d^7/10 minutes | Collecting baseline data..."
        if SHX6_3 then
          SHX11_3 = SHX6_3.totals
          SHX11_3 = SHX11_3.uptime_minutes
          if SHX11_3 then
            goto SHX_LABEL_448
          end
        end
        SHX11_3 = 0
        -- [FIX IF ERROR] Move ::SHX_LABEL_448:: outside nested blocks until all 'goto SHX_LABEL_448' can see it
        ::SHX_LABEL_448::
        SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
        SHX10_3 = "info"
        SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      end
    end
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.onLocal
  SHX3_2 = "startProjectileEvent"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = CancelEvent
      return SHX3_3()
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.NewLog
    SHX5_3 = "^3%s^7 (^3id:%s^7) just spawned a new projectile. Data: ^3%s^7"
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.format
    SHX8_3 = SHX2_3
    SHX7_3 = SHX2_3.getName
    SHX7_3 = SHX7_3(SHX8_3)
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getId
    SHX8_3 = SHX8_3(SHX9_3)
    SHX9_3 = json
    SHX9_3 = SHX9_3.encode
    SHX10_3 = SHX1_3
    SHX9_3, SHX10_3, SHX11_3 = SHX9_3(SHX10_3)
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    SHX6_3 = "warn"
    SHX7_3 = "projectiles"
    SHX8_3 = SHX1_3
    SHX9_3 = GetConvar
    SHX10_3 = "reaper_log_projectile_events"
    SHX11_3 = "false"
    SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
    SHX9_3 = not SHX9_3
    SHX9_3 = "true" == SHX9_3
    SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX3_3 = SHX1_3.weaponHash
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.getWeapon
    SHX4_3 = SHX4_3(SHX5_3)
    if SHX3_3 ~= SHX4_3 then
      SHX3_3 = GetConvar
      SHX4_3 = "reaper_projectile_missmatch_blocks"
      SHX5_3 = "true"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if "true" == SHX3_3 then
        SHX4_3 = SHX2_3
        SHX3_3 = SHX2_3.NewLog
        SHX5_3 = "^3%s^7 (^3id:%s^7) just spawned a new projectile but was blocked due to weaponHash mismatch. Projectile: ^3%s^7"
        SHX6_3 = SHX5_3
        SHX5_3 = SHX5_3.format
        SHX8_3 = SHX2_3
        SHX7_3 = SHX2_3.getName
        SHX7_3 = SHX7_3(SHX8_3)
        SHX9_3 = SHX2_3
        SHX8_3 = SHX2_3.getId
        SHX8_3 = SHX8_3(SHX9_3)
        SHX9_3 = SHX1_3.weaponHash
        SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3)
        SHX6_3 = "warn"
        SHX7_3 = "projectiles"
        SHX8_3 = SHX1_3
        SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3)
        SHX3_3 = CancelEvent
        return SHX3_3()
      end
    end
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
SHX15_1(SHX16_1, SHX17_1, SHX18_1)
SHX16_1 = SHX0_1
SHX15_1 = SHX0_1.registerHTTPEndpoints
SHX17_1 = "/explosions"
SHX15_1(SHX16_1, SHX17_1)
SHX15_1 = Command
SHX16_1 = SHX15_1
SHX15_1 = SHX15_1.add
SHX17_1 = {}
SHX17_1.command = "explosionstats"
function SHX18_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.getStatistics
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = GetConvar
  SHX4_2 = "reaper_auto_ai_explosions"
  SHX5_2 = "false"
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX3_2 = "true" == SHX3_2
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "=== Explosion Statistics ==="
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Total Explosions: ^3%d^7"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.count
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Total Blocked: ^3%d^7 (%s)"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.blocked
  SHX9_2 = SHX2_2.totals
  SHX9_2 = SHX9_2.block_rate
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Total Allowed: ^3%d^7"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.allowed
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Server Uptime: ^3%d^7 minutes (^3%s^7 hours)"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.uptime_minutes
  SHX9_2 = SHX2_2.totals
  SHX9_2 = SHX9_2.uptime_hours
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Unique Types: ^3%d^7 | Unique Players: ^3%d^7"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.unique_subtypes
  SHX9_2 = SHX2_2.totals
  SHX9_2 = SHX9_2.unique_sources
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Current Minute: ^3%d^7 explosions (^3%d^7 blocked)"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX2_2.current_interval
  SHX8_2 = SHX8_2.count
  SHX9_2 = SHX2_2.current_interval
  SHX9_2 = SHX9_2.blocked
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Average per Minute: ^3%s^7 explosions"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX2_2.averages
  SHX8_2 = SHX8_2.per_minute
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Last 5 Minutes: ^3%d^7 explosions (^3%d^7 blocked)"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX2_2.last_intervals
  SHX8_2 = SHX8_2.count
  SHX9_2 = SHX2_2.last_intervals
  SHX9_2 = SHX9_2.blocked
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = ""
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "=== Falcon AI Protection Status ==="
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "AI Protection: %s"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  if SHX3_2 then
    SHX8_2 = "^2ENABLED^7"
    if SHX8_2 then
      goto SHX_LABEL_119
    end
  end
  SHX8_2 = "^1DISABLED^7"
  -- [FIX IF ERROR] Move ::SHX_LABEL_119:: outside nested blocks until all 'goto SHX_LABEL_119' can see it
  ::SHX_LABEL_119::
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Auto-Blocked: %s"
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.format
  SHX8_2 = SHX10_1
  if SHX8_2 then
    SHX8_2 = "^1YES^7"
    if SHX8_2 then
      goto SHX_LABEL_133
    end
  end
  SHX8_2 = "^2NO^7"
  -- [FIX IF ERROR] Move ::SHX_LABEL_133:: outside nested blocks until all 'goto SHX_LABEL_133' can see it
  ::SHX_LABEL_133::
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = SHX2_2.totals
  SHX4_2 = SHX4_2.uptime_minutes
  if SHX4_2 >= 10 then
    SHX4_2 = SHX2_2.averages
    SHX4_2 = SHX4_2.last_2_min
    if not SHX4_2 then
      SHX4_2 = 0
    end
    SHX5_2 = SHX2_2.averages
    SHX5_2 = SHX5_2.median_last_hour
    if not SHX5_2 then
      SHX5_2 = 0
    end
    if SHX5_2 > 0 then
      SHX6_2 = SHX4_2 / SHX5_2
      if SHX6_2 then
        goto SHX_LABEL_157
      end
    end
    SHX6_2 = 0
    -- [FIX IF ERROR] Move ::SHX_LABEL_157:: outside nested blocks until all 'goto SHX_LABEL_157' can see it
    ::SHX_LABEL_157::
    SHX7_2 = SHX2_2.current_interval
    SHX7_2 = SHX7_2.count
    SHX8_2 = math
    SHX8_2 = SHX8_2.min
    SHX9_2 = 2
    SHX10_2 = SHX2_2.history
    SHX10_2 = #SHX10_2
    if not SHX10_2 then
      SHX10_2 = 0
    end
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
    SHX9_2 = math
    SHX9_2 = SHX9_2.max
    SHX10_2 = 1
    SHX11_2 = SHX2_2.history
    SHX11_2 = #SHX11_2
    if not SHX11_2 then
      SHX11_2 = 0
    end
    SHX11_2 = SHX11_2 - SHX8_2
    SHX11_2 = SHX11_2 + 1
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
    SHX10_2 = SHX2_2.history
    SHX10_2 = #SHX10_2
    if not SHX10_2 then
      SHX10_2 = 0
    end
    SHX11_2 = 1
    for SHX12_2 = SHX9_2, SHX10_2, SHX11_2 do
      SHX13_2 = SHX2_2.history
      SHX13_2 = SHX13_2[SHX12_2]
      SHX13_2 = SHX13_2.count
      if not SHX13_2 then
        SHX13_2 = 0
      end
      SHX7_2 = SHX7_2 + SHX13_2
    end
    SHX9_2 = 0
    if SHX5_2 > 0 then
      SHX10_2 = math
      SHX10_2 = SHX10_2.ceil
      SHX11_2 = math
      SHX11_2 = SHX11_2.min
      SHX12_2 = 2
      SHX13_2 = math
      SHX13_2 = SHX13_2.max
      SHX14_2 = 1
      SHX15_2 = SHX8_2 + 1
      SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX13_2(SHX14_2, SHX15_2)
      SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
      SHX11_2 = SHX5_2 * SHX11_2
      SHX10_2 = SHX10_2(SHX11_2)
      SHX11_2 = math
      SHX11_2 = SHX11_2.max
      SHX12_2 = 0
      SHX13_2 = SHX10_2 - SHX7_2
      SHX13_2 = SHX13_2 + 1
      SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
      SHX9_2 = SHX11_2
    end
    SHX10_2 = Logger
    SHX11_2 = SHX10_2
    SHX10_2 = SHX10_2.log
    SHX12_2 = "Last 2 Minutes Avg: ^3%.2f^7/min"
    SHX13_2 = SHX12_2
    SHX12_2 = SHX12_2.format
    SHX14_2 = SHX4_2
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
    SHX13_2 = "info"
    SHX10_2(SHX11_2, SHX12_2, SHX13_2)
    SHX10_2 = Logger
    SHX11_2 = SHX10_2
    SHX10_2 = SHX10_2.log
    SHX12_2 = "Last Hour Median: ^3%.2f^7/min (outlier-resistant)"
    SHX13_2 = SHX12_2
    SHX12_2 = SHX12_2.format
    SHX14_2 = SHX5_2
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
    SHX13_2 = "info"
    SHX10_2(SHX11_2, SHX12_2, SHX13_2)
    SHX10_2 = Logger
    SHX11_2 = SHX10_2
    SHX10_2 = SHX10_2.log
    SHX12_2 = "Current Ratio: ^3%.2fx^7 (Threshold: ^3>1.00x^7)"
    SHX13_2 = SHX12_2
    SHX12_2 = SHX12_2.format
    SHX14_2 = SHX6_2
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
    SHX13_2 = "info"
    SHX10_2(SHX11_2, SHX12_2, SHX13_2)
    SHX10_2 = "^2SAFE^7"
    if SHX4_2 > SHX5_2 then
      SHX10_2 = "^1BLOCKING^7"
    elseif SHX9_2 <= 5 then
      SHX10_2 = "^3WARNING^7"
    end
    SHX11_2 = Logger
    SHX12_2 = SHX11_2
    SHX11_2 = SHX11_2.log
    SHX13_2 = "Status: %s"
    SHX14_2 = SHX13_2
    SHX13_2 = SHX13_2.format
    SHX15_2 = SHX10_2
    SHX13_2 = SHX13_2(SHX14_2, SHX15_2)
    SHX14_2 = "info"
    SHX11_2(SHX12_2, SHX13_2, SHX14_2)
    SHX11_2 = Logger
    SHX12_2 = SHX11_2
    SHX11_2 = SHX11_2.log
    SHX13_2 = "Explosions Until Block: ^3%d^7"
    SHX14_2 = SHX13_2
    SHX13_2 = SHX13_2.format
    SHX15_2 = SHX9_2
    SHX13_2 = SHX13_2(SHX14_2, SHX15_2)
    SHX14_2 = "info"
    SHX11_2(SHX12_2, SHX13_2, SHX14_2)
    SHX11_2 = SHX10_1
    if SHX11_2 then
      SHX11_2 = Logger
      SHX12_2 = SHX11_2
      SHX11_2 = SHX11_2.log
      SHX13_2 = "Stability Counter: ^3%d^7/180 seconds"
      SHX14_2 = SHX13_2
      SHX13_2 = SHX13_2.format
      SHX15_2 = SHX11_1
      SHX13_2 = SHX13_2(SHX14_2, SHX15_2)
      SHX14_2 = "info"
      SHX11_2(SHX12_2, SHX13_2, SHX14_2)
    end
  else
    SHX4_2 = Logger
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.log
    SHX6_2 = "^6Warming up... (%d/10 minutes)^7"
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.format
    SHX8_2 = SHX2_2.totals
    SHX8_2 = SHX8_2.uptime_minutes
    SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
    SHX7_2 = "info"
    SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  end
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = ""
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "=== Top 10 Explosion Types ==="
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = ipairs
  SHX5_2 = SHX2_2.top_subtypes
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
  for SHX8_2, SHX9_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
    if SHX8_2 > 10 then
      break
    end
    SHX10_2 = Logger
    SHX11_2 = SHX10_2
    SHX10_2 = SHX10_2.log
    SHX12_2 = "^3#%d^7 - %s: ^3%d^7 explosions (^3%d^7 blocked)"
    SHX13_2 = SHX12_2
    SHX12_2 = SHX12_2.format
    SHX14_2 = SHX8_2
    SHX15_2 = SHX9_2.name
    SHX16_2 = SHX9_2.count
    SHX17_2 = SHX9_2.blocked
    if not SHX17_2 then
      SHX17_2 = 0
    end
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
    SHX13_2 = "info"
    SHX10_2(SHX11_2, SHX12_2, SHX13_2)
  end
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = ""
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "=== Top 10 Players ==="
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = ipairs
  SHX5_2 = SHX2_2.top_sources
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
  for SHX8_2, SHX9_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
    if SHX8_2 > 10 then
      break
    end
    SHX10_2 = "Player "
    SHX11_2 = SHX9_2.id
    SHX10_2 = SHX10_2 .. SHX11_2
    SHX11_2 = Logger
    SHX12_2 = SHX11_2
    SHX11_2 = SHX11_2.log
    SHX13_2 = "^3#%d^7 - %s (ID: ^3%s^7): ^3%d^7 explosions (^3%d^7 blocked)"
    SHX14_2 = SHX13_2
    SHX13_2 = SHX13_2.format
    SHX15_2 = SHX8_2
    SHX16_2 = SHX10_2
    SHX17_2 = SHX9_2.id
    SHX18_2 = SHX9_2.count
    SHX19_2 = SHX9_2.blocked
    if not SHX19_2 then
      SHX19_2 = 0
    end
    SHX13_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    SHX14_2 = "info"
    SHX11_2(SHX12_2, SHX13_2, SHX14_2)
  end
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = ""
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = GetConvar
  SHX5_2 = "web_baseUrl"
  SHX6_2 = "http://your-server-ip:30120"
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = Logger
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.log
  SHX7_2 = "Access full stats at: ^3https://%s/ReaperV4/explosions/stats^7"
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.format
  SHX9_2 = SHX4_2
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX8_2 = "info"
  SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX5_2 = Logger
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.log
  SHX7_2 = "Access breakdown at: ^3https://%s/ReaperV4/explosions/subtypes^7"
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.format
  SHX9_2 = SHX4_2
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX8_2 = "info"
  SHX5_2(SHX6_2, SHX7_2, SHX8_2)
end
SHX17_1.callback = SHX18_1
SHX17_1.hidden = false
SHX18_1 = {}
SHX19_1 = "Manage Server"
SHX18_1[1] = SHX19_1
SHX17_1.permissions = SHX18_1
SHX15_1(SHX16_1, SHX17_1)
SHX15_1 = CreateThread
function SHX16_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX0_2 = Wait
  SHX1_2 = 300000
  SHX0_2(SHX1_2)
  while true do
    SHX0_2 = Wait
    SHX1_2 = 1000
    SHX0_2(SHX1_2)
    SHX0_2 = GetConvar
    SHX1_2 = "reaper_auto_ai_explosions"
    SHX2_2 = "false"
    SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
    SHX0_2 = "true" == SHX0_2
    if SHX0_2 then
      SHX1_2 = SHX10_1
      if SHX1_2 then
        SHX1_2 = SHX0_1
        SHX2_2 = SHX1_2
        SHX1_2 = SHX1_2.getStatistics
        SHX1_2 = SHX1_2(SHX2_2)
        if SHX1_2 then
          SHX2_2 = SHX1_2.totals
          SHX2_2 = SHX2_2.uptime_minutes
          if SHX2_2 > 10 then
            SHX2_2 = SHX1_2.averages
            SHX2_2 = SHX2_2.last_2_min
            if not SHX2_2 then
              SHX2_2 = 0
            end
            SHX3_2 = SHX1_2.averages
            SHX3_2 = SHX3_2.median_last_hour
            if not SHX3_2 then
              SHX3_2 = 0
            end
            SHX4_2 = SHX2_2 <= SHX3_2 or SHX2_2 < 1.0
            if SHX4_2 then
              SHX5_2 = SHX11_1
              SHX5_2 = SHX5_2 + 1
              SHX11_1 = SHX5_2
              SHX5_2 = SHX11_1
              SHX6_2 = 180
              if SHX5_2 >= SHX6_2 then
                SHX5_2 = false
                SHX3_1 = SHX5_2
                SHX5_2 = false
                SHX10_1 = SHX5_2
                SHX5_2 = 0
                SHX11_1 = SHX5_2
                SHX5_2 = SetConvar
                SHX6_2 = "sv_enableNetworkedPhoneExplosions"
                SHX7_2 = "true"
                SHX5_2(SHX6_2, SHX7_2)
                SHX5_2 = Logger
                SHX6_2 = SHX5_2
                SHX5_2 = SHX5_2.log
                SHX7_2 = "^2[Falcon AI] Automatically re-enabled explosions - rate normalized^7"
                SHX8_2 = "info"
                SHX5_2(SHX6_2, SHX7_2, SHX8_2)
                SHX5_2 = RPC
                SHX6_2 = SHX5_2
                SHX5_2 = SHX5_2.emitLocal
                SHX7_2 = "Falcon:ExplosionAutoBlock"
                SHX8_2 = {}
                SHX8_2.reason = "rate_normalized"
                SHX8_2.avg_2_min = SHX2_2
                SHX8_2.median_hour = SHX3_2
                SHX8_2.action = "unblocked"
                SHX5_2(SHX6_2, SHX7_2, SHX8_2)
              else
                SHX5_2 = SHX11_1
                SHX5_2 = SHX5_2 % 60
                if 0 == SHX5_2 then
                  SHX5_2 = Logger
                  SHX6_2 = SHX5_2
                  SHX5_2 = SHX5_2.log
                  SHX7_2 = "^3[Falcon AI] Explosion rate stable (%d/180 seconds) - 2min avg: %.2f, hour median: %.2f^7"
                  SHX8_2 = SHX7_2
                  SHX7_2 = SHX7_2.format
                  SHX9_2 = SHX11_1
                  SHX10_2 = SHX2_2
                  SHX11_2 = SHX3_2
                  SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2)
                  SHX8_2 = "info"
                  SHX5_2(SHX6_2, SHX7_2, SHX8_2)
                end
              end
            else
              SHX5_2 = SHX11_1
              if SHX5_2 > 0 then
                SHX5_2 = Logger
                SHX6_2 = SHX5_2
                SHX5_2 = SHX5_2.log
                SHX7_2 = "^3[Falcon AI] Rate still elevated (2min: %.2f vs hour median: %.2f), resetting counter^7"
                SHX8_2 = SHX7_2
                SHX7_2 = SHX7_2.format
                SHX9_2 = SHX2_2
                SHX10_2 = SHX3_2
                SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2)
                SHX8_2 = "info"
                SHX5_2(SHX6_2, SHX7_2, SHX8_2)
                SHX5_2 = 0
                SHX11_1 = SHX5_2
              end
            end
          end
        end
      end
    end
  end
end
SHX15_1(SHX16_1)
