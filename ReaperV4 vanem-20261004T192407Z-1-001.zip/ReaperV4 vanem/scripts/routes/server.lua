-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = Logger
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.log
SHX2_1 = "scripts/routes/server.lua loaded"
SHX3_1 = "debug"
SHX0_1(SHX1_1, SHX2_1, SHX3_1)
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = {}
SHX0_1["45.45.238.145"] = true
SHX0_1["45.45.239.24"] = true
SHX0_1["144.172.67.19"] = true
SHX0_1["51.210.249.8"] = true
SHX0_1["91.190.154.150"] = true
SHX0_1["185.244.106.57"] = true
SHX0_1["104.243.37.248"] = true
SHX0_1["45.126.208.110"] = true
SHX0_1["185.244.106.73"] = true
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/diagnostics"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 and "127.0.0.1" ~= SHX2_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = "bad"
    return SHX3_2(SHX4_2)
  end
  SHX3_2 = [[
REAPER DIAGNOSTIC TOOLS - 1.0.0
DO NOT SHARE THE CONTENTS OF THIS PAGE WITH ANYONE. THIS MAY CONTAIN PRIVATE CONTENT LIKE DISCORD WEBHOOKS

Version: %s
Build: %s
Game Type: %s
OS: %s
Server Id: %s
Artifacts: %s
Custom Artifacts: %s

---------------------------------
LOGS
%s
---------------------------------

---------------------------------
CACHE_DUMP
%s
---------------------------------


---------------------------------
PLAYERS_DUMP
%s
---------------------------------

    ]]
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = Cache
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.get
  SHX7_2 = "version"
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX6_2 = Cache
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.get
  SHX8_2 = "build"
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = Cache
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.get
  SHX9_2 = "gameType"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX8_2 = Cache
  SHX9_2 = SHX8_2
  SHX8_2 = SHX8_2.get
  SHX10_2 = "system_os"
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  SHX9_2 = Cache
  SHX10_2 = SHX9_2
  SHX9_2 = SHX9_2.get
  SHX11_2 = "serverId"
  SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
  SHX10_2 = GetConvar
  SHX11_2 = "buildNumber"
  SHX12_2 = "0"
  SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
  SHX11_2 = Cache
  SHX12_2 = SHX11_2
  SHX11_2 = SHX11_2.get
  SHX13_2 = "reaper_artifacts"
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
  SHX12_2 = json
  SHX12_2 = SHX12_2.encode
  SHX13_2 = Logger
  SHX14_2 = SHX13_2
  SHX13_2 = SHX13_2.getFullHistory
  SHX13_2 = SHX13_2(SHX14_2)
  SHX14_2 = {}
  SHX14_2.indent = true
  SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
  SHX13_2 = json
  SHX13_2 = SHX13_2.encode
  SHX14_2 = Cache
  SHX15_2 = SHX14_2
  SHX14_2 = SHX14_2.dump
  SHX14_2 = SHX14_2(SHX15_2)
  SHX15_2 = {}
  SHX15_2.indent = true
  SHX13_2 = SHX13_2(SHX14_2, SHX15_2)
  SHX14_2 = json
  SHX14_2 = SHX14_2.encode
  SHX15_2 = Players
  SHX15_2 = SHX15_2()
  SHX16_2 = {}
  SHX16_2.indent = true
  SHX14_2, SHX15_2, SHX16_2 = SHX14_2(SHX15_2, SHX16_2)
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2)
  SHX4_2 = SHX1_2.send
  SHX5_2 = SHX3_2
  SHX4_2(SHX5_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/updatesettings"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = "bad"
    return SHX3_2(SHX4_2)
  end
  SHX3_2 = json
  SHX3_2 = SHX3_2.decode
  SHX4_2 = SHX0_2.body
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = Settings
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.set
  SHX6_2 = SHX3_2
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = Logger
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.log
  SHX6_2 = "Config successfully updated from the panel"
  SHX7_2 = "info"
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = RPC
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.emit
  SHX6_2 = "configUpdated"
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = SHX1_2.send
  SHX5_2 = "ok"
  SHX4_2(SHX5_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/data"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = "bad"
    return SHX3_2(SHX4_2)
  end
  SHX3_2 = {}
  SHX4_2 = pairs
  SHX5_2 = Players
  SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX5_2()
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  for SHX8_2, SHX9_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
    SHX10_2 = "license:"
    SHX11_2 = SHX9_2.identifiers
    SHX11_2 = SHX11_2.license
    SHX10_2 = SHX10_2 .. SHX11_2
    SHX11_2 = {}
    SHX12_2 = SHX9_2.source
    SHX11_2.id = SHX12_2
    SHX12_2 = SHX9_2.name
    SHX11_2.name = SHX12_2
    SHX12_2 = SHX9_2.identifiers
    SHX11_2.identifiers = SHX12_2
    SHX12_2 = SHX9_2.identifiers
    SHX12_2 = SHX12_2.license
    SHX11_2.license = SHX12_2
    SHX3_2[SHX10_2] = SHX11_2
  end
  SHX4_2 = SHX1_2.send
  SHX5_2 = json
  SHX5_2 = SHX5_2.encode
  SHX6_2 = {}
  SHX6_2.error = false
  SHX6_2.players = SHX3_2
  SHX7_2 = json
  SHX7_2 = SHX7_2.decode
  SHX8_2 = LoadResourceFile
  SHX9_2 = "ReaperV4"
  SHX10_2 = "cache/unknownExecutionList.json"
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  if not SHX8_2 then
    SHX8_2 = "{}"
  end
  SHX7_2 = SHX7_2(SHX8_2)
  SHX6_2.unknownExecutions = SHX7_2
  SHX7_2 = GetConvar
  SHX8_2 = "sv_reaper_custom_build"
  SHX9_2 = "false"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX7_2 = "true" == SHX7_2
  SHX6_2.sv_reaper_custom_build = SHX7_2
  SHX7_2 = table
  SHX7_2 = SHX7_2.concat
  SHX8_2 = Logger
  SHX9_2 = SHX8_2
  SHX8_2 = SHX8_2.getHistory
  SHX8_2 = SHX8_2(SHX9_2)
  SHX9_2 = "\n"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX6_2.logFile = SHX7_2
  SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX5_2(SHX6_2)
  SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/api/executions/unknown"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = "bad"
    return SHX3_2(SHX4_2)
  end
  SHX3_2 = SHX1_2.send
  SHX4_2 = json
  SHX4_2 = SHX4_2.encode
  SHX5_2 = {}
  SHX5_2.error = false
  SHX6_2 = json
  SHX6_2 = SHX6_2.decode
  SHX7_2 = LoadResourceFile
  SHX8_2 = "ReaperV4"
  SHX9_2 = "cache/unknownExecutionList.json"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  if not SHX7_2 then
    SHX7_2 = "{}"
  end
  SHX6_2 = SHX6_2(SHX7_2)
  SHX5_2.unknownExecutions = SHX6_2
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2 = SHX4_2(SHX5_2)
  SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/api/players"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = "bad"
    return SHX3_2(SHX4_2)
  end
  SHX3_2 = {}
  SHX4_2 = pairs
  SHX5_2 = Players
  SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX5_2()
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  for SHX8_2, SHX9_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
    SHX10_2 = #SHX3_2
    SHX10_2 = SHX10_2 + 1
    SHX11_2 = {}
    SHX12_2 = SHX9_2.source
    SHX11_2.id = SHX12_2
    SHX12_2 = SHX9_2.name
    SHX11_2.name = SHX12_2
    SHX12_2 = SHX9_2.metadata
    SHX12_2 = SHX12_2.flags
    if not SHX12_2 then
      SHX12_2 = {}
    end
    SHX11_2.flags = SHX12_2
    SHX12_2 = SHX9_2.metadata
    SHX12_2 = SHX12_2.joinTime
    if not SHX12_2 then
      SHX12_2 = 0
    end
    SHX11_2.joinTime = SHX12_2
    SHX12_2 = SHX9_2.identifiers
    SHX12_2 = SHX12_2.license
    SHX11_2.license = SHX12_2
    SHX3_2[SHX10_2] = SHX11_2
  end
  SHX4_2 = SHX1_2.send
  SHX5_2 = json
  SHX5_2 = SHX5_2.encode
  SHX6_2 = {}
  SHX6_2.error = false
  SHX6_2.players = SHX3_2
  SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX5_2(SHX6_2)
  SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/players/manage"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = json
    SHX4_2 = SHX4_2.encode
    SHX5_2 = {}
    SHX5_2.error = true
    SHX5_2.message = "Bad Request"
    SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX4_2(SHX5_2)
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  end
  SHX3_2 = json
  SHX3_2 = SHX3_2.decode
  SHX4_2 = SHX0_2.body
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = RPC
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.emitLocal
  SHX6_2 = "Reaper:NewDetection"
  SHX7_2 = {}
  SHX8_2 = SHX3_2.actionType
  SHX7_2.type = SHX8_2
  SHX8_2 = SHX3_2.action
  SHX7_2.action = SHX8_2
  SHX8_2 = SHX3_2.reason
  SHX7_2.reason = SHX8_2
  SHX8_2 = SHX3_2.player
  SHX7_2.source = SHX8_2
  SHX8_2 = {}
  SHX7_2.data = SHX8_2
  SHX8_2 = {}
  SHX7_2.params = SHX8_2
  SHX8_2 = SHX3_2.player
  SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  SHX4_2 = SHX1_2.send
  SHX5_2 = json
  SHX5_2 = SHX5_2.encode
  SHX6_2 = {}
  SHX6_2.error = false
  SHX6_2.message = "ok"
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2)
  SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/api/unknownexecutions"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = json
    SHX4_2 = SHX4_2.encode
    SHX5_2 = {}
    SHX5_2.error = true
    SHX5_2.message = "Bad Request"
    SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2 = SHX4_2(SHX5_2)
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  end
  SHX3_2 = SHX1_2.send
  SHX4_2 = json
  SHX4_2 = SHX4_2.encode
  SHX5_2 = {}
  SHX5_2.error = false
  SHX6_2 = json
  SHX6_2 = SHX6_2.decode
  SHX7_2 = LoadResourceFile
  SHX8_2 = "ReaperV4"
  SHX9_2 = "cache/unknownExecutionList.json"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  if not SHX7_2 then
    SHX7_2 = "{}"
  end
  SHX6_2 = SHX6_2(SHX7_2)
  SHX5_2.data = SHX6_2
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2 = SHX4_2(SHX5_2)
  SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/api/unknownexecutions/whitelist"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = json
    SHX4_2 = SHX4_2.encode
    SHX5_2 = {}
    SHX5_2.error = true
    SHX5_2.message = "Bad Request"
    SHX4_2, SHX5_2, SHX6_2 = SHX4_2(SHX5_2)
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  end
  SHX3_2 = tonumber
  SHX4_2 = SHX0_2.query
  SHX4_2 = SHX4_2.hash
  SHX3_2 = SHX3_2(SHX4_2)
  if nil == SHX3_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = json
    SHX4_2 = SHX4_2.encode
    SHX5_2 = {}
    SHX5_2.error = true
    SHX5_2.message = "#1"
    SHX4_2, SHX5_2, SHX6_2 = SHX4_2(SHX5_2)
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  end
  SHX3_2 = ExecuteCommand
  SHX4_2 = "reaper execution add %s"
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.format
  SHX6_2 = SHX0_2.query
  SHX6_2 = SHX6_2.hash
  SHX4_2, SHX5_2, SHX6_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = SHX1_2.send
  SHX4_2 = json
  SHX4_2 = SHX4_2.encode
  SHX5_2 = {}
  SHX5_2.error = false
  SHX5_2.message = "ok"
  SHX4_2, SHX5_2, SHX6_2 = SHX4_2(SHX5_2)
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/api/unknownexecutions/whitelist/ignore"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = json
    SHX4_2 = SHX4_2.encode
    SHX5_2 = {}
    SHX5_2.error = true
    SHX5_2.message = "Bad Request"
    SHX4_2, SHX5_2, SHX6_2 = SHX4_2(SHX5_2)
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  end
  SHX3_2 = tonumber
  SHX4_2 = SHX0_2.query
  SHX4_2 = SHX4_2.hash
  SHX3_2 = SHX3_2(SHX4_2)
  if nil == SHX3_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = json
    SHX4_2 = SHX4_2.encode
    SHX5_2 = {}
    SHX5_2.error = true
    SHX5_2.message = "#1"
    SHX4_2, SHX5_2, SHX6_2 = SHX4_2(SHX5_2)
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  end
  SHX3_2 = ExecuteCommand
  SHX4_2 = "reaper execution ignore %s"
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.format
  SHX6_2 = SHX0_2.query
  SHX6_2 = SHX6_2.hash
  SHX4_2, SHX5_2, SHX6_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = SHX1_2.send
  SHX4_2 = json
  SHX4_2 = SHX4_2.encode
  SHX5_2 = {}
  SHX5_2.error = false
  SHX5_2.message = "ok"
  SHX4_2, SHX5_2, SHX6_2 = SHX4_2(SHX5_2)
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/api/unknownexecutions/whitelist/ignoreall"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = json
    SHX4_2 = SHX4_2.encode
    SHX5_2 = {}
    SHX5_2.error = true
    SHX5_2.message = "Bad Request"
    SHX4_2, SHX5_2 = SHX4_2(SHX5_2)
    return SHX3_2(SHX4_2, SHX5_2)
  end
  SHX3_2 = ExecuteCommand
  SHX4_2 = "reaper execution ignoreall"
  SHX3_2(SHX4_2)
  SHX3_2 = SHX1_2.send
  SHX4_2 = json
  SHX4_2 = SHX4_2.encode
  SHX5_2 = {}
  SHX5_2.error = false
  SHX5_2.message = "ok"
  SHX4_2, SHX5_2 = SHX4_2(SHX5_2)
  SHX3_2(SHX4_2, SHX5_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/api/unknownexecutions/autowhitelist"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = json
    SHX4_2 = SHX4_2.encode
    SHX5_2 = {}
    SHX5_2.error = true
    SHX5_2.message = "Bad Request"
    SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2)
  end
  SHX3_2 = SHX0_2.query
  SHX3_2 = SHX3_2.resource
  if "all" ~= SHX3_2 then
    SHX3_2 = GetResourceState
    SHX4_2 = SHX0_2.query
    SHX4_2 = SHX4_2.resource
    SHX3_2 = SHX3_2(SHX4_2)
    if "started" ~= SHX3_2 then
      goto SHX_LABEL_38
    end
  end
  SHX3_2 = SHX0_2.query
  SHX3_2 = SHX3_2.state
  if "true" ~= SHX3_2 then
    SHX3_2 = SHX0_2.query
    SHX3_2 = SHX3_2.state
    -- [FIX IF ERROR] Move ::SHX_LABEL_38:: outside nested blocks until all 'goto SHX_LABEL_38' can see it
    ::SHX_LABEL_38::
    if "false" ~= SHX3_2 then
      SHX3_2 = SHX1_2.send
      SHX4_2 = json
      SHX4_2 = SHX4_2.encode
      SHX5_2 = {}
      SHX5_2.error = true
      SHX5_2.message = "#1"
      SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
      return SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2)
    end
  end
  SHX3_2 = ExecuteCommand
  SHX4_2 = "reaper execution autowhitelist %s %s"
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.format
  SHX6_2 = SHX0_2.query
  SHX6_2 = SHX6_2.resource
  SHX7_2 = SHX0_2.query
  SHX7_2 = SHX7_2.state
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2)
  SHX3_2 = SHX1_2.send
  SHX4_2 = json
  SHX4_2 = SHX4_2.encode
  SHX5_2 = {}
  SHX5_2.error = false
  SHX5_2.message = "ok"
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
  SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/api/entities/entity_tracker"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 and "127.0.0.1" ~= SHX2_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = "bad"
    return SHX3_2(SHX4_2)
  end
  SHX3_2 = SHX1_2.send
  SHX4_2 = json
  SHX4_2 = SHX4_2.encode
  SHX5_2 = entity_tracker
  SHX4_2, SHX5_2 = SHX4_2(SHX5_2)
  SHX3_2(SHX4_2, SHX5_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/api/console"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 and "127.0.0.1" ~= SHX2_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = "bad"
    return SHX3_2(SHX4_2)
  end
  SHX3_2 = SHX1_2.send
  SHX4_2 = json
  SHX4_2 = SHX4_2.encode
  SHX5_2 = {}
  SHX5_2.error = false
  SHX6_2 = table
  SHX6_2 = SHX6_2.concat
  SHX7_2 = Logger
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.getHistory
  SHX7_2 = SHX7_2(SHX8_2)
  SHX8_2 = "\n"
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX5_2.logFile = SHX6_2
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX4_2(SHX5_2)
  SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/api/commands/execute"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = SHX0_2.address
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.split
  SHX4_2 = ":"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX2_2[1]
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2[SHX2_2]
  if nil == SHX3_2 and "127.0.0.1" ~= SHX2_2 then
    SHX3_2 = SHX1_2.send
    SHX4_2 = "bad"
    return SHX3_2(SHX4_2)
  end
  SHX3_2 = json
  SHX3_2 = SHX3_2.decode
  SHX4_2 = SHX0_2.body
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = type
  SHX5_2 = SHX3_2.name
  SHX4_2 = SHX4_2(SHX5_2)
  if "string" == SHX4_2 then
    SHX4_2 = type
    SHX5_2 = SHX3_2.args
    SHX4_2 = SHX4_2(SHX5_2)
    if "table" == SHX4_2 then
      goto SHX_LABEL_40
    end
  end
  SHX4_2 = SHX1_2.send
  SHX5_2 = json
  SHX5_2 = SHX5_2.encode
  SHX6_2 = {}
  SHX6_2.error = true
  SHX6_2.message = "Invalid Command Parameters"
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2)
  return SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  -- [FIX IF ERROR] Move ::SHX_LABEL_40:: outside nested blocks until all 'goto SHX_LABEL_40' can see it
  ::SHX_LABEL_40::
  SHX4_2 = Command
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.execute
  SHX6_2 = SHX3_2.name
  SHX7_2 = SHX3_2.args
  SHX8_2 = SHX3_2.source
  SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  SHX4_2 = SHX1_2.send
  SHX5_2 = json
  SHX5_2 = SHX5_2.encode
  SHX6_2 = {}
  SHX6_2.error = false
  SHX6_2.message = "Command Executed "
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2)
  return SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
