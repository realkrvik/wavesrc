-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = Command
Command = SHX0_1
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = Logger
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.log
SHX2_1 = "scripts/commands/server.lua loaded"
SHX3_1 = "debug"
SHX0_1(SHX1_1, SHX2_1, SHX3_1)
SHX0_1 = RPC
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.on
SHX2_1 = "reaperStarted"
function SHX3_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = Cache
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX2_2 = "gameType"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "help"
  function SHX4_2(...)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX0_3 = Logger
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.log
    SHX2_3 = "Commands List:\n"
    SHX3_3 = table
    SHX3_3 = SHX3_3.concat
    SHX4_3 = table
    SHX4_3 = SHX4_3.map
    SHX5_3 = table
    SHX5_3 = SHX5_3.filter
    SHX6_3 = Command
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.getCommands
    SHX6_3 = SHX6_3(SHX7_3)
    function SHX7_3(SHX0_4)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_4
      SHX1_4 = SHX0_4.hidden
      SHX1_4 = true ~= SHX1_4
      return SHX1_4
    end
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
    function SHX6_3(SHX0_4)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX1_4 = "   -> ^3%s^7 %s^4->^7 %s"
      SHX2_4 = SHX1_4
      SHX1_4 = SHX1_4.format
      SHX3_4 = SHX0_4.command
      SHX4_4 = table
      SHX4_4 = SHX4_4.concat
      SHX5_4 = table
      SHX5_4 = SHX5_4.map
      SHX6_4 = SHX0_4.args
      function SHX7_4(SHX0_5)
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX1_5, SHX2_5, SHX3_5
        SHX1_5 = "<^3%s^7> "
        SHX2_5 = SHX1_5
        SHX1_5 = SHX1_5.format
        SHX3_5 = SHX0_5
        return SHX1_5(SHX2_5, SHX3_5)
      end
      SHX5_4 = SHX5_4(SHX6_4, SHX7_4)
      if not SHX5_4 then
        SHX5_4 = {}
      end
      SHX4_4 = SHX4_4(SHX5_4)
      SHX5_4 = SHX0_4.description
      if not SHX5_4 then
        SHX5_4 = "No Description"
      end
      return SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4)
    end
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX5_3 = "\n"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    SHX2_3 = SHX2_3 .. SHX3_3
    SHX3_3 = "info"
    return SHX0_3(SHX1_3, SHX2_3, SHX3_3)
  end
  SHX3_2.callback = SHX4_2
  SHX4_2 = {}
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "install"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3, SHX26_3, SHX27_3, SHX28_3, SHX29_3, SHX30_3, SHX31_3, SHX32_3, SHX33_3
    SHX2_3 = GetCurrentResourceName
    SHX2_3 = SHX2_3()
    SHX3_3 = false
    SHX4_3 = Security
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.genUUID
    SHX6_3 = "xxxx-xxxx-xxxx"
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX5_3 = {}
    SHX6_3 = 0
    SHX7_3 = GetNumResources
    SHX7_3 = SHX7_3()
    SHX7_3 = SHX7_3 - 1
    SHX8_3 = 1
    for SHX9_3 = SHX6_3, SHX7_3, SHX8_3 do
      SHX10_3 = GetResourceByFindIndex
      SHX11_3 = SHX9_3
      SHX10_3 = SHX10_3(SHX11_3)
      SHX11_3 = GetResourceState
      SHX12_3 = SHX10_3
      SHX11_3 = SHX11_3(SHX12_3)
      if ("started" == SHX11_3 or "starting" == SHX11_3) and SHX2_3 ~= SHX10_3 then
        SHX12_3 = table
        SHX12_3 = SHX12_3.filter
        SHX13_3 = GetResourceMetaDataValues
        SHX14_3 = SHX10_3
        SHX15_3 = "client_script"
        SHX13_3 = SHX13_3(SHX14_3, SHX15_3)
        function SHX14_3(SHX0_4)
          -- [AI CLEANUP] Decompiled Lua - Fix these:
          -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
          -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
          -- 3. Replace goto/label with while/repeat-until where possible
          -- 4. Remove decompiler comments, add meaningful ones
          -- 5. Fix indentation and formatting
          
          local SHX1_4, SHX2_4, SHX3_4
          SHX2_4 = SHX0_4
          SHX1_4 = SHX0_4.match
          SHX3_4 = "@ReaperV4"
          SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
          SHX1_4 = nil == SHX1_4
          return SHX1_4
        end
        SHX12_3 = SHX12_3(SHX13_3, SHX14_3)
        SHX13_3 = table
        SHX13_3 = SHX13_3.filter
        SHX14_3 = GetResourceMetaDataValues
        SHX15_3 = SHX10_3
        SHX16_3 = "server_script"
        SHX14_3 = SHX14_3(SHX15_3, SHX16_3)
        function SHX15_3(SHX0_4)
          -- [AI CLEANUP] Decompiled Lua - Fix these:
          -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
          -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
          -- 3. Replace goto/label with while/repeat-until where possible
          -- 4. Remove decompiler comments, add meaningful ones
          -- 5. Fix indentation and formatting
          
          local SHX1_4, SHX2_4, SHX3_4
          SHX2_4 = SHX0_4
          SHX1_4 = SHX0_4.match
          SHX3_4 = "@ReaperV4"
          SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
          SHX1_4 = nil == SHX1_4
          return SHX1_4
        end
        SHX13_3 = SHX13_3(SHX14_3, SHX15_3)
        SHX14_3 = table
        SHX14_3 = SHX14_3.filter
        SHX15_3 = GetResourceMetaDataValues
        SHX16_3 = SHX10_3
        SHX17_3 = "shared_script"
        SHX15_3 = SHX15_3(SHX16_3, SHX17_3)
        function SHX16_3(SHX0_4)
          -- [AI CLEANUP] Decompiled Lua - Fix these:
          -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
          -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
          -- 3. Replace goto/label with while/repeat-until where possible
          -- 4. Remove decompiler comments, add meaningful ones
          -- 5. Fix indentation and formatting
          
          local SHX1_4, SHX2_4, SHX3_4
          SHX2_4 = SHX0_4
          SHX1_4 = SHX0_4.match
          SHX3_4 = "@ReaperV4"
          SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
          SHX1_4 = nil == SHX1_4
          return SHX1_4
        end
        SHX14_3 = SHX14_3(SHX15_3, SHX16_3)
        SHX15_3 = false
        SHX16_3 = pairs
        SHX17_3 = SHX12_3
        SHX16_3, SHX17_3, SHX18_3, SHX19_3 = SHX16_3(SHX17_3)
        for SHX20_3, SHX21_3 in SHX16_3, SHX17_3, SHX18_3, SHX19_3 do
          SHX23_3 = SHX21_3
          SHX22_3 = SHX21_3.match
          SHX24_3 = ".js"
          SHX22_3 = SHX22_3(SHX23_3, SHX24_3)
          if SHX22_3 then
            SHX15_3 = true
          end
        end
        SHX16_3 = pairs
        SHX17_3 = SHX13_3
        SHX16_3, SHX17_3, SHX18_3, SHX19_3 = SHX16_3(SHX17_3)
        for SHX20_3, SHX21_3 in SHX16_3, SHX17_3, SHX18_3, SHX19_3 do
          SHX23_3 = SHX21_3
          SHX22_3 = SHX21_3.match
          SHX24_3 = ".js"
          SHX22_3 = SHX22_3(SHX23_3, SHX24_3)
          if SHX22_3 then
            SHX15_3 = true
          end
        end
        SHX16_3 = pairs
        SHX17_3 = SHX14_3
        SHX16_3, SHX17_3, SHX18_3, SHX19_3 = SHX16_3(SHX17_3)
        for SHX20_3, SHX21_3 in SHX16_3, SHX17_3, SHX18_3, SHX19_3 do
          SHX23_3 = SHX21_3
          SHX22_3 = SHX21_3.match
          SHX24_3 = ".js"
          SHX22_3 = SHX22_3(SHX23_3, SHX24_3)
          if SHX22_3 then
            SHX15_3 = true
          end
        end
        SHX16_3 = "fxmanifest"
        SHX17_3 = LoadResourceFile
        SHX18_3 = SHX10_3
        SHX19_3 = "fxmanifest.lua"
        SHX17_3 = SHX17_3(SHX18_3, SHX19_3)
        SHX19_3 = SHX10_3
        SHX18_3 = SHX10_3.gsub
        SHX20_3 = "%%20"
        SHX21_3 = " "
        SHX18_3 = SHX18_3(SHX19_3, SHX20_3, SHX21_3)
        if not SHX17_3 then
          SHX16_3 = "__resource"
          SHX19_3 = LoadResourceFile
          SHX20_3 = SHX10_3
          SHX21_3 = "__resource.lua"
          SHX19_3 = SHX19_3(SHX20_3, SHX21_3)
          SHX17_3 = SHX19_3
        end
        if not SHX17_3 then
          SHX19_3 = Logger
          SHX20_3 = SHX19_3
          SHX19_3 = SHX19_3.log
          SHX21_3 = "Skipping install for ^3"
          SHX22_3 = SHX18_3
          SHX23_3 = "^7 due to no fxmanifest found"
          SHX21_3 = SHX21_3 .. SHX22_3 .. SHX23_3
          SHX22_3 = "warn"
          SHX19_3(SHX20_3, SHX21_3, SHX22_3)
        else
          SHX19_3 = false
          SHX20_3 = SHX17_3
          SHX21_3 = string
          SHX21_3 = SHX21_3.match
          SHX22_3 = SHX17_3
          SHX23_3 = "shared_script \"@ReaperV4/imports/bypass.lua\""
          SHX21_3 = SHX21_3(SHX22_3, SHX23_3)
          if SHX21_3 then
            SHX21_3 = string
            SHX21_3 = SHX21_3.match
            SHX22_3 = SHX17_3
            SHX23_3 = "lua54 \"yes\" %-%- needed for Reaper"
            SHX21_3 = SHX21_3(SHX22_3, SHX23_3)
            if SHX21_3 then
              SHX21_3 = string
              SHX21_3 = SHX21_3.match
              SHX22_3 = SHX17_3
              SHX23_3 = "shared_script \"@ReaperV4/imports/bypass_c.lua\""
              SHX21_3 = SHX21_3(SHX22_3, SHX23_3)
              if SHX21_3 then
                SHX21_3 = string
                SHX21_3 = SHX21_3.match
                SHX22_3 = SHX17_3
                SHX23_3 = "shared_script \"@ReaperV4/imports/bypass_s.lua\""
                SHX21_3 = SHX21_3(SHX22_3, SHX23_3)
                if SHX21_3 then
                  SHX21_3 = false == SHX15_3
                end
              end
            end
          end
          SHX22_3 = string
          SHX22_3 = SHX22_3.match
          SHX23_3 = SHX17_3
          SHX24_3 = "ReaperV4/c%-bypass.lua"
          SHX22_3 = SHX22_3(SHX23_3, SHX24_3)
          if not SHX22_3 then
            SHX22_3 = string
            SHX22_3 = SHX22_3.match
            SHX23_3 = SHX17_3
            SHX24_3 = "ReaperV4/s%-bypass.lua"
            SHX22_3 = SHX22_3(SHX23_3, SHX24_3)
            if not SHX22_3 then
              SHX22_3 = string
              SHX22_3 = SHX22_3.match
              SHX23_3 = SHX17_3
              SHX24_3 = "shared_script \"@ReaperV4/bypass.lua\""
              SHX22_3 = SHX22_3(SHX23_3, SHX24_3)
              if SHX22_3 then
                SHX22_3 = string
                SHX22_3 = SHX22_3.match
                SHX23_3 = SHX17_3
                SHX24_3 = "shared_script \"@ReaperV4/imports/bypass_c.lua\""
                SHX22_3 = SHX22_3(SHX23_3, SHX24_3)
              end
              SHX22_3 = string
              SHX22_3 = SHX22_3.match
              SHX23_3 = SHX17_3
              SHX24_3 = "server_script \"@ReaperV4/imports/bypass_s.lua\""
              SHX22_3 = nil == SHX22_3 or SHX22_3
            end
          end
          if SHX22_3 or not SHX21_3 then
            SHX23_3 = ""
            SHX24_3 = pairs
            SHX25_3 = string
            SHX25_3 = SHX25_3.split
            SHX26_3 = SHX17_3
            SHX27_3 = "\n"
            SHX25_3, SHX26_3, SHX27_3, SHX28_3, SHX29_3, SHX30_3, SHX31_3, SHX32_3, SHX33_3 = SHX25_3(SHX26_3, SHX27_3)
            SHX24_3, SHX25_3, SHX26_3, SHX27_3 = SHX24_3(SHX25_3, SHX26_3, SHX27_3, SHX28_3, SHX29_3, SHX30_3, SHX31_3, SHX32_3, SHX33_3)
            for SHX28_3, SHX29_3 in SHX24_3, SHX25_3, SHX26_3, SHX27_3 do
              SHX30_3 = string
              SHX30_3 = SHX30_3.match
              SHX31_3 = SHX29_3
              SHX32_3 = "lua54 \"yes\" %-%- needed for Reaper"
              SHX30_3 = SHX30_3(SHX31_3, SHX32_3)
              if not SHX30_3 then
                SHX30_3 = string
                SHX30_3 = SHX30_3.match
                SHX31_3 = SHX29_3
                SHX32_3 = "shared_script \"@ReaperV4/await.lua\""
                SHX30_3 = SHX30_3(SHX31_3, SHX32_3)
                if not SHX30_3 then
                  SHX30_3 = string
                  SHX30_3 = SHX30_3.match
                  SHX31_3 = SHX29_3
                  SHX32_3 = "client_script \"@ReaperV4/c%-bypass.lua\""
                  SHX30_3 = SHX30_3(SHX31_3, SHX32_3)
                  if not SHX30_3 then
                    SHX30_3 = string
                    SHX30_3 = SHX30_3.match
                    SHX31_3 = SHX29_3
                    SHX32_3 = "server_script \"@ReaperV4/s%-bypass.lua\""
                    SHX30_3 = SHX30_3(SHX31_3, SHX32_3)
                    if not SHX30_3 then
                      SHX30_3 = string
                      SHX30_3 = SHX30_3.match
                      SHX31_3 = SHX29_3
                      SHX32_3 = "shared_script \"@ReaperV4/bypass.lua\""
                      SHX30_3 = SHX30_3(SHX31_3, SHX32_3)
                      if not SHX30_3 then
                        SHX30_3 = string
                        SHX30_3 = SHX30_3.match
                        SHX31_3 = SHX29_3
                        SHX32_3 = "shared_script \"@ReaperV4/imports/bypass.js\""
                        SHX30_3 = SHX30_3(SHX31_3, SHX32_3)
                        if not SHX30_3 then
                          SHX30_3 = string
                          SHX30_3 = SHX30_3.match
                          SHX31_3 = SHX29_3
                          SHX32_3 = "shared_script \"@ReaperV4/imports/bypass.lua\""
                          SHX30_3 = SHX30_3(SHX31_3, SHX32_3)
                          if not SHX30_3 then
                            SHX30_3 = string
                            SHX30_3 = SHX30_3.match
                            SHX31_3 = SHX29_3
                            SHX32_3 = "server_script \"@ReaperV4/imports/bypass_s.lua\""
                            SHX30_3 = SHX30_3(SHX31_3, SHX32_3)
                            if not SHX30_3 then
                              SHX30_3 = string
                              SHX30_3 = SHX30_3.match
                              SHX31_3 = SHX29_3
                              SHX32_3 = "shared_script \"@ReaperV4/imports/bypass_s.lua\""
                              SHX30_3 = SHX30_3(SHX31_3, SHX32_3)
                              if not SHX30_3 then
                                SHX30_3 = string
                                SHX30_3 = SHX30_3.match
                                SHX31_3 = SHX29_3
                                SHX32_3 = "shared_script \"@ReaperV4/imports/bypass_c.lua\""
                                SHX30_3 = SHX30_3(SHX31_3, SHX32_3)
                                if not SHX30_3 then
                                  SHX30_3 = string
                                  SHX30_3 = SHX30_3.match
                                  SHX31_3 = SHX29_3
                                  SHX32_3 = "client_script \"@ReaperV4/imports/bypass_c.lua\""
                                  SHX30_3 = SHX30_3(SHX31_3, SHX32_3)
                                  if not SHX30_3 then
                                    SHX30_3 = SHX23_3
                                    SHX31_3 = SHX29_3
                                    SHX32_3 = "\n"
                                    SHX30_3 = SHX30_3 .. SHX31_3 .. SHX32_3
                                    SHX23_3 = SHX30_3
                                end
                              end
                            end
                          end
                        end
                      end
                    end
                  end
                end
              end
              else
                SHX19_3 = true
              end
            end
            SHX17_3 = SHX23_3
          end
          SHX23_3 = GetResourceMetadata
          SHX24_3 = SHX10_3
          SHX25_3 = "reaper_ignore"
          SHX26_3 = 0
          SHX23_3 = SHX23_3(SHX24_3, SHX25_3, SHX26_3)
          if not SHX23_3 then
            SHX23_3 = GetConvar
            SHX24_3 = "reaper_ignore_"
            SHX25_3 = SHX10_3
            SHX24_3 = SHX24_3 .. SHX25_3
            SHX25_3 = "false"
            SHX23_3 = SHX23_3(SHX24_3, SHX25_3)
            SHX23_3 = "true" == SHX23_3
          end
          if SHX23_3 then
            SHX24_3 = Logger
            SHX25_3 = SHX24_3
            SHX24_3 = SHX24_3.log
            SHX26_3 = "Skipping install for ^3"
            SHX27_3 = SHX18_3
            SHX28_3 = "^7 as its an ignored resource"
            SHX26_3 = SHX26_3 .. SHX27_3 .. SHX28_3
            SHX27_3 = "warn"
            SHX24_3(SHX25_3, SHX26_3, SHX27_3)
          end
          if SHX21_3 and SHX23_3 then
            SHX24_3 = ""
            SHX25_3 = pairs
            SHX26_3 = string
            SHX26_3 = SHX26_3.split
            SHX27_3 = SHX17_3
            SHX28_3 = "\n"
            SHX26_3, SHX27_3, SHX28_3, SHX29_3, SHX30_3, SHX31_3, SHX32_3, SHX33_3 = SHX26_3(SHX27_3, SHX28_3)
            SHX25_3, SHX26_3, SHX27_3, SHX28_3 = SHX25_3(SHX26_3, SHX27_3, SHX28_3, SHX29_3, SHX30_3, SHX31_3, SHX32_3, SHX33_3)
            for SHX29_3, SHX30_3 in SHX25_3, SHX26_3, SHX27_3, SHX28_3 do
              SHX31_3 = string
              SHX31_3 = SHX31_3.match
              SHX32_3 = SHX30_3
              SHX33_3 = "lua54 \"yes\" %-%- needed for Reaper"
              SHX31_3 = SHX31_3(SHX32_3, SHX33_3)
              if not SHX31_3 then
                SHX31_3 = string
                SHX31_3 = SHX31_3.match
                SHX32_3 = SHX30_3
                SHX33_3 = "shared_script \"@ReaperV4/bypass.lua\""
                SHX31_3 = SHX31_3(SHX32_3, SHX33_3)
                if not SHX31_3 then
                  SHX31_3 = SHX24_3
                  SHX32_3 = SHX30_3
                  SHX33_3 = "\n"
                  SHX31_3 = SHX31_3 .. SHX32_3 .. SHX33_3
                  SHX24_3 = SHX31_3
                end
              end
            end
            SHX3_3 = true
            SHX25_3 = SaveResourceFile
            SHX26_3 = SHX2_3
            SHX27_3 = "cache/"
            SHX28_3 = SHX4_3
            SHX29_3 = "-"
            SHX30_3 = SHX10_3
            SHX31_3 = "-"
            SHX32_3 = SHX16_3
            SHX33_3 = ".lua"
            SHX27_3 = SHX27_3 .. SHX28_3 .. SHX29_3 .. SHX30_3 .. SHX31_3 .. SHX32_3 .. SHX33_3
            SHX28_3 = SHX20_3
            SHX29_3 = #SHX20_3
            SHX25_3(SHX26_3, SHX27_3, SHX28_3, SHX29_3)
            SHX25_3 = Citizen
            SHX25_3 = SHX25_3.Wait
            SHX26_3 = 25
            SHX25_3(SHX26_3)
            SHX25_3 = SaveResourceFile
            SHX26_3 = SHX10_3
            SHX27_3 = SHX16_3
            SHX28_3 = ".lua"
            SHX27_3 = SHX27_3 .. SHX28_3
            SHX28_3 = SHX24_3
            SHX29_3 = #SHX24_3
            SHX25_3(SHX26_3, SHX27_3, SHX28_3, SHX29_3)
            SHX25_3 = Logger
            SHX26_3 = SHX25_3
            SHX25_3 = SHX25_3.log
            SHX27_3 = "Successfully uninstalled from an ignored resource. Resource: ^3"
            SHX28_3 = SHX18_3
            SHX29_3 = "^0!"
            SHX27_3 = SHX27_3 .. SHX28_3 .. SHX29_3
            SHX28_3 = "warn"
            SHX25_3(SHX26_3, SHX27_3, SHX28_3)
          end
          if not SHX23_3 then
            SHX24_3 = string
            SHX24_3 = SHX24_3.match
            SHX25_3 = SHX17_3
            SHX26_3 = "client_script"
            SHX24_3 = SHX24_3(SHX25_3, SHX26_3)
            if not SHX24_3 then
              SHX24_3 = string
              SHX24_3 = SHX24_3.match
              SHX25_3 = SHX17_3
              SHX26_3 = "client_scripts"
              SHX24_3 = SHX24_3(SHX25_3, SHX26_3)
              if not SHX24_3 then
                SHX24_3 = string
                SHX24_3 = SHX24_3.match
                SHX25_3 = SHX17_3
                SHX26_3 = "server_script"
                SHX24_3 = SHX24_3(SHX25_3, SHX26_3)
                if not SHX24_3 then
                  SHX24_3 = string
                  SHX24_3 = SHX24_3.match
                  SHX25_3 = SHX17_3
                  SHX26_3 = "server_scripts"
                  SHX24_3 = SHX24_3(SHX25_3, SHX26_3)
                  if not SHX24_3 then
                    SHX24_3 = string
                    SHX24_3 = SHX24_3.match
                    SHX25_3 = SHX17_3
                    SHX26_3 = "shared_scripts"
                    SHX24_3 = SHX24_3(SHX25_3, SHX26_3)
                  end
                end
              end
            end
            if SHX24_3 and (not SHX21_3 or SHX19_3) then
              SHX24_3 = SaveResourceFile
              SHX25_3 = SHX2_3
              SHX26_3 = "cache/"
              SHX27_3 = SHX4_3
              SHX28_3 = "-"
              SHX29_3 = SHX10_3
              SHX30_3 = "-"
              SHX31_3 = SHX16_3
              SHX32_3 = ".lua"
              SHX26_3 = SHX26_3 .. SHX27_3 .. SHX28_3 .. SHX29_3 .. SHX30_3 .. SHX31_3 .. SHX32_3
              SHX27_3 = SHX20_3
              SHX28_3 = #SHX20_3
              SHX24_3(SHX25_3, SHX26_3, SHX27_3, SHX28_3)
              SHX24_3 = Citizen
              SHX24_3 = SHX24_3.Wait
              SHX25_3 = 25
              SHX24_3(SHX25_3)
              SHX24_3 = string
              SHX24_3 = SHX24_3.match
              SHX25_3 = SHX17_3
              SHX26_3 = "lua54 \"yes\" %-%- needed for Reaper"
              SHX24_3 = SHX24_3(SHX25_3, SHX26_3)
              if nil == SHX24_3 then
                SHX24_3 = [[
lua54 "yes" -- needed for Reaper

]]
                SHX25_3 = SHX17_3
                SHX24_3 = SHX24_3 .. SHX25_3
                SHX17_3 = SHX24_3
              end
              SHX24_3 = string
              SHX24_3 = SHX24_3.match
              SHX25_3 = SHX17_3
              SHX26_3 = "shared_script \"@ReaperV4/imports/bypass_c.lua\""
              SHX24_3 = SHX24_3(SHX25_3, SHX26_3)
              if nil == SHX24_3 then
                SHX24_3 = "shared_script \"@ReaperV4/imports/bypass_c.lua\"\n"
                SHX25_3 = SHX17_3
                SHX24_3 = SHX24_3 .. SHX25_3
                SHX17_3 = SHX24_3
              end
              SHX24_3 = string
              SHX24_3 = SHX24_3.match
              SHX25_3 = SHX17_3
              SHX26_3 = "shared_script \"@ReaperV4/imports/bypass_s.lua\""
              SHX24_3 = SHX24_3(SHX25_3, SHX26_3)
              if nil == SHX24_3 then
                SHX24_3 = "shared_script \"@ReaperV4/imports/bypass_s.lua\"\n"
                SHX25_3 = SHX17_3
                SHX24_3 = SHX24_3 .. SHX25_3
                SHX17_3 = SHX24_3
              end
              SHX24_3 = string
              SHX24_3 = SHX24_3.match
              SHX25_3 = SHX17_3
              SHX26_3 = "shared_script \"@ReaperV4/imports/bypass.lua\""
              SHX24_3 = SHX24_3(SHX25_3, SHX26_3)
              if nil == SHX24_3 then
                SHX24_3 = "shared_script \"@ReaperV4/imports/bypass.lua\"\n"
                SHX25_3 = SHX17_3
                SHX24_3 = SHX24_3 .. SHX25_3
                SHX17_3 = SHX24_3
              end
              if SHX15_3 then
                SHX24_3 = string
                SHX24_3 = SHX24_3.match
                SHX25_3 = SHX17_3
                SHX26_3 = "shared_script \"@ReaperV4/imports/bypass.js\""
                SHX24_3 = SHX24_3(SHX25_3, SHX26_3)
                if nil == SHX24_3 then
                  SHX24_3 = "shared_script \"@ReaperV4/imports/bypass.js\"\n"
                  SHX25_3 = SHX17_3
                  SHX24_3 = SHX24_3 .. SHX25_3
                  SHX17_3 = SHX24_3
                end
              end
              SHX24_3 = SaveResourceFile
              SHX25_3 = SHX10_3
              SHX26_3 = SHX16_3
              SHX27_3 = ".lua"
              SHX26_3 = SHX26_3 .. SHX27_3
              SHX27_3 = SHX17_3
              SHX28_3 = #SHX17_3
              SHX24_3(SHX25_3, SHX26_3, SHX27_3, SHX28_3)
              SHX24_3 = LoadResourceFile
              SHX25_3 = SHX10_3
              SHX26_3 = SHX16_3
              SHX27_3 = ".lua"
              SHX26_3 = SHX26_3 .. SHX27_3
              SHX24_3 = SHX24_3(SHX25_3, SHX26_3)
              SHX25_3 = string
              SHX25_3 = SHX25_3.match
              SHX26_3 = SHX24_3
              SHX27_3 = "shared_script \"@ReaperV4/imports/bypass.lua\""
              SHX25_3 = SHX25_3(SHX26_3, SHX27_3)
              if SHX25_3 then
                SHX3_3 = true
                SHX25_3 = Logger
                SHX26_3 = SHX25_3
                SHX25_3 = SHX25_3.log
                SHX27_3 = "Successfully installed into ^3"
                SHX28_3 = SHX18_3
                SHX29_3 = "^0. The server will restart soon!"
                SHX27_3 = SHX27_3 .. SHX28_3 .. SHX29_3
                SHX28_3 = "warn"
                SHX25_3(SHX26_3, SHX27_3, SHX28_3)
              else
                SHX25_3 = table
                SHX25_3 = SHX25_3.insert
                SHX26_3 = SHX5_3
                SHX27_3 = "Unable to install into ^3"
                SHX28_3 = SHX18_3
                SHX29_3 = "^0. Please manually install Reaper into the fxmanifest for this script!"
                SHX27_3 = SHX27_3 .. SHX28_3 .. SHX29_3
                SHX25_3(SHX26_3, SHX27_3)
              end
            end
          end
        end
      end
    end
    SHX6_3 = #SHX5_3
    if 0 ~= SHX6_3 then
      SHX6_3 = pairs
      SHX7_3 = SHX5_3
      SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX6_3(SHX7_3)
      for SHX10_3, SHX11_3 in SHX6_3, SHX7_3, SHX8_3, SHX9_3 do
        SHX12_3 = Logger
        SHX13_3 = SHX12_3
        SHX12_3 = SHX12_3.log
        SHX14_3 = SHX11_3
        SHX15_3 = "error"
        SHX12_3(SHX13_3, SHX14_3, SHX15_3)
      end
      SHX6_3 = CreateThread
      function SHX7_3()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_4, SHX1_4, SHX2_4, SHX3_4
        SHX0_4 = RPC
        SHX1_4 = SHX0_4
        SHX0_4 = SHX0_4.emit
        SHX2_4 = "blockPlayers"
        SHX3_4 = "We ran into an issue while trying to connect you to the server. Please contact the server administration to resolve this issue."
        SHX0_4(SHX1_4, SHX2_4, SHX3_4)
        while true do
          SHX0_4 = Logger
          SHX1_4 = SHX0_4
          SHX0_4 = SHX0_4.log
          SHX2_4 = "^1Reaper was unable to install into all resources. To prevent further issues, players will be unable to join until the issue is corrected."
          SHX3_4 = "error"
          SHX0_4(SHX1_4, SHX2_4, SHX3_4)
          SHX0_4 = Wait
          SHX1_4 = 8000
          SHX0_4(SHX1_4)
        end
      end
      SHX6_3(SHX7_3)
      return
    end
    if not SHX3_3 then
      SHX6_3 = SHX1_3[2]
      if "-force_restart" ~= SHX6_3 then
        goto SHX_LABEL_578
      end
    end
    SHX6_3 = os
    SHX6_3 = SHX6_3.exit
    SHX7_3 = "Reaper was installed into new scripts and requires a server restart."
    SHX6_3(SHX7_3)
    -- [FIX IF ERROR] Move ::SHX_LABEL_578:: outside nested blocks until all 'goto SHX_LABEL_578' can see it
    ::SHX_LABEL_578::
    ALLOW_CONNECTIONS = true
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.description = "Installs Reaper into all resources"
  SHX4_2 = {}
  SHX5_2 = "Update Config"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "diagnostics"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX0_3 = System
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.getOs
    SHX0_3 = SHX0_3(SHX1_3)
    if "Windows" == SHX0_3 then
      SHX0_3 = GetConvar
      SHX1_3 = "netPort"
      SHX2_3 = "30120"
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
      SHX1_3 = "http://localhost:"
      SHX2_3 = SHX0_3
      SHX3_3 = "/ReaperV4/diagnostics"
      SHX1_3 = SHX1_3 .. SHX2_3 .. SHX3_3
      SHX2_3 = os
      SHX2_3 = SHX2_3.execute
      SHX3_3 = "start "
      SHX4_3 = SHX1_3
      SHX3_3 = SHX3_3 .. SHX4_3
      SHX2_3(SHX3_3)
      SHX2_3 = Logger
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.log
      SHX4_3 = "Diagnostics URL: ^3%s"
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.format
      SHX6_3 = SHX1_3
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
      SHX5_3 = "info"
      SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    else
      SHX0_3 = GetConvar
      SHX1_3 = "netPort"
      SHX2_3 = "30120"
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
      SHX1_3 = "http://server-ip:"
      SHX2_3 = SHX0_3
      SHX3_3 = "/ReaperV4/diagnostics"
      SHX1_3 = SHX1_3 .. SHX2_3 .. SHX3_3
      SHX2_3 = Logger
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.log
      SHX4_3 = "Diagnostics URL: ^3%s"
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.format
      SHX6_3 = SHX1_3
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
      SHX5_3 = "info"
      SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    end
  end
  SHX3_2.callback = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Update Config"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX3_2.hidden = true
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "uninstall"
  function SHX4_2(...)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3
    SHX0_3 = GetCurrentResourceName
    SHX0_3 = SHX0_3()
    SHX1_3 = Security
    SHX2_3 = SHX1_3
    SHX1_3 = SHX1_3.genUUID
    SHX3_3 = "xxxx-xxxx-xxxx"
    SHX1_3 = SHX1_3(SHX2_3, SHX3_3)
    SHX2_3 = 0
    SHX3_3 = GetNumResources
    SHX3_3 = SHX3_3()
    SHX3_3 = SHX3_3 - 1
    SHX4_3 = 1
    for SHX5_3 = SHX2_3, SHX3_3, SHX4_3 do
      SHX6_3 = 0
      SHX7_3 = GetResourceByFindIndex
      SHX8_3 = SHX5_3
      SHX7_3 = SHX7_3(SHX8_3)
      if SHX0_3 ~= SHX7_3 then
        SHX8_3 = "fxmanifest"
        SHX9_3 = LoadResourceFile
        SHX10_3 = SHX7_3
        SHX11_3 = "fxmanifest.lua"
        SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
        if not SHX9_3 then
          SHX8_3 = "__resource"
          SHX10_3 = LoadResourceFile
          SHX11_3 = SHX7_3
          SHX12_3 = "__resource.lua"
          SHX10_3 = SHX10_3(SHX11_3, SHX12_3)
          SHX9_3 = SHX10_3
        end
        SHX10_3 = SHX9_3
        SHX11_3 = string
        SHX11_3 = SHX11_3.match
        SHX12_3 = SHX10_3
        SHX13_3 = "lua54 \"yes\" %-%- needed for Reaper"
        SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
        if not SHX11_3 then
          SHX11_3 = string
          SHX11_3 = SHX11_3.match
          SHX12_3 = SHX10_3
          SHX13_3 = "shared_script \"@ReaperV4/bypass.lua\""
          SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
          if not SHX11_3 then
            SHX11_3 = string
            SHX11_3 = SHX11_3.match
            SHX12_3 = SHX10_3
            SHX13_3 = "shared_script \"@ReaperV4/imports/bypass.js\""
            SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
            if not SHX11_3 then
              SHX11_3 = string
              SHX11_3 = SHX11_3.match
              SHX12_3 = SHX10_3
              SHX13_3 = "shared_script \"@ReaperV4/imports/bypass.lua\""
              SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
              if not SHX11_3 then
                SHX11_3 = string
                SHX11_3 = SHX11_3.match
                SHX12_3 = SHX10_3
                SHX13_3 = "shared_script \"@ReaperV4/imports/bypass_c.lua\""
                SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
                if not SHX11_3 then
                  SHX11_3 = string
                  SHX11_3 = SHX11_3.match
                  SHX12_3 = SHX10_3
                  SHX13_3 = "client_script \"@ReaperV4/imports/bypass_c.lua\""
                  SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
                  if not SHX11_3 then
                    SHX11_3 = string
                    SHX11_3 = SHX11_3.match
                    SHX12_3 = SHX10_3
                    SHX13_3 = "server_script \"@ReaperV4/imports/bypass_s.lua\""
                    SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
                    if not SHX11_3 then
                      SHX11_3 = string
                      SHX11_3 = SHX11_3.match
                      SHX12_3 = SHX10_3
                      SHX13_3 = "shared_script \"@ReaperV4/imports/bypass_s.lua\""
                      SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
                      if not SHX11_3 then
                        goto SHX_LABEL_213
                      end
                    end
                  end
                end
              end
            end
          end
        end
        SHX11_3 = ""
        SHX12_3 = pairs
        SHX13_3 = string
        SHX13_3 = SHX13_3.split
        SHX14_3 = SHX9_3
        SHX15_3 = "\n"
        SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3 = SHX13_3(SHX14_3, SHX15_3)
        SHX12_3, SHX13_3, SHX14_3, SHX15_3 = SHX12_3(SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3)
        for SHX16_3, SHX17_3 in SHX12_3, SHX13_3, SHX14_3, SHX15_3 do
          SHX18_3 = string
          SHX18_3 = SHX18_3.match
          SHX19_3 = SHX17_3
          SHX20_3 = "lua54 \"yes\" %-%- needed for Reaper"
          SHX18_3 = SHX18_3(SHX19_3, SHX20_3)
          if not SHX18_3 then
            SHX18_3 = string
            SHX18_3 = SHX18_3.match
            SHX19_3 = SHX17_3
            SHX20_3 = "shared_script \"@ReaperV4/bypass.lua\""
            SHX18_3 = SHX18_3(SHX19_3, SHX20_3)
            if not SHX18_3 then
              SHX18_3 = string
              SHX18_3 = SHX18_3.match
              SHX19_3 = SHX17_3
              SHX20_3 = "shared_script \"@ReaperV4/imports/bypass.js\""
              SHX18_3 = SHX18_3(SHX19_3, SHX20_3)
              if not SHX18_3 then
                SHX18_3 = string
                SHX18_3 = SHX18_3.match
                SHX19_3 = SHX17_3
                SHX20_3 = "shared_script \"@ReaperV4/imports/bypass.lua\""
                SHX18_3 = SHX18_3(SHX19_3, SHX20_3)
                if not SHX18_3 then
                  SHX18_3 = string
                  SHX18_3 = SHX18_3.match
                  SHX19_3 = SHX17_3
                  SHX20_3 = "shared_script \"@ReaperV4/imports/bypass_c.lua\""
                  SHX18_3 = SHX18_3(SHX19_3, SHX20_3)
                  if not SHX18_3 then
                    SHX18_3 = string
                    SHX18_3 = SHX18_3.match
                    SHX19_3 = SHX17_3
                    SHX20_3 = "client_script \"@ReaperV4/imports/bypass_c.lua\""
                    SHX18_3 = SHX18_3(SHX19_3, SHX20_3)
                    if not SHX18_3 then
                      SHX18_3 = string
                      SHX18_3 = SHX18_3.match
                      SHX19_3 = SHX17_3
                      SHX20_3 = "shared_script \"@ReaperV4/imports/bypass_s.lua\""
                      SHX18_3 = SHX18_3(SHX19_3, SHX20_3)
                      if not SHX18_3 then
                        if 0 ~= SHX6_3 then
                          SHX18_3 = SHX6_3 + 1
                          if SHX18_3 == SHX16_3 then
                            SHX19_3 = SHX17_3
                            SHX18_3 = SHX17_3.len
                            SHX18_3 = SHX18_3(SHX19_3)
                          end
                        end
                        if 1 ~= SHX18_3 then
                          SHX18_3 = SHX11_3
                          SHX19_3 = SHX17_3
                          SHX20_3 = "\n"
                          SHX18_3 = SHX18_3 .. SHX19_3 .. SHX20_3
                          SHX11_3 = SHX18_3
                        end
                    end
                  end
                end
              end
            end
          end
          else
            SHX18_3 = string
            SHX18_3 = SHX18_3.match
            SHX19_3 = SHX17_3
            SHX20_3 = "lua54 \"yes\" %-%- needed for Reaper"
            SHX18_3 = SHX18_3(SHX19_3, SHX20_3)
            if SHX18_3 then
              SHX6_3 = SHX16_3
            end
          end
        end
        SHX12_3 = SaveResourceFile
        SHX13_3 = SHX0_3
        SHX14_3 = "cache/"
        SHX15_3 = SHX1_3
        SHX16_3 = "-"
        SHX17_3 = SHX7_3
        SHX18_3 = "-"
        SHX19_3 = SHX8_3
        SHX20_3 = ".lua"
        SHX14_3 = SHX14_3 .. SHX15_3 .. SHX16_3 .. SHX17_3 .. SHX18_3 .. SHX19_3 .. SHX20_3
        SHX15_3 = SHX10_3
        SHX16_3 = #SHX10_3
        SHX12_3(SHX13_3, SHX14_3, SHX15_3, SHX16_3)
        SHX12_3 = Citizen
        SHX12_3 = SHX12_3.Wait
        SHX13_3 = 25
        SHX12_3(SHX13_3)
        SHX12_3 = SaveResourceFile
        SHX13_3 = SHX7_3
        SHX14_3 = SHX8_3
        SHX15_3 = ".lua"
        SHX14_3 = SHX14_3 .. SHX15_3
        SHX15_3 = SHX11_3
        SHX16_3 = #SHX11_3
        SHX12_3(SHX13_3, SHX14_3, SHX15_3, SHX16_3)
        SHX13_3 = SHX7_3
        SHX12_3 = SHX7_3.gsub
        SHX14_3 = "%%20"
        SHX15_3 = " "
        SHX12_3 = SHX12_3(SHX13_3, SHX14_3, SHX15_3)
        SHX13_3 = Logger
        SHX14_3 = SHX13_3
        SHX13_3 = SHX13_3.log
        SHX15_3 = "Successfully uninstalled from ^3"
        SHX16_3 = SHX12_3
        SHX17_3 = "^0!"
        SHX15_3 = SHX15_3 .. SHX16_3 .. SHX17_3
        SHX16_3 = "warn"
        SHX13_3(SHX14_3, SHX15_3, SHX16_3)
      end
      -- [FIX IF ERROR] Move ::SHX_LABEL_213:: outside nested blocks until all 'goto SHX_LABEL_213' can see it
      ::SHX_LABEL_213::
    end
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.description = "Removes Reaper from all resources"
  SHX4_2 = {}
  SHX5_2 = "Update Config"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "devmode"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    if 0 ~= SHX0_3 then
      SHX2_3 = Player
      SHX3_3 = SHX0_3
      SHX2_3 = SHX2_3(SHX3_3)
      if nil == SHX2_3 then
        return
      end
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "^3%s ^7(^3fivem:%s^7) has just toggled development mode."
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.format
      SHX8_3 = SHX2_3
      SHX7_3 = SHX2_3.getName
      SHX7_3 = SHX7_3(SHX8_3)
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getIdentifier
      SHX10_3 = "fivem"
      SHX8_3, SHX9_3, SHX10_3 = SHX8_3(SHX9_3, SHX10_3)
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX6_3 = "info"
      SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    else
      SHX2_3 = Logger
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.log
      SHX4_3 = "Development mode has just been toggled."
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.format
      SHX4_3 = SHX4_3(SHX5_3)
      SHX5_3 = "info"
      SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    end
    SHX2_3 = Settings
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.get
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3.devMode
    SHX3_3 = not SHX3_3
    SHX2_3.devMode = SHX3_3
    SHX3_3 = Settings
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.set
    SHX5_3 = SHX2_3
    SHX3_3(SHX4_3, SHX5_3)
    SHX3_3 = RPC
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.emit
    SHX5_3 = "configUpdated"
    SHX3_3(SHX4_3, SHX5_3)
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.description = "Toggles Developer Mode"
  SHX4_2 = {}
  SHX5_2 = "Quick Actions"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "syncconfig"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3
    SHX2_3 = Logger
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.log
    SHX4_3 = "Syncing config from the panel..."
    SHX5_3 = "info"
    SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    SHX2_3 = HTTP
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.await
    SHX4_3 = "https://api.reaperac.com/api/v1/servers/%s/config?secret=%s"
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.format
    SHX6_3 = Cache
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.get
    SHX8_3 = "dbId"
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
    SHX7_3 = Cache
    SHX8_3 = SHX7_3
    SHX7_3 = SHX7_3.get
    SHX9_3 = "secret"
    SHX7_3, SHX8_3, SHX9_3 = SHX7_3(SHX8_3, SHX9_3)
    SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX3_3 = SHX2_3.status
    if 200 ~= SHX3_3 then
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "We ran into an unknown error when trying to sync the config. The server responded with error code ^3%s^7"
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.format
      SHX7_3 = SHX2_3.status
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
      SHX6_3 = "error"
      return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    end
    SHX3_3 = json
    SHX3_3 = SHX3_3.decode
    SHX4_3 = SHX2_3.body
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = Settings
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.set
    SHX6_3 = SHX3_3
    SHX4_3(SHX5_3, SHX6_3)
    SHX4_3 = Logger
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.log
    SHX6_3 = "Config successfully synced from the panel"
    SHX7_3 = "info"
    SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    SHX4_3 = RPC
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.emit
    SHX6_3 = "configUpdated"
    SHX4_3(SHX5_3, SHX6_3)
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.description = "Syncs the latest version of the config from the panel"
  SHX4_2 = {}
  SHX5_2 = "Update Config"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  if "gta5" == SHX0_2 then
    SHX1_2 = Command
    SHX2_2 = SHX1_2
    SHX1_2 = SHX1_2.add
    SHX3_2 = {}
    SHX3_2.command = "logsyncevents"
    function SHX4_2(SHX0_3, SHX1_3)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
      if 0 ~= SHX0_3 then
        SHX2_3 = Player
        SHX3_3 = SHX0_3
        SHX2_3 = SHX2_3(SHX3_3)
        if nil == SHX2_3 then
          return
        end
        SHX3_3 = Logger
        SHX4_3 = SHX3_3
        SHX3_3 = SHX3_3.log
        SHX5_3 = "^3%s ^7(^3fivem:%s^7) has just toggled logSyncEvents"
        SHX6_3 = SHX5_3
        SHX5_3 = SHX5_3.format
        SHX8_3 = SHX2_3
        SHX7_3 = SHX2_3.getName
        SHX7_3 = SHX7_3(SHX8_3)
        SHX9_3 = SHX2_3
        SHX8_3 = SHX2_3.getIdentifier
        SHX10_3 = "fivem"
        SHX8_3, SHX9_3, SHX10_3 = SHX8_3(SHX9_3, SHX10_3)
        SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
        SHX6_3 = "info"
        SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      else
        SHX2_3 = Logger
        SHX3_3 = SHX2_3
        SHX2_3 = SHX2_3.log
        SHX4_3 = "logSyncEvents has just been toggled."
        SHX5_3 = SHX4_3
        SHX4_3 = SHX4_3.format
        SHX4_3 = SHX4_3(SHX5_3)
        SHX5_3 = "info"
        SHX2_3(SHX3_3, SHX4_3, SHX5_3)
      end
      SHX2_3 = Cache
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.set
      SHX4_3 = "logSyncEvents"
      SHX5_3 = Cache
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.get
      SHX7_3 = "logSyncEvents"
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
      SHX5_3 = not SHX5_3
      SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    end
    SHX3_2.callback = SHX4_2
    SHX3_2.description = "Toggles Sync Event Logs (Debug)"
    SHX4_2 = {}
    SHX5_2 = "Quick Actions"
    SHX4_2[1] = SHX5_2
    SHX3_2.permissions = SHX4_2
    SHX3_2.hidden = true
    SHX1_2(SHX2_2, SHX3_2)
    SHX1_2 = Command
    SHX2_2 = SHX1_2
    SHX1_2 = SHX1_2.add
    SHX3_2 = {}
    SHX3_2.command = "screenshot"
    function SHX4_2(SHX0_3, SHX1_3)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
      SHX2_3 = Player
      SHX3_3 = SHX1_3[2]
      SHX2_3 = SHX2_3(SHX3_3)
      if nil == SHX2_3 then
        SHX3_3 = Logger
        SHX4_3 = SHX3_3
        SHX3_3 = SHX3_3.log
        SHX5_3 = "^3%s^7 is not a valid player source"
        SHX6_3 = SHX5_3
        SHX5_3 = SHX5_3.format
        SHX7_3 = SHX1_3[2]
        SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
        SHX6_3 = "error"
        return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      end
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "Attempting to take a screenshot of ^3%s ^7(^3id:%s^7). This may take a few seconds."
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.format
      SHX8_3 = SHX2_3
      SHX7_3 = SHX2_3.getName
      SHX7_3 = SHX7_3(SHX8_3)
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getId
      SHX8_3, SHX9_3, SHX10_3 = SHX8_3(SHX9_3)
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX6_3 = "info"
      SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      SHX4_3 = SHX2_3
      SHX3_3 = SHX2_3.getScreenshot
      SHX3_3 = SHX3_3(SHX4_3)
      if nil == SHX3_3 then
        SHX4_3 = Logger
        SHX5_3 = SHX4_3
        SHX4_3 = SHX4_3.log
        SHX6_3 = "Reaper was unable to take a screenshot of ^3%s ^7(^3id:%s^7)"
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.format
        SHX9_3 = SHX2_3
        SHX8_3 = SHX2_3.getName
        SHX8_3 = SHX8_3(SHX9_3)
        SHX10_3 = SHX2_3
        SHX9_3 = SHX2_3.getId
        SHX9_3, SHX10_3 = SHX9_3(SHX10_3)
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
        SHX7_3 = "error"
        return SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      end
      SHX4_3 = string
      SHX4_3 = SHX4_3.match
      SHX5_3 = SHX3_3
      SHX6_3 = "https"
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
      if not SHX4_3 then
        SHX4_3 = Logger
        SHX5_3 = SHX4_3
        SHX4_3 = SHX4_3.log
        SHX6_3 = "Reaper was unable to take a screenshot of ^3%s ^7(^3id:%s^7). Reason: ^3%s^7"
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.format
        SHX9_3 = SHX2_3
        SHX8_3 = SHX2_3.getName
        SHX8_3 = SHX8_3(SHX9_3)
        SHX10_3 = SHX2_3
        SHX9_3 = SHX2_3.getId
        SHX9_3 = SHX9_3(SHX10_3)
        SHX10_3 = SHX3_3
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
        SHX7_3 = "error"
        return SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      end
      SHX4_3 = Logger
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.log
      SHX6_3 = "Successfully took a screenshot of ^3%s ^7(^3id:%s^7) ^4->^7 ^3%s"
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.format
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getName
      SHX8_3 = SHX8_3(SHX9_3)
      SHX10_3 = SHX2_3
      SHX9_3 = SHX2_3.getId
      SHX9_3 = SHX9_3(SHX10_3)
      SHX10_3 = SHX3_3
      SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX7_3 = "info"
      SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    end
    SHX3_2.callback = SHX4_2
    SHX3_2.description = "Takes a screenshot of the players screen."
    SHX4_2 = {}
    SHX5_2 = "Admin Menu"
    SHX4_2[1] = SHX5_2
    SHX3_2.permissions = SHX4_2
    SHX4_2 = {}
    SHX5_2 = "player_source"
    SHX4_2[1] = SHX5_2
    SHX3_2.args = SHX4_2
    SHX1_2(SHX2_2, SHX3_2)
    SHX1_2 = Command
    SHX2_2 = SHX1_2
    SHX1_2 = SHX1_2.add
    SHX3_2 = {}
    SHX3_2.command = "clip"
    function SHX4_2(SHX0_3, SHX1_3)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
      SHX2_3 = Player
      SHX3_3 = SHX1_3[2]
      SHX2_3 = SHX2_3(SHX3_3)
      if nil == SHX2_3 then
        SHX3_3 = Logger
        SHX4_3 = SHX3_3
        SHX3_3 = SHX3_3.log
        SHX5_3 = "^3%s^7 is not a valid player source"
        SHX6_3 = SHX5_3
        SHX5_3 = SHX5_3.format
        SHX7_3 = SHX1_3[2]
        SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
        SHX6_3 = "error"
        return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      end
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "Attempting to take a screen recording of ^3%s ^7(^3id:%s^7). This may take a few seconds."
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.format
      SHX8_3 = SHX2_3
      SHX7_3 = SHX2_3.getName
      SHX7_3 = SHX7_3(SHX8_3)
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getId
      SHX8_3, SHX9_3, SHX10_3 = SHX8_3(SHX9_3)
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX6_3 = "info"
      SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      SHX4_3 = SHX2_3
      SHX3_3 = SHX2_3.getScreenRecording
      SHX3_3 = SHX3_3(SHX4_3)
      if nil == SHX3_3 then
        SHX4_3 = Logger
        SHX5_3 = SHX4_3
        SHX4_3 = SHX4_3.log
        SHX6_3 = "Reaper was unable to take a screen recording of ^3%s ^7(^3id:%s^7)"
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.format
        SHX9_3 = SHX2_3
        SHX8_3 = SHX2_3.getName
        SHX8_3 = SHX8_3(SHX9_3)
        SHX10_3 = SHX2_3
        SHX9_3 = SHX2_3.getId
        SHX9_3, SHX10_3 = SHX9_3(SHX10_3)
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
        SHX7_3 = "error"
        return SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      end
      SHX4_3 = string
      SHX4_3 = SHX4_3.match
      SHX5_3 = SHX3_3
      SHX6_3 = "https"
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
      if not SHX4_3 then
        SHX4_3 = Logger
        SHX5_3 = SHX4_3
        SHX4_3 = SHX4_3.log
        SHX6_3 = "Reaper was unable to take a screen recording of ^3%s ^7(^3id:%s^7). Reason: ^3%s^7"
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.format
        SHX9_3 = SHX2_3
        SHX8_3 = SHX2_3.getName
        SHX8_3 = SHX8_3(SHX9_3)
        SHX10_3 = SHX2_3
        SHX9_3 = SHX2_3.getId
        SHX9_3 = SHX9_3(SHX10_3)
        SHX10_3 = SHX3_3
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
        SHX7_3 = "error"
        return SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      end
      SHX4_3 = Logger
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.log
      SHX6_3 = "Successfully took a screen recording of ^3%s ^7(^3id:%s^7) ^4->^7 ^3%s"
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.format
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getName
      SHX8_3 = SHX8_3(SHX9_3)
      SHX10_3 = SHX2_3
      SHX9_3 = SHX2_3.getId
      SHX9_3 = SHX9_3(SHX10_3)
      SHX10_3 = SHX3_3
      SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX7_3 = "info"
      SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    end
    SHX3_2.callback = SHX4_2
    SHX3_2.description = "Takes a screen recording of the players screen."
    SHX4_2 = {}
    SHX5_2 = "Admin Menu"
    SHX4_2[1] = SHX5_2
    SHX3_2.permissions = SHX4_2
    SHX4_2 = {}
    SHX5_2 = "player_source"
    SHX4_2[1] = SHX5_2
    SHX3_2.args = SHX4_2
    SHX1_2(SHX2_2, SHX3_2)
    SHX1_2 = Command
    SHX2_2 = SHX1_2
    SHX1_2 = SHX1_2.add
    SHX3_2 = {}
    SHX3_2.command = "ocr"
    function SHX4_2(SHX0_3, SHX1_3)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
      SHX2_3 = Player
      SHX3_3 = SHX1_3[2]
      SHX2_3 = SHX2_3(SHX3_3)
      if nil == SHX2_3 then
        SHX3_3 = Logger
        SHX4_3 = SHX3_3
        SHX3_3 = SHX3_3.log
        SHX5_3 = "^3%s^7 is not a valid player source"
        SHX6_3 = SHX5_3
        SHX5_3 = SHX5_3.format
        SHX7_3 = SHX1_3[2]
        SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
        SHX6_3 = "error"
        return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      end
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "Attempting to get OCR text from ^3%s ^7(^3id:%s^7). This may take a few seconds."
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.format
      SHX8_3 = SHX2_3
      SHX7_3 = SHX2_3.getName
      SHX7_3 = SHX7_3(SHX8_3)
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getId
      SHX8_3, SHX9_3, SHX10_3 = SHX8_3(SHX9_3)
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX6_3 = "info"
      SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      SHX4_3 = SHX2_3
      SHX3_3 = SHX2_3.getOCR
      SHX3_3 = SHX3_3(SHX4_3)
      if nil == SHX3_3 then
        SHX4_3 = Logger
        SHX5_3 = SHX4_3
        SHX4_3 = SHX4_3.log
        SHX6_3 = "Reaper was unable to get OCR text from ^3%s ^7(^3id:%s^7)"
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.format
        SHX9_3 = SHX2_3
        SHX8_3 = SHX2_3.getName
        SHX8_3 = SHX8_3(SHX9_3)
        SHX10_3 = SHX2_3
        SHX9_3 = SHX2_3.getId
        SHX9_3, SHX10_3 = SHX9_3(SHX10_3)
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
        SHX7_3 = "error"
        return SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      end
      SHX4_3 = Logger
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.log
      SHX6_3 = "Successfully received OCR text from ^3%s ^7(^3id:%s^7)"
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.format
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getName
      SHX8_3 = SHX8_3(SHX9_3)
      SHX10_3 = SHX2_3
      SHX9_3 = SHX2_3.getId
      SHX9_3, SHX10_3 = SHX9_3(SHX10_3)
      SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX7_3 = "info"
      SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      SHX4_3 = print
      SHX5_3 = SHX3_3
      SHX4_3(SHX5_3)
      SHX4_3 = RPC
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.emit
      SHX6_3 = "Reaper:SendConsoleMessage"
      SHX7_3 = SHX3_3
      SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    end
    SHX3_2.callback = SHX4_2
    SHX3_2.description = "Gets text from a players screen"
    SHX4_2 = {}
    SHX5_2 = "Admin Menu"
    SHX4_2[1] = SHX5_2
    SHX3_2.permissions = SHX4_2
    SHX4_2 = {}
    SHX5_2 = "player_source"
    SHX4_2[1] = SHX5_2
    SHX3_2.args = SHX4_2
    SHX1_2(SHX2_2, SHX3_2)
  end
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "wipe"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3
    SHX2_3 = SHX1_3[2]
    SHX3_3 = table
    SHX3_3 = SHX3_3.concat
    SHX4_3 = SHX1_3
    SHX5_3 = " "
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    SHX5_3 = SHX3_3
    SHX4_3 = SHX3_3.find
    SHX6_3 = "-m="
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    if SHX4_3 then
      SHX5_3 = SHX3_3
      SHX4_3 = SHX3_3.sub
      SHX7_3 = SHX3_3
      SHX6_3 = SHX3_3.find
      SHX8_3 = "-m="
      SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
      if not SHX6_3 then
        SHX6_3 = 0
      end
      SHX7_3 = #SHX3_3
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.gsub
      SHX6_3 = "-m="
      SHX7_3 = ""
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      if SHX4_3 then
        goto SHX_LABEL_28
      end
    end
    SHX4_3 = nil
    -- [FIX IF ERROR] Move ::SHX_LABEL_28:: outside nested blocks until all 'goto SHX_LABEL_28' can see it
    ::SHX_LABEL_28::
    if nil ~= SHX4_3 then
      SHX5_3 = tonumber
      SHX6_3 = SHX4_3
      SHX5_3 = SHX5_3(SHX6_3)
      if nil == SHX5_3 then
        SHX5_3 = tostring
        SHX6_3 = GetHashKey
        SHX7_3 = SHX4_3
        SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3 = SHX6_3(SHX7_3)
        SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3)
        SHX4_3 = SHX5_3
      end
    end
    SHX5_3 = {}
    SHX5_3.all = true
    SHX5_3.peds = true
    SHX5_3.vehicles = true
    SHX5_3.props = true
    SHX6_3 = SHX5_3[SHX2_3]
    if nil == SHX6_3 then
      SHX6_3 = Logger
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.log
      SHX8_3 = "Invalid command usage! reaper wipe all|peds|vehicles|props"
      SHX9_3 = "error"
      return SHX6_3(SHX7_3, SHX8_3, SHX9_3)
    end
    if "all" == SHX2_3 or "peds" == SHX2_3 then
      SHX6_3 = 0
      SHX7_3 = {}
      SHX8_3 = pairs
      SHX9_3 = GetAllPeds
      SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3 = SHX9_3()
      SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3)
      for SHX12_3, SHX13_3 in SHX8_3, SHX9_3, SHX10_3, SHX11_3 do
        SHX14_3 = IsPedAPlayer
        SHX15_3 = SHX13_3
        SHX14_3 = SHX14_3(SHX15_3)
        if not SHX14_3 then
          SHX14_3 = tostring
          SHX15_3 = GetEntityModel
          SHX16_3 = SHX13_3
          SHX15_3, SHX16_3, SHX17_3, SHX18_3 = SHX15_3(SHX16_3)
          SHX14_3 = SHX14_3(SHX15_3, SHX16_3, SHX17_3, SHX18_3)
          if nil == SHX4_3 or SHX14_3 == SHX4_3 then
            SHX15_3 = DeleteEntity
            SHX16_3 = SHX13_3
            SHX15_3(SHX16_3)
            SHX15_3 = SHX7_3[SHX14_3]
            if nil == SHX15_3 then
              SHX15_3 = {}
              SHX15_3.model = SHX14_3
              SHX15_3.amount = 0
              SHX7_3[SHX14_3] = SHX15_3
            end
            SHX6_3 = SHX6_3 + 1
            SHX15_3 = SHX7_3[SHX14_3]
            SHX16_3 = SHX7_3[SHX14_3]
            SHX16_3 = SHX16_3.amount
            SHX16_3 = SHX16_3 + 1
            SHX15_3.amount = SHX16_3
          end
        end
      end
      SHX8_3 = Logger
      SHX9_3 = SHX8_3
      SHX8_3 = SHX8_3.log
      SHX10_3 = "Successfully deleted ^3%s^7 peds"
      SHX11_3 = SHX10_3
      SHX10_3 = SHX10_3.format
      SHX12_3 = SHX6_3
      SHX10_3 = SHX10_3(SHX11_3, SHX12_3)
      SHX11_3 = "info"
      SHX8_3(SHX9_3, SHX10_3, SHX11_3)
      SHX8_3 = json
      SHX8_3 = SHX8_3.encode
      SHX9_3 = SHX7_3
      SHX8_3 = SHX8_3(SHX9_3)
      SHX8_3 = #SHX8_3
      if 2 ~= SHX8_3 then
        SHX9_3 = SHX3_3
        SHX8_3 = SHX3_3.match
        SHX10_3 = "-v"
        SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
        if SHX8_3 then
          SHX8_3 = table
          SHX8_3 = SHX8_3.map
          SHX9_3 = SHX7_3
          function SHX10_3(SHX0_4)
            -- [AI CLEANUP] Decompiled Lua - Fix these:
            -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
            -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
            -- 3. Replace goto/label with while/repeat-until where possible
            -- 4. Remove decompiler comments, add meaningful ones
            -- 5. Fix indentation and formatting
            
            local SHX1_4, SHX2_4, SHX3_4, SHX4_4
            SHX1_4 = "Model: %s - %s"
            SHX2_4 = SHX1_4
            SHX1_4 = SHX1_4.format
            SHX3_4 = SHX0_4.model
            SHX4_4 = SHX0_4.amount
            return SHX1_4(SHX2_4, SHX3_4, SHX4_4)
          end
          SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
          SHX9_3 = Logger
          SHX10_3 = SHX9_3
          SHX9_3 = SHX9_3.log
          SHX11_3 = "    ^1->^7 %s"
          SHX12_3 = SHX11_3
          SHX11_3 = SHX11_3.format
          SHX13_3 = table
          SHX13_3 = SHX13_3.concat
          SHX14_3 = SHX8_3
          SHX15_3 = [[

    ^1->^7 ]]
          SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3 = SHX13_3(SHX14_3, SHX15_3)
          SHX11_3 = SHX11_3(SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3)
          SHX12_3 = "none"
          SHX9_3(SHX10_3, SHX11_3, SHX12_3)
        end
      end
    end
    if "all" == SHX2_3 or "vehicles" == SHX2_3 then
      SHX6_3 = 0
      SHX7_3 = {}
      SHX9_3 = SHX3_3
      SHX8_3 = SHX3_3.match
      SHX10_3 = "-f"
      SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
      SHX9_3 = pairs
      SHX10_3 = GetAllVehicles
      SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3 = SHX10_3()
      SHX9_3, SHX10_3, SHX11_3, SHX12_3 = SHX9_3(SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3)
      for SHX13_3, SHX14_3 in SHX9_3, SHX10_3, SHX11_3, SHX12_3 do
        SHX15_3 = tostring
        SHX16_3 = GetEntityModel
        SHX17_3 = SHX14_3
        SHX16_3, SHX17_3, SHX18_3 = SHX16_3(SHX17_3)
        SHX15_3 = SHX15_3(SHX16_3, SHX17_3, SHX18_3)
        if nil == SHX4_3 or SHX15_3 == SHX4_3 then
          SHX16_3 = GetPedInVehicleSeat
          SHX17_3 = SHX14_3
          SHX18_3 = -1
          SHX16_3 = SHX16_3(SHX17_3, SHX18_3)
          if 0 == SHX16_3 or SHX8_3 then
            SHX16_3 = DeleteEntity
            SHX17_3 = SHX14_3
            SHX16_3(SHX17_3)
            SHX16_3 = SHX7_3[SHX15_3]
            if nil == SHX16_3 then
              SHX16_3 = {}
              SHX16_3.model = SHX15_3
              SHX16_3.amount = 0
              SHX7_3[SHX15_3] = SHX16_3
            end
            SHX6_3 = SHX6_3 + 1
            SHX16_3 = SHX7_3[SHX15_3]
            SHX17_3 = SHX7_3[SHX15_3]
            SHX17_3 = SHX17_3.amount
            SHX17_3 = SHX17_3 + 1
            SHX16_3.amount = SHX17_3
          end
        end
      end
      SHX9_3 = Logger
      SHX10_3 = SHX9_3
      SHX9_3 = SHX9_3.log
      SHX11_3 = "Successfully deleted ^3%s^7 vehicles"
      SHX12_3 = SHX11_3
      SHX11_3 = SHX11_3.format
      SHX13_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
      SHX12_3 = "info"
      SHX9_3(SHX10_3, SHX11_3, SHX12_3)
      SHX9_3 = json
      SHX9_3 = SHX9_3.encode
      SHX10_3 = SHX7_3
      SHX9_3 = SHX9_3(SHX10_3)
      SHX9_3 = #SHX9_3
      if 2 ~= SHX9_3 then
        SHX9_3 = RPC
        SHX10_3 = SHX9_3
        SHX9_3 = SHX9_3.emitNet
        SHX11_3 = "entities:cleanup"
        SHX12_3 = -1
        SHX9_3(SHX10_3, SHX11_3, SHX12_3)
        SHX10_3 = SHX3_3
        SHX9_3 = SHX3_3.match
        SHX11_3 = "-v"
        SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
        if SHX9_3 then
          SHX9_3 = table
          SHX9_3 = SHX9_3.map
          SHX10_3 = SHX7_3
          function SHX11_3(SHX0_4)
            -- [AI CLEANUP] Decompiled Lua - Fix these:
            -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
            -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
            -- 3. Replace goto/label with while/repeat-until where possible
            -- 4. Remove decompiler comments, add meaningful ones
            -- 5. Fix indentation and formatting
            
            local SHX1_4, SHX2_4, SHX3_4, SHX4_4
            SHX1_4 = "Model: %s - %s"
            SHX2_4 = SHX1_4
            SHX1_4 = SHX1_4.format
            SHX3_4 = SHX0_4.model
            SHX4_4 = SHX0_4.amount
            return SHX1_4(SHX2_4, SHX3_4, SHX4_4)
          end
          SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
          SHX10_3 = Logger
          SHX11_3 = SHX10_3
          SHX10_3 = SHX10_3.log
          SHX12_3 = "    ^1->^7 %s"
          SHX13_3 = SHX12_3
          SHX12_3 = SHX12_3.format
          SHX14_3 = table
          SHX14_3 = SHX14_3.concat
          SHX15_3 = SHX9_3
          SHX16_3 = [[

    ^1->^7 ]]
          SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3 = SHX14_3(SHX15_3, SHX16_3)
          SHX12_3 = SHX12_3(SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3)
          SHX13_3 = "none"
          SHX10_3(SHX11_3, SHX12_3, SHX13_3)
        end
      end
    end
    if "all" == SHX2_3 or "props" == SHX2_3 then
      SHX6_3 = 0
      SHX7_3 = {}
      SHX9_3 = SHX3_3
      SHX8_3 = SHX3_3.match
      SHX10_3 = "-f"
      SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
      SHX9_3 = pairs
      SHX10_3 = GetAllObjects
      SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3 = SHX10_3()
      SHX9_3, SHX10_3, SHX11_3, SHX12_3 = SHX9_3(SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3)
      for SHX13_3, SHX14_3 in SHX9_3, SHX10_3, SHX11_3, SHX12_3 do
        SHX15_3 = tostring
        SHX16_3 = GetEntityModel
        SHX17_3 = SHX14_3
        SHX16_3, SHX17_3, SHX18_3 = SHX16_3(SHX17_3)
        SHX15_3 = SHX15_3(SHX16_3, SHX17_3, SHX18_3)
        if nil == SHX4_3 or SHX15_3 == SHX4_3 then
          SHX16_3 = GetEntityAttachedTo
          SHX17_3 = SHX14_3
          SHX16_3 = SHX16_3(SHX17_3)
        end
        if 0 == SHX16_3 or SHX8_3 then
          SHX16_3 = DeleteEntity
          SHX17_3 = SHX14_3
          SHX16_3(SHX17_3)
          SHX16_3 = SHX7_3[SHX15_3]
          if nil == SHX16_3 then
            SHX16_3 = {}
            SHX16_3.model = SHX15_3
            SHX16_3.amount = 0
            SHX7_3[SHX15_3] = SHX16_3
          end
          SHX6_3 = SHX6_3 + 1
          SHX16_3 = SHX7_3[SHX15_3]
          SHX17_3 = SHX7_3[SHX15_3]
          SHX17_3 = SHX17_3.amount
          SHX17_3 = SHX17_3 + 1
          SHX16_3.amount = SHX17_3
        end
      end
      SHX9_3 = Logger
      SHX10_3 = SHX9_3
      SHX9_3 = SHX9_3.log
      SHX11_3 = "Successfully deleted ^3%s^7 props"
      SHX12_3 = SHX11_3
      SHX11_3 = SHX11_3.format
      SHX13_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
      SHX12_3 = "info"
      SHX9_3(SHX10_3, SHX11_3, SHX12_3)
      SHX9_3 = json
      SHX9_3 = SHX9_3.encode
      SHX10_3 = SHX7_3
      SHX9_3 = SHX9_3(SHX10_3)
      SHX9_3 = #SHX9_3
      if 2 ~= SHX9_3 then
        SHX10_3 = SHX3_3
        SHX9_3 = SHX3_3.match
        SHX11_3 = "-v"
        SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
        if SHX9_3 then
          SHX9_3 = table
          SHX9_3 = SHX9_3.map
          SHX10_3 = SHX7_3
          function SHX11_3(SHX0_4)
            -- [AI CLEANUP] Decompiled Lua - Fix these:
            -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
            -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
            -- 3. Replace goto/label with while/repeat-until where possible
            -- 4. Remove decompiler comments, add meaningful ones
            -- 5. Fix indentation and formatting
            
            local SHX1_4, SHX2_4, SHX3_4, SHX4_4
            SHX1_4 = "Model: %s - %s"
            SHX2_4 = SHX1_4
            SHX1_4 = SHX1_4.format
            SHX3_4 = SHX0_4.model
            SHX4_4 = SHX0_4.amount
            return SHX1_4(SHX2_4, SHX3_4, SHX4_4)
          end
          SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
          SHX10_3 = Logger
          SHX11_3 = SHX10_3
          SHX10_3 = SHX10_3.log
          SHX12_3 = "    ^1->^7 %s"
          SHX13_3 = SHX12_3
          SHX12_3 = SHX12_3.format
          SHX14_3 = table
          SHX14_3 = SHX14_3.concat
          SHX15_3 = SHX9_3
          SHX16_3 = [[

    ^1->^7 ]]
          SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3 = SHX14_3(SHX15_3, SHX16_3)
          SHX12_3 = SHX12_3(SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3)
          SHX13_3 = "none"
          SHX10_3(SHX11_3, SHX12_3, SHX13_3)
        end
      end
    end
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.description = "Deletes spawned entities from the map"
  SHX4_2 = {}
  SHX5_2 = "all|peds|vehicles|props"
  SHX6_2 = "-v|nil"
  SHX4_2[1] = SHX5_2
  SHX4_2[2] = SHX6_2
  SHX3_2.args = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Entity Wipe"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "devcommands"
  function SHX4_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3
    SHX1_3 = Player
    SHX2_3 = SHX0_3
    SHX1_3 = SHX1_3(SHX2_3)
    if nil == SHX1_3 then
      return
    end
    SHX2_3 = RPC
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.emitNet
    SHX4_3 = "RegisterTestCommands"
    SHX6_3 = SHX1_3
    SHX5_3 = SHX1_3.getId
    SHX5_3, SHX6_3, SHX7_3, SHX8_3 = SHX5_3(SHX6_3)
    SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3)
    SHX2_3 = Logger
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.log
    SHX4_3 = "Successfully enabled developer commands for ^3%s ^7(^3id:%s^7)"
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.format
    SHX7_3 = SHX1_3
    SHX6_3 = SHX1_3.getName
    SHX6_3 = SHX6_3(SHX7_3)
    SHX8_3 = SHX1_3
    SHX7_3 = SHX1_3.getId
    SHX7_3, SHX8_3 = SHX7_3(SHX8_3)
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
    SHX5_3 = "info"
    SHX2_3(SHX3_3, SHX4_3, SHX5_3)
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.hidden = true
  SHX4_2 = {}
  SHX5_2 = "Update Config"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "player"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3
    SHX2_3 = Player
    SHX3_3 = SHX1_3[2]
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "Invalid command usage, it looks like you have provided an invalid player iD!"
      SHX6_3 = "error"
      return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    end
    SHX3_3 = Logger
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.log
    SHX5_3 = "https://my.reaperac.com/@me/players/%s"
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.format
    SHX8_3 = SHX2_3
    SHX7_3 = SHX2_3.getIdentifier
    SHX9_3 = "license"
    SHX7_3, SHX8_3, SHX9_3 = SHX7_3(SHX8_3, SHX9_3)
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX6_3 = "info"
    SHX3_3(SHX4_3, SHX5_3, SHX6_3)
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.description = "View a players history across all Reaper servers"
  SHX4_2 = {}
  SHX5_2 = "player_source"
  SHX4_2[1] = SHX5_2
  SHX3_2.args = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Admin Menu"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "kick"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3
    SHX2_3 = Player
    SHX3_3 = SHX1_3[2]
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "Invalid command usage, you have provided an invalid player ID!"
      SHX6_3 = "error"
      return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    end
    SHX3_3 = Cache
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.get
    SHX5_3 = "ownerName"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    SHX4_3 = Cache
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.get
    SHX6_3 = "ownerId"
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    if 0 ~= SHX0_3 then
      SHX5_3 = Player
      SHX6_3 = SHX0_3
      SHX5_3 = SHX5_3(SHX6_3)
      if nil == SHX5_3 then
        SHX6_3 = Logger
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.log
        SHX8_3 = "Unknown Error #1"
        SHX9_3 = "error"
        return SHX6_3(SHX7_3, SHX8_3, SHX9_3)
      end
      SHX7_3 = SHX5_3
      SHX6_3 = SHX5_3.getCfxInfo
      SHX6_3 = SHX6_3(SHX7_3)
      SHX3_3 = SHX6_3.cfxUsername
      SHX7_3 = SHX5_3
      SHX6_3 = SHX5_3.getCfxInfo
      SHX6_3 = SHX6_3(SHX7_3)
      SHX4_3 = SHX6_3.cfxId
    end
    SHX5_3 = Logger
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.log
    SHX7_3 = "^3%s^7 (^3fivem:%s^7) is kicking ^3%s^7 (^3id:%s^7) from the server."
    SHX8_3 = SHX7_3
    SHX7_3 = SHX7_3.format
    SHX9_3 = SHX3_3
    SHX10_3 = SHX4_3
    SHX12_3 = SHX2_3
    SHX11_3 = SHX2_3.getName
    SHX11_3 = SHX11_3(SHX12_3)
    SHX13_3 = SHX2_3
    SHX12_3 = SHX2_3.getId
    SHX12_3, SHX13_3, SHX14_3, SHX15_3 = SHX12_3(SHX13_3)
    SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3)
    SHX8_3 = "info"
    SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    SHX5_3 = RPC
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.emitLocal
    SHX7_3 = "Reaper:NewDetection"
    SHX8_3 = {}
    SHX8_3.type = "manualDetection"
    SHX8_3.action = "Kick Player"
    SHX9_3 = "%s ~ %s"
    SHX10_3 = SHX9_3
    SHX9_3 = SHX9_3.format
    SHX11_3 = table
    SHX11_3 = SHX11_3.concat
    SHX12_3 = SHX1_3
    SHX13_3 = " "
    SHX14_3 = 3
    SHX15_3 = #SHX1_3
    SHX11_3 = SHX11_3(SHX12_3, SHX13_3, SHX14_3, SHX15_3)
    SHX12_3 = SHX3_3
    SHX9_3 = SHX9_3(SHX10_3, SHX11_3, SHX12_3)
    SHX8_3.reason = SHX9_3
    SHX9_3 = {}
    SHX8_3.data = SHX9_3
    SHX9_3 = {}
    SHX8_3.params = SHX9_3
    SHX10_3 = SHX2_3
    SHX9_3 = SHX2_3.getId
    SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3 = SHX9_3(SHX10_3)
    SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3)
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.description = "Kicks a player from the server"
  SHX4_2 = {}
  SHX5_2 = "player_source"
  SHX6_2 = "reason"
  SHX4_2[1] = SHX5_2
  SHX4_2[2] = SHX6_2
  SHX3_2.args = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Manage Players"
  SHX6_2 = "Kick Players"
  SHX4_2[1] = SHX5_2
  SHX4_2[2] = SHX6_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "ban"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3
    SHX2_3 = Player
    SHX3_3 = SHX1_3[2]
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "Invalid command usage, you have provided an invalid player ID!"
      SHX6_3 = "error"
      return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    end
    SHX3_3 = Cache
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.get
    SHX5_3 = "ownerName"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    SHX4_3 = Cache
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.get
    SHX6_3 = "ownerId"
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    if 0 ~= SHX0_3 then
      SHX5_3 = Player
      SHX6_3 = SHX0_3
      SHX5_3 = SHX5_3(SHX6_3)
      if nil == SHX5_3 then
        SHX6_3 = Logger
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.log
        SHX8_3 = "Unknown Error #1"
        SHX9_3 = "error"
        return SHX6_3(SHX7_3, SHX8_3, SHX9_3)
      end
      SHX7_3 = SHX5_3
      SHX6_3 = SHX5_3.getCfxInfo
      SHX6_3 = SHX6_3(SHX7_3)
      SHX3_3 = SHX6_3.cfxUsername
      SHX7_3 = SHX5_3
      SHX6_3 = SHX5_3.getCfxInfo
      SHX6_3 = SHX6_3(SHX7_3)
      SHX4_3 = SHX6_3.cfxId
    end
    SHX5_3 = Logger
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.log
    SHX7_3 = "^3%s^7 (^3fivem:%s^7) is banning ^3%s^7 (^3id:%s^7) from the server."
    SHX8_3 = SHX7_3
    SHX7_3 = SHX7_3.format
    SHX9_3 = SHX3_3
    SHX10_3 = SHX4_3
    SHX12_3 = SHX2_3
    SHX11_3 = SHX2_3.getName
    SHX11_3 = SHX11_3(SHX12_3)
    SHX13_3 = SHX2_3
    SHX12_3 = SHX2_3.getId
    SHX12_3, SHX13_3, SHX14_3, SHX15_3 = SHX12_3(SHX13_3)
    SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3)
    SHX8_3 = "info"
    SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    SHX5_3 = RPC
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.emitLocal
    SHX7_3 = "Reaper:NewDetection"
    SHX8_3 = {}
    SHX8_3.type = "manualDetection"
    SHX8_3.action = "Ban Player"
    SHX9_3 = "%s ~ %s"
    SHX10_3 = SHX9_3
    SHX9_3 = SHX9_3.format
    SHX11_3 = table
    SHX11_3 = SHX11_3.concat
    SHX12_3 = SHX1_3
    SHX13_3 = " "
    SHX14_3 = 3
    SHX15_3 = #SHX1_3
    SHX11_3 = SHX11_3(SHX12_3, SHX13_3, SHX14_3, SHX15_3)
    SHX12_3 = SHX3_3
    SHX9_3 = SHX9_3(SHX10_3, SHX11_3, SHX12_3)
    SHX8_3.reason = SHX9_3
    SHX9_3 = {}
    SHX8_3.data = SHX9_3
    SHX9_3 = {}
    SHX8_3.params = SHX9_3
    SHX10_3 = SHX2_3
    SHX9_3 = SHX2_3.getId
    SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3 = SHX9_3(SHX10_3)
    SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3)
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.description = "Bans a player from the server"
  SHX4_2 = {}
  SHX5_2 = "player_source"
  SHX6_2 = "reason"
  SHX4_2[1] = SHX5_2
  SHX4_2[2] = SHX6_2
  SHX3_2.args = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Manage Players"
  SHX6_2 = "Ban Players"
  SHX4_2[1] = SHX5_2
  SHX4_2[2] = SHX6_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "unban"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3
    SHX2_3 = SHX1_3[2]
    SHX3_3 = nil
    if 0 == SHX0_3 then
      SHX4_3 = Cache
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "ownerAccessKey"
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
      if SHX4_3 then
        SHX4_3 = Cache
        SHX5_3 = SHX4_3
        SHX4_3 = SHX4_3.get
        SHX6_3 = "ownerAccessKey"
        SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
        SHX3_3 = SHX4_3
      else
        SHX4_3 = HTTP
        SHX5_3 = SHX4_3
        SHX4_3 = SHX4_3.await
        SHX6_3 = "https://api.reaperac.com/api/v1/access/grant"
        SHX7_3 = "POST"
        SHX8_3 = json
        SHX8_3 = SHX8_3.encode
        SHX9_3 = {}
        SHX10_3 = Cache
        SHX11_3 = SHX10_3
        SHX10_3 = SHX10_3.get
        SHX12_3 = "secret"
        SHX10_3 = SHX10_3(SHX11_3, SHX12_3)
        SHX9_3.server_secret = SHX10_3
        SHX10_3 = tonumber
        SHX11_3 = Cache
        SHX12_3 = SHX11_3
        SHX11_3 = SHX11_3.get
        SHX13_3 = "ownerId"
        SHX11_3, SHX12_3, SHX13_3 = SHX11_3(SHX12_3, SHX13_3)
        SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
        SHX9_3.fivemId = SHX10_3
        SHX10_3 = Cache
        SHX11_3 = SHX10_3
        SHX10_3 = SHX10_3.get
        SHX12_3 = "serverId"
        SHX10_3 = SHX10_3(SHX11_3, SHX12_3)
        SHX9_3.serverId = SHX10_3
        SHX8_3 = SHX8_3(SHX9_3)
        SHX9_3 = {}
        SHX9_3["Content-Type"] = "application/json"
        SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
        SHX5_3 = SHX4_3.status
        if 200 ~= SHX5_3 then
          SHX5_3 = Logger
          SHX6_3 = SHX5_3
          SHX5_3 = SHX5_3.log
          SHX7_3 = "Failed to receive response from from ^3sv1.reaperac.com^7 when trying to remove this ban."
          SHX8_3 = "error"
          return SHX5_3(SHX6_3, SHX7_3, SHX8_3)
        end
        SHX5_3 = json
        SHX5_3 = SHX5_3.decode
        SHX6_3 = SHX4_3.body
        SHX5_3 = SHX5_3(SHX6_3)
        SHX6_3 = SHX5_3.code
        if 200 ~= SHX6_3 then
          SHX6_3 = print
          SHX7_3 = SHX5_3
          return SHX6_3(SHX7_3)
        end
        SHX6_3 = Cache
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.set
        SHX8_3 = "ownerAccessKey"
        SHX9_3 = SHX5_3.access_token
        SHX6_3(SHX7_3, SHX8_3, SHX9_3)
        SHX3_3 = SHX5_3.access_token
      end
    else
      SHX4_3 = Player
      SHX5_3 = SHX0_3
      SHX4_3 = SHX4_3(SHX5_3)
      if nil == SHX4_3 then
        return
      end
      SHX6_3 = SHX4_3
      SHX5_3 = SHX4_3.getAccessToken
      SHX5_3, SHX6_3 = SHX5_3(SHX6_3)
      if not SHX5_3 then
        SHX7_3 = Logger
        SHX8_3 = SHX7_3
        SHX7_3 = SHX7_3.log
        SHX9_3 = "Reaper ran into an error when trying to fetch users access token."
        SHX10_3 = "error"
        return SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      end
      SHX3_3 = SHX6_3
    end
    SHX4_3 = #SHX2_3
    if 24 ~= SHX4_3 then
      SHX4_3 = Logger
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.log
      SHX6_3 = "It looks like you have provided an invalid ban ID"
      SHX7_3 = "error"
      return SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    end
    SHX4_3 = HTTP
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.await
    SHX6_3 = "https://api.reaperac.com/api/v1/servers/%s/detections/%s?isFalse=%s"
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.format
    SHX8_3 = Cache
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.get
    SHX10_3 = "dbId"
    SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
    SHX9_3 = SHX2_3
    SHX10_3 = false
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
    SHX7_3 = "DELETE"
    SHX8_3 = nil
    SHX9_3 = {}
    SHX9_3["api-key"] = SHX3_3
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX5_3 = SHX4_3.status
    if 200 ~= SHX5_3 then
      SHX5_3 = Logger
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.log
      SHX7_3 = "Failed to receive response from from ^3sv1.reaperac.com^7 when trying to remove this ban."
      SHX8_3 = "error"
      return SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    end
    SHX5_3 = json
    SHX5_3 = SHX5_3.decode
    SHX6_3 = SHX4_3.body
    SHX5_3 = SHX5_3(SHX6_3)
    SHX6_3 = SHX5_3.code
    if 200 ~= SHX6_3 then
      SHX6_3 = print
      SHX7_3 = SHX4_3.body
      return SHX6_3(SHX7_3)
    end
    SHX6_3 = SHX5_3.error
    if SHX6_3 then
      SHX6_3 = SHX5_3.message
      if "This detection does not exist. Refresh your page" == SHX6_3 then
        SHX5_3.message = "It looks like you have provided an invalid ban ID"
      end
      SHX6_3 = Logger
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.log
      SHX8_3 = SHX5_3.message
      SHX9_3 = "error"
      return SHX6_3(SHX7_3, SHX8_3, SHX9_3)
    end
    SHX6_3 = Logger
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.log
    SHX8_3 = "The ban ^3%s^7 has been successfully removed"
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.format
    SHX10_3 = SHX2_3
    SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
    SHX9_3 = "info"
    SHX6_3(SHX7_3, SHX8_3, SHX9_3)
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.description = "Removes the specified ban"
  SHX4_2 = {}
  SHX5_2 = "banID"
  SHX6_2 = "reason"
  SHX4_2[1] = SHX5_2
  SHX4_2[2] = SHX6_2
  SHX3_2.args = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Remove Bans"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "pmevent"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3
    SHX2_3 = SHX1_3[2]
    SHX3_3 = SHX1_3[3]
    SHX4_3 = Logger
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.log
    SHX6_3 = "Pattern test for ^3%s^7 using ^3%s^7 returned ^3%s^7"
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.format
    SHX8_3 = SHX2_3
    SHX9_3 = SHX3_3
    SHX10_3 = tostring
    SHX11_3 = string
    SHX11_3 = SHX11_3.match
    SHX12_3 = SHX2_3
    SHX13_3 = SHX3_3
    SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
    SHX11_3 = nil ~= SHX11_3
    SHX10_3, SHX11_3, SHX12_3, SHX13_3 = SHX10_3(SHX11_3)
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3)
    SHX7_3 = "info"
    SHX4_3(SHX5_3, SHX6_3, SHX7_3)
  end
  SHX3_2.callback = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "event"
  SHX6_2 = "pattern"
  SHX4_2[1] = SHX5_2
  SHX4_2[2] = SHX6_2
  SHX3_2.args = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Manage Server"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "toggleentitytracker"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    if not SHX2_3 then
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "You must be in the server to run this command."
      SHX6_3 = "error"
      return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.emit
    SHX5_3 = "Reaper:ToggleEntityInfo"
    SHX3_3(SHX4_3, SHX5_3)
    SHX3_3 = Logger
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.log
    SHX5_3 = "Successfully toggled entity tracker"
    SHX6_3 = "info"
    SHX3_3(SHX4_3, SHX5_3, SHX6_3)
  end
  SHX3_2.callback = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Admin Menu"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "tptonetentity"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    if not SHX2_3 then
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "You must be in the server to run this command."
      SHX6_3 = "error"
      return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    end
    SHX3_3 = NetworkGetEntityFromNetworkId
    SHX4_3 = tonumber
    SHX5_3 = SHX1_3[2]
    SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3 = SHX4_3(SHX5_3)
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3)
    if 0 == SHX3_3 then
      SHX4_3 = Logger
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.log
      SHX6_3 = "^3%s^7 is not a valid net id"
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.format
      SHX8_3 = SHX1_3[2]
      SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
      SHX7_3 = "error"
      return SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    end
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.setCoords
    SHX6_3 = GetEntityCoords
    SHX7_3 = SHX3_3
    SHX6_3, SHX7_3, SHX8_3 = SHX6_3(SHX7_3)
    SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
    SHX4_3 = Logger
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.log
    SHX6_3 = "Successfully teleported to the entity ^3%s^7"
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.format
    SHX8_3 = SHX1_3[2]
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
    SHX7_3 = "info"
    SHX4_3(SHX5_3, SHX6_3, SHX7_3)
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.hidden = false
  SHX4_2 = {}
  SHX5_2 = "Manage Server"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "onesynctest"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3
    SHX2_3 = Player
    SHX3_3 = SHX1_3[2]
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "Invalid command usage, you have provided an invalid player ID!"
      SHX6_3 = "error"
      return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    end
    SHX3_3 = RPC
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.await
    SHX5_3 = "getOneSyncData"
    SHX7_3 = SHX2_3
    SHX6_3 = SHX2_3.getId
    SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX6_3(SHX7_3)
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX4_3 = Logger
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.log
    SHX6_3 = json
    SHX6_3 = SHX6_3.encode
    SHX7_3 = {}
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getName
    SHX8_3 = SHX8_3(SHX9_3)
    SHX7_3.name = SHX8_3
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getCoords
    SHX8_3 = SHX8_3(SHX9_3)
    SHX7_3.coords = SHX8_3
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getWeapon
    SHX8_3 = SHX8_3(SHX9_3)
    SHX7_3.weapon = SHX8_3
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getVoiceProximity
    SHX8_3 = SHX8_3(SHX9_3)
    SHX7_3.voice_proximity = SHX8_3
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getWeaponDamageModifier
    SHX8_3 = SHX8_3(SHX9_3)
    SHX7_3.weapon_damage_modifier = SHX8_3
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.isInvincible
    SHX8_3 = SHX8_3(SHX9_3)
    SHX7_3.isInvincible = SHX8_3
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.isInFreeCam
    SHX8_3 = SHX8_3(SHX9_3)
    SHX7_3.in_free_cam = SHX8_3
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getCamFocusPos
    SHX8_3 = SHX8_3(SHX9_3)
    SHX7_3.player_focus_pos = SHX8_3
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.isVisible
    SHX8_3 = SHX8_3(SHX9_3)
    SHX7_3.is_visible = SHX8_3
    SHX7_3.player_client_data = SHX3_3
    SHX8_3 = {}
    SHX8_3.indent = true
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
    SHX7_3 = "none"
    SHX4_3(SHX5_3, SHX6_3, SHX7_3)
  end
  SHX3_2.callback = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "player_id"
  SHX4_2[1] = SHX5_2
  SHX3_2.args = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Manage Server"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX3_2.hidden = true
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "encryptstr"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3
    if 0 ~= SHX0_3 then
      return
    end
    SHX2_3 = print
    SHX3_3 = Security
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.encrypt
    SHX5_3 = SHX1_3[2]
    SHX3_3, SHX4_3, SHX5_3 = SHX3_3(SHX4_3, SHX5_3)
    SHX2_3(SHX3_3, SHX4_3, SHX5_3)
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.hidden = true
  SHX4_2 = {}
  SHX5_2 = "Manage Server"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "randomuuid"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    if 0 ~= SHX0_3 then
      return
    end
    SHX2_3 = print
    SHX3_3 = Security
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.genUUID
    SHX3_3, SHX4_3 = SHX3_3(SHX4_3)
    SHX2_3(SHX3_3, SHX4_3)
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.hidden = true
  SHX4_2 = {}
  SHX5_2 = "Manage Server"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "getstatedata"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    SHX2_3 = Player
    SHX3_3 = SHX1_3[2]
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_3[3]
    if not SHX3_3 then
      SHX3_3 = ""
    end
    SHX4_3 = tonumber
    SHX5_3 = SHX1_3[4]
    SHX4_3 = SHX4_3(SHX5_3)
    if not SHX4_3 then
      SHX4_3 = 25
    end
    if nil == SHX2_3 then
      SHX5_3 = Logger
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.log
      SHX7_3 = "Invalid command usage, you have provided an invalid player ID!"
      SHX8_3 = "error"
      return SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    end
    SHX5_3 = RPC
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.await
    SHX7_3 = "getLastRecordedStateData"
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getId
    SHX8_3 = SHX8_3(SHX9_3)
    SHX9_3 = {}
    SHX10_3 = SHX3_3
    SHX11_3 = SHX4_3
    SHX9_3[1] = SHX10_3
    SHX9_3[2] = SHX11_3
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX6_3 = Logger
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.log
    SHX8_3 = json
    SHX8_3 = SHX8_3.encode
    SHX9_3 = SHX5_3
    SHX10_3 = {}
    SHX10_3.indent = true
    SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
    SHX9_3 = "none"
    SHX6_3(SHX7_3, SHX8_3, SHX9_3)
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.hidden = true
  SHX4_2 = {}
  SHX5_2 = "Manage Server"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "togglestatelogger"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX2_3 = Player
    SHX3_3 = SHX1_3[2]
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "Invalid command usage, you have provided an invalid player ID!"
      SHX6_3 = "error"
      return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.rpc_await
    SHX5_3 = "toggle_state_tracker"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    SHX4_3 = type
    SHX5_3 = SHX3_3
    SHX4_3 = SHX4_3(SHX5_3)
    if "boolean" ~= SHX4_3 then
      SHX4_3 = Logger
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.log
      SHX6_3 = "Failed to toggle state logger for ^3%s^7 (^3id%s^7)"
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.format
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getName
      SHX8_3 = SHX8_3(SHX9_3)
      SHX10_3 = SHX2_3
      SHX9_3 = SHX2_3.getId
      SHX9_3, SHX10_3 = SHX9_3(SHX10_3)
      SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX7_3 = "error"
      SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    end
    if SHX3_3 then
      SHX4_3 = Logger
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.log
      SHX6_3 = "Successfully enabled the state logger for ^3%s^7 (^3id%s^7)"
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.format
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getName
      SHX8_3 = SHX8_3(SHX9_3)
      SHX10_3 = SHX2_3
      SHX9_3 = SHX2_3.getId
      SHX9_3, SHX10_3 = SHX9_3(SHX10_3)
      SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX7_3 = "info"
      SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    else
      SHX4_3 = Logger
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.log
      SHX6_3 = "Successfully disabled the state logger for ^3%s^7 (^3id%s^7)"
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.format
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getName
      SHX8_3 = SHX8_3(SHX9_3)
      SHX10_3 = SHX2_3
      SHX9_3 = SHX2_3.getId
      SHX9_3, SHX10_3 = SHX9_3(SHX10_3)
      SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX7_3 = "info"
      SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    end
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.hidden = true
  SHX4_2 = {}
  SHX5_2 = "Manage Server"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "refreshflaggedevents"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3
    SHX2_3 = HTTP
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.await
    SHX4_3 = "https://api.reaperac.com/api/v1/data/flaggedevents"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
    SHX2_3 = SHX2_3.body
    if not SHX2_3 then
      SHX2_3 = "{}"
    end
    SHX3_3 = json
    SHX3_3 = SHX3_3.decode
    SHX4_3 = SHX2_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = LoadResourceFile
    SHX5_3 = "ReaperV4"
    SHX6_3 = "cache/flaggedEvents.json"
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    if not SHX4_3 then
      SHX4_3 = ""
    end
    SHX4_3 = #SHX4_3
    SHX5_3 = #SHX2_3
    if SHX4_3 ~= SHX5_3 then
      SHX4_3 = SaveResourceFile
      SHX5_3 = "ReaperV4"
      SHX6_3 = "cache/flaggedEvents.json"
      SHX7_3 = SHX2_3
      SHX8_3 = #SHX2_3
      SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX4_3 = RPC
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.emitLocal
      SHX6_3 = "Reaper:UpdateFlaggedEvents"
      SHX4_3(SHX5_3, SHX6_3)
    end
    SHX4_3 = Logger
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.log
    SHX6_3 = "Successfully refreshed flagged events."
    SHX7_3 = "info"
    SHX4_3(SHX5_3, SHX6_3, SHX7_3)
  end
  SHX3_2.callback = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Manage Server"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX3_2.hidden = true
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "addeventkey"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3
    SHX2_3 = SHX1_3[2]
    SHX3_3 = SHX1_3[3]
    SHX4_3 = SHX1_3[4]
    if nil ~= SHX4_3 then
      SHX5_3 = #SHX4_3
      if 19 == SHX5_3 then
        goto SHX_LABEL_27
      end
      SHX5_3 = #SHX4_3
      if 20 == SHX5_3 then
        goto SHX_LABEL_27
      end
      SHX5_3 = #SHX4_3
      if 18 == SHX5_3 then
        goto SHX_LABEL_27
      end
      SHX5_3 = #SHX4_3
      if 17 == SHX5_3 then
        goto SHX_LABEL_27
      end
    end
    SHX5_3 = Logger
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.log
    SHX7_3 = "You have provided an invalid event key. ^3%s^7 is not a valid key"
    SHX8_3 = SHX7_3
    SHX7_3 = SHX7_3.format
    SHX9_3 = SHX4_3
    SHX7_3 = SHX7_3(SHX8_3, SHX9_3)
    SHX8_3 = "error"
    return SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    -- [FIX IF ERROR] Move ::SHX_LABEL_27:: outside nested blocks until all 'goto SHX_LABEL_27' can see it
    ::SHX_LABEL_27::
    SHX5_3 = GetResourceState
    SHX6_3 = SHX2_3
    SHX5_3 = SHX5_3(SHX6_3)
    if "missing" == SHX5_3 then
      SHX5_3 = Logger
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.log
      SHX7_3 = "You have provided an invalid resource name. ^3%s^7 is not a valid resource name"
      SHX8_3 = SHX7_3
      SHX7_3 = SHX7_3.format
      SHX9_3 = SHX2_3
      SHX7_3 = SHX7_3(SHX8_3, SHX9_3)
      SHX8_3 = "error"
      return SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    end
    SHX5_3 = json
    SHX5_3 = SHX5_3.decode
    SHX6_3 = LoadResourceFile
    SHX7_3 = "ReaperV4"
    SHX8_3 = "cache/event_lock.json"
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
    if not SHX6_3 then
      SHX6_3 = "{}"
    end
    SHX5_3 = SHX5_3(SHX6_3)
    SHX6_3 = "%s_%s"
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.format
    SHX8_3 = Security
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.hash
    SHX10_3 = SHX2_3
    SHX11_3 = "97ae7727-b78e47fc-075ea9de-c852f7da-44587eed"
    SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3)
    SHX9_3 = Security
    SHX10_3 = SHX9_3
    SHX9_3 = SHX9_3.hash
    SHX11_3 = SHX3_3
    SHX12_3 = "97ae7727-b78e47fc-075ea9de-c852f7da-44587eed"
    SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3 = SHX9_3(SHX10_3, SHX11_3, SHX12_3)
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
    SHX7_3 = SHX5_3[SHX6_3]
    if nil == SHX7_3 then
      SHX7_3 = {}
      SHX5_3[SHX6_3] = SHX7_3
    end
    SHX7_3 = SHX5_3[SHX6_3]
    SHX8_3 = {}
    SHX8_3.type = "manual"
    SHX8_3.event_name = SHX3_3
    SHX7_3[SHX4_3] = SHX8_3
    SHX7_3 = json
    SHX7_3 = SHX7_3.encode
    SHX8_3 = SHX5_3
    SHX7_3 = SHX7_3(SHX8_3)
    SHX8_3 = SaveResourceFile
    SHX9_3 = "ReaperV4"
    SHX10_3 = "cache/event_lock.json"
    SHX11_3 = SHX7_3
    SHX12_3 = #SHX7_3
    SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3)
    SHX8_3 = Logger
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.log
    SHX10_3 = "Successfully added ^3%s^7 as a key for the event ^3%s^7 in the resource ^3%s^7"
    SHX11_3 = SHX10_3
    SHX10_3 = SHX10_3.format
    SHX12_3 = SHX4_3
    SHX13_3 = SHX3_3
    SHX14_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3)
    SHX11_3 = "info"
    SHX8_3(SHX9_3, SHX10_3, SHX11_3)
    SHX8_3 = RPC
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.emitLocal
    SHX10_3 = "Reaper:SyncKeyLock"
    SHX8_3(SHX9_3, SHX10_3)
  end
  SHX3_2.callback = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "resource_name"
  SHX6_2 = "event_name"
  SHX7_2 = "key"
  SHX4_2[1] = SHX5_2
  SHX4_2[2] = SHX6_2
  SHX4_2[3] = SHX7_2
  SHX3_2.args = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Manage Server"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "removeeventkey"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3
    SHX2_3 = SHX1_3[2]
    SHX3_3 = SHX1_3[3]
    SHX4_3 = SHX1_3[4]
    if nil ~= SHX4_3 then
      SHX5_3 = #SHX4_3
      if 19 == SHX5_3 then
        goto SHX_LABEL_27
      end
      SHX5_3 = #SHX4_3
      if 20 == SHX5_3 then
        goto SHX_LABEL_27
      end
      SHX5_3 = #SHX4_3
      if 18 == SHX5_3 then
        goto SHX_LABEL_27
      end
      SHX5_3 = #SHX4_3
      if 17 == SHX5_3 then
        goto SHX_LABEL_27
      end
    end
    SHX5_3 = Logger
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.log
    SHX7_3 = "You have provided an invalid event key. ^3%s^7 is not a valid key"
    SHX8_3 = SHX7_3
    SHX7_3 = SHX7_3.format
    SHX9_3 = SHX4_3
    SHX7_3 = SHX7_3(SHX8_3, SHX9_3)
    SHX8_3 = "error"
    return SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    -- [FIX IF ERROR] Move ::SHX_LABEL_27:: outside nested blocks until all 'goto SHX_LABEL_27' can see it
    ::SHX_LABEL_27::
    SHX5_3 = GetResourceState
    SHX6_3 = SHX2_3
    SHX5_3 = SHX5_3(SHX6_3)
    if "missing" == SHX5_3 then
      SHX5_3 = Logger
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.log
      SHX7_3 = "You have provided an invalid resource name. ^3%s^7 is not a valid resource name"
      SHX8_3 = SHX7_3
      SHX7_3 = SHX7_3.format
      SHX9_3 = SHX2_3
      SHX7_3 = SHX7_3(SHX8_3, SHX9_3)
      SHX8_3 = "error"
      return SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    end
    SHX5_3 = json
    SHX5_3 = SHX5_3.decode
    SHX6_3 = LoadResourceFile
    SHX7_3 = "ReaperV4"
    SHX8_3 = "cache/event_lock.json"
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
    if not SHX6_3 then
      SHX6_3 = "{}"
    end
    SHX5_3 = SHX5_3(SHX6_3)
    SHX6_3 = "%s_%s"
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.format
    SHX8_3 = Security
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.hash
    SHX10_3 = SHX2_3
    SHX11_3 = "97ae7727-b78e47fc-075ea9de-c852f7da-44587eed"
    SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3)
    SHX9_3 = Security
    SHX10_3 = SHX9_3
    SHX9_3 = SHX9_3.hash
    SHX11_3 = SHX3_3
    SHX12_3 = "97ae7727-b78e47fc-075ea9de-c852f7da-44587eed"
    SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3 = SHX9_3(SHX10_3, SHX11_3, SHX12_3)
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
    SHX7_3 = SHX5_3[SHX6_3]
    if nil ~= SHX7_3 then
      SHX7_3 = SHX5_3[SHX6_3]
      SHX7_3 = SHX7_3[SHX4_3]
      if nil ~= SHX7_3 then
        goto SHX_LABEL_82
      end
    end
    SHX7_3 = Logger
    SHX8_3 = SHX7_3
    SHX7_3 = SHX7_3.log
    SHX9_3 = "The key ^3%s^7 does not exist for the event ^3%s^7 in the resource ^3%s^7"
    SHX10_3 = SHX9_3
    SHX9_3 = SHX9_3.format
    SHX11_3 = SHX4_3
    SHX12_3 = SHX3_3
    SHX13_3 = SHX2_3
    SHX9_3 = SHX9_3(SHX10_3, SHX11_3, SHX12_3, SHX13_3)
    SHX10_3 = "error"
    return SHX7_3(SHX8_3, SHX9_3, SHX10_3)
    -- [FIX IF ERROR] Move ::SHX_LABEL_82:: outside nested blocks until all 'goto SHX_LABEL_82' can see it
    ::SHX_LABEL_82::
    SHX7_3 = SHX5_3[SHX6_3]
    SHX7_3[SHX4_3] = nil
    SHX7_3 = next
    SHX8_3 = SHX5_3[SHX6_3]
    SHX7_3 = SHX7_3(SHX8_3)
    if nil == SHX7_3 then
      SHX5_3[SHX6_3] = nil
    end
    SHX7_3 = json
    SHX7_3 = SHX7_3.encode
    SHX8_3 = SHX5_3
    SHX7_3 = SHX7_3(SHX8_3)
    SHX8_3 = SaveResourceFile
    SHX9_3 = "ReaperV4"
    SHX10_3 = "cache/event_lock.json"
    SHX11_3 = SHX7_3
    SHX12_3 = #SHX7_3
    SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3)
    SHX8_3 = Logger
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.log
    SHX10_3 = "Successfully removed ^3%s^7 as a key for the event ^3%s^7 in the resource ^3%s^7"
    SHX11_3 = SHX10_3
    SHX10_3 = SHX10_3.format
    SHX12_3 = SHX4_3
    SHX13_3 = SHX3_3
    SHX14_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3)
    SHX11_3 = "info"
    SHX8_3(SHX9_3, SHX10_3, SHX11_3)
    SHX8_3 = RPC
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.emitLocal
    SHX10_3 = "Reaper:SyncKeyLock"
    SHX8_3(SHX9_3, SHX10_3)
  end
  SHX3_2.callback = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "resource_name"
  SHX6_2 = "event_name"
  SHX7_2 = "key"
  SHX4_2[1] = SHX5_2
  SHX4_2[2] = SHX6_2
  SHX4_2[3] = SHX7_2
  SHX3_2.args = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Manage Server"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "reloaddisableddetections"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    SHX0_3 = RPC
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.emit
    SHX2_3 = "LoadDisabledDetections"
    SHX0_3(SHX1_3, SHX2_3)
    SHX0_3 = Logger
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.log
    SHX2_3 = "Reloading disabled detections"
    SHX3_3 = "info"
    SHX0_3(SHX1_3, SHX2_3, SHX3_3)
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.hidden = true
  SHX4_2 = {}
  SHX5_2 = "Update Config"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "reloadfeatures"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    SHX0_3 = Features
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.load
    SHX2_3 = true
    SHX0_3(SHX1_3, SHX2_3)
    SHX0_3 = Logger
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.log
    SHX2_3 = "Reloading features"
    SHX3_3 = "info"
    SHX0_3(SHX1_3, SHX2_3, SHX3_3)
  end
  SHX3_2.callback = SHX4_2
  SHX3_2.hidden = true
  SHX4_2 = {}
  SHX5_2 = "Update Config"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "refresh_blacklisted_execution_keys"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3
    SHX2_3 = SHX1_3[2]
    SHX2_3 = "-s" == SHX2_3
    SHX3_3 = HTTP
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.awaitSuccess
    SHX5_3 = "https://api.reaperac.com/api/v1/data/blacklisted_execution_keys"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    SHX4_3 = SHX3_3.status
    if 200 ~= SHX4_3 then
      SHX4_3 = Logger
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.log
      SHX6_3 = "Failed to load blacklisted execution keys from ^3https://api.reaperac.com"
      SHX7_3 = "error"
      return SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    end
    SHX4_3 = json
    SHX4_3 = SHX4_3.decode
    SHX5_3 = SHX3_3.body
    SHX4_3 = SHX4_3(SHX5_3)
    if nil == SHX4_3 then
      SHX5_3 = Logger
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.log
      SHX7_3 = "Failed to decode blacklisted execution keys from ^3https://api.reaperac.com"
      SHX8_3 = "error"
      return SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    end
    SHX5_3 = Settings
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.get
    SHX5_3 = SHX5_3(SHX6_3)
    SHX6_3 = pairs
    SHX7_3 = SHX5_3.blacklisted_execution_keys
    if not SHX7_3 then
      SHX7_3 = {}
    end
    SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX6_3(SHX7_3)
    for SHX10_3, SHX11_3 in SHX6_3, SHX7_3, SHX8_3, SHX9_3 do
      SHX4_3[SHX10_3] = true
    end
    SHX6_3 = SetConvarReplicated
    SHX7_3 = "reaper_blacklisted_execution_keys"
    SHX8_3 = json
    SHX8_3 = SHX8_3.encode
    SHX9_3 = SHX4_3
    SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3 = SHX8_3(SHX9_3)
    SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3)
    if not SHX2_3 then
      SHX6_3 = Logger
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.log
      SHX8_3 = "Successfully loaded blacklisted execution keys"
      SHX9_3 = "info"
      SHX6_3(SHX7_3, SHX8_3, SHX9_3)
    end
  end
  SHX3_2.callback = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = exports
  SHX2_2 = "ClipPlayersScreen"
  function SHX3_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3
    SHX1_3 = Player
    SHX2_3 = SHX0_3
    SHX1_3 = SHX1_3(SHX2_3)
    if nil == SHX1_3 then
      SHX2_3 = false
      return SHX2_3
    end
    SHX3_3 = SHX1_3
    SHX2_3 = SHX1_3.getScreenRecording
    return SHX2_3(SHX3_3)
  end
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = ExecuteCommand
  SHX2_2 = "reaper install"
  SHX1_2(SHX2_2)
  SHX1_2 = CreateThread
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
    SHX0_3 = Command
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.execute
    SHX2_3 = "refresh_blacklisted_execution_keys"
    SHX3_3 = {}
    SHX4_3 = 0
    SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3)
  end
  SHX1_2(SHX2_2)
end
SHX0_1(SHX1_1, SHX2_1, SHX3_1)
