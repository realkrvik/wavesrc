-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = {}
SHX1_1 = false
SHX2_1 = false
SHX3_1 = false
SHX4_1 = false
SHX5_1 = false
SHX6_1 = RPC
SHX7_1 = SHX6_1
SHX6_1 = SHX6_1.on
SHX8_1 = "configUpdated"
function SHX9_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX0_2 = Settings
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX0_2 = SHX0_2(SHX1_2)
  SHX1_2 = GetConvar
  SHX2_2 = "sv_reaper_custom_build"
  SHX3_2 = "false"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = "true" == SHX1_2
  SHX2_2 = SHX0_2.generalRules
  SHX2_2 = SHX2_2.antiSoundExploits
  SHX1_1 = SHX2_2
  SHX2_2 = SHX0_2.generalRules
  SHX2_2 = SHX2_2.whitelisted_sounds
  if not SHX2_2 then
    SHX2_2 = {}
  end
  SHX0_1 = SHX2_2
  if false == SHX1_2 then
    SHX2_2 = SetConvar
    SHX3_2 = "sv_enableNetworkedSounds"
    SHX4_2 = tostring
    SHX5_2 = SHX0_2.generalRules
    SHX5_2 = SHX5_2.antiSoundExploits
    SHX5_2 = not SHX5_2
    SHX4_2, SHX5_2 = SHX4_2(SHX5_2)
    SHX2_2(SHX3_2, SHX4_2, SHX5_2)
    SHX2_2 = SetConvarReplicated
    SHX3_2 = "reaper_auto_bypass_play_sound"
    SHX4_2 = "false"
    SHX2_2(SHX3_2, SHX4_2)
    SHX2_2 = false
    SHX2_1 = SHX2_2
  else
    SHX2_2 = SetConvar
    SHX3_2 = "sv_enableNetworkedSounds"
    SHX4_2 = "true"
    SHX2_2(SHX3_2, SHX4_2)
    SHX2_2 = SetConvarReplicated
    SHX3_2 = "reaper_auto_bypass_play_sound"
    SHX4_2 = "true"
    SHX2_2(SHX3_2, SHX4_2)
    SHX2_2 = true
    SHX2_1 = SHX2_2
  end
  SHX2_2 = SHX0_2.generalRules
  SHX2_2 = SHX2_2.antiNativeSpoofer
  SHX2_2 = SHX2_2.enabled
  SHX5_1 = SHX2_2
  SHX2_2 = GetConvar
  SHX3_2 = "reaper_block_all_fire_events"
  SHX4_2 = "true"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = "true" == SHX2_2
  SHX3_1 = SHX2_2
  SHX2_2 = GetConvar
  SHX3_2 = "reaper_auto_fire_whitelist"
  SHX4_2 = "false"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = "true" == SHX2_2
  SHX4_1 = SHX2_2
end
SHX6_1(SHX7_1, SHX8_1, SHX9_1)
SHX6_1 = RPC
SHX7_1 = SHX6_1
SHX6_1 = SHX6_1.on
SHX8_1 = "reaperStarted"
function SHX9_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.register
  SHX2_2 = "requestPlaySound"
  function SHX3_2(SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3
    SHX5_3 = Player
    SHX6_3 = SHX0_3
    SHX5_3 = SHX5_3(SHX6_3)
    if not SHX5_3 then
      SHX6_3 = false
      return SHX6_3
    end
    SHX6_3 = SHX2_1
    if false == SHX6_3 then
      SHX6_3 = false
      return SHX6_3
    end
    SHX7_3 = SHX5_3
    SHX6_3 = SHX5_3.NewLog
    SHX8_3 = "^3%s^7 (^3id:%s^7) just requested to play the sound (^3%s^7) from ^3%s^7 (^3%s^7)"
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.format
    SHX11_3 = SHX5_3
    SHX10_3 = SHX5_3.getName
    SHX10_3 = SHX10_3(SHX11_3)
    SHX12_3 = SHX5_3
    SHX11_3 = SHX5_3.getId
    SHX11_3 = SHX11_3(SHX12_3)
    SHX12_3 = SHX1_3
    SHX13_3 = SHX2_3
    SHX14_3 = SHX3_3
    SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
    SHX9_3 = "debug"
    SHX10_3 = "sound_events"
    SHX11_3 = {}
    SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    SHX6_3 = ExecutionCheck
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.execution_valid
    SHX9_3 = SHX5_3
    SHX8_3 = SHX5_3.getId
    SHX8_3 = SHX8_3(SHX9_3)
    SHX9_3 = "PlaySound"
    SHX10_3 = SHX3_3
    SHX11_3 = SHX2_3
    SHX12_3 = SHX4_3
    SHX13_3 = SHX1_3 or SHX13_3
    if not SHX1_3 then
      SHX13_3 = "0"
    end
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3)
    if false == SHX6_3 then
      SHX6_3 = false
      return SHX6_3
    end
    SHX7_3 = SHX5_3
    SHX6_3 = SHX5_3.setMeta
    SHX8_3 = "temp_allow_playSound"
    SHX9_3 = GetGameTimer
    SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3 = SHX9_3()
    SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
    SHX6_3 = true
    return SHX6_3
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "networkPlaySoundEvent"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = CancelEvent
      return SHX3_3()
    end
    SHX3_3 = SHX1_1
    if false == SHX3_3 then
      return
    end
    SHX3_3 = GetGameTimer
    SHX3_3 = SHX3_3()
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.getMeta
    SHX6_3 = "temp_allow_playSound"
    SHX7_3 = 0
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    SHX3_3 = SHX3_3 - SHX4_3
    SHX4_3 = 10000
    if SHX3_3 < SHX4_3 then
      SHX4_3 = SHX2_3
      SHX3_3 = SHX2_3.setMeta
      SHX5_3 = "allowed_soundRef_"
      SHX6_3 = SHX1_3.audioHash
      SHX5_3 = SHX5_3 .. SHX6_3
      SHX6_3 = true
      SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      SHX4_3 = SHX2_3
      SHX3_3 = SHX2_3.setMeta
      SHX5_3 = "allowed_soundRef_"
      SHX6_3 = SHX1_3.audioRefHash
      SHX5_3 = SHX5_3 .. SHX6_3
      SHX6_3 = true
      SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.getMeta
    SHX5_3 = "allowed_soundRef_"
    SHX6_3 = SHX1_3.audioHash
    SHX5_3 = SHX5_3 .. SHX6_3
    SHX6_3 = false
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    if false == SHX3_3 then
      SHX4_3 = SHX2_3
      SHX3_3 = SHX2_3.getMeta
      SHX5_3 = "allowed_soundRef_"
      SHX6_3 = SHX1_3.audioRefHash
      SHX5_3 = SHX5_3 .. SHX6_3
      SHX6_3 = false
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      if false == SHX3_3 then
        SHX3_3 = CancelEvent
        SHX3_3()
        SHX4_3 = SHX2_3
        SHX3_3 = SHX2_3.NewLog
        SHX5_3 = "^3%s^7 (^3id:%s^7) just started playing a sound without authorization (^3%s^7)"
        SHX6_3 = SHX5_3
        SHX5_3 = SHX5_3.format
        SHX8_3 = SHX2_3
        SHX7_3 = SHX2_3.getName
        SHX7_3 = SHX7_3(SHX8_3)
        SHX9_3 = SHX2_3
        SHX8_3 = SHX2_3.getId
        SHX8_3 = SHX8_3(SHX9_3)
        SHX9_3 = json
        SHX9_3 = SHX9_3.encode
        SHX10_3 = SHX1_3
        SHX9_3, SHX10_3, SHX11_3 = SHX9_3(SHX10_3)
        SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
        SHX6_3 = "warn"
        SHX7_3 = "sound_events"
        SHX8_3 = {}
        SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3)
        SHX3_3 = GetConvar
        SHX4_3 = "reaper_ban_play_sounds"
        SHX5_3 = "true"
        SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
        if "true" == SHX3_3 then
          SHX3_3 = tostring
          SHX4_3 = SHX1_3.audioHash
          SHX3_3 = SHX3_3(SHX4_3)
          SHX4_3 = SHX0_1
          SHX3_3 = SHX4_3[SHX3_3]
          if nil == SHX3_3 then
            SHX3_3 = RPC
            SHX4_3 = SHX3_3
            SHX3_3 = SHX3_3.emitLocal
            SHX5_3 = "Reaper:NewDetection"
            SHX6_3 = {}
            SHX6_3.type = "NETWORK_PLAY_SOUND_EVENT"
            SHX6_3.data = SHX1_3
            SHX7_3 = {}
            SHX8_3 = SHX1_3.audioHash
            SHX7_3[1] = SHX8_3
            SHX6_3.params = SHX7_3
            SHX6_3.action = "Ban Player"
            SHX8_3 = SHX2_3
            SHX7_3 = SHX2_3.getId
            SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX7_3(SHX8_3)
            SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
          end
        end
      end
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.NewLog
    SHX5_3 = "^3%s^7 (^3id:%s^7) just started playing the sound ^3%s^7"
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.format
    SHX8_3 = SHX2_3
    SHX7_3 = SHX2_3.getName
    SHX7_3 = SHX7_3(SHX8_3)
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getId
    SHX8_3 = SHX8_3(SHX9_3)
    SHX9_3 = SHX1_3.audioHash
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX6_3 = "info"
    SHX7_3 = "sound_events"
    SHX8_3 = SHX1_3
    SHX9_3 = GetConvar
    SHX10_3 = "reaper_log_sound_events"
    SHX11_3 = "false"
    SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
    SHX9_3 = "true" ~= SHX9_3
    SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.register
  SHX2_2 = "requestNetworkStartSyncScene"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = false
      return SHX3_3
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.setMeta
    SHX5_3 = "temp_allow_networkStartSyncScene"
    SHX6_3 = GetGameTimer
    SHX6_3 = SHX6_3()
    SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    SHX3_3 = true
    return SHX3_3
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "requestNetworkSyncedSceneEvent"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = CancelEvent
      return SHX3_3()
    end
    SHX3_3 = GetConvar
    SHX4_3 = "reaper_block_synced_scene_events"
    SHX5_3 = "false"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if "true" == SHX3_3 then
      SHX3_3 = CancelEvent
      return SHX3_3()
    end
    SHX3_3 = GetGameTimer
    SHX3_3 = SHX3_3()
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.getMeta
    SHX6_3 = "temp_allow_networkStartSyncScene"
    SHX7_3 = 0
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    SHX3_3 = SHX3_3 - SHX4_3
    SHX4_3 = 5000
    if SHX3_3 > SHX4_3 then
      SHX3_3 = GetConvar
      SHX4_3 = "reaper_block_unauthorized_networked_scenes"
      SHX5_3 = "true"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if "true" == SHX3_3 then
        SHX3_3 = CancelEvent
        SHX3_3()
        SHX3_3 = GetConvar
        SHX4_3 = "reaper_request_networked_synced_scene_f_a"
        SHX5_3 = "false"
        SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
        if "true" == SHX3_3 then
          SHX3_3 = Logger
          SHX4_3 = SHX3_3
          SHX3_3 = SHX3_3.log
          SHX5_3 = "^3%s^7 (^3id:%s^7) just requested a new networked scene event without authorization. Data: ^3%s"
          SHX6_3 = SHX5_3
          SHX5_3 = SHX5_3.format
          SHX8_3 = SHX2_3
          SHX7_3 = SHX2_3.getName
          SHX7_3 = SHX7_3(SHX8_3)
          SHX9_3 = SHX2_3
          SHX8_3 = SHX2_3.getId
          SHX8_3 = SHX8_3(SHX9_3)
          SHX9_3 = json
          SHX9_3 = SHX9_3.encode
          SHX10_3 = SHX1_3
          SHX9_3, SHX10_3 = SHX9_3(SHX10_3)
          SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
          SHX6_3 = "warn"
          SHX3_3(SHX4_3, SHX5_3, SHX6_3)
        end
      end
    end
    SHX3_3 = GetConvar
    SHX4_3 = "reaper_log_start_networked_scene_events"
    SHX5_3 = "false"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if "true" == SHX3_3 then
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "^3%s^7 (^3id:%s^7) just emitted requestNetworkSyncedSceneEvent. Data: ^3%s"
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.format
      SHX8_3 = SHX2_3
      SHX7_3 = SHX2_3.getName
      SHX7_3 = SHX7_3(SHX8_3)
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getId
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = json
      SHX9_3 = SHX9_3.encode
      SHX10_3 = SHX1_3
      SHX9_3, SHX10_3 = SHX9_3(SHX10_3)
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX6_3 = "warn"
      SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    end
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "startNetworkSyncedSceneEvent"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = CancelEvent
      return SHX3_3()
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.NewLog
    SHX5_3 = "^3%s^7 (^3id:%s^7) just emitted startNetworkSyncedSceneEvent"
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.format
    SHX8_3 = SHX2_3
    SHX7_3 = SHX2_3.getName
    SHX7_3 = SHX7_3(SHX8_3)
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getId
    SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX8_3(SHX9_3)
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    SHX6_3 = "info"
    SHX7_3 = "fire_events"
    SHX8_3 = {}
    SHX8_3.event_data = SHX1_3
    SHX9_3 = GetConvar
    SHX10_3 = "reaper_log_start_networked_scene_events"
    SHX11_3 = "false"
    SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
    SHX9_3 = "true" ~= SHX9_3
    SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX3_3 = GetConvar
    SHX4_3 = "reaper_block_synced_scene_events"
    SHX5_3 = "false"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if "true" == SHX3_3 then
      SHX3_3 = CancelEvent
      SHX3_3()
    end
    SHX3_3 = GetGameTimer
    SHX3_3 = SHX3_3()
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.getMeta
    SHX6_3 = "temp_allow_networkStartSyncScene"
    SHX7_3 = 0
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    SHX3_3 = SHX3_3 - SHX4_3
    SHX4_3 = 5000
    if SHX3_3 > SHX4_3 then
      SHX3_3 = GetConvar
      SHX4_3 = "reaper_block_unauthorized_networked_scenes"
      SHX5_3 = "true"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if "true" == SHX3_3 then
        SHX3_3 = Logger
        SHX4_3 = SHX3_3
        SHX3_3 = SHX3_3.log
        SHX5_3 = "^3%s^7 (^3id:%s^7) just started a new networked scene event without authorization. Data: ^3%s"
        SHX6_3 = SHX5_3
        SHX5_3 = SHX5_3.format
        SHX8_3 = SHX2_3
        SHX7_3 = SHX2_3.getName
        SHX7_3 = SHX7_3(SHX8_3)
        SHX9_3 = SHX2_3
        SHX8_3 = SHX2_3.getId
        SHX8_3 = SHX8_3(SHX9_3)
        SHX9_3 = json
        SHX9_3 = SHX9_3.encode
        SHX10_3 = SHX1_3
        SHX9_3, SHX10_3, SHX11_3 = SHX9_3(SHX10_3)
        SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
        SHX6_3 = "warn"
        SHX3_3(SHX4_3, SHX5_3, SHX6_3)
        SHX3_3 = CancelEvent
        return SHX3_3()
      end
    end
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "updateNetworkSyncedSceneEvent"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = CancelEvent
      return SHX3_3()
    end
    SHX3_3 = GetConvar
    SHX4_3 = "reaper_log_start_networked_scene_events"
    SHX5_3 = "false"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if "true" == SHX3_3 then
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "^3%s^7 (^3id:%s^7) just emitted updateNetworkSyncedSceneEvent. Data: ^3%s"
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.format
      SHX8_3 = SHX2_3
      SHX7_3 = SHX2_3.getName
      SHX7_3 = SHX7_3(SHX8_3)
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getId
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = json
      SHX9_3 = SHX9_3.encode
      SHX10_3 = SHX1_3
      SHX9_3, SHX10_3 = SHX9_3(SHX10_3)
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX6_3 = "warn"
      SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    end
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "stopNetworkSyncedSceneEvent"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = CancelEvent
      return SHX3_3()
    end
    SHX3_3 = GetConvar
    SHX4_3 = "reaper_log_start_networked_scene_events"
    SHX5_3 = "false"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if "true" == SHX3_3 then
      SHX3_3 = Logger
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.log
      SHX5_3 = "^3%s^7 (^3id:%s^7) just emitted stopNetworkSyncedSceneEvent. Data: ^3%s"
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.format
      SHX8_3 = SHX2_3
      SHX7_3 = SHX2_3.getName
      SHX7_3 = SHX7_3(SHX8_3)
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getId
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = json
      SHX9_3 = SHX9_3.encode
      SHX10_3 = SHX1_3
      SHX9_3, SHX10_3 = SHX9_3(SHX10_3)
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX6_3 = "warn"
      SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    end
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "reaperNetworkRequestControlRejected"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    if not SHX2_3 then
      return
    end
    SHX3_3 = GetConvar
    SHX4_3 = "reaper_log_network_request_control_rejections"
    SHX5_3 = "true"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if "true" == SHX3_3 then
      SHX4_3 = SHX2_3
      SHX3_3 = SHX2_3.NewLog
      SHX5_3 = "^3%s^7 (^3id:%s^7) attempted to request control of an entity but was rejected. Entity: ^3%s^7"
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.format
      SHX8_3 = SHX2_3
      SHX7_3 = SHX2_3.getName
      SHX7_3 = SHX7_3(SHX8_3)
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getId
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = NetworkGetEntityFromNetworkId
      SHX10_3 = SHX1_3
      SHX9_3, SHX10_3 = SHX9_3(SHX10_3)
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX6_3 = "warn"
      SHX7_3 = "entities"
      SHX8_3 = {}
      SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3)
    end
    SHX3_3 = GetConvar
    SHX4_3 = "reaper_ban_network_request_control_rejections"
    SHX5_3 = "false"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if "true" == SHX3_3 then
      SHX3_3 = RPC
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.emitLocal
      SHX5_3 = "Reaper:NewDetection"
      SHX6_3 = {}
      SHX6_3.type = "REQUEST_CONTROL_EVENT"
      SHX8_3 = SHX2_3
      SHX7_3 = SHX2_3.getMeta
      SHX9_3 = "REQUEST_CONTROL_EVENT"
      SHX10_3 = 0
      SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      SHX6_3.data = SHX7_3
      SHX7_3 = {}
      SHX8_3 = SHX0_3
      SHX7_3[1] = SHX8_3
      SHX6_3.params = SHX7_3
      SHX6_3.action = "Ban Player"
      SHX8_3 = SHX2_3
      SHX7_3 = SHX2_3.getId
      SHX7_3, SHX8_3, SHX9_3, SHX10_3 = SHX7_3(SHX8_3)
      SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.setMeta
    SHX5_3 = "REQUEST_CONTROL_EVENT"
    SHX7_3 = SHX2_3
    SHX6_3 = SHX2_3.getMeta
    SHX8_3 = "REQUEST_CONTROL_EVENT"
    SHX9_3 = 0
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3)
    SHX6_3 = SHX6_3 + 1
    SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.getMeta
    SHX5_3 = "REQUEST_CONTROL_EVENT"
    SHX6_3 = 0
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    SHX4_3 = GetConvarInt
    SHX5_3 = "REAPER_REQUEST_CONTROL_EVENT_RATE"
    SHX6_3 = 25
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    if SHX3_3 > SHX4_3 then
      SHX3_3 = RPC
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.emitLocal
      SHX5_3 = "Reaper:NewDetection"
      SHX6_3 = {}
      SHX6_3.type = "REQUEST_CONTROL_EVENT"
      SHX8_3 = SHX2_3
      SHX7_3 = SHX2_3.getMeta
      SHX9_3 = "REQUEST_CONTROL_EVENT"
      SHX10_3 = 0
      SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      SHX6_3.data = SHX7_3
      SHX7_3 = {}
      SHX8_3 = SHX0_3
      SHX7_3[1] = SHX8_3
      SHX6_3.params = SHX7_3
      SHX6_3.action = "Ban Player"
      SHX8_3 = SHX2_3
      SHX7_3 = SHX2_3.getId
      SHX7_3, SHX8_3, SHX9_3, SHX10_3 = SHX7_3(SHX8_3)
      SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
    end
    SHX3_3 = Wait
    SHX4_3 = 3000
    SHX3_3(SHX4_3)
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.setMeta
    SHX5_3 = "REQUEST_CONTROL_EVENT"
    SHX7_3 = SHX2_3
    SHX6_3 = SHX2_3.getMeta
    SHX8_3 = "REQUEST_CONTROL_EVENT"
    SHX9_3 = 0
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3)
    SHX6_3 = SHX6_3 - 1
    SHX3_3(SHX4_3, SHX5_3, SHX6_3)
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "ragdollRequestEvent"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX2_3 = GetConvar
    SHX3_3 = "reaper_log_ragdoll_requests"
    SHX4_3 = "false"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
    if "true" == SHX2_3 then
      SHX2_3 = print
      SHX3_3 = "ragdollRequestEvent"
      SHX4_3 = source
      SHX5_3 = SHX0_3
      SHX6_3 = json
      SHX6_3 = SHX6_3.encode
      SHX7_3 = SHX1_3
      SHX6_3, SHX7_3 = SHX6_3(SHX7_3)
      SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
    end
    SHX2_3 = CancelEvent
    SHX2_3()
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = Cache
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.set
  SHX2_2 = "logSyncEvents"
  SHX3_2 = false
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "REAPER_SYNC_EVENT"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = Cache
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.get
    SHX4_3 = "logSyncEvents"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
    if SHX2_3 then
      SHX2_3 = print
      SHX3_3 = "REAPER_SYNC_EVENT"
      SHX4_3 = source
      SHX5_3 = SHX0_3
      SHX6_3 = SHX1_3
      SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3)
    end
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.register
  SHX2_2 = "requestFireSpawn"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = "DENIED"
      return SHX3_3
    end
    SHX3_3 = SHX1_3.type
    if "entity" ~= SHX3_3 then
      SHX3_3 = SHX1_3.type
      if "script" ~= SHX3_3 then
        goto SHX_LABEL_22
      end
    end
    SHX3_3 = SHX1_3.coords
    if SHX3_3 then
      SHX3_3 = type
      SHX4_3 = SHX1_3.coords
      SHX3_3 = SHX3_3(SHX4_3)
      -- [FIX IF ERROR] Move ::SHX_LABEL_22:: outside nested blocks until all 'goto SHX_LABEL_22' can see it
      ::SHX_LABEL_22::
      if "vector3" ~= SHX3_3 then
        SHX3_3 = "DENIED"
        return SHX3_3
      end
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.getMeta
    SHX5_3 = "allowed_fires"
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if not SHX3_3 then
      SHX3_3 = {}
    end
    SHX4_3 = table
    SHX4_3 = SHX4_3.insert
    SHX5_3 = SHX3_3
    SHX6_3 = {}
    SHX7_3 = SHX1_3.type
    SHX6_3.type = SHX7_3
    SHX7_3 = SHX1_3.netId
    SHX6_3.netId = SHX7_3
    SHX7_3 = SHX1_3.coords
    SHX6_3.coords = SHX7_3
    SHX7_3 = SHX1_3.maxChildren
    SHX6_3.maxChildren = SHX7_3
    SHX4_3(SHX5_3, SHX6_3)
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.setMeta
    SHX6_3 = "allowed_fires"
    SHX7_3 = SHX3_3
    SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    SHX4_3 = "OK"
    return SHX4_3
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "fireEvent"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3
    SHX2_3 = SHX1_3[1]
    SHX2_3 = SHX2_3[1]
    SHX3_3 = Player
    SHX4_3 = SHX0_3
    SHX3_3 = SHX3_3(SHX4_3)
    if nil == SHX3_3 then
      SHX4_3 = CancelEvent
      return SHX4_3()
    end
    SHX5_3 = SHX3_3
    SHX4_3 = SHX3_3.NewLog
    SHX6_3 = "^3%s^7 (^3id:%s^7) just created a new fire. Data: ^3%s^7"
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.format
    SHX9_3 = SHX3_3
    SHX8_3 = SHX3_3.getName
    SHX8_3 = SHX8_3(SHX9_3)
    SHX10_3 = SHX3_3
    SHX9_3 = SHX3_3.getId
    SHX9_3 = SHX9_3(SHX10_3)
    SHX10_3 = json
    SHX10_3 = SHX10_3.encode
    SHX11_3 = SHX2_3
    SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = SHX10_3(SHX11_3)
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
    SHX7_3 = "info"
    SHX8_3 = "fire_events"
    SHX9_3 = {}
    SHX10_3 = GetConvar
    SHX11_3 = "reaper_log_fireEvent"
    SHX12_3 = "false"
    SHX10_3 = SHX10_3(SHX11_3, SHX12_3)
    SHX10_3 = "true" ~= SHX10_3
    SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
    SHX4_3 = SHX3_1
    if SHX4_3 then
      SHX4_3 = CancelEvent
      return SHX4_3()
    end
    SHX4_3 = SHX4_1
    if SHX4_3 then
      SHX5_3 = SHX3_3
      SHX4_3 = SHX3_3.getMeta
      SHX6_3 = "allowed_fires"
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
      if not SHX4_3 then
        SHX4_3 = {}
      end
      SHX5_3 = false
      SHX6_3 = pairs
      SHX7_3 = SHX4_3
      SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX6_3(SHX7_3)
      for SHX10_3, SHX11_3 in SHX6_3, SHX7_3, SHX8_3, SHX9_3 do
        SHX12_3 = SHX11_3.type
        if "script" == SHX12_3 then
          SHX12_3 = SHX2_3.weaponHash
          if 0 == SHX12_3 then
            SHX12_3 = SHX2_3.entityGlobalId
            if 0 == SHX12_3 then
              SHX12_3 = GetDistanceBetweenCoords
              SHX13_3 = vec3
              SHX14_3 = SHX2_3.posX
              SHX15_3 = SHX2_3.posY
              SHX16_3 = SHX2_3.posZ
              SHX13_3 = SHX13_3(SHX14_3, SHX15_3, SHX16_3)
              SHX14_3 = SHX11_3.coords
              SHX12_3 = SHX12_3(SHX13_3, SHX14_3)
              if SHX12_3 < 20 then
                SHX5_3 = true
                break
              end
          end
        end
        else
          SHX12_3 = SHX11_3.type
          if "entity" == SHX12_3 then
            SHX12_3 = SHX2_3.weaponHash
            if 0 == SHX12_3 then
              SHX12_3 = SHX2_3.entityGlobalId
              if 0 ~= SHX12_3 then
                SHX5_3 = true
                break
              end
            end
          end
        end
      end
      if false == SHX5_3 then
        SHX6_3 = CancelEvent
        return SHX6_3()
      end
    end
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "clearPedTasksEvent"
  function SHX3_2(...)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = CancelEvent
    SHX0_3()
    SHX0_3 = GetConvar
    SHX1_3 = "reaper_log_clearPedTasksEvent"
    SHX2_3 = "false"
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
    if "true" == SHX0_3 then
      SHX0_3 = print
      SHX1_3 = source
      SHX2_3 = ...
      SHX0_3(SHX1_3, SHX2_3)
    end
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "vehicleComponentControlEvent"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    if nil == SHX2_3 then
      SHX3_3 = CancelEvent
      return SHX3_3()
    end
    SHX4_3 = SHX2_3
    SHX3_3 = SHX2_3.NewLog
    SHX5_3 = "^3%s^7 (^3id:%s^7) just requested control of a vehicle (^3veh:%s^7) component (^3id:%s^7)"
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.format
    SHX8_3 = SHX2_3
    SHX7_3 = SHX2_3.getName
    SHX7_3 = SHX7_3(SHX8_3)
    SHX9_3 = SHX2_3
    SHX8_3 = SHX2_3.getId
    SHX8_3 = SHX8_3(SHX9_3)
    SHX9_3 = SHX1_3.vehicleGlobalId
    SHX10_3 = SHX1_3.componentIndex
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
    SHX6_3 = "info"
    SHX7_3 = "vehicle_components"
    SHX8_3 = {}
    SHX8_3.event_data = SHX1_3
    SHX9_3 = true
    SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX3_3 = NetworkGetEntityFromNetworkId
    SHX4_3 = SHX1_3.vehicleGlobalId
    SHX3_3 = SHX3_3(SHX4_3)
    if 0 == SHX3_3 then
      SHX4_3 = CancelEvent
      return SHX4_3()
    end
    SHX4_3 = GetEntityCoords
    SHX5_3 = SHX3_3
    SHX4_3 = SHX4_3(SHX5_3)
    SHX5_3 = GetConvar
    SHX6_3 = "reaper_log_vehicleComponentControlEvent"
    SHX7_3 = "false"
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
    if "true" == SHX5_3 then
      SHX5_3 = print
      SHX6_3 = "vehicleComponentControlEvent"
      SHX7_3 = json
      SHX7_3 = SHX7_3.encode
      SHX8_3 = {}
      SHX10_3 = SHX2_3
      SHX9_3 = SHX2_3.getId
      SHX9_3 = SHX9_3(SHX10_3)
      SHX8_3.id = SHX9_3
      SHX10_3 = SHX2_3
      SHX9_3 = SHX2_3.getName
      SHX9_3 = SHX9_3(SHX10_3)
      SHX8_3.name = SHX9_3
      SHX10_3 = SHX2_3
      SHX9_3 = SHX2_3.getCoords
      SHX9_3 = SHX9_3(SHX10_3)
      SHX8_3.coords = SHX9_3
      SHX7_3 = SHX7_3(SHX8_3)
      SHX8_3 = json
      SHX8_3 = SHX8_3.encode
      SHX9_3 = {}
      SHX10_3 = SHX1_3.vehicleGlobalId
      SHX9_3.vehicleGlobalId = SHX10_3
      SHX9_3.coords = SHX4_3
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = json
      SHX9_3 = SHX9_3.encode
      SHX10_3 = SHX1_3
      SHX9_3, SHX10_3, SHX11_3, SHX12_3 = SHX9_3(SHX10_3)
      SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3)
    end
    SHX5_3 = GetDistanceBetweenCoords
    SHX6_3 = SHX4_3
    SHX8_3 = SHX2_3
    SHX7_3 = SHX2_3.getCoords
    SHX7_3 = SHX7_3(SHX8_3)
    SHX8_3 = true
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    SHX6_3 = SHX1_3.componentIndex
    if 0 ~= SHX6_3 then
      SHX6_3 = SHX1_3.componentIndex
    end
    if 4 == SHX6_3 and SHX5_3 > 10 then
      SHX6_3 = GetConvar
      SHX7_3 = "reaper_filter_vehicleComponentControlEvent"
      SHX8_3 = "true"
      SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
      if "true" == SHX6_3 then
        SHX6_3 = CancelEvent
        SHX6_3()
        SHX7_3 = SHX2_3
        SHX6_3 = SHX2_3.NewLog
        SHX8_3 = "A vehicle component control request ^3by^7 %s (^3id:%s^7) was blocked. Distance: ^3%s^7"
        SHX9_3 = SHX8_3
        SHX8_3 = SHX8_3.format
        SHX11_3 = SHX2_3
        SHX10_3 = SHX2_3.getName
        SHX10_3 = SHX10_3(SHX11_3)
        SHX12_3 = SHX2_3
        SHX11_3 = SHX2_3.getId
        SHX11_3 = SHX11_3(SHX12_3)
        SHX12_3 = SHX5_3
        SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3)
        SHX9_3 = "warn"
        SHX10_3 = "vehicle_components"
        SHX11_3 = {}
        SHX11_3.event_data = SHX1_3
        SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
      end
    end
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.onLocal
  SHX2_2 = "vehicleComponentControlReply"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetConvar
    SHX3_3 = "reaper_log_vehicleComponentControlEvent"
    SHX4_3 = "false"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
    if "true" == SHX2_3 then
      SHX2_3 = print
      SHX3_3 = "vehicleComponentControlReply"
      SHX4_3 = SHX0_3
      SHX5_3 = json
      SHX5_3 = SHX5_3.encode
      SHX6_3 = SHX1_3
      SHX5_3, SHX6_3 = SHX5_3(SHX6_3)
      SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3)
    end
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.register
  SHX2_2 = "IsEntityPlayingAnim"
  function SHX3_2(SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3
    SHX5_3 = Player
    SHX6_3 = SHX0_3
    SHX5_3 = SHX5_3(SHX6_3)
    SHX6_3 = Player
    SHX7_3 = SHX1_3
    SHX6_3 = SHX6_3(SHX7_3)
    if nil == SHX5_3 or nil == SHX6_3 then
      SHX7_3 = false
      return SHX7_3
    end
    SHX7_3 = RPC
    SHX8_3 = SHX7_3
    SHX7_3 = SHX7_3.await
    SHX9_3 = "IsEntityPlayingAnim"
    SHX10_3 = SHX1_3
    SHX11_3 = {}
    SHX12_3 = SHX2_3
    SHX13_3 = SHX3_3
    SHX14_3 = SHX4_3
    SHX11_3[1] = SHX12_3
    SHX11_3[2] = SHX13_3
    SHX11_3[3] = SHX14_3
    SHX12_3 = 1000
    SHX13_3 = 4000
    SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3)
    if "RESPONSE_FAILED" == SHX7_3 then
      SHX8_3 = false
      return SHX8_3
    end
    return SHX7_3
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.register
  SHX2_2 = "SetReplicatedCacheValue"
  function SHX3_2(SHX0_3, SHX1_3, SHX2_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX3_3 = Player
    SHX4_3 = SHX0_3
    SHX3_3 = SHX3_3(SHX4_3)
    if nil == SHX3_3 then
      SHX4_3 = true
      return SHX4_3
    end
    SHX5_3 = SHX3_3
    SHX4_3 = SHX3_3.setMeta
    SHX6_3 = "replicated_"
    SHX7_3 = SHX1_3
    SHX6_3 = SHX6_3 .. SHX7_3
    SHX7_3 = SHX2_3
    SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    SHX4_3 = true
    return SHX4_3
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
end
SHX6_1(SHX7_1, SHX8_1, SHX9_1)
function SHX6_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.await
  SHX3_2 = "getOneSyncData"
  SHX4_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX2_2 = {}
  SHX3_2 = "6727be9de6c1a76656564140d16900b194981581bef063"
  SHX3_2 = SHX1_2[SHX3_2]
  SHX2_2.coords_recently_changed = SHX3_2
  SHX3_2 = SHX1_2["45e82eb1e9d079258ae0"]
  SHX2_2.in_vehicle = SHX3_2
  SHX3_2 = SHX1_2["20b5e2be3d793c8a337cccf118"]
  SHX2_2.has_parachute = SHX3_2
  SHX3_2 = SHX1_2["92b1f557ade2a7a71f86b495"]
  SHX2_2.renderingCam = SHX3_2
  SHX3_2 = SHX1_2["4523c489bea7323571ee0dd82e1161"]
  SHX2_2.isEntityVisible = SHX3_2
  SHX3_2 = SHX1_2["1d6a876bc5e3efa9eedb10"]
  SHX2_2.alpha_level = SHX3_2
  SHX3_2 = "b4b5e2a704c1a0ec65a30d297f221f782ecf518278"
  SHX3_2 = SHX1_2[SHX3_2]
  SHX2_2.last_known_cam_change = SHX3_2
  SHX3_2 = "b4b5e2a704c1a0ec65a30d43f86b4da3a3e3d93798e7cd307186f9"
  SHX3_2 = SHX1_2[SHX3_2]
  SHX2_2.last_known_invisible_change = SHX3_2
  SHX3_2 = "b4b5e2a704c1a0ec65a30dcbbee562017e275c85b95f35"
  SHX3_2 = SHX1_2[SHX3_2]
  SHX2_2.last_known_alpha_change = SHX3_2
  SHX3_2 = SHX1_2["48b11bbe9668b09444"]
  SHX2_2.ped_model = SHX3_2
  SHX3_2 = "feb1abbc73934dde6e37960a76828691914e17b623bed22211a0e396"
  SHX3_2 = SHX1_2[SHX3_2]
  SHX2_2.network_is_in_spectator_mode = SHX3_2
  return SHX2_2
end
SHX7_1 = CreateThread
function SHX8_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2
  while true do
    SHX0_2 = SHX5_1
    if SHX0_2 then
      SHX0_2 = GetPlayers
      SHX0_2 = SHX0_2()
      SHX1_2 = pairs
      SHX2_2 = SHX0_2
      SHX1_2, SHX2_2, SHX3_2, SHX4_2 = SHX1_2(SHX2_2)
      for SHX5_2, SHX6_2 in SHX1_2, SHX2_2, SHX3_2, SHX4_2 do
        SHX7_2 = Player
        SHX8_2 = SHX6_2
        SHX7_2 = SHX7_2(SHX8_2)
        if SHX7_2 then
          SHX9_2 = SHX7_2
          SHX8_2 = SHX7_2.getPed
          SHX8_2 = SHX8_2(SHX9_2)
          if 0 ~= SHX8_2 then
            SHX8_2 = GetConvar
            SHX9_2 = "reaper_check_ped_model_server"
            SHX10_2 = "false"
            SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
            if "true" == SHX8_2 then
              SHX9_2 = SHX7_2
              SHX8_2 = SHX7_2.getMeta
              SHX10_2 = "replicated_"
              SHX12_2 = SHX7_2
              SHX11_2 = SHX7_2.getPedModel
              SHX11_2 = SHX11_2(SHX12_2)
              SHX10_2 = SHX10_2 .. SHX11_2
              SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
              if nil == SHX8_2 then
                SHX8_2 = SHX6_1
                SHX10_2 = SHX7_2
                SHX9_2 = SHX7_2.getId
                SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2 = SHX9_2(SHX10_2)
                SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
                if "RESPONSE_FAILED" ~= SHX8_2 then
                  SHX9_2 = SHX8_2.ped_model
                  SHX11_2 = SHX7_2
                  SHX10_2 = SHX7_2.getPedModel
                  SHX10_2 = SHX10_2(SHX11_2)
                  if SHX9_2 ~= SHX10_2 then
                    SHX9_2 = RPC
                    SHX10_2 = SHX9_2
                    SHX9_2 = SHX9_2.emitLocal
                    SHX11_2 = "Reaper:NewDetection"
                    SHX12_2 = {}
                    SHX12_2.type = "NATIVE_SPOOF"
                    SHX12_2.data = SHX8_2
                    SHX13_2 = {}
                    SHX14_2 = "GetEntityModel()"
                    SHX13_2[1] = SHX14_2
                    SHX12_2.params = SHX13_2
                    SHX12_2.action = "Ban Player"
                    SHX14_2 = SHX7_2
                    SHX13_2 = SHX7_2.getId
                    SHX13_2, SHX14_2 = SHX13_2(SHX14_2)
                    SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
                  end
                end
              end
            end
            SHX9_2 = SHX7_2
            SHX8_2 = SHX7_2.isInFreeCam
            SHX8_2 = SHX8_2(SHX9_2)
            SHX10_2 = SHX7_2
            SHX9_2 = SHX7_2.getMeta
            SHX11_2 = "free_cam_status"
            SHX12_2 = false
            SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2)
            if SHX8_2 ~= SHX9_2 then
              if SHX8_2 then
                SHX9_2 = CreateThread
                function SHX10_2()
                  -- [AI CLEANUP] Decompiled Lua - Fix these:
                  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
                  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
                  -- 3. Replace goto/label with while/repeat-until where possible
                  -- 4. Remove decompiler comments, add meaningful ones
                  -- 5. Fix indentation and formatting
                  
                  local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
                  SHX0_3 = SHX6_1
                  SHX1_3 = SHX7_2
                  SHX2_3 = SHX1_3
                  SHX1_3 = SHX1_3.getId
                  SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3 = SHX1_3(SHX2_3)
                  SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
                  if "RESPONSE_FAILED" ~= SHX0_3 then
                    SHX1_3 = SHX7_2
                    SHX2_3 = SHX1_3
                    SHX1_3 = SHX1_3.isInFreeCam
                    SHX1_3 = SHX1_3(SHX2_3)
                    if SHX1_3 then
                      SHX1_3 = SHX0_3.renderingCam
                      if -1 == SHX1_3 then
                        SHX1_3 = SHX0_3.in_vehicle
                        if false == SHX1_3 then
                          SHX1_3 = SHX0_3.has_parachute
                          if false == SHX1_3 then
                            SHX1_3 = SHX0_3.last_known_cam_change
                            SHX2_3 = 20000
                            if SHX1_3 > SHX2_3 then
                              SHX1_3 = SHX0_3.network_is_in_spectator_mode
                              if false == SHX1_3 then
                                SHX1_3 = SHX0_3.coords_recently_changed
                                if false == SHX1_3 then
                                  SHX1_3 = RPC
                                  SHX2_3 = SHX1_3
                                  SHX1_3 = SHX1_3.emitLocal
                                  SHX3_3 = "Reaper:NewDetection"
                                  SHX4_3 = {}
                                  SHX4_3.type = "NATIVE_SPOOF"
                                  SHX4_3.data = SHX0_3
                                  SHX5_3 = {}
                                  SHX6_3 = "GetRenderingCam()"
                                  SHX5_3[1] = SHX6_3
                                  SHX4_3.params = SHX5_3
                                  SHX4_3.action = "Ban Player"
                                  SHX5_3 = SHX7_2
                                  SHX6_3 = SHX5_3
                                  SHX5_3 = SHX5_3.getId
                                  SHX5_3, SHX6_3 = SHX5_3(SHX6_3)
                                  SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
                                end
                              end
                            end
                          end
                        end
                      end
                    end
                  end
                end
                SHX9_2(SHX10_2)
              end
              SHX10_2 = SHX7_2
              SHX9_2 = SHX7_2.setMeta
              SHX11_2 = "free_cam_status"
              SHX12_2 = SHX8_2
              SHX13_2 = 10
              SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2)
            end
            SHX10_2 = SHX7_2
            SHX9_2 = SHX7_2.isVisible
            SHX9_2 = SHX9_2(SHX10_2)
            SHX11_2 = SHX7_2
            SHX10_2 = SHX7_2.getMeta
            SHX12_2 = "visible_status"
            SHX13_2 = false
            SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2)
            if SHX9_2 ~= SHX10_2 then
              if false == SHX9_2 then
                SHX10_2 = CreateThread
                function SHX11_2()
                  -- [AI CLEANUP] Decompiled Lua - Fix these:
                  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
                  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
                  -- 3. Replace goto/label with while/repeat-until where possible
                  -- 4. Remove decompiler comments, add meaningful ones
                  -- 5. Fix indentation and formatting
                  
                  local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
                  SHX0_3 = SHX6_1
                  SHX1_3 = SHX7_2
                  SHX2_3 = SHX1_3
                  SHX1_3 = SHX1_3.getId
                  SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3 = SHX1_3(SHX2_3)
                  SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
                  if "RESPONSE_FAILED" ~= SHX0_3 then
                    SHX1_3 = SHX7_2
                    SHX2_3 = SHX1_3
                    SHX1_3 = SHX1_3.isVisible
                    SHX1_3 = SHX1_3(SHX2_3)
                    if false == SHX1_3 then
                      SHX1_3 = SHX0_3.renderingCam
                      if -1 == SHX1_3 then
                        SHX1_3 = SHX0_3.isEntityVisible
                        if true == SHX1_3 then
                          SHX1_3 = SHX0_3.last_known_invisible_change
                          SHX2_3 = 20000
                          if SHX1_3 > SHX2_3 then
                            SHX1_3 = RPC
                            SHX2_3 = SHX1_3
                            SHX1_3 = SHX1_3.emitLocal
                            SHX3_3 = "Reaper:NewDetection"
                            SHX4_3 = {}
                            SHX4_3.type = "NATIVE_SPOOF"
                            SHX4_3.data = SHX0_3
                            SHX5_3 = {}
                            SHX6_3 = "IsEntityVisible()"
                            SHX5_3[1] = SHX6_3
                            SHX4_3.params = SHX5_3
                            SHX4_3.action = "Ban Player"
                            SHX5_3 = SHX7_2
                            SHX6_3 = SHX5_3
                            SHX5_3 = SHX5_3.getId
                            SHX5_3, SHX6_3 = SHX5_3(SHX6_3)
                            SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
                          end
                        end
                      end
                    end
                  end
                end
                SHX10_2(SHX11_2)
              end
              SHX11_2 = SHX7_2
              SHX10_2 = SHX7_2.setMeta
              SHX12_2 = "visible_status"
              SHX13_2 = SHX9_2
              SHX14_2 = 10
              SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2)
            end
          end
        end
        SHX8_2 = Wait
        SHX9_2 = 25
        SHX8_2(SHX9_2)
      end
      SHX1_2 = Wait
      SHX2_2 = #SHX0_2
      SHX3_2 = 1000
      SHX2_2 = SHX3_2 / SHX2_2
      SHX1_2(SHX2_2)
    else
      SHX0_2 = Wait
      SHX1_2 = 10000
      SHX0_2(SHX1_2)
    end
    SHX0_2 = Wait
    SHX1_2 = 0
    SHX0_2(SHX1_2)
  end
end
SHX7_1(SHX8_1)
