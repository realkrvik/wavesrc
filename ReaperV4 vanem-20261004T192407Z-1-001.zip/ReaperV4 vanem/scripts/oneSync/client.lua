-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1, SHX21_1, SHX22_1, SHX23_1
SHX0_1 = Security
SHX1_1 = Logger
SHX2_1 = RPC
SHX3_1 = Player
SHX4_1 = NUI
SHX5_1 = IsEntityPlayingAnim
SHX6_1 = PlayerPedId
SHX7_1 = GetRenderingCam
SHX8_1 = IsEntityVisible
SHX9_1 = GetEntityAlpha
SHX10_1 = GetGameTimer
SHX11_1 = IsPedInAnyVehicle
SHX12_1 = GetPedParachuteState
SHX13_1 = GetEntityModel
SHX14_1 = GetVehiclePedIsEntering
SHX15_1 = GetVehiclePedIsIn
SHX16_1 = ResetPedLastVehicle
SHX17_1 = NetworkIsInTutorialSession
SHX18_1 = BusyspinnerIsOn
function SHX19_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  if 1 == SHX0_2 or true == SHX0_2 then
    SHX1_2 = true
    return SHX1_2
  else
    SHX1_2 = false
    return SHX1_2
  end
end
SHX21_1 = SHX2_1
SHX20_1 = SHX2_1.register
SHX22_1 = "IsEntityPlayingAnim"
function SHX23_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX3_2 = SHX5_1
  SHX4_2 = SHX6_1
  SHX4_2 = SHX4_2()
  SHX5_2 = SHX0_2
  SHX6_2 = SHX1_2
  SHX7_2 = SHX2_2
  return SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2)
end
SHX20_1(SHX21_1, SHX22_1, SHX23_1)
SHX21_1 = SHX2_1
SHX20_1 = SHX2_1.register
SHX22_1 = "getOneSyncData"
function SHX23_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX0_2 = SHX10_1
  SHX0_2 = SHX0_2()
  SHX1_2 = SHX6_1
  SHX1_2 = SHX1_2()
  SHX2_2 = SHX15_1
  SHX3_2 = SHX1_2
  SHX4_2 = true
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX3_2 = SHX16_1
  SHX4_2 = SHX1_2
  SHX3_2(SHX4_2)
  SHX3_2 = {}
  SHX4_2 = "6727be9de6c1a76656564140d16900b194981581bef063"
  SHX5_2 = SHX3_1
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.getRecentlyChanged
  SHX7_2 = "LastFailedMovementChecks"
  SHX8_2 = 10000
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX3_2[SHX4_2] = SHX5_2
  SHX4_2 = SHX19_1
  SHX5_2 = SHX11_1
  SHX6_2 = SHX1_2
  SHX7_2 = true
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  if not SHX4_2 then
    SHX4_2 = SHX3_1
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.get
    SHX6_2 = "enteringVehicle"
    SHX7_2 = 0
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX4_2 = SHX0_2 - SHX4_2
    SHX5_2 = 5000
    SHX4_2 = SHX4_2 < SHX5_2
  end
  SHX3_2["45e82eb1e9d079258ae0"] = SHX4_2
  SHX4_2 = SHX12_1
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX4_2 = -1 ~= SHX4_2
  SHX3_2["20b5e2be3d793c8a337cccf118"] = SHX4_2
  SHX4_2 = SHX7_1
  SHX4_2 = SHX4_2()
  SHX3_2["92b1f557ade2a7a71f86b495"] = SHX4_2
  SHX4_2 = SHX19_1
  SHX5_2 = SHX8_1
  SHX6_2 = SHX1_2
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2)
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  SHX3_2["4523c489bea7323571ee0dd82e1161"] = SHX4_2
  SHX4_2 = SHX9_1
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX3_2["1d6a876bc5e3efa9eedb10"] = SHX4_2
  SHX4_2 = "b4b5e2a704c1a0ec65a30d297f221f782ecf518278"
  SHX5_2 = SHX3_1
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.get
  SHX7_2 = "CamChange"
  SHX8_2 = 0
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX5_2 = SHX0_2 - SHX5_2
  SHX3_2[SHX4_2] = SHX5_2
  SHX4_2 = "b4b5e2a704c1a0ec65a30d43f86b4da3a3e3d93798e7cd307186f9"
  SHX5_2 = SHX3_1
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.getSetTime
  SHX7_2 = "EntityVisible"
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX5_2 = SHX0_2 - SHX5_2
  SHX3_2[SHX4_2] = SHX5_2
  SHX4_2 = "b4b5e2a704c1a0ec65a30dcbbee562017e275c85b95f35"
  SHX5_2 = SHX3_1
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.getSetTime
  SHX7_2 = "alphaSetTo0"
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX5_2 = SHX0_2 - SHX5_2
  SHX3_2[SHX4_2] = SHX5_2
  SHX4_2 = SHX13_1
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX3_2["48b11bbe9668b09444"] = SHX4_2
  SHX4_2 = "feb1abbc73934dde6e37960a76828691914e17b623bed22211a0e396"
  SHX5_2 = SHX3_1
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.get
  SHX7_2 = "NetworkIsInSpectatorMode"
  SHX8_2 = false
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  if not SHX5_2 then
    SHX5_2 = SHX3_1
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.getRecentlyChanged
    SHX7_2 = "NetworkIsInSpectatorMode"
    SHX8_2 = 10000
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    if not SHX5_2 then
      SHX5_2 = SHX17_1
      SHX5_2 = SHX5_2()
      if not SHX5_2 then
        SHX5_2 = SHX18_1
        SHX5_2 = SHX5_2()
      end
    end
  end
  SHX3_2[SHX4_2] = SHX5_2
  return SHX3_2
end
SHX20_1(SHX21_1, SHX22_1, SHX23_1)
