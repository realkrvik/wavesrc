-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = {}
SHX0_1.current_minute_explosions = 0
SHX0_1.current_minute_blocked = 0
SHX1_1 = os
SHX1_1 = SHX1_1.time
SHX1_1 = SHX1_1()
SHX0_1.current_minute_timestamp = SHX1_1
SHX1_1 = {}
SHX0_1.history = SHX1_1
SHX0_1.max_history_size = 60
SHX0_1.total_explosions = 0
SHX0_1.total_blocked = 0
SHX1_1 = {}
SHX0_1.explosion_types = SHX1_1
SHX1_1 = {}
SHX0_1.blocked_types = SHX1_1
SHX1_1 = {}
SHX0_1.player_explosions = SHX1_1
SHX1_1 = {}
SHX0_1.explosion_names = SHX1_1
SHX1_1 = os
SHX1_1 = SHX1_1.time
SHX1_1 = SHX1_1()
SHX0_1.start_time = SHX1_1
SHX1_1 = 1
SHX2_1 = SHX0_1.max_history_size
SHX3_1 = 1
for SHX4_1 = SHX1_1, SHX2_1, SHX3_1 do
  SHX5_1 = table
  SHX5_1 = SHX5_1.insert
  SHX6_1 = SHX0_1.history
  SHX7_1 = {}
  SHX8_1 = os
  SHX8_1 = SHX8_1.time
  SHX8_1 = SHX8_1()
  SHX9_1 = SHX0_1.max_history_size
  SHX9_1 = SHX9_1 - SHX4_1
  SHX9_1 = SHX9_1 * 60
  SHX8_1 = SHX8_1 - SHX9_1
  SHX7_1.timestamp = SHX8_1
  SHX7_1.explosions = 0
  SHX7_1.blocked = 0
  SHX7_1.explosions_per_second = 0
  SHX5_1(SHX6_1, SHX7_1)
end
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX0_2 = os
  SHX0_2 = SHX0_2.time
  SHX0_2 = SHX0_2()
  SHX1_2 = {}
  SHX2_2 = SHX0_1.current_minute_timestamp
  SHX1_2.timestamp = SHX2_2
  SHX2_2 = SHX0_1.current_minute_explosions
  SHX1_2.explosions = SHX2_2
  SHX2_2 = SHX0_1.current_minute_blocked
  SHX1_2.blocked = SHX2_2
  SHX2_2 = SHX0_1.current_minute_explosions
  SHX2_2 = SHX2_2 / 60
  SHX1_2.explosions_per_second = SHX2_2
  SHX2_2 = table
  SHX2_2 = SHX2_2.insert
  SHX3_2 = SHX0_1.history
  SHX4_2 = SHX1_2
  SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = SHX0_1.history
  SHX2_2 = #SHX2_2
  SHX3_2 = SHX0_1.max_history_size
  if SHX2_2 > SHX3_2 then
    SHX2_2 = table
    SHX2_2 = SHX2_2.remove
    SHX3_2 = SHX0_1.history
    SHX4_2 = 1
    SHX2_2(SHX3_2, SHX4_2)
  end
  SHX0_1.current_minute_explosions = 0
  SHX0_1.current_minute_blocked = 0
  SHX0_1.current_minute_timestamp = SHX0_2
end
SHX2_1 = CreateThread
function SHX3_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  while true do
    SHX0_2 = Wait
    SHX1_2 = 60000
    SHX0_2(SHX1_2)
    SHX0_2 = SHX1_1
    SHX0_2()
  end
end
SHX2_1(SHX3_1)
SHX2_1 = RPC
SHX3_1 = SHX2_1
SHX2_1 = SHX2_1.on
SHX4_1 = "configUpdated"
function SHX5_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX0_2 = Cache
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX2_2 = "gameType"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  if not SHX0_2 then
    SHX0_2 = "gta5"
  end
  SHX1_2 = table
  SHX1_2 = SHX1_2.count
  SHX2_2 = SHX0_1.explosion_names
  SHX1_2 = SHX1_2(SHX2_2)
  if 0 == SHX1_2 then
    SHX1_2 = HTTP
    SHX2_2 = SHX1_2
    SHX1_2 = SHX1_2.await
    SHX3_2 = "https://api.reaperac.com/api/v1/data/explosions?game="
    SHX4_2 = SHX0_2
    SHX3_2 = SHX3_2 .. SHX4_2
    SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
    if SHX1_2 then
      SHX2_2 = SHX1_2.body
      if SHX2_2 then
        SHX2_2 = json
        SHX2_2 = SHX2_2.decode
        SHX3_2 = SHX1_2.body
        SHX2_2 = SHX2_2(SHX3_2)
        if not SHX2_2 then
          SHX2_2 = {}
        end
        SHX0_1.explosion_names = SHX2_2
        SHX2_2 = Logger
        SHX3_2 = SHX2_2
        SHX2_2 = SHX2_2.log
        SHX4_2 = "Loaded "
        SHX5_2 = table
        SHX5_2 = SHX5_2.count
        SHX6_2 = SHX0_1.explosion_names
        SHX5_2 = SHX5_2(SHX6_2)
        SHX6_2 = " explosion types for monitoring"
        SHX4_2 = SHX4_2 .. SHX5_2 .. SHX6_2
        SHX5_2 = "debug"
        SHX2_2(SHX3_2, SHX4_2, SHX5_2)
      end
    end
  end
end
SHX2_1(SHX3_1, SHX4_1, SHX5_1)
function SHX2_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = SHX0_1.explosion_names
  SHX2_2 = tostring
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX1_2 = SHX1_2[SHX2_2]
  if not SHX1_2 then
    SHX1_2 = tostring
    SHX2_2 = SHX0_2
    SHX1_2 = SHX1_2(SHX2_2)
  end
  return SHX1_2
end
function SHX3_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX4_2 = SHX2_1
  SHX5_2 = SHX2_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = tostring
  SHX6_2 = SHX2_2
  SHX5_2 = SHX5_2(SHX6_2)
  SHX6_2 = SHX0_1.current_minute_explosions
  SHX6_2 = SHX6_2 + 1
  SHX0_1.current_minute_explosions = SHX6_2
  if SHX3_2 then
    SHX6_2 = SHX0_1.current_minute_blocked
    SHX6_2 = SHX6_2 + 1
    SHX0_1.current_minute_blocked = SHX6_2
  end
  SHX6_2 = SHX0_1.total_explosions
  SHX6_2 = SHX6_2 + 1
  SHX0_1.total_explosions = SHX6_2
  if SHX3_2 then
    SHX6_2 = SHX0_1.total_blocked
    SHX6_2 = SHX6_2 + 1
    SHX0_1.total_blocked = SHX6_2
  end
  SHX6_2 = SHX0_1.explosion_types
  SHX6_2 = SHX6_2[SHX5_2]
  if not SHX6_2 then
    SHX6_2 = SHX0_1.explosion_types
    SHX7_2 = {}
    SHX7_2.name = SHX4_2
    SHX7_2.count = 0
    SHX7_2.blocked = 0
    SHX6_2[SHX5_2] = SHX7_2
  end
  SHX6_2 = SHX0_1.explosion_types
  SHX6_2 = SHX6_2[SHX5_2]
  SHX7_2 = SHX0_1.explosion_types
  SHX7_2 = SHX7_2[SHX5_2]
  SHX7_2 = SHX7_2.count
  SHX7_2 = SHX7_2 + 1
  SHX6_2.count = SHX7_2
  if SHX3_2 then
    SHX6_2 = SHX0_1.explosion_types
    SHX6_2 = SHX6_2[SHX5_2]
    SHX7_2 = SHX0_1.explosion_types
    SHX7_2 = SHX7_2[SHX5_2]
    SHX7_2 = SHX7_2.blocked
    SHX7_2 = SHX7_2 + 1
    SHX6_2.blocked = SHX7_2
  end
  SHX6_2 = SHX0_1.player_explosions
  SHX6_2 = SHX6_2[SHX0_2]
  if not SHX6_2 then
    SHX6_2 = SHX0_1.player_explosions
    SHX7_2 = {}
    SHX7_2.player_id = SHX0_2
    SHX7_2.player_name = SHX1_2
    SHX7_2.explosions = 0
    SHX7_2.blocked = 0
    SHX8_2 = {}
    SHX7_2.types = SHX8_2
    SHX6_2[SHX0_2] = SHX7_2
  end
  SHX6_2 = SHX0_1.player_explosions
  SHX6_2 = SHX6_2[SHX0_2]
  SHX7_2 = SHX0_1.player_explosions
  SHX7_2 = SHX7_2[SHX0_2]
  SHX7_2 = SHX7_2.explosions
  SHX7_2 = SHX7_2 + 1
  SHX6_2.explosions = SHX7_2
  if SHX3_2 then
    SHX6_2 = SHX0_1.player_explosions
    SHX6_2 = SHX6_2[SHX0_2]
    SHX7_2 = SHX0_1.player_explosions
    SHX7_2 = SHX7_2[SHX0_2]
    SHX7_2 = SHX7_2.blocked
    SHX7_2 = SHX7_2 + 1
    SHX6_2.blocked = SHX7_2
  end
  SHX6_2 = SHX0_1.player_explosions
  SHX6_2 = SHX6_2[SHX0_2]
  SHX6_2 = SHX6_2.types
  SHX6_2 = SHX6_2[SHX5_2]
  if not SHX6_2 then
    SHX6_2 = SHX0_1.player_explosions
    SHX6_2 = SHX6_2[SHX0_2]
    SHX6_2 = SHX6_2.types
    SHX7_2 = {}
    SHX7_2.name = SHX4_2
    SHX7_2.count = 0
    SHX6_2[SHX5_2] = SHX7_2
  end
  SHX6_2 = SHX0_1.player_explosions
  SHX6_2 = SHX6_2[SHX0_2]
  SHX6_2 = SHX6_2.types
  SHX6_2 = SHX6_2[SHX5_2]
  SHX7_2 = SHX0_1.player_explosions
  SHX7_2 = SHX7_2[SHX0_2]
  SHX7_2 = SHX7_2.types
  SHX7_2 = SHX7_2[SHX5_2]
  SHX7_2 = SHX7_2.count
  SHX7_2 = SHX7_2 + 1
  SHX6_2.count = SHX7_2
end
SHX4_1 = AddEventHandler
SHX5_1 = "ExplosionMonitor:Track"
function SHX6_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  if not SHX0_2 then
    return
  end
  SHX4_2 = SHX3_1
  SHX5_2 = SHX0_2
  SHX6_2 = SHX1_2
  SHX7_2 = SHX2_2
  SHX8_2 = SHX3_2
  SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
end
SHX4_1(SHX5_1, SHX6_1)
SHX4_1 = RPC
SHX5_1 = SHX4_1
SHX4_1 = SHX4_1.on
SHX6_1 = "reaperStarted"
function SHX7_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2
  SHX0_2 = Logger
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.log
  SHX2_2 = "Explosion monitoring system initialized and listening"
  SHX3_2 = "debug"
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
end
SHX4_1(SHX5_1, SHX6_1, SHX7_1)
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  if not SHX1_2 then
    SHX1_2 = 10
  end
  SHX2_2 = {}
  SHX3_2 = pairs
  SHX4_2 = SHX0_2
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
  for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    SHX9_2 = type
    SHX10_2 = SHX8_2
    SHX9_2 = SHX9_2(SHX10_2)
    if "table" == SHX9_2 then
      SHX9_2 = SHX8_2.count
      if SHX9_2 then
        SHX9_2 = table
        SHX9_2 = SHX9_2.insert
        SHX10_2 = SHX2_2
        SHX11_2 = SHX8_2
        SHX9_2(SHX10_2, SHX11_2)
      end
    end
  end
  SHX3_2 = table
  SHX3_2 = SHX3_2.sort
  SHX4_2 = SHX2_2
  function SHX5_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3
    SHX2_3 = SHX0_3.count
    SHX3_3 = SHX1_3.count
    SHX2_3 = SHX2_3 > SHX3_3
    return SHX2_3
  end
  SHX3_2(SHX4_2, SHX5_2)
  SHX3_2 = {}
  SHX4_2 = 1
  SHX5_2 = math
  SHX5_2 = SHX5_2.min
  SHX6_2 = SHX1_2
  SHX7_2 = #SHX2_2
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX6_2 = 1
  for SHX7_2 = SHX4_2, SHX5_2, SHX6_2 do
    SHX8_2 = table
    SHX8_2 = SHX8_2.insert
    SHX9_2 = SHX3_2
    SHX10_2 = SHX2_2[SHX7_2]
    SHX8_2(SHX9_2, SHX10_2)
  end
  return SHX3_2
end
function SHX5_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX0_2 = os
  SHX0_2 = SHX0_2.time
  SHX0_2 = SHX0_2()
  SHX1_2 = SHX0_1.start_time
  SHX1_2 = SHX0_2 - SHX1_2
  SHX2_2 = SHX1_2 / 60
  SHX3_2 = SHX2_2 / 60
  if SHX2_2 > 0 then
    SHX4_2 = SHX0_1.total_explosions
    SHX4_2 = SHX4_2 / SHX2_2
    if SHX4_2 then
      goto SHX_LABEL_19
    end
  end
  SHX4_2 = 0
  -- [FIX IF ERROR] Move ::SHX_LABEL_19:: outside nested blocks until all 'goto SHX_LABEL_19' can see it
  ::SHX_LABEL_19::
  if SHX2_2 > 0 then
    SHX5_2 = SHX0_1.total_blocked
    SHX5_2 = SHX5_2 / SHX2_2
    if SHX5_2 then
      goto SHX_LABEL_27
    end
  end
  SHX5_2 = 0
  -- [FIX IF ERROR] Move ::SHX_LABEL_27:: outside nested blocks until all 'goto SHX_LABEL_27' can see it
  ::SHX_LABEL_27::
  SHX6_2 = SHX0_1.current_minute_explosions
  SHX7_2 = SHX0_1.current_minute_blocked
  SHX8_2 = math
  SHX8_2 = SHX8_2.max
  SHX9_2 = 1
  SHX10_2 = SHX0_1.history
  SHX10_2 = #SHX10_2
  SHX10_2 = SHX10_2 - 4
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  SHX9_2 = SHX0_1.history
  SHX9_2 = #SHX9_2
  SHX10_2 = 1
  for SHX11_2 = SHX8_2, SHX9_2, SHX10_2 do
    SHX12_2 = SHX0_1.history
    SHX12_2 = SHX12_2[SHX11_2]
    SHX12_2 = SHX12_2.explosions
    SHX6_2 = SHX6_2 + SHX12_2
    SHX12_2 = SHX0_1.history
    SHX12_2 = SHX12_2[SHX11_2]
    SHX12_2 = SHX12_2.blocked
    SHX7_2 = SHX7_2 + SHX12_2
  end
  SHX8_2 = SHX0_1.total_explosions
  if SHX8_2 > 0 then
    SHX8_2 = SHX0_1.total_blocked
    SHX9_2 = SHX0_1.total_explosions
    SHX8_2 = SHX8_2 / SHX9_2
    SHX8_2 = SHX8_2 * 100
    if SHX8_2 then
      goto SHX_LABEL_64
    end
  end
  SHX8_2 = 0
  -- [FIX IF ERROR] Move ::SHX_LABEL_64:: outside nested blocks until all 'goto SHX_LABEL_64' can see it
  ::SHX_LABEL_64::
  SHX9_2 = {}
  SHX10_2 = {}
  SHX11_2 = SHX0_1.current_minute_timestamp
  SHX10_2.timestamp = SHX11_2
  SHX11_2 = SHX0_1.current_minute_explosions
  SHX10_2.explosions = SHX11_2
  SHX11_2 = SHX0_1.current_minute_blocked
  SHX10_2.blocked = SHX11_2
  SHX11_2 = SHX0_1.current_minute_timestamp
  SHX11_2 = SHX0_2 - SHX11_2
  SHX10_2.elapsed_seconds = SHX11_2
  SHX9_2.current_minute = SHX10_2
  SHX10_2 = {}
  SHX11_2 = SHX0_1.total_explosions
  SHX10_2.explosions = SHX11_2
  SHX11_2 = SHX0_1.total_blocked
  SHX10_2.blocked = SHX11_2
  SHX11_2 = SHX0_1.total_explosions
  SHX12_2 = SHX0_1.total_blocked
  SHX11_2 = SHX11_2 - SHX12_2
  SHX10_2.allowed = SHX11_2
  SHX11_2 = string
  SHX11_2 = SHX11_2.format
  SHX12_2 = "%.2f%%"
  SHX13_2 = SHX8_2
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
  SHX10_2.block_rate = SHX11_2
  SHX10_2.uptime_seconds = SHX1_2
  SHX11_2 = math
  SHX11_2 = SHX11_2.floor
  SHX12_2 = SHX2_2
  SHX11_2 = SHX11_2(SHX12_2)
  SHX10_2.uptime_minutes = SHX11_2
  SHX11_2 = string
  SHX11_2 = SHX11_2.format
  SHX12_2 = "%.2f"
  SHX13_2 = SHX3_2
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
  SHX10_2.uptime_hours = SHX11_2
  SHX11_2 = table
  SHX11_2 = SHX11_2.count
  SHX12_2 = SHX0_1.explosion_types
  SHX11_2 = SHX11_2(SHX12_2)
  SHX10_2.unique_types = SHX11_2
  SHX11_2 = table
  SHX11_2 = SHX11_2.count
  SHX12_2 = SHX0_1.player_explosions
  SHX11_2 = SHX11_2(SHX12_2)
  SHX10_2.unique_players = SHX11_2
  SHX9_2.totals = SHX10_2
  SHX10_2 = {}
  SHX11_2 = string
  SHX11_2 = SHX11_2.format
  SHX12_2 = "%.2f"
  SHX13_2 = SHX4_2
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
  SHX10_2.explosions_per_minute = SHX11_2
  SHX11_2 = string
  SHX11_2 = SHX11_2.format
  SHX12_2 = "%.2f"
  SHX13_2 = SHX5_2
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
  SHX10_2.blocked_per_minute = SHX11_2
  SHX11_2 = string
  SHX11_2 = SHX11_2.format
  SHX12_2 = "%.2f"
  SHX13_2 = SHX4_2 / 60
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
  SHX10_2.explosions_per_second = SHX11_2
  SHX9_2.averages = SHX10_2
  SHX10_2 = {}
  SHX10_2.explosions = SHX6_2
  SHX10_2.blocked = SHX7_2
  SHX11_2 = string
  SHX11_2 = SHX11_2.format
  SHX12_2 = "%.2f"
  SHX13_2 = SHX6_2 / 5
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
  SHX10_2.explosions_per_minute = SHX11_2
  SHX9_2.last_5_minutes = SHX10_2
  SHX10_2 = SHX4_1
  SHX11_2 = SHX0_1.explosion_types
  SHX12_2 = 20
  SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
  SHX9_2.top_explosion_types = SHX10_2
  SHX10_2 = SHX4_1
  SHX11_2 = SHX0_1.player_explosions
  SHX12_2 = 20
  SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
  SHX9_2.top_players = SHX10_2
  SHX10_2 = SHX0_1.history
  SHX9_2.history = SHX10_2
  return SHX9_2
end
SHX6_1 = HTTP
SHX7_1 = SHX6_1
SHX6_1 = SHX6_1.listen
SHX8_1 = "/explosions/stats"
function SHX9_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX2_2 = SHX5_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX1_2.send
  SHX4_2 = {}
  SHX4_2.success = true
  SHX4_2.data = SHX2_2
  SHX5_2 = os
  SHX5_2 = SHX5_2.time
  SHX5_2 = SHX5_2()
  SHX4_2.timestamp = SHX5_2
  SHX3_2(SHX4_2)
end
SHX6_1(SHX7_1, SHX8_1, SHX9_1)
SHX6_1 = HTTP
SHX7_1 = SHX6_1
SHX6_1 = SHX6_1.listen
SHX8_1 = "/explosions/summary"
function SHX9_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX5_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX1_2.send
  SHX4_2 = {}
  SHX4_2.success = true
  SHX5_2 = {}
  SHX6_2 = SHX2_2.totals
  SHX6_2 = SHX6_2.explosions
  SHX5_2.total_explosions = SHX6_2
  SHX6_2 = SHX2_2.totals
  SHX6_2 = SHX6_2.blocked
  SHX5_2.total_blocked = SHX6_2
  SHX6_2 = SHX2_2.totals
  SHX6_2 = SHX6_2.allowed
  SHX5_2.total_allowed = SHX6_2
  SHX6_2 = SHX2_2.totals
  SHX6_2 = SHX6_2.block_rate
  SHX5_2.block_rate = SHX6_2
  SHX6_2 = SHX2_2.totals
  SHX6_2 = SHX6_2.uptime_minutes
  SHX5_2.uptime_minutes = SHX6_2
  SHX6_2 = SHX2_2.current_minute
  SHX6_2 = SHX6_2.explosions
  SHX5_2.current_minute_explosions = SHX6_2
  SHX6_2 = SHX2_2.averages
  SHX6_2 = SHX6_2.explosions_per_minute
  SHX5_2.avg_explosions_per_minute = SHX6_2
  SHX6_2 = SHX2_2.totals
  SHX6_2 = SHX6_2.unique_types
  SHX5_2.unique_types = SHX6_2
  SHX6_2 = SHX2_2.totals
  SHX6_2 = SHX6_2.unique_players
  SHX5_2.unique_players = SHX6_2
  SHX4_2.data = SHX5_2
  SHX5_2 = os
  SHX5_2 = SHX5_2.time
  SHX5_2 = SHX5_2()
  SHX4_2.timestamp = SHX5_2
  SHX3_2(SHX4_2)
end
SHX6_1(SHX7_1, SHX8_1, SHX9_1)
SHX6_1 = HTTP
SHX7_1 = SHX6_1
SHX6_1 = SHX6_1.listen
SHX8_1 = "/explosions/types"
function SHX9_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = tonumber
  SHX3_2 = SHX0_2.query
  SHX3_2 = SHX3_2.limit
  SHX2_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX2_2 = 20
  end
  SHX3_2 = SHX1_2.send
  SHX4_2 = {}
  SHX4_2.success = true
  SHX5_2 = {}
  SHX6_2 = SHX4_1
  SHX7_2 = SHX0_1.explosion_types
  SHX8_2 = SHX2_2
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX5_2.top_types = SHX6_2
  SHX6_2 = table
  SHX6_2 = SHX6_2.count
  SHX7_2 = SHX0_1.explosion_types
  SHX6_2 = SHX6_2(SHX7_2)
  SHX5_2.total_unique_types = SHX6_2
  SHX4_2.data = SHX5_2
  SHX5_2 = os
  SHX5_2 = SHX5_2.time
  SHX5_2 = SHX5_2()
  SHX4_2.timestamp = SHX5_2
  SHX3_2(SHX4_2)
end
SHX6_1(SHX7_1, SHX8_1, SHX9_1)
SHX6_1 = HTTP
SHX7_1 = SHX6_1
SHX6_1 = SHX6_1.listen
SHX8_1 = "/explosions/type"
function SHX9_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = SHX0_2.query
  SHX2_2 = SHX2_2.type
  if not SHX2_2 then
    SHX3_2 = SHX1_2.status
    SHX4_2 = 400
    SHX3_2 = SHX3_2(SHX4_2)
    SHX3_2 = SHX3_2.send
    SHX4_2 = {}
    SHX4_2.success = false
    SHX4_2.error = "Missing 'type' query parameter"
    SHX3_2(SHX4_2)
    return
  end
  SHX3_2 = SHX0_1.explosion_types
  SHX4_2 = tostring
  SHX5_2 = SHX2_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX3_2 = SHX3_2[SHX4_2]
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX6_2 = {}
  SHX6_2.explosion_type = SHX2_2
  SHX7_2 = SHX2_1
  SHX8_2 = SHX2_2
  SHX7_2 = SHX7_2(SHX8_2)
  SHX6_2.explosion_name = SHX7_2
  if SHX3_2 then
    SHX7_2 = SHX3_2.count
    if SHX7_2 then
      goto SHX_LABEL_37
    end
  end
  SHX7_2 = 0
  -- [FIX IF ERROR] Move ::SHX_LABEL_37:: outside nested blocks until all 'goto SHX_LABEL_37' can see it
  ::SHX_LABEL_37::
  SHX6_2.count = SHX7_2
  if SHX3_2 then
    SHX7_2 = SHX3_2.blocked
    if SHX7_2 then
      goto SHX_LABEL_44
    end
  end
  SHX7_2 = 0
  -- [FIX IF ERROR] Move ::SHX_LABEL_44:: outside nested blocks until all 'goto SHX_LABEL_44' can see it
  ::SHX_LABEL_44::
  SHX6_2.blocked = SHX7_2
  SHX5_2.data = SHX6_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX6_1(SHX7_1, SHX8_1, SHX9_1)
SHX6_1 = HTTP
SHX7_1 = SHX6_1
SHX6_1 = SHX6_1.listen
SHX8_1 = "/explosions/players"
function SHX9_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = tonumber
  SHX3_2 = SHX0_2.query
  SHX3_2 = SHX3_2.limit
  SHX2_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX2_2 = 20
  end
  SHX3_2 = SHX1_2.send
  SHX4_2 = {}
  SHX4_2.success = true
  SHX5_2 = {}
  SHX6_2 = SHX4_1
  SHX7_2 = SHX0_1.player_explosions
  SHX8_2 = SHX2_2
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX5_2.top_players = SHX6_2
  SHX6_2 = table
  SHX6_2 = SHX6_2.count
  SHX7_2 = SHX0_1.player_explosions
  SHX6_2 = SHX6_2(SHX7_2)
  SHX5_2.total_unique_players = SHX6_2
  SHX4_2.data = SHX5_2
  SHX5_2 = os
  SHX5_2 = SHX5_2.time
  SHX5_2 = SHX5_2()
  SHX4_2.timestamp = SHX5_2
  SHX3_2(SHX4_2)
end
SHX6_1(SHX7_1, SHX8_1, SHX9_1)
SHX6_1 = HTTP
SHX7_1 = SHX6_1
SHX6_1 = SHX6_1.listen
SHX8_1 = "/explosions/player"
function SHX9_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX2_2 = tonumber
  SHX3_2 = SHX0_2.query
  SHX3_2 = SHX3_2.id
  SHX2_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX3_2 = SHX1_2.status
    SHX4_2 = 400
    SHX3_2 = SHX3_2(SHX4_2)
    SHX3_2 = SHX3_2.send
    SHX4_2 = {}
    SHX4_2.success = false
    SHX4_2.error = "Missing 'id' query parameter"
    SHX3_2(SHX4_2)
    return
  end
  SHX3_2 = SHX0_1.player_explosions
  SHX3_2 = SHX3_2[SHX2_2]
  if not SHX3_2 then
    SHX4_2 = SHX1_2.status
    SHX5_2 = 404
    SHX4_2 = SHX4_2(SHX5_2)
    SHX4_2 = SHX4_2.send
    SHX5_2 = {}
    SHX5_2.success = false
    SHX5_2.error = "Player not found"
    SHX4_2(SHX5_2)
    return
  end
  SHX4_2 = {}
  SHX5_2 = pairs
  SHX6_2 = SHX3_2.types
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2)
  for SHX9_2, SHX10_2 in SHX5_2, SHX6_2, SHX7_2, SHX8_2 do
    SHX11_2 = table
    SHX11_2 = SHX11_2.insert
    SHX12_2 = SHX4_2
    SHX13_2 = SHX10_2
    SHX11_2(SHX12_2, SHX13_2)
  end
  SHX5_2 = table
  SHX5_2 = SHX5_2.sort
  SHX6_2 = SHX4_2
  function SHX7_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3
    SHX2_3 = SHX0_3.count
    SHX3_3 = SHX1_3.count
    SHX2_3 = SHX2_3 > SHX3_3
    return SHX2_3
  end
  SHX5_2(SHX6_2, SHX7_2)
  SHX5_2 = SHX1_2.send
  SHX6_2 = {}
  SHX6_2.success = true
  SHX7_2 = {}
  SHX8_2 = SHX3_2.player_id
  SHX7_2.player_id = SHX8_2
  SHX8_2 = SHX3_2.player_name
  SHX7_2.player_name = SHX8_2
  SHX8_2 = SHX3_2.explosions
  SHX7_2.total_explosions = SHX8_2
  SHX8_2 = SHX3_2.blocked
  SHX7_2.total_blocked = SHX8_2
  SHX7_2.explosion_types = SHX4_2
  SHX6_2.data = SHX7_2
  SHX7_2 = os
  SHX7_2 = SHX7_2.time
  SHX7_2 = SHX7_2()
  SHX6_2.timestamp = SHX7_2
  SHX5_2(SHX6_2)
end
SHX6_1(SHX7_1, SHX8_1, SHX9_1)
SHX6_1 = Command
SHX7_1 = SHX6_1
SHX6_1 = SHX6_1.add
SHX8_1 = {}
SHX8_1.command = "explosionstats"
function SHX9_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2
  SHX2_2 = SHX5_1
  SHX2_2 = SHX2_2()
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "=== Explosion Statistics ==="
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "Total Explosions: ^3%d^7"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX2_2.totals
  SHX7_2 = SHX7_2.explosions
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "Total Blocked: ^3%d^7 (%s)"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX2_2.totals
  SHX7_2 = SHX7_2.blocked
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.block_rate
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "Total Allowed: ^3%d^7"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX2_2.totals
  SHX7_2 = SHX7_2.allowed
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "Server Uptime: ^3%d^7 minutes (^3%s^7 hours)"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX2_2.totals
  SHX7_2 = SHX7_2.uptime_minutes
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.uptime_hours
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "Unique Types: ^3%d^7 | Unique Players: ^3%d^7"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX2_2.totals
  SHX7_2 = SHX7_2.unique_types
  SHX8_2 = SHX2_2.totals
  SHX8_2 = SHX8_2.unique_players
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "Current Minute: ^3%d^7 explosions (^3%d^7 blocked)"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX2_2.current_minute
  SHX7_2 = SHX7_2.explosions
  SHX8_2 = SHX2_2.current_minute
  SHX8_2 = SHX8_2.blocked
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "Average per Minute: ^3%s^7 explosions"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX2_2.averages
  SHX7_2 = SHX7_2.explosions_per_minute
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "Last 5 Minutes: ^3%d^7 explosions (^3%d^7 blocked)"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX2_2.last_5_minutes
  SHX7_2 = SHX7_2.explosions
  SHX8_2 = SHX2_2.last_5_minutes
  SHX8_2 = SHX8_2.blocked
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = ""
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "=== Top 10 Explosion Types ==="
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = ipairs
  SHX4_2 = SHX2_2.top_explosion_types
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
  for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    if SHX7_2 > 10 then
      break
    end
    SHX9_2 = Logger
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.log
    SHX11_2 = "^3#%d^7 - %s: ^3%d^7 explosions (^3%d^7 blocked)"
    SHX12_2 = SHX11_2
    SHX11_2 = SHX11_2.format
    SHX13_2 = SHX7_2
    SHX14_2 = SHX8_2.name
    SHX15_2 = SHX8_2.count
    SHX16_2 = SHX8_2.blocked
    if not SHX16_2 then
      SHX16_2 = 0
    end
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2)
    SHX12_2 = "info"
    SHX9_2(SHX10_2, SHX11_2, SHX12_2)
  end
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = ""
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "=== Top 10 Players ==="
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = ipairs
  SHX4_2 = SHX2_2.top_players
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
  for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    if SHX7_2 > 10 then
      break
    end
    SHX9_2 = Logger
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.log
    SHX11_2 = "^3#%d^7 - %s (ID: ^3%d^7): ^3%d^7 explosions"
    SHX12_2 = SHX11_2
    SHX11_2 = SHX11_2.format
    SHX13_2 = SHX7_2
    SHX14_2 = SHX8_2.player_name
    SHX15_2 = SHX8_2.player_id
    SHX16_2 = SHX8_2.explosions
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2)
    SHX12_2 = "info"
    SHX9_2(SHX10_2, SHX11_2, SHX12_2)
  end
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = ""
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "Access full stats at: ^3http://your-server-ip:30120/ReaperV4/explosions/stats^7"
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "Access breakdown at: ^3http://your-server-ip:30120/ReaperV4/explosions/types^7"
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
end
SHX8_1.callback = SHX9_1
SHX8_1.hidden = false
SHX9_1 = {}
SHX10_1 = "Manage Server"
SHX9_1[1] = SHX10_1
SHX8_1.permissions = SHX9_1
SHX6_1(SHX7_1, SHX8_1)
SHX6_1 = Logger
SHX7_1 = SHX6_1
SHX6_1 = SHX6_1.log
SHX8_1 = "Explosion monitoring system initialized with HTTP endpoints"
SHX9_1 = "info"
SHX6_1(SHX7_1, SHX8_1, SHX9_1)
SHX6_1 = Logger
SHX7_1 = SHX6_1
SHX6_1 = SHX6_1.log
SHX8_1 = "Access explosion stats at ^3/ReaperV4/explosions/stats^7 or ^3/ReaperV4/explosions/summary^7"
SHX9_1 = "debug"
SHX6_1(SHX7_1, SHX8_1, SHX9_1)
