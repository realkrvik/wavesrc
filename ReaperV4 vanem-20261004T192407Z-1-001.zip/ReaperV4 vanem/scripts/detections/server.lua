-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = Security
Security = SHX0_1
SHX0_1 = {}
SHX0_1.logs = ""
SHX0_1.kicks = ""
SHX0_1.bans = ""
SHX1_1 = false
SHX2_1 = {}
SHX3_1 = {}
SHX3_1.POSSIBLY_CHEATING = [[


You have been disconnected for possibly cheating.
Detection: %s

This server is protected by Reaper AntiCheat.
https://reaperac.com
]]
SHX2_1["en-US"] = SHX3_1
SHX3_1 = {}
SHX3_1.POSSIBLY_CHEATING = "\n\nDu wurdest m\195\182glicherweise wegen Cheating vom Server gebannt.\nDetection: %s\n\nDieser Server ist gesch\195\188tzt durch Reaper AntiCheat.\nhttps://reaperac.com\n"
SHX2_1["de-DE"] = SHX3_1
SHX3_1 = {}
SHX3_1.POSSIBLY_CHEATING = "\n\n\215\160\215\149\215\170\215\167\215\170 \215\158\215\148\215\169\215\168\215\170 \215\162\215\167\215\145 \215\151\215\169\215\147 \215\156\215\166\215\153\215\152\215\153\215\157.\nDetection: %s\n\n\215\148\215\169\215\168\215\170 \215\148\215\150\215\148 \215\158\215\149\215\146\215\159 \215\162\215\156 \215\153\215\147\215\153 Reaper AntiCheat.\nhttps://reaperac.com\n"
SHX2_1["he-IL"] = SHX3_1
SHX3_1 = GetConvar
SHX4_1 = "locale"
SHX5_1 = "en-US"
SHX3_1 = SHX3_1(SHX4_1, SHX5_1)
SHX4_1 = SHX2_1[SHX3_1]
if not SHX4_1 then
  SHX4_1 = SHX2_1["en-US"]
end
SHX5_1 = {}
SHX6_1 = RPC
SHX7_1 = SHX6_1
SHX6_1 = SHX6_1.on
SHX8_1 = "configUpdated"
function SHX9_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX0_2 = Settings
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX0_2 = SHX0_2(SHX1_2)
  SHX1_2 = GetConvar
  SHX2_2 = "gamename"
  SHX3_2 = "gta5"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX3_2 = SHX3_1
  SHX2_2 = SHX2_1
  SHX2_2 = SHX2_2[SHX3_2]
  if not SHX2_2 then
    SHX2_2 = SHX2_1["en-US"]
  end
  SHX4_1 = SHX2_2
  SHX2_2 = {}
  SHX3_2 = SHX0_2.alerts
  SHX3_2 = SHX3_2.warnings
  SHX2_2.logs = SHX3_2
  SHX3_2 = SHX0_2.alerts
  SHX3_2 = SHX3_2.kicks
  SHX2_2.kicks = SHX3_2
  SHX3_2 = SHX0_2.alerts
  SHX3_2 = SHX3_2.bans
  SHX2_2.bans = SHX3_2
  SHX0_1 = SHX2_2
  SHX2_2 = SHX0_2.alerts
  SHX2_2 = SHX2_2.recordScreenSwitch
  if SHX2_2 and "rdr3" == SHX1_2 then
    SHX2_2 = SHX0_2.alerts
    SHX2_2.recordScreenSwitch = false
    SHX2_2 = Logger
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.log
    SHX4_2 = "Please note the ^3Record Screen^7 module was enabled but is not supported on RDR3"
    SHX5_2 = "error"
    SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  end
  SHX2_2 = SHX0_2.alerts
  SHX2_2 = SHX2_2.recordScreenSwitch
  SHX1_1 = SHX2_2
end
SHX6_1(SHX7_1, SHX8_1, SHX9_1)
SHX6_1 = {}
SHX7_1 = {}
SHX7_1.reason = "Attempting to spectate someone."
SHX7_1.action = "settings.generalRules.antiSpectate.action"
SHX6_1.antiSpectate = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to modify weapon damage. %s"
SHX7_1.action = "settings.weaponRules.antiWeaponModifier.action"
SHX6_1.antiWeaponModifier = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to spawn a weapon. Weapon: %s"
SHX7_1.action = "settings.weaponRules.autoAntiWeaponSpawn.action"
SHX6_1.antiWeaponSpawn = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to spawn a blacklisted weapon. Weapon: %s"
SHX7_1.action = "settings.weaponRules.blacklistedWeapons.action"
SHX6_1.blacklistedWeapon = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to spoof kill a player."
SHX7_1.action = "'Ban Player'"
SHX6_1.antiSpoofKill = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to teleport. Distance: %s"
SHX7_1.action = "settings.generalRules.antiTeleport.action"
SHX6_1.antiTeleport = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to no-clip. Height: %s"
SHX7_1.action = "settings.generalRules.antiNoClip.action"
SHX6_1.antiNoClip = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to use god mode. Type: %s"
SHX7_1.action = "settings.generalRules.antiGodMode.action"
SHX6_1.antiGodMode = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to use 'No Critical Hits'"
SHX7_1.action = "settings.generalRules.antiNoCriticalHits.action"
SHX6_1.antiNoCriticalHits = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to use infinite combat roll. Value: %s"
SHX7_1.action = "settings.generalRules.antiInfiniteCombatRoll.action"
SHX6_1.antiInfiniteCombatRoll = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Possible AimBot detected."
SHX7_1.action = "settings.generalRules.antiAimBot.action"
SHX6_1.antiAimBot = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to use free cam. Type: 1"
SHX7_1.action = "settings.generalRules.antiFreeCam.action"
SHX6_1.antiFreeCam = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to use free cam. Type: 2"
SHX7_1.action = "settings.generalRules.antiFreeCam2.action"
SHX6_1.antiFreeCam2 = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to use free cam. Type: 3"
SHX7_1.action = "settings.generalRules.antiFreeCam3.action"
SHX6_1.antiFreeCam3 = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to go invisible. Type: %s"
SHX7_1.action = "settings.generalRules.antiInvisible.action"
SHX6_1.antiInvisible = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to modify their vehicle. Type: %s"
SHX7_1.action = "settings.generalRules.antiVehicleModifier.action"
SHX6_1.antiVehicleModifier = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to warp into a vehicle."
SHX7_1.action = "settings.generalRules.antiWarpIntoVehicle.action"
SHX6_1.antiWarpIntoVehicle = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to repair their vehicle."
SHX7_1.action = "settings.generalRules.antiRepairVehicle.action"
SHX6_1.antiRepairVehicle = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to spawn an isolated vehicle. Src: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.antiSpawnIsolated = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to kick a player from a vehicle."
SHX7_1.action = "'Ban Player'"
SHX6_1.antiRemoveFromVehicle = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Menu Detection (1)"
SHX7_1.action = "settings.generalRules.blacklistedTextures.action"
SHX6_1.blacklistedTextures = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Menu Detection (2)"
SHX7_1.action = "settings.generalRules.blacklistedLabels.action"
SHX6_1.blacklistedLabels = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Blacklisted cheat flag loaded."
SHX7_1.action = "settings.generalRules.blacklistedCommands.action"
SHX6_1.blacklistedCommands = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Menu Detection (3)"
SHX7_1.action = "settings.generalRules.onScreenMenuDetection.action"
SHX6_1.onScreenMenuDetection = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to change their ped model. Model: %s"
SHX7_1.action = "settings.generalRules.antiSkinChanger.action"
SHX6_1.antiSkinChanger = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to attach to another player."
SHX7_1.action = "settings.generalRules.antiAttach.action"
SHX6_1.antiAttach = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to spawn a particle. Hash: %s"
SHX7_1.action = "settings.particleRules.nonWhitelistedParticleSpawnedAction"
SHX6_1.particleWhitelist = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to change their voice proximity to %s. Type: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.antiVoiceExploits = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to spawn a blacklisted model (Auto Blacklist). Model: %s"
SHX6_1.autoBlacklistedEntity = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to spawn a blacklisted model. Model: %s"
SHX6_1.blacklistedEntity = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to spawn an entity (model:%s) to far away. Distance: %s"
SHX7_1.action = "settings.entityRules.maxEntitySpawnDistance.action"
SHX6_1.entityMaxSpawnDistance = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to modify server event values. Event: %s"
SHX6_1.antiModifyEvent = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to modify client event values. Event: %s"
SHX6_1.antiModifyEvent2 = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to trigger a client event. Event: %s"
SHX6_1.antiTriggerClientEvent = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to trigger the event %s with an invalid key. Key: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.invalidKeyLock = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to trigger a server event. Event: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.antiTriggerServerEvent = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to trigger a server only event. Event: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.antiTriggerServerOnlyEvent = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to re-trigger a server event. Event: %s"
SHX6_1.antiReTriggerServerEvent = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Test Detection"
SHX7_1.action = "'Ban Player'"
SHX6_1.test = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Nexus Detected. Attempting to force emote players."
SHX7_1.action = "'Ban Player'"
SHX6_1.nexusForceEmote = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Executor Detected. Type: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.executorDetected = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to request control of entities."
SHX7_1.action = "'Ban Player'"
SHX6_1.REQUEST_CONTROL_EVENT = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to ragdoll players."
SHX7_1.action = "'Ban Player'"
SHX6_1.RAGDOLL_REQUEST_EVENT = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to play sounds on players. Sound: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.NETWORK_PLAY_SOUND_EVENT = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to mass spawn explosions."
SHX7_1.action = "'Ban Player'"
SHX6_1.REQUEST_PHONE_EXPLOSION_EVENT = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to spawn a blacklisted explosion. Explosion: %s"
SHX6_1.blacklistedExplosion = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to run %s from %s (%s)"
SHX7_1.action = "'Ban Player'"
SHX6_1.unknownExecution = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to trigger %s from %s (%s) (Auto EP)"
SHX7_1.action = "'Ban Player'"
SHX6_1.autoEventProtection = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to spawn a blacklisted particle. Hash: %s"
SHX6_1.blacklistedParticle = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to damage a player over a range of %s with a max range of %s"
SHX7_1.action = "settings.weaponRules.maxKillDistance.action"
SHX6_1.maxKillDistance = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to open NUI Dev Tools"
SHX7_1.action = "settings.generalRules.antiDevTools.action"
SHX6_1.antiNuiTools = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to force kill a player with Eulen."
SHX7_1.action = "'Ban Player'"
SHX6_1.forceKillEulen = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to stop a resource. Resource: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.resourceStop = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to ragdoll a player."
SHX7_1.action = "'Ban Player'"
SHX6_1.antiRagdollPlayers = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to spoof punch a player. Type: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.antiSpoofPunch = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to trigger %s from %s (%s) (Auto EP)"
SHX7_1.action = "'Ban Player'"
SHX6_1.machoV1 = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Cheat Detected. %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.machoV2 = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to use a modified player hitbox"
SHX7_1.action = "settings.generalRules.antiHitboxModifier.action"
SHX6_1.antiHitboxModifier = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to use a aim assist"
SHX7_1.action = "'Log Player'"
SHX6_1.antiAimAssistRpf = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Unauthorized Animation Loaded"
SHX7_1.action = "settings.generalRules.unauthorizedAnimationLoaded.action"
SHX6_1.unauthorizedAnimationLoaded = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "%s"
SHX7_1.action = "'Log Player'"
SHX6_1.customDetection = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to spoof the native %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.NATIVE_SPOOF = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Heartbeat timeout. Component: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.heartbeat = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Anti Cheat Bypass - Key Missmatch. Component: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.keyMissmatch = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "%s"
SHX7_1.action = "'Ban Player'"
SHX6_1.antiCheatBypass = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to change clothes. Component: %s - Current Value: %s - Allowed Value: %s"
SHX7_1.action = "settings.generalRules.antiClothingChanger.action"
SHX6_1.antiClothingChanger = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to modify a weapon component. Weapon: %s - Component: %s"
SHX7_1.action = "settings.generalRules.antiClothingChanger.action"
SHX6_1.antiWeaponComponentModifier = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Blacklisted execution key detected. Key: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.blacklistedCheatHash = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Invalid Native Call. Native: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.invalidNativeCall = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Invalid Native Call. Native: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.invalidNativeCall2 = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Native evaluation failed for %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.failedNativeCheck = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "%s"
SHX7_1.action = "'Ban Player'"
SHX6_1.hookTampering = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Failed to execute detection. Detection: %s"
SHX7_1.action = "'Ban Player'"
SHX6_1.detectionExecutionFailed = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Flagged the event rule %s while triggering the event %s"
SHX6_1.event_rule = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to attach entities to players."
SHX7_1.action = "'Ban Player'"
SHX6_1.antiAttachEntities = SHX7_1
SHX7_1 = {}
SHX7_1.reason = "Attempting to modify their peds speed."
SHX7_1.action = "settings.generalRules.antiPedSpeedModifier.action"
SHX6_1.antiPedSpeedModifier = SHX7_1
SHX7_1 = RPC
SHX8_1 = SHX7_1
SHX7_1 = SHX7_1.on
SHX9_1 = "reaperReady"
function SHX10_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.on
  SHX2_2 = "LoadDisabledDetections"
  function SHX3_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX0_3 = HTTP
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.awaitSuccess
    SHX2_3 = "https://api.reaperac.com/api/v1/detections/disabled"
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
    SHX1_3 = SHX0_3.status
    if 200 ~= SHX1_3 then
      SHX1_3 = Logger
      SHX2_3 = SHX1_3
      SHX1_3 = SHX1_3.log
      SHX3_3 = "Failed to load disabled detections from ^3https://api.reaperac.com"
      SHX4_3 = "error"
      return SHX1_3(SHX2_3, SHX3_3, SHX4_3)
    end
    SHX1_3 = json
    SHX1_3 = SHX1_3.decode
    SHX2_3 = SHX0_3.body
    SHX1_3 = SHX1_3(SHX2_3)
    if nil == SHX1_3 then
      SHX2_3 = Logger
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.log
      SHX4_3 = "Failed to decode response from ^3https://api.reaperac.com/api/v1/detections/disabled"
      SHX5_3 = "error"
      return SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    end
    SHX5_1 = SHX1_3
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.emit
  SHX2_2 = "LoadDisabledDetections"
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RPC
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.register
  SHX2_2 = "Reaper:NewDetection"
  SHX3_2 = Cache
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.get
  SHX5_2 = "security_key"
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX2_2 = SHX2_2 .. SHX3_2
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    SHX2_3 = Player
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = json
    SHX3_3 = SHX3_3.decode
    SHX4_3 = Security
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.decrypt
    SHX6_3 = SHX1_3
    SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    if nil == SHX2_3 then
      return
    end
    SHX5_3 = SHX3_3.type
    SHX4_3 = SHX6_1
    SHX4_3 = SHX4_3[SHX5_3]
    if nil == SHX4_3 then
      SHX4_3 = Logger
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.log
      SHX6_3 = "^3%s^7 (^3id:%s^7) just sent an unknown detection type. Type: ^3%s"
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.format
      SHX9_3 = SHX2_3
      SHX8_3 = SHX2_3.getName
      SHX8_3 = SHX8_3(SHX9_3)
      SHX10_3 = SHX2_3
      SHX9_3 = SHX2_3.getId
      SHX9_3 = SHX9_3(SHX10_3)
      SHX10_3 = SHX3_3.type
      SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX7_3 = "error"
      SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      SHX4_3 = {}
      SHX4_3.error = true
      SHX4_3.message = "ERROR:1"
      return SHX4_3
    end
    SHX4_3 = {}
    SHX5_3 = SHX3_3.type
    SHX4_3.detection = SHX5_3
    SHX5_3 = SHX3_3.action
    if not SHX5_3 then
      SHX5_3 = load
      SHX6_3 = "return "
      SHX8_3 = SHX3_3.type
      SHX7_3 = SHX6_1
      SHX7_3 = SHX7_3[SHX8_3]
      SHX7_3 = SHX7_3.action
      SHX6_3 = SHX6_3 .. SHX7_3
      SHX7_3 = nil
      SHX8_3 = nil
      SHX9_3 = {}
      SHX10_3 = Settings
      SHX11_3 = SHX10_3
      SHX10_3 = SHX10_3.get
      SHX10_3 = SHX10_3(SHX11_3)
      SHX9_3.settings = SHX10_3
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3)
      SHX5_3 = SHX5_3()
    end
    SHX4_3.action = SHX5_3
    SHX6_3 = SHX3_3.type
    SHX5_3 = SHX6_1
    SHX5_3 = SHX5_3[SHX6_3]
    SHX5_3 = SHX5_3.reason
    SHX4_3.reason = SHX5_3
    SHX4_3.source = SHX0_3
    SHX5_3 = SHX3_3.data
    SHX4_3.data = SHX5_3
    SHX5_3 = SHX3_3.params
    SHX4_3.params = SHX5_3
    SHX5_3 = RPC
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.emitLocal
    SHX7_3 = "Reaper:HandlePlayer"
    SHX8_3 = SHX4_3
    SHX9_3 = SHX0_3
    SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX5_3 = {}
    SHX6_3 = SHX3_3.key
    SHX5_3.key = SHX6_3
    return SHX5_3
  end
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
end
SHX7_1(SHX8_1, SHX9_1, SHX10_1)
SHX7_1 = RPC
SHX8_1 = SHX7_1
SHX7_1 = SHX7_1.onNet
SHX9_1 = "Reaper:NewDetection"
function SHX10_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX2_2 = source
  SHX2_2 = SHX1_2 or SHX2_2
  if "" ~= SHX2_2 or not SHX1_2 then
    SHX2_2 = source
  end
  SHX3_2 = Player
  SHX4_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2)
  if nil == SHX3_2 then
    return
  end
  SHX4_2 = SHX0_2.action
  if "log" == SHX4_2 then
    SHX0_2.action = "Log Player"
  else
    SHX4_2 = SHX0_2.action
    if "kick" == SHX4_2 then
      SHX0_2.action = "Kick Player"
    else
      SHX4_2 = SHX0_2.action
      if "ban" == SHX4_2 then
        SHX0_2.action = "Ban Player"
      end
    end
  end
  SHX4_2 = {}
  SHX5_2 = SHX0_2.type
  SHX4_2.detection = SHX5_2
  SHX5_2 = SHX0_2.action
  if not SHX5_2 then
    SHX5_2 = load
    SHX6_2 = "return "
    SHX8_2 = SHX0_2.type
    SHX7_2 = SHX6_1
    SHX7_2 = SHX7_2[SHX8_2]
    SHX7_2 = SHX7_2.action
    SHX6_2 = SHX6_2 .. SHX7_2
    SHX7_2 = nil
    SHX8_2 = nil
    SHX9_2 = {}
    SHX10_2 = Settings
    SHX11_2 = SHX10_2
    SHX10_2 = SHX10_2.get
    SHX10_2 = SHX10_2(SHX11_2)
    SHX9_2.settings = SHX10_2
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2)
    SHX5_2 = SHX5_2()
  end
  SHX4_2.action = SHX5_2
  SHX5_2 = SHX0_2.reason
  if not SHX5_2 then
    SHX6_2 = SHX0_2.type
    SHX5_2 = SHX6_1
    SHX5_2 = SHX5_2[SHX6_2]
    SHX5_2 = SHX5_2.reason
  end
  SHX4_2.reason = SHX5_2
  SHX4_2.source = SHX2_2
  SHX5_2 = SHX0_2.data
  SHX4_2.data = SHX5_2
  SHX5_2 = SHX0_2.params
  SHX4_2.params = SHX5_2
  SHX5_2 = RPC
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.emitLocal
  SHX7_2 = "Reaper:HandlePlayer"
  SHX8_2 = SHX4_2
  SHX9_2 = SHX2_2
  SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2)
end
SHX7_1(SHX8_1, SHX9_1, SHX10_1)
SHX7_1 = RPC
SHX8_1 = SHX7_1
SHX7_1 = SHX7_1.onNet
SHX9_1 = "Reaper:HandlePlayer"
function SHX10_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2
  SHX2_2 = source
  SHX2_2 = SHX1_2 or SHX2_2
  if "" ~= SHX2_2 or not SHX1_2 then
    SHX2_2 = source
  end
  SHX3_2 = Player
  SHX4_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2)
  if nil == SHX3_2 then
    return
  end
  SHX4_2 = SHX0_1.logs
  SHX5_2 = 3447003
  SHX6_2 = nil
  SHX7_2 = nil
  SHX8_2 = "detected"
  SHX9_2 = SHX0_2.reason
  SHX10_2 = SHX9_2
  SHX9_2 = SHX9_2.format
  SHX11_2 = table
  SHX11_2 = SHX11_2.unpack
  SHX12_2 = SHX0_2.params
  if not SHX12_2 then
    SHX12_2 = {}
  end
  SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX11_2(SHX12_2)
  SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
  SHX10_2 = SHX0_2.action
  if "none" == SHX10_2 then
    return
  end
  SHX10_2 = SHX0_2.action
  if "Log Player" ~= SHX10_2 then
    SHX10_2 = SHX0_2.action
    if "Kick Player" ~= SHX10_2 then
      SHX10_2 = SHX0_2.action
      if "Ban Player" ~= SHX10_2 then
        SHX10_2 = print
        SHX11_2 = "invalid action"
        return SHX10_2(SHX11_2)
      end
    end
  end
  SHX10_2 = Cache
  SHX11_2 = SHX10_2
  SHX10_2 = SHX10_2.get
  SHX12_2 = "inDevMode"
  SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
  if SHX10_2 then
    SHX10_2 = SHX0_2.detection
    if "manualDetection" ~= SHX10_2 then
      SHX11_2 = SHX3_2
      SHX10_2 = SHX3_2.NewLog
      SHX12_2 = "[^1%s^7] - ^3%s ^7(^3id:%s^7) was just ^3%s^7 for ^3%s^7"
      SHX13_2 = SHX12_2
      SHX12_2 = SHX12_2.format
      SHX14_2 = "DEV-MODE"
      SHX16_2 = SHX3_2
      SHX15_2 = SHX3_2.getName
      SHX15_2 = SHX15_2(SHX16_2)
      SHX17_2 = SHX3_2
      SHX16_2 = SHX3_2.getId
      SHX16_2 = SHX16_2(SHX17_2)
      SHX17_2 = "detected"
      SHX18_2 = SHX9_2
      SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
      SHX13_2 = "warn"
      SHX14_2 = "detections"
      SHX15_2 = {}
      return SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
    end
  end
  SHX11_2 = SHX0_2.detection
  SHX10_2 = SHX5_1
  SHX10_2 = SHX10_2[SHX11_2]
  if SHX10_2 then
    SHX11_2 = SHX3_2
    SHX10_2 = SHX3_2.NewLog
    SHX12_2 = "[^1%s^7] - ^3%s ^7(^3id:%s^7) was just ^3%s^7 for ^3%s^7"
    SHX13_2 = SHX12_2
    SHX12_2 = SHX12_2.format
    SHX14_2 = "DETECTION-DISABLED"
    SHX16_2 = SHX3_2
    SHX15_2 = SHX3_2.getName
    SHX15_2 = SHX15_2(SHX16_2)
    SHX17_2 = SHX3_2
    SHX16_2 = SHX3_2.getId
    SHX16_2 = SHX16_2(SHX17_2)
    SHX17_2 = "detected"
    SHX18_2 = SHX9_2
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
    SHX13_2 = "debug"
    SHX14_2 = "detections"
    SHX15_2 = {}
    return SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
  end
  SHX11_2 = SHX3_2
  SHX10_2 = SHX3_2.getMeta
  SHX12_2 = "activeHandle"
  SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
  if not SHX10_2 then
    SHX10_2 = SHX0_2.detection
    if "manualDetection" == SHX10_2 then
      goto SHX_LABEL_113
    end
    SHX10_2 = GetConvar
    SHX11_2 = "reaper_test_server"
    SHX12_2 = "false"
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
    if "false" ~= SHX10_2 then
      goto SHX_LABEL_113
    end
    SHX11_2 = SHX3_2
    SHX10_2 = SHX3_2.isBypassed
    SHX12_2 = SHX0_2.detection
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
    if not SHX10_2 then
      goto SHX_LABEL_113
    end
  end
  return
  -- [FIX IF ERROR] Move ::SHX_LABEL_113:: outside nested blocks until all 'goto SHX_LABEL_113' can see it
  ::SHX_LABEL_113::
  SHX10_2 = SHX0_2.action
  if "Kick Player" ~= SHX10_2 then
    SHX10_2 = SHX0_2.action
    if "Ban Player" ~= SHX10_2 then
      goto SHX_LABEL_181
    end
  end
  SHX11_2 = SHX3_2
  SHX10_2 = SHX3_2.setMeta
  SHX12_2 = "activeHandle"
  SHX13_2 = true
  SHX10_2(SHX11_2, SHX12_2, SHX13_2)
  SHX10_2 = Cache
  SHX11_2 = SHX10_2
  SHX10_2 = SHX10_2.set
  SHX12_2 = "awaiting_detection_upload:"
  SHX14_2 = SHX3_2
  SHX13_2 = SHX3_2.getIdentifier
  SHX15_2 = "license"
  SHX13_2 = SHX13_2(SHX14_2, SHX15_2)
  SHX12_2 = SHX12_2 .. SHX13_2
  SHX13_2 = true
  SHX10_2(SHX11_2, SHX12_2, SHX13_2)
  SHX10_2 = SHX0_2.action
  if "Kick Player" == SHX10_2 then
    SHX8_2 = "kicked"
    SHX5_2 = 15105570
    SHX4_2 = SHX0_1.kicks
  else
    SHX10_2 = SHX0_2.action
    if "Ban Player" == SHX10_2 then
      SHX8_2 = "banned"
      SHX5_2 = 15158332
      SHX4_2 = SHX0_1.bans
    end
  end
  SHX10_2 = pairs
  SHX11_2 = table
  SHX11_2 = SHX11_2.concat_tab
  SHX12_2 = table
  SHX12_2 = SHX12_2.concat_tab
  SHX13_2 = GetAllVehicles
  SHX13_2 = SHX13_2()
  SHX14_2 = GetAllObjects
  SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX14_2()
  SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
  SHX13_2 = GetAllPeds
  SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX13_2()
  SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
  SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
  for SHX14_2, SHX15_2 in SHX10_2, SHX11_2, SHX12_2, SHX13_2 do
    SHX16_2 = NetworkGetEntityOwner
    SHX17_2 = SHX15_2
    SHX16_2 = SHX16_2(SHX17_2)
    SHX18_2 = SHX3_2
    SHX17_2 = SHX3_2.getId
    SHX17_2 = SHX17_2(SHX18_2)
    if SHX16_2 == SHX17_2 then
      SHX17_2 = DeleteEntity
      SHX18_2 = SHX15_2
      SHX17_2(SHX18_2)
    end
  end
  SHX10_2 = SetPlayerRoutingBucket
  SHX11_2 = SHX2_2
  SHX12_2 = 69420
  SHX10_2(SHX11_2, SHX12_2)
  SHX10_2 = SetRoutingBucketPopulationEnabled
  SHX11_2 = 69420
  SHX12_2 = false
  SHX10_2(SHX11_2, SHX12_2)
  -- [FIX IF ERROR] Move ::SHX_LABEL_181:: outside nested blocks until all 'goto SHX_LABEL_181' can see it
  ::SHX_LABEL_181::
  SHX10_2 = SHX1_1
  if SHX10_2 then
    SHX10_2 = SHX0_2.detection
    if "resourceStop" ~= SHX10_2 then
      SHX11_2 = SHX3_2
      SHX10_2 = SHX3_2.getScreenRecording
      SHX10_2 = SHX10_2(SHX11_2)
      SHX6_2 = SHX10_2
      if SHX6_2 then
        SHX10_2 = string
        SHX10_2 = SHX10_2.match
        SHX11_2 = SHX6_2
        SHX12_2 = "https"
        SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
        if not SHX10_2 then
          SHX10_2 = Logger
          SHX11_2 = SHX10_2
          SHX10_2 = SHX10_2.log
          SHX12_2 = "Reaper was unable to take a screen recording of ^3%s ^7(^3id:%s^7). Reason: ^3%s^7"
          SHX13_2 = SHX12_2
          SHX12_2 = SHX12_2.format
          SHX15_2 = SHX3_2
          SHX14_2 = SHX3_2.getName
          SHX14_2 = SHX14_2(SHX15_2)
          SHX16_2 = SHX3_2
          SHX15_2 = SHX3_2.getId
          SHX15_2 = SHX15_2(SHX16_2)
          SHX16_2 = SHX6_2
          SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2)
          SHX13_2 = "error"
          SHX10_2(SHX11_2, SHX12_2, SHX13_2)
        end
      end
    end
  end
  SHX10_2 = type
  SHX11_2 = SHX0_2.data
  SHX10_2 = SHX10_2(SHX11_2)
  if "table" ~= SHX10_2 then
    SHX10_2 = {}
    SHX12_2 = SHX3_2
    SHX11_2 = SHX3_2.getCoords
    SHX11_2 = SHX11_2(SHX12_2)
    SHX10_2.coords = SHX11_2
    SHX0_2.data = SHX10_2
  end
  SHX10_2 = Cache
  SHX11_2 = SHX10_2
  SHX10_2 = SHX10_2.get
  SHX12_2 = "inDevMode"
  SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
  if SHX10_2 then
    SHX10_2 = SHX0_2.detection
    if "manualDetection" ~= SHX10_2 then
      SHX11_2 = SHX3_2
      SHX10_2 = SHX3_2.setMeta
      SHX12_2 = "activeHandle"
      SHX13_2 = false
      SHX10_2(SHX11_2, SHX12_2, SHX13_2)
      SHX10_2 = Cache
      SHX11_2 = SHX10_2
      SHX10_2 = SHX10_2.set
      SHX12_2 = "awaiting_detection_upload:"
      SHX14_2 = SHX3_2
      SHX13_2 = SHX3_2.getIdentifier
      SHX15_2 = "license"
      SHX13_2 = SHX13_2(SHX14_2, SHX15_2)
      SHX12_2 = SHX12_2 .. SHX13_2
      SHX13_2 = nil
      SHX10_2(SHX11_2, SHX12_2, SHX13_2)
      SHX11_2 = SHX3_2
      SHX10_2 = SHX3_2.NewLog
      SHX12_2 = "[^1%s^7] - ^3%s ^7(^3id:%s^7) was just ^3%s^7 for ^3%s^7"
      SHX13_2 = SHX12_2
      SHX12_2 = SHX12_2.format
      SHX14_2 = "DEV-MODE"
      SHX16_2 = SHX3_2
      SHX15_2 = SHX3_2.getName
      SHX15_2 = SHX15_2(SHX16_2)
      SHX17_2 = SHX3_2
      SHX16_2 = SHX3_2.getId
      SHX16_2 = SHX16_2(SHX17_2)
      SHX17_2 = "detected"
      SHX18_2 = SHX9_2
      SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
      SHX13_2 = "warn"
      SHX14_2 = "detections"
      SHX15_2 = {}
      return SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
    end
  end
  SHX10_2 = HTTP
  SHX11_2 = SHX10_2
  SHX10_2 = SHX10_2.await
  SHX12_2 = "https://api.reaperac.com/api/v1/servers/%s/detections"
  SHX13_2 = SHX12_2
  SHX12_2 = SHX12_2.format
  SHX14_2 = Cache
  SHX15_2 = SHX14_2
  SHX14_2 = SHX14_2.get
  SHX16_2 = "dbId"
  SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX14_2(SHX15_2, SHX16_2)
  SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
  SHX13_2 = "POST"
  SHX14_2 = json
  SHX14_2 = SHX14_2.encode
  SHX15_2 = {}
  SHX16_2 = Cache
  SHX17_2 = SHX16_2
  SHX16_2 = SHX16_2.get
  SHX18_2 = "secret"
  SHX16_2 = SHX16_2(SHX17_2, SHX18_2)
  SHX15_2.secret = SHX16_2
  SHX16_2 = Cache
  SHX17_2 = SHX16_2
  SHX16_2 = SHX16_2.get
  SHX18_2 = "serverId"
  SHX16_2 = SHX16_2(SHX17_2, SHX18_2)
  SHX15_2.serverId = SHX16_2
  SHX16_2 = SHX0_2.detection
  SHX15_2.detection = SHX16_2
  SHX16_2 = SHX0_2.action
  SHX15_2.action = SHX16_2
  SHX16_2 = {}
  SHX18_2 = SHX3_2
  SHX17_2 = SHX3_2.getName
  SHX17_2 = SHX17_2(SHX18_2)
  SHX16_2.name = SHX17_2
  SHX18_2 = SHX3_2
  SHX17_2 = SHX3_2.getIdentifier
  SHX19_2 = "license"
  SHX17_2 = SHX17_2(SHX18_2, SHX19_2)
  SHX16_2.license = SHX17_2
  SHX18_2 = SHX3_2
  SHX17_2 = SHX3_2.getIdentifier
  SHX19_2 = "discord"
  SHX17_2 = SHX17_2(SHX18_2, SHX19_2)
  SHX16_2.discord = SHX17_2
  SHX18_2 = SHX3_2
  SHX17_2 = SHX3_2.getIdentifier
  SHX19_2 = "steam"
  SHX17_2 = SHX17_2(SHX18_2, SHX19_2)
  SHX16_2.steam = SHX17_2
  SHX18_2 = SHX3_2
  SHX17_2 = SHX3_2.getIdentifier
  SHX19_2 = "ip"
  SHX17_2 = SHX17_2(SHX18_2, SHX19_2)
  SHX16_2.ip = SHX17_2
  SHX18_2 = SHX3_2
  SHX17_2 = SHX3_2.getIdentifier
  SHX19_2 = "fivem"
  SHX17_2 = SHX17_2(SHX18_2, SHX19_2)
  SHX16_2.fivem = SHX17_2
  SHX15_2.identifiers = SHX16_2
  SHX15_2.vid = SHX6_2
  SHX15_2.reason = SHX9_2
  SHX16_2 = table
  SHX16_2 = SHX16_2.numbers_to_string
  SHX17_2 = SHX0_2.data
  SHX16_2 = SHX16_2(SHX17_2)
  SHX15_2.data = SHX16_2
  SHX14_2 = SHX14_2(SHX15_2)
  SHX15_2 = {}
  SHX15_2["Content-Type"] = "application/json"
  SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
  SHX11_2 = json
  SHX11_2 = SHX11_2.decode
  SHX12_2 = SHX10_2.body
  if not SHX12_2 then
    SHX12_2 = "{ \"id\": \"unknown\", \"error\": true, \"message\": \"error code 1\"}"
  end
  SHX11_2 = SHX11_2(SHX12_2)
  SHX12_2 = SHX11_2.error
  if false ~= SHX12_2 then
    SHX12_2 = Logger
    SHX13_2 = SHX12_2
    SHX12_2 = SHX12_2.log
    SHX14_2 = "Error uploading detection to reaperac.com. (%s) Data: "
    SHX15_2 = SHX14_2
    SHX14_2 = SHX14_2.format
    SHX16_2 = SHX10_2.status
    SHX17_2 = SHX10_2.body
    SHX14_2 = SHX14_2(SHX15_2, SHX16_2, SHX17_2)
    SHX15_2 = "error"
    SHX12_2(SHX13_2, SHX14_2, SHX15_2)
  end
  SHX13_2 = SHX3_2
  SHX12_2 = SHX3_2.NewLog
  SHX14_2 = "^3%s ^7(^3id:%s^7) was just ^3%s^7 (^3detection:%s^7) for ^3%s^7 Clip: ^3%s^7"
  SHX15_2 = SHX14_2
  SHX14_2 = SHX14_2.format
  SHX17_2 = SHX3_2
  SHX16_2 = SHX3_2.getName
  SHX16_2 = SHX16_2(SHX17_2)
  SHX18_2 = SHX3_2
  SHX17_2 = SHX3_2.getId
  SHX17_2 = SHX17_2(SHX18_2)
  SHX18_2 = SHX8_2
  SHX19_2 = SHX11_2.id
  SHX20_2 = SHX9_2
  SHX21_2 = SHX6_2 or SHX21_2
  if not SHX6_2 then
    SHX21_2 = "None"
  end
  SHX14_2 = SHX14_2(SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
  SHX15_2 = "warn"
  SHX16_2 = "detections"
  SHX17_2 = {}
  SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
  if "" ~= SHX4_2 then
    SHX12_2 = CreateThread
    function SHX13_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3
      SHX0_3 = HTTP
      SHX1_3 = SHX0_3
      SHX0_3 = SHX0_3.await
      SHX2_3 = SHX4_2
      SHX3_3 = "POST"
      SHX4_3 = json
      SHX4_3 = SHX4_3.encode
      SHX5_3 = {}
      SHX6_3 = "Reaper AntiCheat v"
      SHX7_3 = Cache
      SHX8_3 = SHX7_3
      SHX7_3 = SHX7_3.get
      SHX9_3 = "version"
      SHX7_3 = SHX7_3(SHX8_3, SHX9_3)
      SHX6_3 = SHX6_3 .. SHX7_3
      SHX5_3.username = SHX6_3
      SHX5_3.avatar_url = "https://media.discordapp.net/attachments/751481798122274966/861294300531523634/image0.png"
      SHX6_3 = {}
      SHX7_3 = {}
      SHX8_3 = {}
      SHX9_3 = "Reaper AntiCheat v"
      SHX10_3 = Cache
      SHX11_3 = SHX10_3
      SHX10_3 = SHX10_3.get
      SHX12_3 = "version"
      SHX10_3 = SHX10_3(SHX11_3, SHX12_3)
      SHX9_3 = SHX9_3 .. SHX10_3
      SHX8_3.name = SHX9_3
      SHX8_3.url = "https://reaperac.com"
      SHX8_3.icon_url = "https://media.discordapp.net/attachments/751481798122274966/861294300531523634/image0.png"
      SHX7_3.author = SHX8_3
      SHX8_3 = [[
```Name: %s
SteamID: %s
Discord: %s
License: %s```
**Violation:**```%s```
**Detection ID:**```%s```
%s]]
      SHX9_3 = SHX8_3
      SHX8_3 = SHX8_3.format
      SHX10_3 = SHX3_2
      SHX11_3 = SHX10_3
      SHX10_3 = SHX10_3.getName
      SHX10_3 = SHX10_3(SHX11_3)
      SHX11_3 = SHX3_2
      SHX12_3 = SHX11_3
      SHX11_3 = SHX11_3.getIdentifier
      SHX13_3 = "steam"
      SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
      if not SHX11_3 then
        SHX11_3 = "None"
      end
      SHX12_3 = SHX3_2
      SHX13_3 = SHX12_3
      SHX12_3 = SHX12_3.getIdentifier
      SHX14_3 = "discord"
      SHX12_3 = SHX12_3(SHX13_3, SHX14_3)
      if not SHX12_3 then
        SHX12_3 = "None"
      end
      SHX13_3 = SHX3_2
      SHX14_3 = SHX13_3
      SHX13_3 = SHX13_3.getIdentifier
      SHX15_3 = "license"
      SHX13_3 = SHX13_3(SHX14_3, SHX15_3)
      if not SHX13_3 then
        SHX13_3 = "None"
      end
      SHX14_3 = SHX9_2
      SHX15_3 = SHX11_2.id
      SHX16_3 = SHX6_2
      if not SHX16_3 then
        SHX16_3 = "No Clip"
      end
      SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
      SHX7_3.description = SHX8_3
      SHX8_3 = SHX5_2
      SHX7_3.color = SHX8_3
      SHX6_3[1] = SHX7_3
      SHX5_3.embeds = SHX6_3
      SHX4_3 = SHX4_3(SHX5_3)
      SHX5_3 = {}
      SHX5_3["Content-Type"] = "application/json"
      SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3)
    end
    SHX12_2(SHX13_2)
  end
  SHX12_2 = Cache
  SHX13_2 = SHX12_2
  SHX12_2 = SHX12_2.get
  SHX14_2 = "statistics"
  SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
  SHX13_2 = SHX0_2.action
  if "Log Player" == SHX13_2 then
    SHX13_2 = SHX12_2.warnings
    SHX13_2 = SHX13_2 + 1
    SHX12_2.warnings = SHX13_2
  else
    SHX13_2 = SHX0_2.action
    if "Kick Player" == SHX13_2 then
      SHX13_2 = SHX12_2.kicks
      SHX13_2 = SHX13_2 + 1
      SHX12_2.kicks = SHX13_2
    else
      SHX13_2 = SHX0_2.action
      if "Ban Player" == SHX13_2 then
        SHX13_2 = SHX12_2.bans
        SHX13_2 = SHX13_2 + 1
        SHX12_2.bans = SHX13_2
      end
    end
  end
  SHX13_2 = Cache
  SHX14_2 = SHX13_2
  SHX13_2 = SHX13_2.set
  SHX15_2 = "statistics"
  SHX16_2 = SHX12_2
  SHX13_2(SHX14_2, SHX15_2, SHX16_2)
  SHX13_2 = EmitPipe
  SHX14_2 = "Reaper:statisticsChange"
  SHX15_2 = SHX12_2
  SHX13_2(SHX14_2, SHX15_2)
  SHX13_2 = SHX0_2.action
  if "Kick Player" ~= SHX13_2 then
    SHX13_2 = SHX0_2.action
    if "Ban Player" ~= SHX13_2 then
      goto SHX_LABEL_423
    end
  end
  SHX13_2 = DropPlayer
  SHX15_2 = SHX3_2
  SHX14_2 = SHX3_2.getId
  SHX14_2 = SHX14_2(SHX15_2)
  SHX15_2 = SHX4_1.POSSIBLY_CHEATING
  SHX16_2 = SHX15_2
  SHX15_2 = SHX15_2.format
  SHX17_2 = SHX11_2.id
  if not SHX17_2 then
    SHX17_2 = 0
  end
  SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX15_2(SHX16_2, SHX17_2)
  SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
  -- [FIX IF ERROR] Move ::SHX_LABEL_423:: outside nested blocks until all 'goto SHX_LABEL_423' can see it
  ::SHX_LABEL_423::
  SHX13_2 = Cache
  SHX14_2 = SHX13_2
  SHX13_2 = SHX13_2.set
  SHX15_2 = "awaiting_detection_upload:"
  SHX17_2 = SHX3_2
  SHX16_2 = SHX3_2.getIdentifier
  SHX18_2 = "license"
  SHX16_2 = SHX16_2(SHX17_2, SHX18_2)
  SHX15_2 = SHX15_2 .. SHX16_2
  SHX16_2 = nil
  SHX13_2(SHX14_2, SHX15_2, SHX16_2)
end
SHX7_1(SHX8_1, SHX9_1, SHX10_1)
SHX7_1 = RPC
SHX8_1 = SHX7_1
SHX7_1 = SHX7_1.onNet
SHX9_1 = "Reaper:CustomDrop"
function SHX10_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = DropPlayer
  SHX2_2 = source
  SHX3_2 = SHX0_2
  SHX1_2(SHX2_2, SHX3_2)
end
SHX7_1(SHX8_1, SHX9_1, SHX10_1)
