-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1, SHX21_1, SHX22_1, SHX23_1, SHX24_1, SHX25_1, SHX26_1, SHX27_1, SHX28_1, SHX29_1, SHX30_1, SHX31_1, SHX32_1, SHX33_1, SHX34_1, SHX35_1, SHX36_1, SHX37_1, SHX38_1, SHX39_1, SHX40_1, SHX41_1, SHX42_1, SHX43_1, SHX44_1, SHX45_1, SHX46_1, SHX47_1, SHX48_1, SHX49_1, SHX50_1, SHX51_1, SHX52_1, SHX53_1, SHX54_1, SHX55_1, SHX56_1, SHX57_1, SHX58_1, SHX59_1, SHX60_1, SHX61_1, SHX62_1, SHX63_1, SHX64_1, SHX65_1, SHX66_1, SHX67_1, SHX68_1, SHX69_1, SHX70_1, SHX71_1, SHX72_1, SHX73_1, SHX74_1, SHX75_1, SHX76_1, SHX77_1, SHX78_1, SHX79_1, SHX80_1, SHX81_1, SHX82_1, SHX83_1, SHX84_1, SHX85_1, SHX86_1, SHX87_1, SHX88_1, SHX89_1, SHX90_1, SHX91_1, SHX92_1, SHX93_1, SHX94_1, SHX95_1, SHX96_1, SHX97_1
SHX0_1 = Security
SHX1_1 = Logger
SHX2_1 = RPC
SHX3_1 = Player
SHX4_1 = NUI
SHX5_1 = PedConfigFlags
SHX6_1 = PedTaskTypes
SHX7_1 = GetConvar
SHX8_1 = NetworkIsInSpectatorMode
SHX9_1 = PlayerId
SHX10_1 = IsEntityVisible
SHX11_1 = GetPlayerInvincible
SHX12_1 = PlayerPedId
SHX13_1 = GetDistanceBetweenCoords
SHX14_1 = GetGroundZFor_3dCoord
SHX15_1 = math
SHX15_1 = SHX15_1.abs
SHX16_1 = math
SHX16_1 = SHX16_1.floor
SHX17_1 = string
SHX17_1 = SHX17_1.match
SHX18_1 = GetRenderingCam
SHX19_1 = Wait
SHX20_1 = json
SHX20_1 = SHX20_1.decode
SHX21_1 = HasStreamedTextureDictLoaded
SHX22_1 = IsEntityPositionFrozen
if not SHX22_1 then
  function SHX22_1(...)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_2, SHX1_2
    SHX0_2 = false
    return SHX0_2
  end
end
SHX23_1 = GetEntityAttachedTo
SHX24_1 = GetEntityProofs
SHX25_1 = NetworkSetInSpectatorMode
SHX26_1 = SetEntityInvincible
SHX27_1 = GetEntityVelocity
SHX28_1 = GetVehiclePedIsIn
SHX29_1 = vec3
SHX30_1 = IsPedDiving
SHX31_1 = IsPedRagdoll
SHX32_1 = IsPedOnVehicle
SHX33_1 = IsEntityAttached
SHX34_1 = IsPedClimbing
SHX35_1 = HasCollisionLoadedAroundEntity
SHX36_1 = IsEntityInWater
SHX37_1 = IsPedSwimming
SHX38_1 = IsPedSwimmingUnderWater
SHX39_1 = GetGameTimer
SHX40_1 = GetEntityRoll
SHX41_1 = GetLabelText
SHX42_1 = GetPedConfigFlag
SHX43_1 = StatGetInt
SHX44_1 = IsEntityWaitingForWorldCollision
SHX45_1 = IsPedFalling
SHX46_1 = IsPedGettingIntoAVehicle
SHX47_1 = MumbleGetTalkerProximity
SHX48_1 = NetworkGetTalkerProximity
SHX49_1 = HasEntityBeenDamagedByAnyVehicle
SHX50_1 = GetPedParachuteState
SHX51_1 = IsPedInAnyVehicle
SHX52_1 = CreateThread
SHX53_1 = GetEntityModel
SHX54_1 = IsPedAPlayer
SHX55_1 = tostring
SHX56_1 = tonumber
SHX57_1 = IsEntityDead
SHX58_1 = GetEntityScript
SHX59_1 = ClearPedTasksImmediately
SHX60_1 = GetEntityAlpha
SHX61_1 = IsCinematicCamRendering
SHX62_1 = GetFollowPedCamViewMode
SHX63_1 = GetFinalRenderedCamCoord
SHX64_1 = IsFollowPedCamActive
SHX65_1 = GetEntitySpeed
SHX66_1 = IsEntityOnScreen
SHX67_1 = GetModelDimensions
SHX68_1 = IsEntityAttachedToEntity
SHX69_1 = GetIsTaskActive
SHX70_1 = GetVehicleBodyHealth
SHX71_1 = GetVehicleGravityAmount
SHX72_1 = GetPedInVehicleSeat
SHX73_1 = GetVehicleTyresCanBurst
SHX74_1 = GetScriptTaskStatus
SHX75_1 = GetVehicleMod
SHX76_1 = GetVehicleWindowTint
SHX77_1 = GetEntityCoords
SHX78_1 = GetVehicleNumberPlateText1
SHX79_1 = SHX78_1
SHX80_1 = SetVehicleNumberPlateText
SHX81_1 = GetVehicleWheelType
SHX82_1 = HasAnimDictLoaded
SHX83_1 = IsEntityPlayingAnim
SHX84_1 = IsPlayerSwitchInProgress
SHX85_1 = NetworkGetNetworkIdFromEntity
SHX86_1 = NetworkSessionIsSolo
SHX87_1 = GetPedDrawableVariation
SHX88_1 = IsPedWalking
SHX89_1 = IsPedSprinting
SHX90_1 = SHX7_1
SHX91_1 = "reaper_check_bullet_proof_tires"
SHX92_1 = "false"
SHX90_1 = SHX90_1(SHX91_1, SHX92_1)
SHX90_1 = "true" == SHX90_1
SHX91_1 = {}
SHX92_1 = -1210645269
SHX91_1[SHX92_1] = 0
SHX92_1 = -1266079991
SHX91_1[SHX92_1] = 0
SHX92_1 = -1620877475
SHX91_1[SHX92_1] = 0
SHX92_1 = -886696809
SHX91_1[SHX92_1] = 0
SHX92_1 = -73289152
SHX91_1[SHX92_1] = 0
SHX92_1 = 708474090
SHX91_1[SHX92_1] = 0
SHX92_1 = 1283054317
SHX91_1[SHX92_1] = 0
SHX92_1 = -393635894
SHX91_1[SHX92_1] = 0
function SHX92_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  if 1 == SHX0_2 or true == SHX0_2 then
    SHX1_2 = true
    return SHX1_2
  else
    SHX1_2 = false
    return SHX1_2
  end
end
SHX93_1 = false
SHX95_1 = SHX4_1
SHX94_1 = SHX4_1.on
SHX96_1 = "ready"
function SHX97_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2
  SHX2_2 = true
  SHX93_1 = SHX2_2
  SHX2_2 = SHX1_2
  SHX3_2 = true
  SHX2_2(SHX3_2)
end
SHX94_1(SHX95_1, SHX96_1, SHX97_1)
SHX94_1 = SHX52_1
function SHX95_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2
  while true do
    SHX0_2 = SHX19_1
    SHX1_2 = 500
    SHX0_2(SHX1_2)
    SHX0_2 = SHX92_1
    SHX1_2 = SHX66_1
    SHX2_2 = SHX12_1
    SHX2_2, SHX3_2 = SHX2_2()
    SHX1_2, SHX2_2, SHX3_2 = SHX1_2(SHX2_2, SHX3_2)
    SHX0_2 = SHX0_2(SHX1_2, SHX2_2, SHX3_2)
    if true == SHX0_2 then
      break
    end
  end
  SHX0_2 = SHX3_1
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.set
  SHX2_2 = "player_loaded"
  SHX3_2 = true
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
end
SHX94_1(SHX95_1)
SHX95_1 = SHX2_1
SHX94_1 = SHX2_1.on
SHX96_1 = "reaperReady"
function SHX97_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX0_2 = SHX3_1
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX2_2 = "gameType"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX1_2 = SHX1_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Reaper ready, fetching needed data"
  SHX4_2 = "debug"
  SHX5_2 = true
  SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2)
  while true do
    SHX1_2 = SHX93_1
    if false ~= SHX1_2 then
      break
    end
    SHX1_2 = SHX19_1
    SHX2_2 = 200
    SHX1_2(SHX2_2)
    SHX1_2 = SHX1_1
    SHX2_2 = SHX1_2
    SHX1_2 = SHX1_2.log
    SHX3_2 = "Waiting for NUI to load..."
    SHX4_2 = "debug"
    SHX5_2 = true
    SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2)
    SHX1_2 = SHX4_1
    SHX2_2 = SHX1_2
    SHX1_2 = SHX1_2.send
    SHX3_2 = "ready"
    SHX1_2(SHX2_2, SHX3_2)
  end
  if "gta5" == SHX0_2 then
    SHX1_2 = SHX20_1
    SHX2_2 = SHX4_1
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.httpRequest
    SHX4_2 = "https://api.reaperac.com/api/v1/data/ocr"
    SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX2_2(SHX3_2, SHX4_2)
    SHX1_2 = SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
    SHX2_2 = SHX20_1
    SHX3_2 = SHX4_1
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.httpRequest
    SHX5_2 = "https://api.reaperac.com/api/v1/data/textures"
    SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX3_2(SHX4_2, SHX5_2)
    SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
    SHX3_2 = SHX20_1
    SHX4_2 = SHX4_1
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.httpRequest
    SHX6_2 = "https://api.reaperac.com/api/v1/data/labels"
    SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX4_2(SHX5_2, SHX6_2)
    SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
    if nil == SHX1_2 or nil == SHX2_2 or nil == SHX3_2 then
      SHX4_2 = SHX1_1
      SHX5_2 = SHX4_2
      SHX4_2 = SHX4_2.log
      SHX6_2 = "failed to load needed data. OCR_Strings: %s, Blacklisted_Textures: %s, Blacklisted_Labels: %s"
      SHX7_2 = SHX6_2
      SHX6_2 = SHX6_2.format
      SHX8_2 = SHX1_2
      SHX9_2 = SHX2_2
      SHX10_2 = SHX3_2
      SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
      SHX7_2 = "error"
      SHX8_2 = true
      SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
      SHX4_2 = SHX19_1
      SHX5_2 = 500
      SHX4_2(SHX5_2)
    end
    SHX4_2 = SHX0_1
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.addDetection
    SHX6_2 = {}
    SHX6_2.time = 3000
    SHX6_2.detection = "antiSpectate"
    function SHX7_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3
      SHX0_3 = SHX25_1
      SHX1_3 = false
      SHX2_3 = SHX12_1
      SHX2_3 = SHX2_3()
      SHX0_3(SHX1_3, SHX2_3)
    end
    SHX6_2.detected = SHX7_2
    function SHX7_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3
      SHX0_3 = SHX8_1
      SHX0_3 = SHX0_3()
      if SHX0_3 then
        SHX0_3 = SHX3_1
        SHX1_3 = SHX0_3
        SHX0_3 = SHX0_3.get
        SHX2_3 = "NetworkIsInSpectatorMode"
        SHX3_3 = false
        SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3)
        SHX0_3 = false == SHX0_3
      end
      return SHX0_3
    end
    SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX4_2 = SHX0_1
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.addDetection
    SHX6_2 = {}
    SHX6_2.time = 8000
    SHX6_2.detection = "antiInfiniteCombatRoll"
    function SHX7_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3
      SHX0_3 = nil
      SHX1_3 = pairs
      SHX2_3 = SHX91_1
      SHX1_3, SHX2_3, SHX3_3, SHX4_3 = SHX1_3(SHX2_3)
      for SHX5_3, SHX6_3 in SHX1_3, SHX2_3, SHX3_3, SHX4_3 do
        SHX7_3 = SHX43_1
        SHX8_3 = SHX5_3
        SHX7_3, SHX8_3 = SHX7_3(SHX8_3)
        SHX9_3 = SHX56_1
        SHX10_3 = SHX3_1
        SHX11_3 = SHX10_3
        SHX10_3 = SHX10_3.get
        SHX12_3 = "StatInit_"
        SHX13_3 = SHX5_3
        SHX12_3 = SHX12_3 .. SHX13_3
        SHX13_3 = SHX6_3
        SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
        if not SHX10_3 then
          SHX10_3 = SHX8_3
        end
        SHX9_3 = SHX9_3(SHX10_3)
        SHX10_3 = SHX92_1
        SHX11_3 = SHX7_3
        SHX10_3 = SHX10_3(SHX11_3)
        if SHX10_3 and SHX8_3 > SHX9_3 and SHX8_3 > 120 then
          SHX0_3 = SHX8_3
          break
        end
      end
      SHX1_3 = nil ~= SHX0_3
      SHX2_3 = {}
      SHX3_3 = SHX0_3
      SHX2_3[1] = SHX3_3
      SHX3_3 = {}
      SHX4_3 = SHX0_3
      SHX3_3[1] = SHX4_3
      return SHX1_3, SHX2_3, SHX3_3
    end
    SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX4_2 = SHX0_1
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.addDetection
    SHX6_2 = {}
    SHX6_2.time = 5000
    SHX6_2.detection = "blacklistedLabels"
    function SHX7_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
      SHX0_3 = nil
      SHX1_3 = pairs
      SHX2_3 = SHX3_2
      if not SHX2_3 then
        SHX2_3 = {}
      end
      SHX1_3, SHX2_3, SHX3_3, SHX4_3 = SHX1_3(SHX2_3)
      for SHX5_3, SHX6_3 in SHX1_3, SHX2_3, SHX3_3, SHX4_3 do
        SHX7_3 = SHX19_1
        SHX8_3 = 0
        SHX7_3(SHX8_3)
        SHX7_3 = SHX41_1
        SHX8_3 = SHX6_3.label
        SHX7_3 = SHX7_3(SHX8_3)
        SHX8_3 = string
        SHX8_3 = SHX8_3.match
        SHX9_3 = SHX7_3
        SHX10_3 = SHX6_3.value
        SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
        if SHX8_3 then
          SHX6_3.text = SHX7_3
          SHX0_3 = SHX6_3
          break
        end
      end
      if SHX0_3 then
        SHX1_3 = true
        SHX2_3 = {}
        SHX3_3 = SHX0_3
        return SHX1_3, SHX2_3, SHX3_3
      end
    end
    SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX4_2 = SHX0_1
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.addDetection
    SHX6_2 = {}
    SHX6_2.time = 8000
    SHX6_2.detection = "antiNoCriticalHits"
    function SHX7_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
      SHX0_3 = SHX3_1
      SHX1_3 = SHX0_3
      SHX0_3 = SHX0_3.get
      SHX2_3 = "CPED_CONFIG_FLAG_NoCriticalHits"
      SHX3_3 = false
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3)
      SHX1_3 = SHX92_1
      SHX2_3 = SHX42_1
      SHX3_3 = SHX12_1
      SHX3_3 = SHX3_3()
      SHX4_3 = SHX5_1.CPED_CONFIG_FLAG_NoCriticalHits
      SHX2_3, SHX3_3, SHX4_3 = SHX2_3(SHX3_3, SHX4_3)
      SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3)
      if SHX0_3 ~= SHX1_3 and SHX1_3 then
        SHX2_3 = {}
        SHX3_3 = SHX0_3
        SHX4_3 = SHX1_3
        SHX2_3[1] = SHX3_3
        SHX2_3[2] = SHX4_3
        if SHX2_3 then
          goto SHX_LABEL_25
        end
      end
      SHX2_3 = nil
      -- [FIX IF ERROR] Move ::SHX_LABEL_25:: outside nested blocks until all 'goto SHX_LABEL_25' can see it
      ::SHX_LABEL_25::
      return SHX2_3
    end
    SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX4_2 = SHX0_1
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.addDetection
    SHX6_2 = {}
    SHX6_2.time = 2000
    SHX6_2.detection = "blacklistedTextures"
    function SHX7_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
      SHX0_3 = nil
      SHX1_3 = pairs
      SHX2_3 = SHX2_2
      if not SHX2_3 then
        SHX2_3 = {}
      end
      SHX1_3, SHX2_3, SHX3_3, SHX4_3 = SHX1_3(SHX2_3)
      for SHX5_3, SHX6_3 in SHX1_3, SHX2_3, SHX3_3, SHX4_3 do
        SHX7_3 = SHX19_1
        SHX8_3 = 0
        SHX7_3(SHX8_3)
        SHX7_3 = SHX21_1
        SHX8_3 = SHX6_3.texture
        SHX7_3 = SHX7_3(SHX8_3)
        if SHX7_3 then
          SHX7_3 = SHX3_1
          SHX8_3 = SHX7_3
          SHX7_3 = SHX7_3.get
          SHX9_3 = SHX6_3.texture
          SHX10_3 = "_loaded"
          SHX9_3 = SHX9_3 .. SHX10_3
          SHX10_3 = false
          SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
          if false == SHX7_3 then
            SHX0_3 = SHX6_3
            break
          end
        end
      end
      if SHX0_3 then
        SHX1_3 = true
        SHX2_3 = {}
        SHX3_3 = SHX0_3
        return SHX1_3, SHX2_3, SHX3_3
      end
    end
    SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX4_2 = SHX2_1
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.onNet
    SHX6_2 = "ReaperV4:AddTextEntry"
    function SHX7_2(SHX0_3, SHX1_3)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
      SHX2_3 = pairs
      SHX3_3 = SHX3_2
      if not SHX3_3 then
        SHX3_3 = {}
      end
      SHX2_3, SHX3_3, SHX4_3, SHX5_3 = SHX2_3(SHX3_3)
      for SHX6_3, SHX7_3 in SHX2_3, SHX3_3, SHX4_3, SHX5_3 do
        SHX8_3 = SHX7_3.label
        if SHX8_3 == SHX0_3 then
          SHX8_3 = string
          SHX8_3 = SHX8_3.match
          SHX9_3 = SHX1_3
          SHX10_3 = SHX7_3.value
          SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
          if SHX8_3 then
            SHX8_3 = SHX7_3.label
            SHX9_3 = "_disabled"
            SHX8_3 = SHX8_3 .. SHX9_3
            SHX7_3.label = SHX8_3
          end
        end
      end
    end
    SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX4_2 = SHX0_1
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.addDetection
    SHX6_2 = {}
    SHX6_2.time = 9000
    SHX6_2.detection = "onScreenMenuDetection"
    SHX6_2.disableVerify = true
    function SHX7_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
      SHX0_3 = nil
      SHX1_3 = SHX4_1
      SHX2_3 = SHX1_3
      SHX1_3 = SHX1_3.getOCRText
      SHX1_3 = SHX1_3(SHX2_3)
      SHX2_3 = SHX1_3
      SHX1_3 = SHX1_3.lower
      SHX1_3 = SHX1_3(SHX2_3)
      SHX2_3 = pairs
      SHX3_3 = SHX1_2
      if not SHX3_3 then
        SHX3_3 = {}
      end
      SHX2_3, SHX3_3, SHX4_3, SHX5_3 = SHX2_3(SHX3_3)
      for SHX6_3, SHX7_3 in SHX2_3, SHX3_3, SHX4_3, SHX5_3 do
        SHX8_3 = SHX19_1
        SHX9_3 = 0
        SHX8_3(SHX9_3)
        SHX8_3 = string
        SHX8_3 = SHX8_3.match
        SHX9_3 = SHX1_3
        SHX10_3 = SHX7_3.str
        SHX11_3 = SHX10_3
        SHX10_3 = SHX10_3.lower
        SHX10_3, SHX11_3 = SHX10_3(SHX11_3)
        SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3)
        if SHX8_3 then
          SHX0_3 = SHX7_3
          break
        end
      end
      if SHX0_3 then
        SHX0_3.ocr_text = SHX1_3
        SHX2_3 = true
        SHX3_3 = {}
        SHX4_3 = SHX0_3
        return SHX2_3, SHX3_3, SHX4_3
      end
    end
    SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX4_2 = SHX0_1
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.addDetection
    SHX6_2 = {}
    SHX6_2.time = 5000
    SHX6_2.detection = "antiSkinChanger"
    function SHX7_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
      SHX0_3 = SHX3_1
      SHX1_3 = SHX0_3
      SHX0_3 = SHX0_3.set
      SHX2_3 = "ped"
      SHX3_3 = SHX53_1
      SHX4_3 = SHX12_1
      SHX4_3 = SHX4_3()
      SHX3_3, SHX4_3 = SHX3_3(SHX4_3)
      SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3)
    end
    SHX6_2.detected = SHX7_2
    function SHX7_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3
      SHX0_3 = SHX53_1
      SHX1_3 = SHX12_1
      SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3 = SHX1_3()
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX1_3 = SHX3_1
      SHX2_3 = SHX1_3
      SHX1_3 = SHX1_3.get
      SHX3_3 = "playerModelLastChange"
      SHX4_3 = 0
      SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3)
      if 0 == SHX1_3 then
        SHX2_3 = SHX3_1
        SHX3_3 = SHX2_3
        SHX2_3 = SHX2_3.set
        SHX4_3 = "playerModelLastChange"
        SHX5_3 = SHX39_1
        SHX5_3, SHX6_3, SHX7_3, SHX8_3 = SHX5_3()
        SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      end
      SHX2_3 = SHX39_1
      SHX2_3 = SHX2_3()
      SHX3_3 = SHX3_1
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.get
      SHX5_3 = "playerModelLastChange"
      SHX6_3 = 0
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      SHX2_3 = SHX2_3 - SHX3_3
      SHX3_3 = 20000
      if SHX2_3 < SHX3_3 then
        SHX2_3 = SHX3_1
        SHX3_3 = SHX2_3
        SHX2_3 = SHX2_3.set
        SHX4_3 = "ped"
        SHX5_3 = SHX0_3
        SHX2_3(SHX3_3, SHX4_3, SHX5_3)
        SHX2_3 = false
        return SHX2_3
      end
      SHX2_3 = SHX56_1
      SHX3_3 = SHX3_1
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.get
      SHX5_3 = "ped"
      SHX6_3 = SHX0_3
      SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX2_3 = SHX0_3 ~= SHX2_3
      SHX3_3 = {}
      SHX4_3 = SHX0_3
      SHX3_3[1] = SHX4_3
      SHX4_3 = {}
      SHX4_3.model = SHX0_3
      SHX5_3 = SHX3_1
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.get
      SHX7_3 = "ped"
      SHX8_3 = SHX0_3
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3)
      SHX4_3.set_model = SHX5_3
      return SHX2_3, SHX3_3, SHX4_3
    end
    SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX4_2 = {}
    SHX4_2.HEAD = 0
    SHX4_2.BEARD = 1
    SHX4_2.HAIR = 2
    SHX4_2.TORSO = 3
    SHX4_2.LEGS = 4
    SHX4_2.HANDS = 5
    SHX4_2.FOOT = 6
    SHX4_2["SCARFS/NECK_ACCESSORIES"] = 7
    SHX4_2.ACCESSORIES_ONE = 8
    SHX4_2.ACCESSORIES_TWO = 9
    SHX4_2.DECALS = 10
    SHX4_2.AUX_PARTS_TORSO = 11
    SHX5_2 = SHX0_1
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.addDetection
    SHX7_2 = {}
    SHX7_2.time = 10000
    SHX7_2.detection = "antiClothingChanger"
    function SHX8_2(SHX0_3)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
      SHX1_3 = SHX12_1
      SHX1_3 = SHX1_3()
      SHX2_3 = SHX53_1
      SHX3_3 = SHX1_3
      SHX2_3 = SHX2_3(SHX3_3)
      SHX3_3 = SHX3_1
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.set
      SHX5_3 = "ped_"
      SHX6_3 = SHX1_3
      SHX7_3 = "_"
      SHX8_3 = SHX2_3
      SHX9_3 = "_component_variation_"
      SHX11_3 = SHX0_3[1]
      SHX10_3 = SHX4_2
      SHX10_3 = SHX10_3[SHX11_3]
      SHX5_3 = SHX5_3 .. SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3 .. SHX10_3
      SHX6_3 = SHX0_3[2]
      SHX7_3 = true
      SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3)
    end
    SHX7_2.detected = SHX8_2
    function SHX8_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3
      SHX0_3 = SHX12_1
      SHX0_3 = SHX0_3()
      SHX1_3 = SHX53_1
      SHX2_3 = SHX0_3
      SHX1_3 = SHX1_3(SHX2_3)
      SHX2_3 = {}
      SHX3_3 = SHX87_1
      SHX4_3 = SHX0_3
      SHX5_3 = 0
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX2_3.HEAD = SHX3_3
      SHX3_3 = SHX87_1
      SHX4_3 = SHX0_3
      SHX5_3 = 1
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX2_3.BEARD = SHX3_3
      SHX3_3 = SHX87_1
      SHX4_3 = SHX0_3
      SHX5_3 = 2
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX2_3.HAIR = SHX3_3
      SHX3_3 = SHX87_1
      SHX4_3 = SHX0_3
      SHX5_3 = 3
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX2_3.TORSO = SHX3_3
      SHX3_3 = SHX87_1
      SHX4_3 = SHX0_3
      SHX5_3 = 4
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX2_3.LEGS = SHX3_3
      SHX3_3 = SHX87_1
      SHX4_3 = SHX0_3
      SHX5_3 = 5
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX2_3.HANDS = SHX3_3
      SHX3_3 = SHX87_1
      SHX4_3 = SHX0_3
      SHX5_3 = 6
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX2_3.FOOT = SHX3_3
      SHX3_3 = SHX87_1
      SHX4_3 = SHX0_3
      SHX5_3 = 7
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX2_3["SCARFS/NECK_ACCESSORIES"] = SHX3_3
      SHX3_3 = SHX87_1
      SHX4_3 = SHX0_3
      SHX5_3 = 8
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX2_3.ACCESSORIES_ONE = SHX3_3
      SHX3_3 = SHX87_1
      SHX4_3 = SHX0_3
      SHX5_3 = 9
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX2_3.ACCESSORIES_TWO = SHX3_3
      SHX3_3 = SHX87_1
      SHX4_3 = SHX0_3
      SHX5_3 = 10
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX2_3.DECALS = SHX3_3
      SHX3_3 = SHX87_1
      SHX4_3 = SHX0_3
      SHX5_3 = 11
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX2_3.AUX_PARTS_TORSO = SHX3_3
      SHX3_3 = {}
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "ped_"
      SHX7_3 = SHX0_3
      SHX8_3 = "_"
      SHX9_3 = SHX1_3
      SHX10_3 = "_component_variation_0"
      SHX6_3 = SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3 .. SHX10_3
      SHX7_3 = SHX2_3.HEAD
      SHX8_3 = true
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX3_3.HEAD = SHX4_3
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "ped_"
      SHX7_3 = SHX0_3
      SHX8_3 = "_"
      SHX9_3 = SHX1_3
      SHX10_3 = "_component_variation_1"
      SHX6_3 = SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3 .. SHX10_3
      SHX7_3 = SHX2_3.BEARD
      SHX8_3 = true
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX3_3.BEARD = SHX4_3
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "ped_"
      SHX7_3 = SHX0_3
      SHX8_3 = "_"
      SHX9_3 = SHX1_3
      SHX10_3 = "_component_variation_2"
      SHX6_3 = SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3 .. SHX10_3
      SHX7_3 = SHX2_3.HAIR
      SHX8_3 = true
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX3_3.HAIR = SHX4_3
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "ped_"
      SHX7_3 = SHX0_3
      SHX8_3 = "_"
      SHX9_3 = SHX1_3
      SHX10_3 = "_component_variation_3"
      SHX6_3 = SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3 .. SHX10_3
      SHX7_3 = SHX2_3.TORSO
      SHX8_3 = true
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX3_3.TORSO = SHX4_3
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "ped_"
      SHX7_3 = SHX0_3
      SHX8_3 = "_"
      SHX9_3 = SHX1_3
      SHX10_3 = "_component_variation_4"
      SHX6_3 = SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3 .. SHX10_3
      SHX7_3 = SHX2_3.LEGS
      SHX8_3 = true
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX3_3.LEGS = SHX4_3
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "ped_"
      SHX7_3 = SHX0_3
      SHX8_3 = "_"
      SHX9_3 = SHX1_3
      SHX10_3 = "_component_variation_5"
      SHX6_3 = SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3 .. SHX10_3
      SHX7_3 = SHX2_3.HANDS
      SHX8_3 = true
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX3_3.HANDS = SHX4_3
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "ped_"
      SHX7_3 = SHX0_3
      SHX8_3 = "_"
      SHX9_3 = SHX1_3
      SHX10_3 = "_component_variation_6"
      SHX6_3 = SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3 .. SHX10_3
      SHX7_3 = SHX2_3.FOOT
      SHX8_3 = true
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX3_3.FOOT = SHX4_3
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "ped_"
      SHX7_3 = SHX0_3
      SHX8_3 = "_"
      SHX9_3 = SHX1_3
      SHX10_3 = "_component_variation_7"
      SHX6_3 = SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3 .. SHX10_3
      SHX7_3 = SHX2_3["SCARFS/NECK_ACCESSORIES"]
      SHX8_3 = true
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX3_3["SCARFS/NECK_ACCESSORIES"] = SHX4_3
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "ped_"
      SHX7_3 = SHX0_3
      SHX8_3 = "_"
      SHX9_3 = SHX1_3
      SHX10_3 = "_component_variation_8"
      SHX6_3 = SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3 .. SHX10_3
      SHX7_3 = SHX2_3.ACCESSORIES_ONE
      SHX8_3 = true
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX3_3.ACCESSORIES_ONE = SHX4_3
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "ped_"
      SHX7_3 = SHX0_3
      SHX8_3 = "_"
      SHX9_3 = SHX1_3
      SHX10_3 = "_component_variation_9"
      SHX6_3 = SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3 .. SHX10_3
      SHX7_3 = SHX2_3.ACCESSORIES_TWO
      SHX8_3 = true
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX3_3.ACCESSORIES_TWO = SHX4_3
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "ped_"
      SHX7_3 = SHX0_3
      SHX8_3 = "_"
      SHX9_3 = SHX1_3
      SHX10_3 = "_component_variation_10"
      SHX6_3 = SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3 .. SHX10_3
      SHX7_3 = SHX2_3.DECALS
      SHX8_3 = true
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX3_3.DECALS = SHX4_3
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "ped_"
      SHX7_3 = SHX0_3
      SHX8_3 = "_"
      SHX9_3 = SHX1_3
      SHX10_3 = "_component_variation_11"
      SHX6_3 = SHX6_3 .. SHX7_3 .. SHX8_3 .. SHX9_3 .. SHX10_3
      SHX7_3 = SHX2_3.AUX_PARTS_TORSO
      SHX8_3 = true
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX3_3.AUX_PARTS_TORSO = SHX4_3
      SHX4_3 = nil
      SHX5_3 = pairs
      SHX6_3 = SHX2_3
      SHX5_3, SHX6_3, SHX7_3, SHX8_3 = SHX5_3(SHX6_3)
      for SHX9_3, SHX10_3 in SHX5_3, SHX6_3, SHX7_3, SHX8_3 do
        SHX11_3 = SHX3_3[SHX9_3]
        if SHX11_3 ~= SHX10_3 then
          SHX11_3 = {}
          SHX11_3.component = SHX9_3
          SHX11_3.component_variation = SHX10_3
          SHX12_3 = SHX3_3[SHX9_3]
          SHX11_3.known_component_variation = SHX12_3
          SHX4_3 = SHX11_3
          break
        end
      end
      if nil ~= SHX4_3 then
        SHX5_3 = SHX3_1
        SHX6_3 = SHX5_3
        SHX5_3 = SHX5_3.getRecentlyChanged
        SHX7_3 = "SetPedComponentVariation"
        SHX8_3 = 40000
        SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3)
        if false == SHX5_3 then
          SHX5_3 = nil ~= SHX4_3
          SHX6_3 = {}
          SHX7_3 = SHX4_3.component
          SHX8_3 = SHX4_3.component_variation
          SHX9_3 = SHX4_3.known_component_variation
          SHX6_3[1] = SHX7_3
          SHX6_3[2] = SHX8_3
          SHX6_3[3] = SHX9_3
          SHX7_3 = SHX4_3
          return SHX5_3, SHX6_3, SHX7_3
      end
      else
        SHX5_3 = false
        return SHX5_3
      end
    end
    SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    SHX5_2 = SHX0_1
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.addDetection
    SHX7_2 = {}
    SHX7_2.time = 3000
    SHX7_2.detection = "antiAttach"
    function SHX8_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3
      SHX0_3 = SHX12_1
      SHX0_3 = SHX0_3()
      SHX1_3 = SHX23_1
      SHX2_3 = SHX0_3
      SHX1_3 = SHX1_3(SHX2_3)
      if 0 ~= SHX1_3 then
        SHX2_3 = SHX54_1
        SHX3_3 = SHX1_3
        SHX2_3 = SHX2_3(SHX3_3)
        if SHX2_3 then
          SHX2_3 = SHX3_1
          SHX3_3 = SHX2_3
          SHX2_3 = SHX2_3.get
          SHX4_3 = "entityAttachedTo"
          SHX5_3 = false
          SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
          if false == SHX2_3 then
            SHX2_3 = SHX39_1
            SHX2_3 = SHX2_3()
            SHX3_3 = SHX3_1
            SHX4_3 = SHX3_3
            SHX3_3 = SHX3_3.getSetTime
            SHX5_3 = "entityAttachedTo"
            SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
            SHX2_3 = SHX2_3 - SHX3_3
            SHX3_3 = 8000
            if SHX2_3 > SHX3_3 then
              SHX2_3 = true
              return SHX2_3
            end
          end
        end
      end
      SHX2_3 = false
      return SHX2_3
    end
    SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    SHX5_2 = SHX0_1
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.addDetection
    SHX7_2 = {}
    SHX7_2.time = 1000
    SHX7_2.detection = "antiNPCVehicleAttach"
    function SHX8_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
      SHX0_3 = SHX12_1
      SHX0_3 = SHX0_3()
      SHX1_3 = SHX46_1
      SHX2_3 = SHX0_3
      SHX1_3 = SHX1_3(SHX2_3)
      if SHX1_3 then
        SHX1_3 = false
        return SHX1_3
      end
      SHX1_3 = pairs
      SHX2_3 = GetGamePool
      SHX3_3 = "CVehicle"
      SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX2_3(SHX3_3)
      SHX1_3, SHX2_3, SHX3_3, SHX4_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
      for SHX5_3, SHX6_3 in SHX1_3, SHX2_3, SHX3_3, SHX4_3 do
        SHX7_3 = SHX68_1
        SHX8_3 = SHX6_3
        SHX9_3 = SHX0_3
        SHX7_3 = SHX7_3(SHX8_3, SHX9_3)
        if SHX7_3 then
          SHX7_3 = SHX23_1
          SHX8_3 = SHX6_3
          SHX7_3 = SHX7_3(SHX8_3)
          if SHX7_3 == SHX0_3 then
            SHX7_3 = SHX2_1
            SHX8_3 = SHX7_3
            SHX7_3 = SHX7_3.emitNet
            SHX9_3 = "Reaper:antiNPCVehicleAttach"
            SHX10_3 = SHX85_1
            SHX11_3 = SHX6_3
            SHX10_3, SHX11_3 = SHX10_3(SHX11_3)
            SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3)
            SHX7_3 = SHX19_1
            SHX8_3 = 50
            SHX7_3(SHX8_3)
          end
        end
      end
      SHX1_3 = false
      return SHX1_3
    end
    SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    SHX5_2 = SHX0_1
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.addDetection
    SHX7_2 = {}
    SHX7_2.time = 2000
    SHX7_2.detection = "antiVoiceExploits"
    function SHX8_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3
      SHX0_3 = SHX16_1
      SHX1_3 = SHX47_1
      SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3 = SHX1_3()
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX1_3 = SHX55_1
      SHX2_3 = SHX0_3
      SHX1_3 = SHX1_3(SHX2_3)
      if "3.4028234663853e+38" == SHX1_3 then
        SHX0_3 = 3.4
      end
      if SHX0_3 > 55 then
        SHX1_3 = SHX3_1
        SHX2_3 = SHX1_3
        SHX1_3 = SHX1_3.get
        SHX3_3 = "mumble_talker_Proximity"
        SHX4_3 = 10.0
        SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3)
        if SHX0_3 > SHX1_3 then
          SHX1_3 = SHX39_1
          SHX1_3 = SHX1_3()
          SHX2_3 = SHX3_1
          SHX3_3 = SHX2_3
          SHX2_3 = SHX2_3.getSetTime
          SHX4_3 = "mumble_talker_Proximity"
          SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
          SHX1_3 = SHX1_3 - SHX2_3
          SHX2_3 = 5000
          if SHX1_3 > SHX2_3 then
            SHX1_3 = true
            SHX2_3 = {}
            SHX3_3 = SHX0_3
            SHX4_3 = "1"
            SHX2_3[1] = SHX3_3
            SHX2_3[2] = SHX4_3
            SHX3_3 = {}
            SHX3_3.network_range = SHX0_3
            SHX4_3 = SHX3_1
            SHX5_3 = SHX4_3
            SHX4_3 = SHX4_3.get
            SHX6_3 = "mumble_talker_Proximity"
            SHX7_3 = 10.0
            SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
            SHX3_3.known_range = SHX4_3
            SHX3_3.type = "1"
            SHX4_3 = SHX3_1
            SHX5_3 = SHX4_3
            SHX4_3 = SHX4_3.getSetTime
            SHX6_3 = "mumble_talker_Proximity"
            SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
            SHX3_3.set_time = SHX4_3
            return SHX1_3, SHX2_3, SHX3_3
          end
        end
      end
      SHX1_3 = SHX0_2
      if "gta5" == SHX1_3 then
        SHX1_3 = SHX48_1
        SHX1_3 = SHX1_3()
        SHX2_3 = SHX55_1
        SHX3_3 = SHX1_3
        SHX2_3 = SHX2_3(SHX3_3)
        if "3.4028234663853e+38" == SHX2_3 then
          SHX1_3 = 3.4
        end
        if SHX1_3 > 55 then
          SHX2_3 = SHX3_1
          SHX3_3 = SHX2_3
          SHX2_3 = SHX2_3.get
          SHX4_3 = "network_talker_Proximity"
          SHX5_3 = 10.0
          SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
          if SHX1_3 > SHX2_3 then
            SHX2_3 = SHX39_1
            SHX2_3 = SHX2_3()
            SHX3_3 = SHX3_1
            SHX4_3 = SHX3_3
            SHX3_3 = SHX3_3.getSetTime
            SHX5_3 = "network_talker_Proximity"
            SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
            SHX2_3 = SHX2_3 - SHX3_3
            SHX3_3 = 5000
            if SHX2_3 > SHX3_3 then
              SHX2_3 = true
              SHX3_3 = {}
              SHX4_3 = SHX1_3
              SHX5_3 = "2"
              SHX3_3[1] = SHX4_3
              SHX3_3[2] = SHX5_3
              SHX4_3 = {}
              SHX4_3.network_range = SHX1_3
              SHX5_3 = SHX3_1
              SHX6_3 = SHX5_3
              SHX5_3 = SHX5_3.get
              SHX7_3 = "network_talker_Proximity"
              SHX8_3 = 10.0
              SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3)
              SHX4_3.known_range = SHX5_3
              SHX4_3.type = "2"
              SHX5_3 = SHX3_1
              SHX6_3 = SHX5_3
              SHX5_3 = SHX5_3.getSetTime
              SHX7_3 = "network_talker_Proximity"
              SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
              SHX4_3.set_time = SHX5_3
              return SHX2_3, SHX3_3, SHX4_3
            end
          end
        end
      end
      SHX1_3 = false
      return SHX1_3
    end
    SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    SHX5_2 = SHX0_1
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.addDetection
    SHX7_2 = {}
    SHX7_2.time = 5000
    SHX7_2.detection = "antiSpawnIsolated"
    function SHX8_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3
      SHX0_3 = SHX28_1
      SHX1_3 = SHX12_1
      SHX1_3, SHX2_3 = SHX1_3()
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
      SHX1_3 = SHX58_1
      SHX2_3 = SHX0_3
      SHX1_3 = SHX1_3(SHX2_3)
      SHX2_3 = 0 ~= SHX0_3 and ("src_3" == SHX1_3 or "src_2" == SHX1_3)
      return SHX2_3
    end
    SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    SHX5_2 = {}
    SHX5_2.Engine = 11
    SHX5_2.Spoiler = 0
    SHX5_2.Breaks = 12
    SHX5_2.Horn = 14
    SHX5_2.Armour = 16
    SHX5_2.TireSmoke = 20
    SHX5_2.Wheels = 23
    SHX6_2 = SHX0_1
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.addDetection
    SHX8_2 = {}
    SHX8_2.time = 2000
    SHX8_2.detection = "antiVehicleModifier"
    function SHX9_2(SHX0_3)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3
      SHX1_3 = SHX12_1
      SHX1_3 = SHX1_3()
      SHX2_3 = SHX28_1
      SHX3_3 = SHX1_3
      SHX2_3 = SHX2_3(SHX3_3)
      SHX3_3 = SHX17_1
      SHX4_3 = SHX0_3[1]
      SHX5_3 = "Plate Change"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX3_3 = SHX3_1
        SHX4_3 = SHX3_3
        SHX3_3 = SHX3_3.set
        SHX5_3 = "vehicle_plate"
        SHX6_3 = {}
        SHX7_3 = SHX78_1
        SHX8_3 = SHX2_3
        SHX7_3 = SHX7_3(SHX8_3)
        SHX6_3.plate = SHX7_3
        SHX6_3.vehicle = SHX2_3
        SHX7_3 = true
        SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3)
      else
        SHX3_3 = SHX0_3[1]
        if "AutoDrive" == SHX3_3 then
          SHX3_3 = SHX3_1
          SHX4_3 = SHX3_3
          SHX3_3 = SHX3_3.set
          SHX5_3 = "drive_to_waypoint"
          SHX6_3 = true
          SHX7_3 = true
          SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3)
        else
          SHX3_3 = SHX0_3[1]
          if "Bulletproof Tire" == SHX3_3 then
            SHX3_3 = SHX3_1
            SHX4_3 = SHX3_3
            SHX3_3 = SHX3_3.set
            SHX5_3 = "tyre_can_burst"
            SHX6_3 = SHX73_1
            SHX7_3 = SHX2_3
            SHX6_3 = SHX6_3(SHX7_3)
            SHX7_3 = true
            SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3)
          else
            SHX3_3 = SHX0_3[1]
            if "Window Tint" == SHX3_3 then
              SHX3_3 = SHX3_1
              SHX4_3 = SHX3_3
              SHX3_3 = SHX3_3.set
              SHX5_3 = "vehicle_window_tint"
              SHX6_3 = SHX76_1
              SHX7_3 = SHX2_3
              SHX6_3 = SHX6_3(SHX7_3)
              SHX7_3 = true
              SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3)
            end
          end
        end
      end
      SHX3_3 = pairs
      SHX4_3 = SHX5_2
      SHX3_3, SHX4_3, SHX5_3, SHX6_3 = SHX3_3(SHX4_3)
      for SHX7_3, SHX8_3 in SHX3_3, SHX4_3, SHX5_3, SHX6_3 do
        SHX9_3 = SHX0_3[1]
        if SHX7_3 == SHX9_3 then
          SHX9_3 = SHX3_1
          SHX10_3 = SHX9_3
          SHX9_3 = SHX9_3.set
          SHX11_3 = "vehicle_mod_"
          SHX12_3 = SHX7_3
          SHX11_3 = SHX11_3 .. SHX12_3
          SHX12_3 = SHX75_1
          SHX13_3 = SHX2_3
          SHX14_3 = SHX8_3
          SHX12_3 = SHX12_3(SHX13_3, SHX14_3)
          SHX13_3 = true
          SHX9_3(SHX10_3, SHX11_3, SHX12_3, SHX13_3)
          break
        end
      end
    end
    SHX8_2.detected = SHX9_2
    function SHX9_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3
      SHX0_3 = SHX12_1
      SHX0_3 = SHX0_3()
      SHX1_3 = SHX28_1
      SHX2_3 = SHX0_3
      SHX1_3 = SHX1_3(SHX2_3)
      if 0 ~= SHX1_3 then
        SHX2_3 = SHX72_1
        SHX3_3 = SHX1_3
        SHX4_3 = -1
        SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
        if SHX2_3 == SHX0_3 then
          SHX2_3 = SHX3_1
          SHX3_3 = SHX2_3
          SHX2_3 = SHX2_3.get
          SHX4_3 = "known_vehicle"
          SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
          if SHX2_3 == SHX1_3 or 0 == SHX1_3 then
            goto SHX_LABEL_70
          end
        end
      end
      if 0 ~= SHX1_3 then
        SHX2_3 = SHX3_1
        SHX3_3 = SHX2_3
        SHX2_3 = SHX2_3.set
        SHX4_3 = "known_vehicle"
        SHX5_3 = SHX1_3
        SHX2_3(SHX3_3, SHX4_3, SHX5_3)
      end
      SHX2_3 = SHX3_1
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.set
      SHX4_3 = "vehicle_gravity"
      SHX5_3 = nil
      SHX2_3(SHX3_3, SHX4_3, SHX5_3)
      SHX2_3 = SHX3_1
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.set
      SHX4_3 = "vehicle_plate"
      SHX5_3 = nil
      SHX2_3(SHX3_3, SHX4_3, SHX5_3)
      SHX2_3 = SHX3_1
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.set
      SHX4_3 = "tyre_can_burst"
      SHX5_3 = nil
      SHX2_3(SHX3_3, SHX4_3, SHX5_3)
      SHX2_3 = SHX3_1
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.set
      SHX4_3 = "drive_to_waypoint"
      SHX5_3 = false
      SHX2_3(SHX3_3, SHX4_3, SHX5_3)
      SHX2_3 = SHX3_1
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.set
      SHX4_3 = "vehicle_window_tint"
      SHX5_3 = nil
      SHX2_3(SHX3_3, SHX4_3, SHX5_3)
      SHX2_3 = pairs
      SHX3_3 = SHX5_2
      SHX2_3, SHX3_3, SHX4_3, SHX5_3 = SHX2_3(SHX3_3)
      for SHX6_3, SHX7_3 in SHX2_3, SHX3_3, SHX4_3, SHX5_3 do
        SHX8_3 = SHX3_1
        SHX9_3 = SHX8_3
        SHX8_3 = SHX8_3.set
        SHX10_3 = "vehicle_mod_"
        SHX11_3 = SHX6_3
        SHX10_3 = SHX10_3 .. SHX11_3
        SHX11_3 = nil
        SHX8_3(SHX9_3, SHX10_3, SHX11_3)
      end
      SHX2_3 = false
      return SHX2_3
      -- [FIX IF ERROR] Move ::SHX_LABEL_70:: outside nested blocks until all 'goto SHX_LABEL_70' can see it
      ::SHX_LABEL_70::
      SHX2_3 = SHX3_1
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.set
      SHX4_3 = "known_vehicle"
      SHX5_3 = SHX1_3
      SHX2_3(SHX3_3, SHX4_3, SHX5_3)
      SHX2_3 = SHX7_1
      SHX3_3 = "reaper_antiVehicleModifier_vehicleGravityCheck"
      SHX4_3 = "false"
      SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
      if "true" == SHX2_3 then
        SHX2_3 = SHX71_1
        SHX3_3 = SHX1_3
        SHX2_3 = SHX2_3(SHX3_3)
        SHX3_3 = {}
        SHX3_3.gravity = SHX2_3
        SHX3_3.vehicle = SHX1_3
        SHX4_3 = SHX3_1
        SHX5_3 = SHX4_3
        SHX4_3 = SHX4_3.get
        SHX6_3 = "vehicle_gravity"
        SHX7_3 = SHX3_3
        SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
        SHX5_3 = SHX4_3.gravity
        if SHX2_3 > SHX5_3 then
          SHX5_3 = SHX4_3.vehicle
          if SHX5_3 == SHX1_3 then
            SHX5_3 = SHX39_1
            SHX5_3 = SHX5_3()
            SHX6_3 = SHX3_1
            SHX7_3 = SHX6_3
            SHX6_3 = SHX6_3.getSetTime
            SHX8_3 = "vehicle_gravity"
            SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
            SHX5_3 = SHX5_3 - SHX6_3
            SHX6_3 = 5000
            if SHX5_3 > SHX6_3 then
              SHX5_3 = true
              SHX6_3 = {}
              SHX7_3 = "Gravity Modifier"
              SHX6_3[1] = SHX7_3
              SHX7_3 = {}
              SHX7_3.vehicle_gravity = SHX2_3
              SHX7_3.known_vehicle_gravity_data = SHX4_3
              return SHX5_3, SHX6_3, SHX7_3
            end
          end
        end
        SHX5_3 = SHX3_1
        SHX6_3 = SHX5_3
        SHX5_3 = SHX5_3.set
        SHX7_3 = "vehicle_gravity"
        SHX8_3 = SHX3_3
        SHX9_3 = true
        SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3)
      end
      SHX2_3 = SHX78_1
      SHX3_3 = SHX1_3
      SHX2_3 = SHX2_3(SHX3_3)
      SHX3_3 = {}
      SHX3_3.plate = SHX2_3
      SHX3_3.vehicle = SHX1_3
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "vehicle_plate"
      SHX7_3 = SHX3_3
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      SHX5_3 = SHX4_3.plate
      if SHX5_3 ~= SHX2_3 then
        SHX5_3 = SHX39_1
        SHX5_3 = SHX5_3()
        SHX6_3 = SHX3_1
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.getSetTime
        SHX8_3 = "vehicle_plate"
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
        SHX5_3 = SHX5_3 - SHX6_3
        SHX6_3 = 5000
        if SHX5_3 > SHX6_3 then
          SHX5_3 = SHX79_1
          SHX6_3 = SHX1_3
          SHX5_3 = SHX5_3(SHX6_3)
          SHX6_3 = SHX80_1
          SHX7_3 = SHX1_3
          SHX8_3 = SHX5_3
          SHX6_3(SHX7_3, SHX8_3)
          SHX6_3 = true
          SHX7_3 = {}
          SHX8_3 = "Plate Change: %s -> %s"
          SHX7_3[1] = SHX8_3
          SHX8_3 = {}
          SHX8_3.plate = SHX2_3
          SHX8_3.real_plate = SHX5_3
          return SHX6_3, SHX7_3, SHX8_3
        end
      end
      SHX5_3 = SHX3_1
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.set
      SHX7_3 = "vehicle_plate"
      SHX8_3 = SHX3_3
      SHX9_3 = true
      SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3)
      SHX5_3 = SHX90_1
      if SHX5_3 then
        SHX5_3 = SHX73_1
        SHX6_3 = SHX1_3
        SHX5_3 = SHX5_3(SHX6_3)
        SHX6_3 = {}
        SHX6_3.state = SHX5_3
        SHX6_3.vehicle = SHX1_3
        SHX7_3 = SHX3_1
        SHX8_3 = SHX7_3
        SHX7_3 = SHX7_3.get
        SHX9_3 = "tyre_can_burst"
        SHX10_3 = SHX6_3
        SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
        SHX8_3 = SHX7_3.state
        if SHX8_3 ~= SHX5_3 then
          SHX8_3 = SHX39_1
          SHX8_3 = SHX8_3()
          SHX9_3 = SHX3_1
          SHX10_3 = SHX9_3
          SHX9_3 = SHX9_3.getSetTime
          SHX11_3 = "tyre_can_burst"
          SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
          SHX8_3 = SHX8_3 - SHX9_3
          SHX9_3 = 5000
          if SHX8_3 > SHX9_3 then
            SHX8_3 = true
            SHX9_3 = {}
            SHX10_3 = "Bulletproof Tire"
            SHX9_3[1] = SHX10_3
            return SHX8_3, SHX9_3
          end
        end
        SHX8_3 = SHX3_1
        SHX9_3 = SHX8_3
        SHX8_3 = SHX8_3.set
        SHX10_3 = "tyre_can_burst"
        SHX11_3 = SHX6_3
        SHX12_3 = true
        SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3)
      end
      SHX5_3 = SHX74_1
      SHX6_3 = SHX0_3
      SHX7_3 = 2477085294
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
      SHX5_3 = 1 == SHX5_3
      if SHX5_3 then
        SHX6_3 = SHX3_1
        SHX7_3 = SHX6_3
        SHX6_3 = SHX6_3.get
        SHX8_3 = "drive_to_waypoint"
        SHX9_3 = false
        SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3)
        if false == SHX6_3 then
          SHX6_3 = SHX39_1
          SHX6_3 = SHX6_3()
          SHX7_3 = SHX3_1
          SHX8_3 = SHX7_3
          SHX7_3 = SHX7_3.getSetTime
          SHX9_3 = "drive_to_waypoint"
          SHX7_3 = SHX7_3(SHX8_3, SHX9_3)
          SHX6_3 = SHX6_3 - SHX7_3
          SHX7_3 = 10000
          if SHX6_3 > SHX7_3 then
            SHX6_3 = true
            SHX7_3 = {}
            SHX8_3 = "AutoDrive"
            SHX7_3[1] = SHX8_3
            return SHX6_3, SHX7_3
          end
        end
      end
      SHX6_3 = SHX3_1
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.set
      SHX8_3 = "drive_to_waypoint"
      SHX9_3 = SHX5_3
      SHX10_3 = true
      SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX6_3 = SHX76_1
      SHX7_3 = SHX1_3
      SHX6_3 = SHX6_3(SHX7_3)
      SHX7_3 = SHX3_1
      SHX8_3 = SHX7_3
      SHX7_3 = SHX7_3.get
      SHX9_3 = "vehicle_window_tint"
      SHX10_3 = SHX6_3
      SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      if SHX6_3 ~= SHX7_3 then
        SHX7_3 = SHX39_1
        SHX7_3 = SHX7_3()
        SHX8_3 = SHX3_1
        SHX9_3 = SHX8_3
        SHX8_3 = SHX8_3.getSetTime
        SHX10_3 = "vehicle_window_tint"
        SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
        SHX7_3 = SHX7_3 - SHX8_3
        SHX8_3 = 10000
        if SHX7_3 > SHX8_3 then
          SHX7_3 = true
          SHX8_3 = {}
          SHX9_3 = "Window Tint"
          SHX8_3[1] = SHX9_3
          return SHX7_3, SHX8_3
        end
      end
      SHX7_3 = SHX3_1
      SHX8_3 = SHX7_3
      SHX7_3 = SHX7_3.set
      SHX9_3 = "vehicle_window_tint"
      SHX10_3 = SHX6_3
      SHX11_3 = true
      SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3)
      SHX7_3 = SHX81_1
      SHX8_3 = SHX1_3
      SHX7_3 = SHX7_3(SHX8_3)
      SHX8_3 = SHX3_1
      SHX9_3 = SHX8_3
      SHX8_3 = SHX8_3.get
      SHX10_3 = "known_wheel_type"
      SHX11_3 = SHX7_3
      SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3)
      if SHX8_3 ~= SHX7_3 then
        SHX9_3 = SHX3_1
        SHX10_3 = SHX9_3
        SHX9_3 = SHX9_3.set
        SHX11_3 = "vehicle_mod_23"
        SHX12_3 = SHX75_1
        SHX13_3 = SHX1_3
        SHX14_3 = 23
        SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3 = SHX12_3(SHX13_3, SHX14_3)
        SHX9_3(SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3)
      end
      SHX9_3 = SHX3_1
      SHX10_3 = SHX9_3
      SHX9_3 = SHX9_3.set
      SHX11_3 = "known_wheel_type"
      SHX12_3 = SHX7_3
      SHX9_3(SHX10_3, SHX11_3, SHX12_3)
      SHX9_3 = pairs
      SHX10_3 = SHX5_2
      SHX9_3, SHX10_3, SHX11_3, SHX12_3 = SHX9_3(SHX10_3)
      for SHX13_3, SHX14_3 in SHX9_3, SHX10_3, SHX11_3, SHX12_3 do
        SHX15_3 = SHX75_1
        SHX16_3 = SHX1_3
        SHX17_3 = SHX14_3
        SHX15_3 = SHX15_3(SHX16_3, SHX17_3)
        SHX16_3 = SHX3_1
        SHX17_3 = SHX16_3
        SHX16_3 = SHX16_3.get
        SHX18_3 = "vehicle_mod_"
        SHX19_3 = SHX13_3
        SHX18_3 = SHX18_3 .. SHX19_3
        SHX19_3 = SHX15_3
        SHX16_3 = SHX16_3(SHX17_3, SHX18_3, SHX19_3)
        if SHX15_3 ~= SHX16_3 then
          SHX17_3 = SHX39_1
          SHX17_3 = SHX17_3()
          SHX18_3 = SHX3_1
          SHX19_3 = SHX18_3
          SHX18_3 = SHX18_3.getSetTime
          SHX20_3 = "vehicle_mod_"
          SHX21_3 = SHX13_3
          SHX20_3 = SHX20_3 .. SHX21_3
          SHX18_3 = SHX18_3(SHX19_3, SHX20_3)
          SHX17_3 = SHX17_3 - SHX18_3
          SHX18_3 = 10000
          if SHX17_3 > SHX18_3 then
            SHX17_3 = true
            SHX18_3 = {}
            SHX19_3 = SHX13_3
            SHX20_3 = SHX16_3
            SHX21_3 = SHX15_3
            SHX18_3[1] = SHX19_3
            SHX18_3[2] = SHX20_3
            SHX18_3[3] = SHX21_3
            SHX19_3 = {}
            SHX20_3 = SHX13_3
            SHX21_3 = SHX16_3
            SHX22_3 = SHX15_3
            SHX19_3[1] = SHX20_3
            SHX19_3[2] = SHX21_3
            SHX19_3[3] = SHX22_3
            return SHX17_3, SHX18_3, SHX19_3
          end
        end
        SHX17_3 = SHX3_1
        SHX18_3 = SHX17_3
        SHX17_3 = SHX17_3.set
        SHX19_3 = "vehicle_mod_"
        SHX20_3 = SHX13_3
        SHX19_3 = SHX19_3 .. SHX20_3
        SHX20_3 = SHX15_3
        SHX21_3 = true
        SHX17_3(SHX18_3, SHX19_3, SHX20_3, SHX21_3)
      end
      SHX9_3 = false
      return SHX9_3
    end
    SHX6_2(SHX7_2, SHX8_2, SHX9_2)
    SHX6_2 = SHX0_1
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.addDetection
    SHX8_2 = {}
    SHX8_2.time = 2000
    SHX8_2.detection = "antiRepairVehicle"
    function SHX9_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
      SHX0_3 = SHX28_1
      SHX1_3 = SHX12_1
      SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3 = SHX1_3()
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
      if 0 == SHX0_3 then
        return
      end
      SHX1_3 = SHX3_1
      SHX2_3 = SHX1_3
      SHX1_3 = SHX1_3.set
      SHX3_3 = "vehicle_health"
      SHX4_3 = {}
      SHX4_3.vehicle = SHX0_3
      SHX5_3 = SHX70_1
      SHX6_3 = SHX0_3
      SHX5_3 = SHX5_3(SHX6_3)
      SHX4_3.health = SHX5_3
      SHX1_3(SHX2_3, SHX3_3, SHX4_3)
    end
    SHX8_2.detected = SHX9_2
    function SHX9_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3
      SHX0_3 = SHX39_1
      SHX0_3 = SHX0_3()
      SHX1_3 = SHX12_1
      SHX1_3 = SHX1_3()
      SHX2_3 = SHX28_1
      SHX3_3 = SHX1_3
      SHX2_3 = SHX2_3(SHX3_3)
      if 0 ~= SHX2_3 then
        SHX3_3 = SHX72_1
        SHX4_3 = SHX2_3
        SHX5_3 = -1
        SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
        if SHX3_3 == SHX1_3 then
          goto SHX_LABEL_23
        end
      end
      SHX3_3 = SHX3_1
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.set
      SHX5_3 = "vehicle_health"
      SHX6_3 = nil
      SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      SHX3_3 = false
      return SHX3_3
      -- [FIX IF ERROR] Move ::SHX_LABEL_23:: outside nested blocks until all 'goto SHX_LABEL_23' can see it
      ::SHX_LABEL_23::
      SHX3_3 = SHX70_1
      SHX4_3 = SHX2_3
      SHX3_3 = SHX3_3(SHX4_3)
      SHX4_3 = {}
      SHX4_3.health = SHX3_3
      SHX4_3.vehicle = SHX2_3
      SHX5_3 = SHX3_1
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.get
      SHX7_3 = "vehicle_health"
      SHX8_3 = SHX4_3
      SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3)
      SHX6_3 = SHX5_3.health
      if SHX3_3 > SHX6_3 then
        SHX6_3 = SHX5_3.vehicle
        if SHX6_3 == SHX2_3 then
          SHX6_3 = SHX3_1
          SHX7_3 = SHX6_3
          SHX6_3 = SHX6_3.get
          SHX8_3 = "LastVehicleFIx"
          SHX9_3 = 0
          SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3)
          SHX6_3 = SHX0_3 - SHX6_3
          SHX7_3 = 10000
          if SHX6_3 > SHX7_3 then
            SHX6_3 = true
            SHX7_3 = {}
            SHX8_3 = {}
            SHX8_3.vehicle_health = SHX3_3
            SHX9_3 = SHX3_1
            SHX10_3 = SHX9_3
            SHX9_3 = SHX9_3.get
            SHX11_3 = "vehicle_health"
            SHX12_3 = SHX4_3
            SHX9_3 = SHX9_3(SHX10_3, SHX11_3, SHX12_3)
            SHX9_3 = SHX9_3.health
            SHX8_3.known_vehicle_health = SHX9_3
            SHX9_3 = SHX85_1
            SHX10_3 = SHX2_3
            SHX9_3 = SHX9_3(SHX10_3)
            SHX8_3.net_veh = SHX9_3
            return SHX6_3, SHX7_3, SHX8_3
          end
        end
      end
      SHX6_3 = SHX3_1
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.set
      SHX8_3 = "vehicle_health"
      SHX9_3 = SHX4_3
      SHX6_3(SHX7_3, SHX8_3, SHX9_3)
      SHX6_3 = false
      return SHX6_3
    end
    SHX6_2(SHX7_2, SHX8_2, SHX9_2)
    SHX6_2 = SHX0_1
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.addDetection
    SHX8_2 = {}
    SHX8_2.time = 10000
    SHX8_2.detection = "antiSoloSession"
    function SHX9_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3
      SHX0_3 = SHX86_1
      return SHX0_3()
    end
    SHX6_2(SHX7_2, SHX8_2, SHX9_2)
    SHX6_2 = {}
    SHX7_2 = -1044093321
    SHX8_2 = {}
    SHX8_2.min = -0.29
    SHX8_2.max = 0.98
    SHX6_2[SHX7_2] = SHX8_2
    SHX7_2 = SHX0_1
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.addDetection
    SHX9_2 = {}
    SHX9_2.time = 10000
    SHX9_2.detection = "antiHitboxModifier"
    function SHX10_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3
      SHX0_3 = SHX53_1
      SHX1_3 = SHX12_1
      SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3 = SHX1_3()
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3)
      SHX1_3 = SHX6_2
      SHX1_3 = SHX1_3[SHX0_3]
      if nil == SHX1_3 then
        SHX2_3 = false
        return SHX2_3
      end
      SHX2_3 = SHX67_1
      SHX3_3 = SHX0_3
      SHX2_3, SHX3_3 = SHX2_3(SHX3_3)
      SHX4_3 = SHX2_3.y
      SHX5_3 = SHX1_3.min
      SHX4_3 = SHX4_3 < SHX5_3
      return SHX4_3
    end
    SHX7_2(SHX8_2, SHX9_2, SHX10_2)
    SHX7_2 = SHX0_1
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.addDetection
    SHX9_2 = {}
    SHX9_2.time = 6000
    SHX9_2.detection = "unauthorizedAnimationLoaded"
    function SHX10_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
      SHX0_3 = {}
      SHX1_3 = {}
      SHX1_3.animDic = "anim@mp_rollarcoaster"
      SHX1_3.animName = "hands_up_idle_a_player_one"
      SHX2_3 = {}
      SHX2_3.animDic = "anim@heists@box_carry@"
      SHX2_3.animName = "idle"
      SHX3_3 = {}
      SHX3_3.animDic = "missminuteman_1ig_2"
      SHX3_3.animName = "handsup_enter"
      SHX0_3[1] = SHX1_3
      SHX0_3[2] = SHX2_3
      SHX0_3[3] = SHX3_3
      SHX1_3 = pairs
      SHX2_3 = SHX0_3
      SHX1_3, SHX2_3, SHX3_3, SHX4_3 = SHX1_3(SHX2_3)
      for SHX5_3, SHX6_3 in SHX1_3, SHX2_3, SHX3_3, SHX4_3 do
        SHX7_3 = SHX82_1
        SHX8_3 = SHX6_3.animDic
        SHX7_3 = SHX7_3(SHX8_3)
        if SHX7_3 then
          SHX7_3 = SHX83_1
          SHX8_3 = SHX12_1
          SHX8_3 = SHX8_3()
          SHX9_3 = SHX6_3.animDic
          SHX10_3 = SHX6_3.animName
          SHX11_3 = 3
          SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3)
          if SHX7_3 then
            SHX7_3 = SHX3_1
            SHX8_3 = SHX7_3
            SHX7_3 = SHX7_3.get
            SHX9_3 = SHX6_3.animDic
            SHX10_3 = "_AnimDict"
            SHX9_3 = SHX9_3 .. SHX10_3
            SHX10_3 = false
            SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
            if false == SHX7_3 then
              SHX7_3 = true
              SHX8_3 = {}
              SHX9_3 = {}
              SHX9_3.animation_set = SHX6_3
              return SHX7_3, SHX8_3, SHX9_3
            end
          end
        end
      end
    end
    SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  end
  SHX1_2 = SHX0_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.addDetection
  SHX3_2 = {}
  SHX3_2.time = 2000
  SHX3_2.detection = "antiFreeCam"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX0_3 = SHX18_1
    SHX0_3 = SHX0_3()
    SHX1_3 = -1 ~= SHX0_3 and 2 ~= SHX0_3
    SHX2_3 = {}
    SHX3_3 = {}
    SHX4_3 = SHX84_1
    SHX4_3 = SHX4_3()
    SHX3_3.player_switch = SHX4_3
    SHX3_3.cam = SHX0_3
    SHX4_3 = SHX3_1
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.getSetTime
    SHX6_3 = "CustomCam"
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX3_3.last_change = SHX4_3
    return SHX1_3, SHX2_3, SHX3_3
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = SHX0_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.addDetection
  SHX3_2 = {}
  SHX3_2.time = 2000
  SHX3_2.detection = "antiFreeCam2"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX0_3 = SHX39_1
    SHX0_3 = SHX0_3()
    SHX1_3 = SHX12_1
    SHX1_3 = SHX1_3()
    SHX2_3 = SHX77_1
    SHX3_3 = SHX1_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX63_1
    SHX3_3 = SHX3_3()
    SHX4_3 = SHX13_1
    SHX5_3 = SHX2_3
    SHX6_3 = SHX3_3
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX5_3 = SHX18_1
    SHX5_3 = SHX5_3()
    if -1 == SHX5_3 and SHX4_3 > 25 then
      SHX6_3 = {}
      SHX7_3 = SHX92_1
      SHX8_3 = SHX64_1
      SHX8_3, SHX9_3, SHX10_3 = SHX8_3()
      SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      SHX6_3.is_follow_ped_cam_active = SHX7_3
      SHX6_3.rendering_cam = SHX5_3
      SHX7_3 = SHX3_1
      SHX8_3 = SHX7_3
      SHX7_3 = SHX7_3.get
      SHX9_3 = "NetworkIsInSpectatorMode"
      SHX10_3 = false
      SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      SHX6_3.network_is_in_spectator_mode = SHX7_3
      SHX7_3 = SHX62_1
      SHX7_3 = SHX7_3()
      SHX6_3.follow_ped_cam_view_mode = SHX7_3
      SHX7_3 = SHX92_1
      SHX8_3 = SHX61_1
      SHX8_3, SHX9_3, SHX10_3 = SHX8_3()
      SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      SHX6_3.is_cinematic_cam_rendering = SHX7_3
      SHX6_3.render_distance = SHX4_3
      SHX7_3 = SHX3_1
      SHX8_3 = SHX7_3
      SHX7_3 = SHX7_3.get
      SHX9_3 = "LastFailedMovementChecks"
      SHX10_3 = 0
      SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      SHX7_3 = SHX0_3 - SHX7_3
      SHX8_3 = 5000
      SHX7_3 = SHX7_3 > SHX8_3
      SHX6_3.HasNotFailedMovementChecks = SHX7_3
      SHX7_3 = SHX65_1
      SHX8_3 = SHX1_3
      SHX7_3 = SHX7_3(SHX8_3)
      SHX6_3.player_speed = SHX7_3
      SHX7_3 = SHX92_1
      SHX8_3 = SHX45_1
      SHX9_3 = SHX1_3
      SHX8_3, SHX9_3, SHX10_3 = SHX8_3(SHX9_3)
      SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      SHX6_3.player_falling = SHX7_3
      SHX7_3 = SHX3_1
      SHX8_3 = SHX7_3
      SHX7_3 = SHX7_3.get
      SHX9_3 = "player_loaded"
      SHX10_3 = false
      SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      SHX6_3.player_loaded = SHX7_3
      SHX6_3.cam_coords = SHX3_3
      SHX6_3.ped_coords = SHX2_3
      SHX7_3 = SHX84_1
      SHX7_3 = SHX7_3()
      SHX6_3.player_switch = SHX7_3
      SHX7_3 = SHX6_3.is_follow_ped_cam_active
      if SHX7_3 then
        SHX7_3 = SHX6_3.network_is_in_spectator_mode
        if false == SHX7_3 then
          SHX7_3 = SHX6_3.follow_ped_cam_view_mode
          if 3 ~= SHX7_3 then
            SHX7_3 = SHX6_3.is_cinematic_cam_rendering
            if false == SHX7_3 then
              SHX7_3 = SHX6_3.HasNotFailedMovementChecks
              if SHX7_3 then
                SHX7_3 = SHX6_3.HasNotFailedMovementChecks_2
                if SHX7_3 then
                  SHX7_3 = SHX6_3.player_speed
                  if SHX7_3 < 15 then
                    SHX7_3 = SHX6_3.player_falling
                    if false == SHX7_3 then
                      SHX7_3 = SHX6_3.player_loaded
                      if SHX7_3 then
                        SHX7_3 = true
                        SHX8_3 = {}
                        SHX9_3 = SHX6_3
                        return SHX7_3, SHX8_3, SHX9_3
                      end
                    end
                  end
                end
              end
            end
          end
        end
      end
    end
    SHX6_3 = false
    return SHX6_3
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = SHX4_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.on
  SHX3_2 = "devtools"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    if 0 == SHX0_3 then
      SHX2_3 = SHX3_1
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.set
      SHX4_3 = "dev_tools_heartbeat"
      SHX5_3 = SHX39_1
      SHX5_3, SHX6_3 = SHX5_3()
      SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3)
    elseif 1 == SHX0_3 then
      SHX2_3 = SHX0_1
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.detection
      SHX4_3 = "antiNuiTools"
      SHX5_3 = {}
      SHX6_3 = {}
      SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3)
    end
    SHX2_3 = SHX1_3
    SHX3_3 = true
    SHX2_3(SHX3_3)
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = SHX0_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.addDetection
  SHX3_2 = {}
  SHX3_2.time = 2000
  SHX3_2.detection = "antiInvisible"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX0_3 = SHX12_1
    SHX0_3 = SHX0_3()
    SHX1_3 = SHX39_1
    SHX1_3 = SHX1_3()
    SHX2_3 = SHX60_1
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX18_1
    SHX3_3 = SHX3_3()
    SHX4_3 = SHX23_1
    SHX5_3 = SHX0_3
    SHX4_3 = SHX4_3(SHX5_3)
    if 0 ~= SHX4_3 then
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.set
      SHX6_3 = "entityAttachedTo"
      SHX7_3 = SHX1_3
      SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    end
    SHX4_3 = SHX3_1
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.getRecentlyChanged
    SHX6_3 = "entityAttachedTo"
    SHX7_3 = 10000
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    if SHX4_3 then
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.set
      SHX6_3 = "EntityVisible"
      SHX7_3 = SHX92_1
      SHX8_3 = SHX10_1
      SHX9_3 = SHX0_3
      SHX8_3, SHX9_3, SHX10_3 = SHX8_3(SHX9_3)
      SHX7_3, SHX8_3, SHX9_3, SHX10_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX4_3 = false
      return SHX4_3
    end
    SHX4_3 = SHX3_1
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.getRecentlyChanged
    SHX6_3 = "alphaSetTo0"
    SHX7_3 = 10000
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    if not SHX4_3 then
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.getRecentlyChanged
      SHX6_3 = "playerModelLastChange"
      SHX7_3 = 30000
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      if not SHX4_3 then
        goto SHX_LABEL_62
      end
    end
    SHX4_3 = SHX3_1
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.set
    SHX6_3 = "alphaSetTo0"
    SHX7_3 = SHX2_3 < 75
    SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    SHX4_3 = false
    return SHX4_3
    -- [FIX IF ERROR] Move ::SHX_LABEL_62:: outside nested blocks until all 'goto SHX_LABEL_62' can see it
    ::SHX_LABEL_62::
    if -1 == SHX3_3 and 0 == SHX2_3 then
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "alphaSetTo0"
      SHX7_3 = false
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      if false == SHX4_3 then
        SHX4_3 = SHX3_1
        SHX5_3 = SHX4_3
        SHX4_3 = SHX4_3.getSetTime
        SHX6_3 = "alphaSetTo0"
        SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
        SHX4_3 = SHX1_3 - SHX4_3
        SHX5_3 = 5000
        if SHX4_3 > SHX5_3 then
          SHX4_3 = true
          SHX5_3 = {}
          SHX6_3 = "EntityAlpha"
          SHX5_3[1] = SHX6_3
          SHX6_3 = {}
          SHX6_3.type = "alpha"
          SHX6_3.alpha = SHX2_3
          SHX7_3 = SHX39_1
          SHX7_3 = SHX7_3()
          SHX8_3 = SHX3_1
          SHX9_3 = SHX8_3
          SHX8_3 = SHX8_3.getSetTime
          SHX10_3 = "alphaSetTo0"
          SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
          SHX7_3 = SHX7_3 - SHX8_3
          SHX6_3.lastChange = SHX7_3
          return SHX4_3, SHX5_3, SHX6_3
        end
      end
    end
    SHX4_3 = SHX3_1
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.getRecentlyChanged
    SHX6_3 = "EntityVisible"
    SHX7_3 = 6000
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    if SHX4_3 then
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.set
      SHX6_3 = "EntityVisible"
      SHX7_3 = SHX92_1
      SHX8_3 = SHX10_1
      SHX9_3 = SHX0_3
      SHX8_3, SHX9_3, SHX10_3 = SHX8_3(SHX9_3)
      SHX7_3, SHX8_3, SHX9_3, SHX10_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
      SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX4_3 = false
      return SHX4_3
    end
    SHX4_3 = SHX92_1
    SHX5_3 = SHX10_1
    SHX6_3 = SHX0_3
    SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3 = SHX5_3(SHX6_3)
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
    if false == SHX4_3 then
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.get
      SHX6_3 = "EntityVisible"
      SHX7_3 = true
      SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
      if true == SHX4_3 then
        SHX4_3 = SHX3_1
        SHX5_3 = SHX4_3
        SHX4_3 = SHX4_3.get
        SHX6_3 = "TempDisableAntiInvis"
        SHX7_3 = 0
        SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
        SHX4_3 = SHX1_3 - SHX4_3
        SHX5_3 = 5000
        if SHX4_3 > SHX5_3 then
          SHX4_3 = true
          SHX5_3 = {}
          SHX6_3 = "EntityVisible"
          SHX5_3[1] = SHX6_3
          SHX6_3 = {}
          SHX6_3.type = "Invisible"
          SHX7_3 = SHX39_1
          SHX7_3 = SHX7_3()
          SHX8_3 = SHX3_1
          SHX9_3 = SHX8_3
          SHX8_3 = SHX8_3.getSetTime
          SHX10_3 = "EntityVisible"
          SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
          SHX7_3 = SHX7_3 - SHX8_3
          SHX6_3.lastChange = SHX7_3
          return SHX4_3, SHX5_3, SHX6_3
        end
      end
    end
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = SHX0_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.addDetection
  SHX3_2 = {}
  SHX3_2.time = 3000
  SHX3_2.detection = "antiGodMode"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = SHX1_3[1]
    if "EntityProofs" == SHX2_3 then
    else
      SHX2_3 = SHX1_3[1]
      if "EntityInvincible" == SHX2_3 then
        SHX2_3 = SHX26_1
        SHX3_3 = SHX12_1
        SHX3_3 = SHX3_3()
        SHX4_3 = false
        SHX2_3(SHX3_3, SHX4_3)
      end
    end
  end
  SHX3_2.detected = SHX4_2
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3
    SHX0_3 = SHX12_1
    SHX0_3 = SHX0_3()
    SHX1_3 = SHX51_1
    SHX2_3 = SHX0_3
    SHX1_3 = SHX1_3(SHX2_3)
    SHX2_3 = SHX24_1
    SHX3_3 = SHX12_1
    SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = SHX3_3()
    SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
    SHX10_3 = SHX3_1
    SHX11_3 = SHX10_3
    SHX10_3 = SHX10_3.getRecentlyChanged
    SHX12_3 = "isInvincible"
    SHX13_3 = 6000
    SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
    if not SHX10_3 then
      SHX10_3 = SHX3_1
      SHX11_3 = SHX10_3
      SHX10_3 = SHX10_3.getRecentlyChanged
      SHX12_3 = "proofs:bulletProof"
      SHX13_3 = 6000
      SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
      if not SHX10_3 then
        goto SHX_LABEL_45
      end
    end
    SHX10_3 = SHX3_1
    SHX11_3 = SHX10_3
    SHX10_3 = SHX10_3.set
    SHX12_3 = "isInvincible"
    SHX13_3 = SHX92_1
    SHX14_3 = SHX11_1
    SHX15_3 = SHX9_1
    SHX15_3, SHX16_3 = SHX15_3()
    SHX14_3, SHX15_3, SHX16_3 = SHX14_3(SHX15_3, SHX16_3)
    SHX13_3 = SHX13_3(SHX14_3, SHX15_3, SHX16_3)
    SHX14_3 = true
    SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3)
    if SHX2_3 then
      SHX10_3 = SHX3_1
      SHX11_3 = SHX10_3
      SHX10_3 = SHX10_3.set
      SHX12_3 = "proofs:bulletProof"
      SHX13_3 = SHX3_3
      SHX14_3 = true
      SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3)
    end
    SHX10_3 = false
    return SHX10_3
    -- [FIX IF ERROR] Move ::SHX_LABEL_45:: outside nested blocks until all 'goto SHX_LABEL_45' can see it
    ::SHX_LABEL_45::
    if SHX2_3 then
      SHX10_3 = SHX92_1
      SHX11_3 = SHX3_3
      SHX10_3 = SHX10_3(SHX11_3)
      if SHX10_3 and not SHX1_3 then
        SHX10_3 = SHX3_1
        SHX11_3 = SHX10_3
        SHX10_3 = SHX10_3.get
        SHX12_3 = "proofs:bulletProof"
        SHX13_3 = false
        SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
        if false == SHX10_3 then
          SHX10_3 = SHX39_1
          SHX10_3 = SHX10_3()
          SHX11_3 = SHX3_1
          SHX12_3 = SHX11_3
          SHX11_3 = SHX11_3.getSetTime
          SHX13_3 = "proofs:bulletProof"
          SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
          SHX10_3 = SHX10_3 - SHX11_3
          SHX11_3 = 5000
          if SHX10_3 > SHX11_3 then
            SHX10_3 = true
            SHX11_3 = {}
            SHX12_3 = "EntityProofs"
            SHX11_3[1] = SHX12_3
            SHX12_3 = {}
            SHX12_3.type = "EntityProofs"
            SHX13_3 = SHX3_1
            SHX14_3 = SHX13_3
            SHX13_3 = SHX13_3.get
            SHX15_3 = "proofs:bulletProof"
            SHX16_3 = false
            SHX13_3 = SHX13_3(SHX14_3, SHX15_3, SHX16_3)
            SHX12_3.known_state = SHX13_3
            SHX12_3.state = SHX3_3
            return SHX10_3, SHX11_3, SHX12_3
          end
        end
      end
    end
    SHX10_3 = SHX11_1
    SHX11_3 = SHX9_1
    SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = SHX11_3()
    SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
    if SHX10_3 then
      SHX10_3 = SHX3_1
      SHX11_3 = SHX10_3
      SHX10_3 = SHX10_3.get
      SHX12_3 = "isInvincible"
      SHX13_3 = false
      SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
      if false == SHX10_3 then
        SHX10_3 = SHX39_1
        SHX10_3 = SHX10_3()
        SHX11_3 = SHX3_1
        SHX12_3 = SHX11_3
        SHX11_3 = SHX11_3.getSetTime
        SHX13_3 = "isInvincible"
        SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
        SHX10_3 = SHX10_3 - SHX11_3
        SHX11_3 = 5000
        if SHX10_3 > SHX11_3 then
          SHX10_3 = true
          SHX11_3 = {}
          SHX12_3 = "EntityInvincible"
          SHX11_3[1] = SHX12_3
          SHX12_3 = {}
          SHX12_3.type = "EntityInvincible"
          SHX13_3 = SHX3_1
          SHX14_3 = SHX13_3
          SHX13_3 = SHX13_3.get
          SHX15_3 = "isInvincible"
          SHX16_3 = false
          SHX13_3 = SHX13_3(SHX14_3, SHX15_3, SHX16_3)
          SHX12_3.known_state = SHX13_3
          SHX13_3 = SHX11_1
          SHX14_3 = SHX9_1
          SHX14_3, SHX15_3, SHX16_3 = SHX14_3()
          SHX13_3 = SHX13_3(SHX14_3, SHX15_3, SHX16_3)
          SHX12_3.state = SHX13_3
          return SHX10_3, SHX11_3, SHX12_3
        end
      end
    end
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = SHX0_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.addDetection
  SHX3_2 = {}
  SHX3_2.time = 2000
  SHX3_2.detection = "antiNoClip"
  function SHX4_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3, SHX26_3, SHX27_3, SHX28_3
    SHX1_3 = SHX3_1
    SHX2_3 = SHX1_3
    SHX1_3 = SHX1_3.getCoords
    SHX1_3 = SHX1_3(SHX2_3)
    SHX2_3 = SHX14_1
    SHX3_3 = SHX1_3.x
    SHX4_3 = SHX1_3.y
    SHX5_3 = SHX1_3.z
    SHX6_3 = true
    SHX2_3, SHX3_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3)
    SHX4_3 = SHX15_1
    SHX5_3 = SHX1_3.z
    SHX5_3 = SHX5_3 - SHX3_3
    SHX4_3 = SHX4_3(SHX5_3)
    SHX5_3 = SHX55_1
    SHX6_3 = SHX0_1
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.hash
    SHX8_3 = "antiNoClipMaxDistance"
    SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3, SHX26_3, SHX27_3, SHX28_3 = SHX6_3(SHX7_3, SHX8_3)
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3, SHX26_3, SHX27_3, SHX28_3)
    SHX5_3 = SHX0_3[SHX5_3]
    if SHX4_3 > SHX5_3 then
      SHX6_3 = SHX3_1
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.getPed
      SHX6_3 = SHX6_3(SHX7_3)
      SHX7_3 = SHX39_1
      SHX7_3 = SHX7_3()
      SHX8_3 = SHX3_1
      SHX9_3 = SHX8_3
      SHX8_3 = SHX8_3.inVehicle
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = SHX40_1
      SHX10_3 = SHX28_1
      SHX11_3 = SHX6_3
      SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3, SHX26_3, SHX27_3, SHX28_3 = SHX10_3(SHX11_3)
      SHX9_3 = SHX9_3(SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3, SHX26_3, SHX27_3, SHX28_3)
      SHX10_3 = {}
      SHX11_3 = SHX50_1
      SHX12_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3)
      SHX10_3.parachute_state = SHX11_3
      SHX11_3 = SHX46_1
      SHX12_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3)
      SHX10_3.getting_into_vehicle = SHX11_3
      SHX11_3 = SHX45_1
      SHX12_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3)
      SHX10_3.is_falling = SHX11_3
      SHX11_3 = SHX34_1
      SHX12_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3)
      SHX10_3.is_climbing = SHX11_3
      SHX11_3 = SHX30_1
      SHX12_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3)
      SHX10_3.is_diving = SHX11_3
      SHX11_3 = SHX44_1
      SHX12_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3)
      SHX10_3.waiting_collision = SHX11_3
      SHX11_3 = SHX22_1
      SHX12_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3)
      SHX10_3.is_frozen = SHX11_3
      SHX11_3 = SHX31_1
      SHX12_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3)
      SHX10_3.is_ragdoll = SHX11_3
      SHX11_3 = SHX32_1
      SHX12_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3)
      SHX10_3.on_vehicle = SHX11_3
      SHX11_3 = SHX33_1
      SHX12_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3)
      SHX10_3.attached = SHX11_3
      SHX11_3 = SHX35_1
      SHX12_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3)
      SHX10_3.col_loaded = SHX11_3
      SHX11_3 = SHX36_1
      SHX12_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3)
      SHX10_3.in_water = SHX11_3
      SHX10_3.is_swiming = false
      SHX10_3.is_swiming_under = false
      SHX10_3.inVehicle = SHX8_3
      SHX10_3.velRoll = SHX9_3
      SHX10_3.time = SHX7_3
      SHX11_3 = SHX23_1
      SHX12_3 = SHX6_3
      SHX11_3 = SHX11_3(SHX12_3)
      if 0 ~= SHX11_3 then
        SHX11_3 = SHX3_1
        SHX12_3 = SHX11_3
        SHX11_3 = SHX11_3.set
        SHX13_3 = "entityAttachedTo"
        SHX14_3 = SHX7_3
        SHX11_3(SHX12_3, SHX13_3, SHX14_3)
      end
      SHX11_3 = SHX3_1
      SHX12_3 = SHX11_3
      SHX11_3 = SHX11_3.getRecentlyChanged
      SHX13_3 = "entityAttachedTo"
      SHX14_3 = 10000
      SHX11_3 = SHX11_3(SHX12_3, SHX13_3, SHX14_3)
      if SHX11_3 then
        SHX11_3 = SHX3_1
        SHX12_3 = SHX11_3
        SHX11_3 = SHX11_3.set
        SHX13_3 = "LastFailedMovementChecks"
        SHX14_3 = SHX7_3
        SHX11_3(SHX12_3, SHX13_3, SHX14_3)
        SHX11_3 = false
        return SHX11_3
      end
      SHX11_3 = SHX10_3.on_vehicle
      if not SHX11_3 then
        SHX11_3 = SHX10_3.is_ragdoll
        if not SHX11_3 then
          SHX11_3 = SHX10_3.is_falling
          if not SHX11_3 then
            goto SHX_LABEL_130
          end
        end
      end
      SHX11_3 = SHX3_1
      SHX12_3 = SHX11_3
      SHX11_3 = SHX11_3.set
      SHX13_3 = "LastFailedMovementChecks"
      SHX14_3 = SHX7_3
      SHX11_3(SHX12_3, SHX13_3, SHX14_3)
      -- [FIX IF ERROR] Move ::SHX_LABEL_130:: outside nested blocks until all 'goto SHX_LABEL_130' can see it
      ::SHX_LABEL_130::
      SHX11_3 = SHX10_3.parachute_state
      if -1 == SHX11_3 then
        SHX11_3 = SHX10_3.getting_into_vehicle
        if not SHX11_3 then
          SHX11_3 = SHX10_3.is_falling
          if not SHX11_3 then
            SHX11_3 = SHX10_3.is_climbing
            if not SHX11_3 then
              SHX11_3 = SHX10_3.is_diving
              if not SHX11_3 then
                SHX11_3 = SHX10_3.waiting_collision
                if not SHX11_3 then
                  SHX11_3 = SHX10_3.is_frozen
                  if not SHX11_3 then
                    SHX11_3 = SHX10_3.is_ragdoll
                    if not SHX11_3 then
                      SHX11_3 = SHX10_3.on_vehicle
                      if not SHX11_3 then
                        SHX11_3 = SHX10_3.attached
                        if not SHX11_3 or SHX8_3 then
                          SHX11_3 = SHX10_3.col_loaded
                          if false ~= SHX11_3 then
                            SHX11_3 = SHX10_3.in_water
                            if not SHX11_3 then
                              SHX11_3 = SHX10_3.is_swiming
                              if not SHX11_3 then
                                SHX11_3 = SHX10_3.is_swiming_under
                                if not SHX11_3 and (not SHX8_3 or 0.0 == SHX9_3) then
                                  goto SHX_LABEL_180
                                end
                              end
                            end
                          end
                        end
                      end
                    end
                  end
                end
              end
            end
          end
        end
      end
      SHX11_3 = false
      return SHX11_3
      -- [FIX IF ERROR] Move ::SHX_LABEL_180:: outside nested blocks until all 'goto SHX_LABEL_180' can see it
      ::SHX_LABEL_180::
      SHX11_3 = SHX3_1
      SHX12_3 = SHX11_3
      SHX11_3 = SHX11_3.getRecentlyChanged
      SHX13_3 = "LastFailedMovementChecks"
      SHX14_3 = 10000
      SHX11_3 = SHX11_3(SHX12_3, SHX13_3, SHX14_3)
      if SHX11_3 then
        SHX11_3 = false
        return SHX11_3
      end
      SHX11_3 = SHX14_1
      SHX12_3 = SHX1_3.x
      SHX12_3 = SHX12_3 - 2
      SHX13_3 = SHX1_3.y
      SHX14_3 = SHX1_3.z
      SHX15_3 = true
      SHX11_3, SHX12_3 = SHX11_3(SHX12_3, SHX13_3, SHX14_3, SHX15_3)
      SHX13_3 = SHX14_1
      SHX14_3 = SHX1_3.x
      SHX14_3 = SHX14_3 + 2
      SHX15_3 = SHX1_3.y
      SHX16_3 = SHX1_3.z
      SHX17_3 = true
      SHX13_3, SHX14_3 = SHX13_3(SHX14_3, SHX15_3, SHX16_3, SHX17_3)
      SHX15_3 = SHX14_1
      SHX16_3 = SHX1_3.x
      SHX17_3 = SHX1_3.y
      SHX17_3 = SHX17_3 + 2
      SHX18_3 = SHX1_3.z
      SHX19_3 = true
      SHX15_3, SHX16_3 = SHX15_3(SHX16_3, SHX17_3, SHX18_3, SHX19_3)
      SHX17_3 = SHX14_1
      SHX18_3 = SHX1_3.x
      SHX19_3 = SHX1_3.y
      SHX19_3 = SHX19_3 - 2
      SHX20_3 = SHX1_3.z
      SHX21_3 = true
      SHX17_3, SHX18_3 = SHX17_3(SHX18_3, SHX19_3, SHX20_3, SHX21_3)
      if SHX11_3 then
        SHX19_3 = SHX15_1
        SHX20_3 = SHX1_3.z
        SHX20_3 = SHX20_3 - SHX12_3
        SHX19_3 = SHX19_3(SHX20_3)
        SHX12_3 = SHX19_3
      end
      if SHX13_3 then
        SHX19_3 = SHX15_1
        SHX20_3 = SHX1_3.z
        SHX20_3 = SHX20_3 - SHX14_3
        SHX19_3 = SHX19_3(SHX20_3)
        SHX14_3 = SHX19_3
      end
      if SHX15_3 then
        SHX19_3 = SHX15_1
        SHX20_3 = SHX1_3.z
        SHX20_3 = SHX20_3 - SHX16_3
        SHX19_3 = SHX19_3(SHX20_3)
        SHX16_3 = SHX19_3
      end
      if SHX17_3 then
        SHX19_3 = SHX15_1
        SHX20_3 = SHX1_3.z
        SHX20_3 = SHX20_3 - SHX18_3
        SHX19_3 = SHX19_3(SHX20_3)
        SHX18_3 = SHX19_3
      end
      if SHX5_3 < SHX12_3 and SHX5_3 < SHX14_3 and SHX5_3 < SHX16_3 and SHX5_3 < SHX18_3 then
        SHX19_3 = SHX39_1
        SHX19_3 = SHX19_3()
        SHX20_3 = SHX3_1
        SHX21_3 = SHX20_3
        SHX20_3 = SHX20_3.getSetTime
        SHX22_3 = "lastFailedTeleportChecks"
        SHX20_3 = SHX20_3(SHX21_3, SHX22_3)
        SHX19_3 = SHX19_3 - SHX20_3
        SHX20_3 = 5000
        if SHX19_3 < SHX20_3 then
          SHX19_3 = true
          SHX20_3 = {}
          SHX21_3 = SHX4_3
          SHX20_3[1] = SHX21_3
          SHX21_3 = {}
          SHX22_3 = SHX4_3
          SHX23_3 = SHX7_3
          SHX24_3 = SHX1_3
          SHX25_3 = SHX9_3
          SHX26_3 = SHX50_1
          SHX27_3 = SHX6_3
          SHX26_3 = SHX26_3(SHX27_3)
          SHX21_3.par = SHX26_3
          SHX26_3 = SHX69_1
          SHX27_3 = SHX6_3
          SHX28_3 = SHX6_1.CTaskCarReactToVehicleCollision
          SHX26_3 = SHX26_3(SHX27_3, SHX28_3)
          SHX21_3.task_react_to_vehicle = SHX26_3
          SHX21_3[1] = SHX22_3
          SHX21_3[2] = SHX23_3
          SHX21_3[3] = SHX24_3
          SHX21_3[4] = SHX25_3
          return SHX19_3, SHX20_3, SHX21_3
        end
      end
    end
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = SHX0_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.addDetection
  SHX3_2 = {}
  SHX3_2.time = 5000
  SHX3_2.detection = "antiPedSpeedModifier"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
    SHX0_3 = SHX12_1
    SHX0_3 = SHX0_3()
    SHX1_3 = SHX88_1
    SHX2_3 = SHX0_3
    SHX1_3 = SHX1_3(SHX2_3)
    if not SHX1_3 then
      SHX1_3 = SHX89_1
      SHX2_3 = SHX0_3
      SHX1_3 = SHX1_3(SHX2_3)
      if not SHX1_3 then
        goto SHX_LABEL_36
      end
    end
    SHX1_3 = SHX27_1
    SHX2_3 = SHX0_3
    SHX1_3 = SHX1_3(SHX2_3)
    SHX1_3 = #SHX1_3
    SHX2_3 = 9.06
    if SHX1_3 > SHX2_3 then
      SHX1_3 = SHX3_1
      SHX2_3 = SHX1_3
      SHX1_3 = SHX1_3.getRecentlyChanged
      SHX3_3 = "LastFailedMovementChecks"
      SHX4_3 = 6000
      SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3)
      if false == SHX1_3 then
        SHX1_3 = SHX3_1
        SHX2_3 = SHX1_3
        SHX1_3 = SHX1_3.get
        SHX3_3 = "PedMovementRateModified"
        SHX4_3 = false
        SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3)
        if false == SHX1_3 then
          SHX1_3 = true
          return SHX1_3
        end
      end
    end
    -- [FIX IF ERROR] Move ::SHX_LABEL_36:: outside nested blocks until all 'goto SHX_LABEL_36' can see it
    ::SHX_LABEL_36::
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = SHX0_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.addDetection
  SHX3_2 = {}
  SHX3_2.time = 2000
  SHX3_2.detection = "antiTeleport"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
    SHX0_3 = SHX3_1
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.set
    SHX2_3 = "coords"
    SHX3_3 = SHX3_1
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.getCoords
    SHX3_3, SHX4_3 = SHX3_3(SHX4_3)
    SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3)
  end
  SHX3_2.detected = SHX4_2
  function SHX4_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3
    SHX1_3 = SHX3_1
    SHX2_3 = SHX1_3
    SHX1_3 = SHX1_3.getRecentlyChanged
    SHX3_3 = "coords"
    SHX4_3 = 6000
    SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3)
    if false == SHX1_3 then
      SHX1_3 = SHX3_1
      SHX2_3 = SHX1_3
      SHX1_3 = SHX1_3.set
      SHX3_3 = "coords"
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.getCoords
      SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3 = SHX4_3(SHX5_3)
      SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3)
      SHX1_3 = false
      return SHX1_3
    end
    SHX1_3 = SHX39_1
    SHX1_3 = SHX1_3()
    SHX2_3 = SHX3_1
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.getPed
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX3_1
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.getCoords
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX23_1
    SHX5_3 = SHX2_3
    SHX4_3 = SHX4_3(SHX5_3)
    if 0 ~= SHX4_3 then
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.set
      SHX6_3 = "entityAttachedTo"
      SHX7_3 = SHX1_3
      SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    end
    SHX4_3 = SHX3_1
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.getRecentlyChanged
    SHX6_3 = "entityAttachedTo"
    SHX7_3 = 10000
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    if SHX4_3 then
      SHX4_3 = SHX3_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.set
      SHX6_3 = "coords"
      SHX7_3 = SHX3_1
      SHX8_3 = SHX7_3
      SHX7_3 = SHX7_3.getCoords
      SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3 = SHX7_3(SHX8_3)
      SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3)
      SHX4_3 = false
      return SHX4_3
    end
    SHX4_3 = SHX49_1
    SHX5_3 = SHX2_3
    SHX4_3 = SHX4_3(SHX5_3)
    SHX5_3 = SHX14_1
    SHX6_3 = SHX3_3.x
    SHX7_3 = SHX3_3.y
    SHX8_3 = SHX3_3.z
    SHX5_3, SHX6_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    SHX7_3 = SHX27_1
    SHX8_3 = SHX28_1
    SHX9_3 = SHX2_3
    SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3 = SHX8_3(SHX9_3)
    SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3)
    SHX8_3 = SHX3_1
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.inVehicle
    SHX8_3 = SHX8_3(SHX9_3)
    SHX9_3 = {}
    SHX10_3 = SHX50_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.parachute_state = SHX10_3
    SHX10_3 = SHX57_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.is_dead = SHX10_3
    SHX10_3 = SHX46_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.getting_in_vehicle = SHX10_3
    SHX10_3 = SHX45_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.is_falling = SHX10_3
    SHX10_3 = SHX30_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.is_diving = SHX10_3
    SHX10_3 = SHX44_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.waiting_collision = SHX10_3
    SHX10_3 = SHX34_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.is_climbing = SHX10_3
    SHX10_3 = SHX31_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.is_ragdoll = SHX10_3
    SHX10_3 = SHX32_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.on_vehicle = SHX10_3
    SHX10_3 = SHX33_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    if SHX10_3 then
      SHX10_3 = not SHX8_3
    end
    SHX9_3.attached = SHX10_3
    SHX10_3 = SHX35_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.col_loaded = SHX10_3
    SHX10_3 = SHX36_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.in_water = SHX10_3
    SHX10_3 = SHX37_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.is_swiming = SHX10_3
    SHX10_3 = SHX38_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.is_swiming_under = SHX10_3
    SHX10_3 = SHX8_3 or SHX10_3
    if SHX8_3 then
      SHX10_3 = SHX29_1
      SHX11_3 = 0.0
      SHX12_3 = 0.0
      SHX13_3 = 0.0
      SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
      SHX10_3 = SHX7_3 ~= SHX10_3
    end
    SHX9_3.inVehicle_and_velocity = SHX10_3
    SHX10_3 = SHX69_1
    SHX11_3 = SHX2_3
    SHX12_3 = SHX6_1.CTaskCarReactToVehicleCollision
    SHX10_3 = SHX10_3(SHX11_3, SHX12_3)
    SHX9_3.task_react_to_vehicle = SHX10_3
    SHX10_3 = SHX10_1
    SHX11_3 = SHX2_3
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.is_visible = SHX10_3
    SHX10_3 = SHX11_1
    SHX11_3 = source
    SHX10_3 = SHX10_3(SHX11_3)
    SHX9_3.in_god_mode = SHX10_3
    SHX9_3.inVehicle = SHX8_3
    SHX9_3.velocity = SHX7_3
    SHX9_3.groundCoords = SHX6_3
    SHX10_3 = SHX9_3.parachute_state
    if -1 ~= SHX10_3 then
      SHX10_3 = SHX9_3.parachute_state
      if 0 ~= SHX10_3 then
        goto SHX_LABEL_212
      end
    end
    SHX10_3 = SHX9_3.is_dead
    if not SHX10_3 and 0 ~= SHX6_3 then
      SHX10_3 = SHX9_3.getting_in_vehicle
      if not SHX10_3 then
        SHX10_3 = SHX9_3.is_falling
        if not SHX10_3 then
          SHX10_3 = SHX9_3.is_diving
          if not SHX10_3 then
            SHX10_3 = SHX9_3.waiting_collision
            if not SHX10_3 then
              SHX10_3 = SHX9_3.is_climbing
              if not SHX10_3 then
                SHX10_3 = SHX9_3.is_ragdoll
                if not SHX10_3 then
                  SHX10_3 = SHX9_3.on_vehicle
                  if not SHX10_3 then
                    SHX10_3 = SHX9_3.attached
                    if not SHX10_3 then
                      SHX10_3 = SHX9_3.col_loaded
                      if false ~= SHX10_3 then
                        SHX10_3 = SHX9_3.in_water
                        if not SHX10_3 then
                          SHX10_3 = SHX9_3.is_swiming
                          if not SHX10_3 then
                            SHX10_3 = SHX9_3.is_swiming_under
                            if not SHX10_3 then
                              if not SHX8_3 then
                                goto SHX_LABEL_227
                              end
                              SHX10_3 = SHX29_1
                              SHX11_3 = 0.0
                              SHX12_3 = 0.0
                              SHX13_3 = 0.0
                              SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
                              if SHX7_3 == SHX10_3 then
                                goto SHX_LABEL_227
                              end
                            end
                          end
                        end
                      end
                    end
                  end
                end
              end
            end
          end
        end
      end
    end
    -- [FIX IF ERROR] Move ::SHX_LABEL_212:: outside nested blocks until all 'goto SHX_LABEL_212' can see it
    ::SHX_LABEL_212::
    SHX10_3 = SHX3_1
    SHX11_3 = SHX10_3
    SHX10_3 = SHX10_3.set
    SHX12_3 = "coords"
    SHX13_3 = SHX3_1
    SHX14_3 = SHX13_3
    SHX13_3 = SHX13_3.getCoords
    SHX13_3, SHX14_3, SHX15_3 = SHX13_3(SHX14_3)
    SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3)
    SHX10_3 = SHX3_1
    SHX11_3 = SHX10_3
    SHX10_3 = SHX10_3.set
    SHX12_3 = "lastFailedTeleportChecks"
    SHX13_3 = SHX39_1
    SHX13_3, SHX14_3, SHX15_3 = SHX13_3()
    SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3)
    SHX10_3 = false
    return SHX10_3
    -- [FIX IF ERROR] Move ::SHX_LABEL_227:: outside nested blocks until all 'goto SHX_LABEL_227' can see it
    ::SHX_LABEL_227::
    SHX10_3 = SHX3_1
    SHX11_3 = SHX10_3
    SHX10_3 = SHX10_3.get
    SHX12_3 = "lastFailedTeleportChecks"
    SHX13_3 = 0
    SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
    SHX10_3 = SHX1_3 - SHX10_3
    SHX11_3 = 5000
    if not (SHX10_3 < SHX11_3) then
      SHX10_3 = SHX3_1
      SHX11_3 = SHX10_3
      SHX10_3 = SHX10_3.getRecentlyChanged
      SHX12_3 = "LastFailedMovementChecks"
      SHX13_3 = 8000
      SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
      if not SHX10_3 then
        goto SHX_LABEL_253
      end
    end
    SHX10_3 = SHX3_1
    SHX11_3 = SHX10_3
    SHX10_3 = SHX10_3.set
    SHX12_3 = "coords"
    SHX13_3 = SHX3_1
    SHX14_3 = SHX13_3
    SHX13_3 = SHX13_3.getCoords
    SHX13_3, SHX14_3, SHX15_3 = SHX13_3(SHX14_3)
    SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3)
    SHX10_3 = false
    return SHX10_3
    -- [FIX IF ERROR] Move ::SHX_LABEL_253:: outside nested blocks until all 'goto SHX_LABEL_253' can see it
    ::SHX_LABEL_253::
    SHX10_3 = SHX13_1
    SHX11_3 = SHX3_3
    SHX12_3 = SHX3_1
    SHX13_3 = SHX12_3
    SHX12_3 = SHX12_3.get
    SHX14_3 = "coords"
    SHX15_3 = SHX3_3
    SHX12_3, SHX13_3, SHX14_3, SHX15_3 = SHX12_3(SHX13_3, SHX14_3, SHX15_3)
    SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3)
    SHX11_3 = SHX55_1
    SHX12_3 = SHX0_1
    SHX13_3 = SHX12_3
    SHX12_3 = SHX12_3.hash
    SHX14_3 = "antiTeleportMaxDistance"
    SHX12_3, SHX13_3, SHX14_3, SHX15_3 = SHX12_3(SHX13_3, SHX14_3)
    SHX11_3 = SHX11_3(SHX12_3, SHX13_3, SHX14_3, SHX15_3)
    SHX11_3 = SHX0_3[SHX11_3]
    if SHX10_3 > SHX11_3 then
      SHX11_3 = true
      SHX12_3 = {}
      SHX13_3 = SHX10_3
      SHX12_3[1] = SHX13_3
      SHX13_3 = {}
      SHX14_3 = SHX50_1
      SHX15_3 = SHX2_3
      SHX14_3 = SHX14_3(SHX15_3)
      SHX13_3.par = SHX14_3
      SHX13_3.distance = SHX10_3
      SHX13_3.velocity = SHX7_3
      SHX13_3.coords = SHX3_3
      SHX13_3.groundCoords = SHX6_3
      SHX13_3.hit_recently = SHX4_3
      return SHX11_3, SHX12_3, SHX13_3
    end
    SHX11_3 = SHX3_1
    SHX12_3 = SHX11_3
    SHX11_3 = SHX11_3.set
    SHX13_3 = "coords"
    SHX14_3 = SHX3_1
    SHX15_3 = SHX14_3
    SHX14_3 = SHX14_3.getCoords
    SHX14_3, SHX15_3 = SHX14_3(SHX15_3)
    SHX11_3(SHX12_3, SHX13_3, SHX14_3, SHX15_3)
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = LocalPlayer
  SHX1_2 = SHX1_2.state
  SHX1_2.DetectionsLoaded = true
end
SHX94_1(SHX95_1, SHX96_1, SHX97_1)
SHX95_1 = SHX1_1
SHX94_1 = SHX1_1.log
SHX96_1 = "scripts/detections/client.lua loaded"
SHX97_1 = "debug"
SHX94_1(SHX95_1, SHX96_1, SHX97_1)
