-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1, SHX21_1, SHX22_1, SHX23_1, SHX24_1, SHX25_1, SHX26_1, SHX27_1, SHX28_1, SHX29_1, SHX30_1, SHX31_1, SHX32_1, SHX33_1, SHX34_1, SHX35_1, SHX36_1, SHX37_1, SHX38_1, SHX39_1, SHX40_1, SHX41_1, SHX42_1
SHX0_1 = Security
SHX1_1 = Logger
SHX2_1 = RPC
SHX3_1 = Player
SHX4_1 = IsAimCamActive
SHX5_1 = CreateThread
SHX6_1 = IsControlJustPressed
SHX7_1 = Wait
SHX8_1 = GetFinalRenderedCamRot
SHX9_1 = GetGameTimer
SHX10_1 = GetSelectedPedWeapon
SHX11_1 = IsPedInMeleeCombat
SHX12_1 = IsPauseMenuActive
SHX13_1 = IsPedDeadOrDying
SHX14_1 = IsPedAimingFromCover
SHX15_1 = IsPedInCover
SHX16_1 = IsPedGoingIntoCover
SHX17_1 = IsPedInAnyVehicle
SHX18_1 = IsGameplayCamShaking
SHX19_1 = IsCinematicIdleCamRendering
SHX20_1 = GetFinalRenderedCamMotionBlurStrength
SHX21_1 = IsCinematicCamRendering
SHX22_1 = GetFollowPedCamViewMode
SHX23_1 = GetFrameTime
SHX24_1 = IsNuiFocused
SHX25_1 = IsUsingKeyboard
SHX26_1 = DisableControlAction
SHX27_1 = IsControlEnabled
SHX28_1 = GetHashKey
SHX29_1 = PlayerPedId
SHX30_1 = math
SHX30_1 = SHX30_1.abs
SHX31_1 = table
SHX31_1 = SHX31_1.insert
SHX32_1 = tostring
SHX33_1 = 0
SHX34_1 = {}
SHX35_1 = 0
SHX36_1 = 0
SHX37_1 = nil
SHX38_1 = false
SHX40_1 = SHX2_1
SHX39_1 = SHX2_1.on
SHX41_1 = "reaperReady"
function SHX42_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX0_2 = SHX3_1
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX2_2 = "config"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX1_2 = SHX32_1
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.hash
  SHX4_2 = "antiAimBot"
  SHX2_2, SHX3_2, SHX4_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX0_2 = SHX0_2[SHX1_2]
  SHX38_1 = SHX0_2
end
SHX39_1(SHX40_1, SHX41_1, SHX42_1)
SHX40_1 = SHX2_1
SHX39_1 = SHX2_1.on
SHX41_1 = "configUpdated"
function SHX42_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX0_2 = SHX3_1
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.get
  SHX2_2 = "config"
  SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
  SHX1_2 = SHX32_1
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.hash
  SHX4_2 = "antiAimBot"
  SHX2_2, SHX3_2, SHX4_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX0_2 = SHX0_2[SHX1_2]
  SHX38_1 = SHX0_2
end
SHX39_1(SHX40_1, SHX41_1, SHX42_1)
SHX39_1 = SHX5_1
function SHX40_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2
  while true do
    SHX0_2 = SHX7_1
    SHX1_2 = 0
    SHX0_2(SHX1_2)
    SHX0_2 = SHX38_1
    if SHX0_2 then
      SHX0_2 = SHX4_1
      SHX0_2 = SHX0_2()
      if SHX0_2 then
        SHX0_2 = SHX6_1
        SHX1_2 = 0
        SHX2_2 = 25
        SHX0_2 = SHX0_2(SHX1_2, SHX2_2)
        if not SHX0_2 then
          SHX0_2 = SHX33_1
          if 0 == SHX0_2 then
            SHX0_2 = SHX9_1
            SHX0_2 = SHX0_2()
            SHX33_1 = SHX0_2
          end
      end
      else
        SHX0_2 = 0
        SHX33_1 = SHX0_2
      end
    else
      SHX0_2 = SHX7_1
      SHX1_2 = 10000
      SHX0_2(SHX1_2)
    end
  end
end
SHX39_1(SHX40_1)
function SHX39_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX8_1
  SHX0_2 = SHX0_2()
  SHX1_2 = SHX0_2.z
  return SHX1_2
end
SHX40_1 = SHX5_1
function SHX41_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  while true do
    SHX0_2 = SHX38_1
    if SHX0_2 then
      SHX0_2 = SHX7_1
      SHX1_2 = 250
      SHX0_2(SHX1_2)
      SHX0_2 = SHX29_1
      SHX0_2 = SHX0_2()
      SHX1_2 = SHX10_1
      SHX2_2 = SHX0_2
      SHX1_2 = SHX1_2(SHX2_2)
      SHX2_2 = SHX9_1
      SHX2_2 = SHX2_2()
      SHX3_2 = SHX37_1
      if SHX3_2 ~= SHX1_2 then
        SHX35_1 = SHX2_2
        SHX37_1 = SHX1_2
      end
      SHX3_2 = SHX11_1
      SHX4_2 = SHX0_2
      SHX3_2 = SHX3_2(SHX4_2)
      if SHX3_2 then
        SHX36_1 = SHX2_2
      end
      SHX3_2 = SHX33_1
      SHX3_2 = SHX2_2 - SHX3_2
      SHX4_2 = 200
      if not (SHX3_2 < SHX4_2) then
        SHX4_2 = SHX33_1
        if 0 ~= SHX4_2 then
          goto SHX_LABEL_38
        end
      end
      SHX4_2 = {}
      SHX34_1 = SHX4_2
      goto SHX_LABEL_196
      -- [FIX IF ERROR] Move ::SHX_LABEL_38:: outside nested blocks until all 'goto SHX_LABEL_38' can see it
      ::SHX_LABEL_38::
      SHX4_2 = SHX35_1
      SHX4_2 = SHX2_2 - SHX4_2
      SHX5_2 = 1000
      if not (SHX4_2 < SHX5_2) then
        SHX4_2 = SHX36_1
        SHX4_2 = SHX2_2 - SHX4_2
        SHX5_2 = 1000
        if not (SHX4_2 < SHX5_2) then
          goto SHX_LABEL_54
        end
      end
      SHX4_2 = {}
      SHX34_1 = SHX4_2
      goto SHX_LABEL_196
      -- [FIX IF ERROR] Move ::SHX_LABEL_54:: outside nested blocks until all 'goto SHX_LABEL_54' can see it
      ::SHX_LABEL_54::
      SHX4_2 = SHX28_1
      SHX5_2 = "WEAPON_UNARMED"
      SHX4_2 = SHX4_2(SHX5_2)
      if SHX1_2 == SHX4_2 then
        SHX4_2 = {}
        SHX34_1 = SHX4_2
      else
        SHX4_2 = SHX12_1
        SHX4_2 = SHX4_2()
        if not SHX4_2 then
          SHX4_2 = SHX24_1
          SHX4_2 = SHX4_2()
          if not SHX4_2 then
            SHX4_2 = SHX13_1
            SHX5_2 = SHX0_2
            SHX4_2 = SHX4_2(SHX5_2)
            if not SHX4_2 then
              SHX4_2 = SHX14_1
              SHX5_2 = SHX0_2
              SHX4_2 = SHX4_2(SHX5_2)
              if not SHX4_2 then
                SHX4_2 = SHX15_1
                SHX5_2 = SHX0_2
                SHX6_2 = false
                SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
                if not SHX4_2 then
                  SHX4_2 = SHX16_1
                  SHX5_2 = SHX0_2
                  SHX4_2 = SHX4_2(SHX5_2)
                  if not SHX4_2 then
                    SHX4_2 = SHX17_1
                    SHX5_2 = SHX0_2
                    SHX6_2 = true
                    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
                    if not SHX4_2 then
                      goto SHX_LABEL_102
                    end
                  end
                end
              end
            end
          end
        end
        SHX4_2 = {}
        SHX34_1 = SHX4_2
        goto SHX_LABEL_196
        -- [FIX IF ERROR] Move ::SHX_LABEL_102:: outside nested blocks until all 'goto SHX_LABEL_102' can see it
        ::SHX_LABEL_102::
        SHX4_2 = SHX18_1
        SHX4_2 = SHX4_2()
        if not SHX4_2 then
          SHX4_2 = SHX21_1
          SHX4_2 = SHX4_2()
          if not SHX4_2 then
            SHX4_2 = SHX19_1
            SHX4_2 = SHX4_2()
            if not SHX4_2 then
              SHX4_2 = SHX22_1
              SHX4_2 = SHX4_2()
              if 4 ~= SHX4_2 then
                SHX4_2 = SHX20_1
                SHX4_2 = SHX4_2()
                SHX5_2 = 1.0E-4
                if not (SHX4_2 > SHX5_2) then
                  SHX4_2 = SHX23_1
                  SHX4_2 = SHX4_2()
                  SHX5_2 = 0.02
                  if not (SHX4_2 > SHX5_2) then
                    SHX4_2 = SHX25_1
                    SHX5_2 = 0
                    SHX4_2 = SHX4_2(SHX5_2)
                    if not SHX4_2 then
                    else
                      SHX4_2 = SHX26_1
                      SHX5_2 = 0
                      SHX6_2 = 1
                      SHX7_2 = true
                      SHX4_2(SHX5_2, SHX6_2, SHX7_2)
                      SHX4_2 = SHX26_1
                      SHX5_2 = 0
                      SHX6_2 = 2
                      SHX7_2 = true
                      SHX4_2(SHX5_2, SHX6_2, SHX7_2)
                      SHX4_2 = SHX39_1
                      SHX4_2 = SHX4_2()
                      SHX5_2 = SHX7_1
                      SHX6_2 = 0
                      SHX5_2(SHX6_2)
                      SHX5_2 = SHX27_1
                      SHX6_2 = 0
                      SHX7_2 = 1
                      SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
                      if not SHX5_2 then
                        SHX5_2 = SHX27_1
                        SHX6_2 = 0
                        SHX7_2 = 2
                        SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
                        if not SHX5_2 then
                          SHX5_2 = SHX39_1
                          SHX5_2 = SHX5_2()
                          SHX6_2 = SHX30_1
                          SHX7_2 = SHX4_2 - SHX5_2
                          SHX6_2 = SHX6_2(SHX7_2)
                          SHX7_2 = SHX4_1
                          SHX7_2 = SHX7_2()
                          if SHX7_2 then
                            SHX7_2 = 0.01
                            if SHX6_2 > SHX7_2 then
                              SHX7_2 = SHX31_1
                              SHX8_2 = SHX34_1
                              SHX9_2 = SHX6_2
                              SHX7_2(SHX8_2, SHX9_2)
                          end
                          else
                            SHX7_2 = {}
                            SHX34_1 = SHX7_2
                          end
                          SHX7_2 = SHX34_1
                          SHX7_2 = #SHX7_2
                          if SHX7_2 > 2 then
                            SHX7_2 = SHX5_1
                            function SHX8_2()
                              -- [AI CLEANUP] Decompiled Lua - Fix these:
                              -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
                              -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
                              -- 3. Replace goto/label with while/repeat-until where possible
                              -- 4. Remove decompiler comments, add meaningful ones
                              -- 5. Fix indentation and formatting
                              
                              local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
                              SHX0_3 = SHX3_1
                              SHX1_3 = SHX0_3
                              SHX0_3 = SHX0_3.get
                              SHX2_3 = "config"
                              SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
                              SHX1_3 = SHX32_1
                              SHX2_3 = SHX0_1
                              SHX3_3 = SHX2_3
                              SHX2_3 = SHX2_3.hash
                              SHX4_3 = "max_aimbot_flags"
                              SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3 = SHX2_3(SHX3_3, SHX4_3)
                              SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
                              SHX0_3 = SHX0_3[SHX1_3]
                              SHX1_3 = SHX3_1
                              SHX2_3 = SHX1_3
                              SHX1_3 = SHX1_3.set
                              SHX3_3 = "aimbot_flags"
                              SHX4_3 = SHX3_1
                              SHX5_3 = SHX4_3
                              SHX4_3 = SHX4_3.get
                              SHX6_3 = "aimbot_flags"
                              SHX7_3 = 0
                              SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
                              SHX4_3 = SHX4_3 + 1
                              SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3)
                              if SHX0_3 <= SHX1_3 then
                                SHX1_3 = SHX3_1
                                SHX2_3 = SHX1_3
                                SHX1_3 = SHX1_3.newDetection
                                SHX3_3 = "antiAimBot"
                                SHX4_3 = nil
                                SHX5_3 = {}
                                SHX6_3 = {}
                                SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
                                SHX1_3 = SHX3_1
                                SHX2_3 = SHX1_3
                                SHX1_3 = SHX1_3.set
                                SHX3_3 = "aimbot_flags"
                                SHX4_3 = 0
                                SHX1_3(SHX2_3, SHX3_3, SHX4_3)
                              end
                              SHX1_3 = SHX7_1
                              SHX2_3 = 6000
                              SHX1_3(SHX2_3)
                              SHX1_3 = SHX3_1
                              SHX2_3 = SHX1_3
                              SHX1_3 = SHX1_3.get
                              SHX3_3 = "aimbot_flags"
                              SHX4_3 = 0
                              SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3)
                              if SHX1_3 >= 0 then
                                SHX1_3 = SHX3_1
                                SHX2_3 = SHX1_3
                                SHX1_3 = SHX1_3.set
                                SHX3_3 = "aimbot_flags"
                                SHX4_3 = SHX3_1
                                SHX5_3 = SHX4_3
                                SHX4_3 = SHX4_3.get
                                SHX6_3 = "aimbot_flags"
                                SHX7_3 = 0
                                SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
                                SHX4_3 = SHX4_3 - 1
                                SHX1_3(SHX2_3, SHX3_3, SHX4_3)
                              end
                            end
                            SHX7_2(SHX8_2)
                            SHX7_2 = {}
                            SHX34_1 = SHX7_2
                          end
                        end
                      end
                    end
                  end
                end
              end
            end
          end
        end
      end
    else
      SHX0_2 = SHX7_1
      SHX1_2 = 10000
      SHX0_2(SHX1_2)
    end
    -- [FIX IF ERROR] Move ::SHX_LABEL_196:: outside nested blocks until all 'goto SHX_LABEL_196' can see it
    ::SHX_LABEL_196::
  end
end
SHX40_1(SHX41_1)
