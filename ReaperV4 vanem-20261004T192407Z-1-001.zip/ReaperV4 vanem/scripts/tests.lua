-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1
SHX0_1 = Security
SHX1_1 = Logger
SHX2_1 = RPC
SHX3_1 = Player
SHX4_1 = NUI
SHX5_1 = GetConvar
SHX6_1 = "reaper_gameType"
SHX7_1 = "unknown"
SHX5_1 = SHX5_1(SHX6_1, SHX7_1)
function SHX6_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX0_2 = SHX1_1
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.log
  SHX2_2 = "reaper_test_server was set to true"
  SHX3_2 = "debug"
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = print
  SHX1_2 = "loaded test commands"
  SHX0_2(SHX1_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "fastrun"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    while true do
      SHX0_3 = Wait
      SHX1_3 = 1
      SHX0_3(SHX1_3)
      SHX0_3 = SetPedMoveRateOverride
      SHX1_3 = PlayerPedId
      SHX1_3 = SHX1_3()
      SHX2_3 = 10.0
      SHX0_3(SHX1_3, SHX2_3)
    end
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "warp"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX0_3 = PlayerPedId
    SHX0_3 = SHX0_3()
    SHX1_3 = GetClosestVehicle
    SHX2_3 = GetEntityCoords
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = 20.0
    SHX4_3 = 0
    SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3)
    SHX2_3 = SetPedIntoVehicle
    SHX3_3 = SHX0_3
    SHX4_3 = SHX1_3
    SHX5_3 = -1
    SHX2_3(SHX3_3, SHX4_3, SHX5_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "visible"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    SHX0_3 = SetEntityVisible
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX2_3 = IsEntityVisible
    SHX3_3 = PlayerPedId
    SHX3_3 = SHX3_3()
    SHX2_3 = SHX2_3(SHX3_3)
    SHX2_3 = not SHX2_3
    SHX0_3(SHX1_3, SHX2_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "spec2"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3
    SHX0_3 = pairs
    SHX1_3 = GetActivePlayers
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX1_3()
    SHX0_3, SHX1_3, SHX2_3, SHX3_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    for SHX4_3, SHX5_3 in SHX0_3, SHX1_3, SHX2_3, SHX3_3 do
      SHX6_3 = GetPlayerPed
      SHX7_3 = SHX5_3
      SHX6_3 = SHX6_3(SHX7_3)
      SHX7_3 = PlayerPedId
      SHX7_3 = SHX7_3()
      if SHX6_3 == SHX7_3 then
        SHX6_3 = print
        SHX7_3 = SHX5_3
        SHX6_3(SHX7_3)
        SHX6_3 = NetworkSetInSpectatorMode
        SHX7_3 = true
        SHX8_3 = GetPlayerPed
        SHX9_3 = SHX5_3
        SHX8_3, SHX9_3 = SHX8_3(SHX9_3)
        SHX6_3(SHX7_3, SHX8_3, SHX9_3)
      end
    end
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "shootall"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3
    SHX0_3 = pairs
    SHX1_3 = GetActivePlayers
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3 = SHX1_3()
    SHX0_3, SHX1_3, SHX2_3, SHX3_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3)
    for SHX4_3, SHX5_3 in SHX0_3, SHX1_3, SHX2_3, SHX3_3 do
      SHX6_3 = GetPlayerPed
      SHX7_3 = SHX5_3
      SHX6_3 = SHX6_3(SHX7_3)
      SHX7_3 = PlayerPedId
      SHX7_3 = SHX7_3()
      if SHX6_3 ~= SHX7_3 then
        SHX6_3 = table
        SHX6_3 = SHX6_3.unpack
        SHX7_3 = GetEntityCoords
        SHX8_3 = PlayerPedId
        SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3 = SHX8_3()
        SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3)
        SHX6_3, SHX7_3, SHX8_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3)
        SHX9_3 = table
        SHX9_3 = SHX9_3.unpack
        SHX10_3 = GetEntityCoords
        SHX11_3 = GetPlayerPed
        SHX12_3 = SHX5_3
        SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3 = SHX11_3(SHX12_3)
        SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3)
        SHX9_3, SHX10_3, SHX11_3 = SHX9_3(SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3)
        SHX12_3 = ShootSingleBulletBetweenCoords
        SHX13_3 = SHX6_3
        SHX14_3 = SHX7_3
        SHX15_3 = SHX8_3
        SHX16_3 = SHX9_3
        SHX17_3 = SHX10_3
        SHX18_3 = SHX11_3
        SHX19_3 = 1.0
        SHX20_3 = 0
        SHX21_3 = GetHashKey
        SHX22_3 = "WEAPON_PISTOL"
        SHX21_3 = SHX21_3(SHX22_3)
        SHX22_3 = PlayerPedId
        SHX22_3 = SHX22_3()
        SHX23_3 = true
        SHX24_3 = false
        SHX25_3 = 1.0
        SHX12_3(SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3)
      end
    end
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "cachetest"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = SetEntityVisible
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX2_3 = true
    SHX0_3(SHX1_3, SHX2_3)
    SHX0_3 = SetEntityVisible
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX2_3 = true
    SHX0_3(SHX1_3, SHX2_3)
    SHX0_3 = SetEntityVisible
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX2_3 = true
    SHX0_3(SHX1_3, SHX2_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "godmode"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    SHX0_3 = print
    SHX1_3 = "godmode"
    SHX0_3(SHX1_3)
    SHX0_3 = SetPlayerInvincible
    SHX1_3 = PlayerId
    SHX1_3 = SHX1_3()
    SHX2_3 = GetPlayerInvincible
    SHX3_3 = PlayerId
    SHX3_3 = SHX3_3()
    SHX2_3 = SHX2_3(SHX3_3)
    SHX2_3 = not SHX2_3
    SHX0_3(SHX1_3, SHX2_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "startfire"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX0_3 = GetEntityCoords
    SHX1_3 = GetPlayerPed
    SHX2_3 = -1
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3 = SHX1_3(SHX2_3)
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
    SHX1_3 = StartScriptFire
    SHX2_3 = SHX0_3.x
    SHX3_3 = SHX0_3.y
    SHX3_3 = SHX3_3 + 3
    SHX4_3 = SHX0_3.z
    SHX4_3 = SHX4_3 - 1
    SHX5_3 = 25
    SHX6_3 = 0
    SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
    SHX1_3 = StartScriptFire
    SHX2_3 = SHX0_3.x
    SHX3_3 = SHX0_3.y
    SHX3_3 = SHX3_3 + 4
    SHX4_3 = SHX0_3.z
    SHX4_3 = SHX4_3 - 1
    SHX5_3 = 25
    SHX6_3 = 0
    SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
    SHX1_3 = StartScriptFire
    SHX2_3 = SHX0_3.x
    SHX3_3 = SHX0_3.y
    SHX3_3 = SHX3_3 + 5
    SHX4_3 = SHX0_3.z
    SHX4_3 = SHX4_3 - 1
    SHX5_3 = 25
    SHX6_3 = 0
    SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "startfire2"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = print
    SHX1_3 = StartEntityFire
    SHX2_3 = PlayerPedId
    SHX2_3 = SHX2_3()
    SHX1_3, SHX2_3 = SHX1_3(SHX2_3)
    SHX0_3(SHX1_3, SHX2_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "scene"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3
    SHX0_3 = RequestAnimDict
    SHX1_3 = "club_intro-2"
    SHX0_3(SHX1_3)
    SHX0_3 = Wait
    SHX1_3 = 500
    SHX0_3(SHX1_3)
    while true do
      SHX0_3 = Wait
      SHX1_3 = 900
      SHX0_3(SHX1_3)
      SHX0_3 = pairs
      SHX1_3 = GetActivePlayers
      SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3 = SHX1_3()
      SHX0_3, SHX1_3, SHX2_3, SHX3_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3)
      for SHX4_3, SHX5_3 in SHX0_3, SHX1_3, SHX2_3, SHX3_3 do
        SHX6_3 = GetPlayerPed
        SHX7_3 = SHX5_3
        SHX6_3 = SHX6_3(SHX7_3)
        SHX7_3 = PlayerPedId
        SHX7_3 = SHX7_3()
        if SHX6_3 ~= SHX7_3 then
          SHX7_3 = GetEntityRotation
          SHX8_3 = SHX6_3
          SHX7_3 = SHX7_3(SHX8_3)
          SHX8_3 = vector3
          SHX9_3 = 0.0
          SHX10_3 = 0.0
          SHX11_3 = 90.0
          SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3)
          SHX7_3 = SHX7_3 + SHX8_3
          SHX8_3 = GetEntityCoords
          SHX9_3 = SHX6_3
          SHX8_3 = SHX8_3(SHX9_3)
          SHX9_3 = NetworkCreateSynchronisedScene
          SHX10_3 = SHX8_3
          SHX11_3 = SHX7_3
          SHX12_3 = 2
          SHX13_3 = false
          SHX14_3 = true
          SHX15_3 = 1065353216
          SHX16_3 = 6
          SHX17_3 = 1.0
          SHX9_3 = SHX9_3(SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3)
          SHX10_3 = NetworkAddPedToSynchronisedScene
          SHX11_3 = SHX6_3
          SHX12_3 = SHX9_3
          SHX13_3 = "club_intro-2"
          SHX14_3 = "prop_npc_phone-2"
          SHX15_3 = 1.5
          SHX16_3 = -4.0
          SHX17_3 = 1
          SHX18_3 = 31
          SHX19_3 = 11488
          SHX20_3 = 0
          SHX10_3(SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3)
          SHX10_3 = NetworkStartSynchronisedScene
          SHX11_3 = SHX9_3
          SHX10_3(SHX11_3)
        end
      end
    end
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "criticalhits"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = SetPedSuffersCriticalHits
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX2_3 = false
    SHX0_3(SHX1_3, SHX2_3)
    SHX0_3 = print
    SHX1_3 = "running"
    SHX0_3(SHX1_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "cam"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX0_3 = CreateCam
    SHX1_3 = "DEFAULT_SCRIPTED_FLY_CAMERA"
    SHX2_3 = true
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
    SHX1_3 = SetCamActive
    SHX2_3 = SHX0_3
    SHX3_3 = true
    SHX1_3(SHX2_3, SHX3_3)
    SHX1_3 = RenderScriptCams
    SHX2_3 = true
    SHX3_3 = false
    SHX4_3 = 1
    SHX5_3 = true
    SHX6_3 = true
    SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "handsup"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    while true do
      SHX0_3 = HasAnimDictLoaded
      SHX1_3 = "missminuteman_1ig_2"
      SHX0_3 = SHX0_3(SHX1_3)
      if SHX0_3 then
        break
      end
      SHX0_3 = Citizen
      SHX0_3 = SHX0_3.Wait
      SHX1_3 = 100
      SHX0_3(SHX1_3)
      SHX0_3 = RequestAnimDict
      SHX1_3 = "missminuteman_1ig_2"
      SHX0_3(SHX1_3)
      SHX0_3 = print
      SHX1_3 = "req anim"
      SHX0_3(SHX1_3)
    end
    SHX0_3 = TaskPlayAnim
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX2_3 = "missminuteman_1ig_2"
    SHX3_3 = "handsup_enter"
    SHX4_3 = 8.0
    SHX5_3 = 8.0
    SHX6_3 = -1
    SHX7_3 = 50
    SHX8_3 = 0
    SHX9_3 = false
    SHX10_3 = false
    SHX11_3 = false
    SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "handsdown"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = ClearPedTasks
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX0_3(SHX1_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "checkanim"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    SHX0_3 = pairs
    SHX1_3 = GetActivePlayers
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX1_3()
    SHX0_3, SHX1_3, SHX2_3, SHX3_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    for SHX4_3, SHX5_3 in SHX0_3, SHX1_3, SHX2_3, SHX3_3 do
      SHX6_3 = GetPlayerPed
      SHX7_3 = SHX5_3
      SHX6_3 = SHX6_3(SHX7_3)
      SHX7_3 = PlayerPedId
      SHX7_3 = SHX7_3()
      if SHX6_3 ~= SHX7_3 then
        SHX6_3 = print
        SHX7_3 = IsEntityPlayingAnim
        SHX8_3 = GetPlayerPed
        SHX9_3 = SHX5_3
        SHX8_3 = SHX8_3(SHX9_3)
        SHX9_3 = "missminuteman_1ig_2"
        SHX10_3 = "handsup_enter"
        SHX11_3 = 3
        SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3)
        SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
      end
    end
    SHX0_3 = print
    SHX1_3 = "done"
    SHX0_3(SHX1_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "loadedblacklistedcommands"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = RegisterCommand
    SHX1_3 = "crashplayer"
    function SHX2_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4
      SHX0_4 = print
      SHX1_4 = "crashplayer"
      SHX0_4(SHX1_4)
    end
    SHX0_3(SHX1_3, SHX2_3)
    SHX0_3 = print
    SHX1_3 = "loaded"
    SHX0_3(SHX1_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "vehmod"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX0_3 = GetVehiclePedIsIn
    SHX1_3 = PlayerPedId
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3 = SHX1_3()
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
    SHX1_3 = print
    SHX2_3 = "veh"
    SHX3_3 = SHX0_3
    SHX4_3 = SetVehicleMod
    SHX5_3 = SHX0_3
    SHX6_3 = 23
    SHX7_3 = 8
    SHX4_3, SHX5_3, SHX6_3, SHX7_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "spawnveh"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3
    while true do
      SHX0_3 = HasModelLoaded
      SHX1_3 = GetHashKey
      SHX2_3 = "blista"
      SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX1_3(SHX2_3)
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
      if SHX0_3 then
        break
      end
      SHX0_3 = RequestModel
      SHX1_3 = GetHashKey
      SHX2_3 = "blista"
      SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX1_3(SHX2_3)
      SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
      SHX0_3 = Wait
      SHX1_3 = 10
      SHX0_3(SHX1_3)
    end
    SHX0_3 = table
    SHX0_3 = SHX0_3.unpack
    SHX1_3 = GetEntityCoords
    SHX2_3 = PlayerPedId
    SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX2_3()
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX0_3, SHX1_3, SHX2_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX3_3 = ReaperAC
    SHX3_3 = SHX3_3.API
    SHX3_3 = SHX3_3.AppendExtraEntityData
    SHX4_3 = {}
    SHX4_3.is_test = "this is a test"
    SHX3_3(SHX4_3)
    SHX3_3 = CreateVehicle
    SHX4_3 = GetHashKey
    SHX5_3 = "blista"
    SHX4_3 = SHX4_3(SHX5_3)
    SHX5_3 = SHX0_3
    SHX6_3 = SHX1_3
    SHX7_3 = SHX2_3
    SHX8_3 = 0.0
    SHX9_3 = true
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3)
    SHX4_3 = SetVehicleHasBeenOwnedByPlayer
    SHX5_3 = SHX3_3
    SHX6_3 = true
    SHX4_3(SHX5_3, SHX6_3)
    SHX4_3 = SetEntityAsMissionEntity
    SHX5_3 = SHX3_3
    SHX6_3 = true
    SHX7_3 = true
    SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    SHX4_3 = TaskWarpPedIntoVehicle
    SHX5_3 = PlayerPedId
    SHX5_3 = SHX5_3()
    SHX6_3 = SHX3_3
    SHX7_3 = -1
    SHX4_3(SHX5_3, SHX6_3, SHX7_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "spawnveh2"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
    SHX0_3 = print
    SHX1_3 = "bruh"
    SHX0_3(SHX1_3)
    while true do
      SHX0_3 = HasModelLoaded
      SHX1_3 = GetHashKey
      SHX2_3 = "overkill"
      SHX1_3, SHX2_3, SHX3_3, SHX4_3 = SHX1_3(SHX2_3)
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3)
      if SHX0_3 then
        break
      end
      SHX0_3 = RequestModel
      SHX1_3 = GetHashKey
      SHX2_3 = "overkill"
      SHX1_3, SHX2_3, SHX3_3, SHX4_3 = SHX1_3(SHX2_3)
      SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3)
      SHX0_3 = Wait
      SHX1_3 = 10
      SHX0_3(SHX1_3)
    end
    SHX0_3 = CreateVehicle
    SHX1_3 = GetHashKey
    SHX2_3 = "overkill"
    SHX1_3 = SHX1_3(SHX2_3)
    SHX2_3 = GetEntityCoords
    SHX3_3 = PlayerPedId
    SHX3_3, SHX4_3 = SHX3_3()
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
    SHX3_3 = 0.0
    SHX4_3 = false
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3)
    SHX1_3 = SetVehicleHasBeenOwnedByPlayer
    SHX2_3 = SHX0_3
    SHX3_3 = true
    SHX1_3(SHX2_3, SHX3_3)
    SHX1_3 = SetEntityAsMissionEntity
    SHX2_3 = SHX0_3
    SHX3_3 = true
    SHX4_3 = true
    SHX1_3(SHX2_3, SHX3_3, SHX4_3)
    SHX1_3 = TaskWarpPedIntoVehicle
    SHX2_3 = PlayerPedId
    SHX2_3 = SHX2_3()
    SHX3_3 = SHX0_3
    SHX4_3 = -1
    SHX1_3(SHX2_3, SHX3_3, SHX4_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "spawnvehfar"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    while true do
      SHX0_3 = HasModelLoaded
      SHX1_3 = GetHashKey
      SHX2_3 = "zentorno"
      SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3 = SHX1_3(SHX2_3)
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
      if SHX0_3 then
        break
      end
      SHX0_3 = RequestModel
      SHX1_3 = GetHashKey
      SHX2_3 = "zentorno"
      SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3 = SHX1_3(SHX2_3)
      SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
      SHX0_3 = Wait
      SHX1_3 = 10
      SHX0_3(SHX1_3)
    end
    SHX0_3 = CreateVehicle
    SHX1_3 = GetHashKey
    SHX2_3 = "zentorno"
    SHX1_3 = SHX1_3(SHX2_3)
    SHX2_3 = 0.0
    SHX3_3 = 0.0
    SHX4_3 = 0.0
    SHX5_3 = 0.0
    SHX6_3 = true
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "fixveh"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    SHX0_3 = PlayerPedId
    SHX0_3 = SHX0_3()
    SHX1_3 = GetVehiclePedIsIn
    SHX2_3 = SHX0_3
    SHX3_3 = false
    SHX1_3 = SHX1_3(SHX2_3, SHX3_3)
    if 0 == SHX1_3 then
      return
    end
    SHX2_3 = SetVehicleFixed
    SHX3_3 = SHX1_3
    SHX2_3(SHX3_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "vehgrav"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = Citizen
    SHX0_3 = SHX0_3.CreateThread
    function SHX1_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4
      while true do
        SHX0_4 = Citizen
        SHX0_4 = SHX0_4.Wait
        SHX1_4 = 0
        SHX0_4(SHX1_4)
        SHX0_4 = IsPedInAnyVehicle
        SHX1_4 = PlayerPedId
        SHX1_4, SHX2_4, SHX3_4 = SHX1_4()
        SHX0_4 = SHX0_4(SHX1_4, SHX2_4, SHX3_4)
        if SHX0_4 then
          SHX0_4 = GetVehiclePedIsIn
          SHX1_4 = PlayerPedId
          SHX1_4 = SHX1_4()
          SHX2_4 = false
          SHX0_4 = SHX0_4(SHX1_4, SHX2_4)
          SHX1_4 = SetVehicleGravityAmount
          SHX2_4 = SHX0_4
          SHX3_4 = 80.0
          SHX1_4(SHX2_4, SHX3_4)
        end
      end
    end
    SHX0_3(SHX1_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "plate"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    SHX0_3 = SetVehicleNumberPlateText
    SHX1_3 = GetVehiclePedIsIn
    SHX2_3 = PlayerPedId
    SHX2_3 = SHX2_3()
    SHX3_3 = true
    SHX1_3 = SHX1_3(SHX2_3, SHX3_3)
    SHX2_3 = tostring
    SHX3_3 = GetGameTimer
    SHX3_3 = SHX3_3()
    SHX2_3, SHX3_3 = SHX2_3(SHX3_3)
    SHX0_3(SHX1_3, SHX2_3, SHX3_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "setinv"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    SHX0_3 = SetPlayerInvincible
    SHX1_3 = PlayerId
    SHX1_3 = SHX1_3()
    SHX2_3 = GetPlayerInvincible
    SHX3_3 = PlayerId
    SHX3_3 = SHX3_3()
    SHX2_3 = SHX2_3(SHX3_3)
    SHX2_3 = not SHX2_3
    SHX0_3(SHX1_3, SHX2_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "ghostalpha"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = print
    SHX1_3 = "run"
    SHX0_3(SHX1_3)
    SHX0_3 = SetLocalPlayerAsGhost
    SHX1_3 = true
    SHX0_3(SHX1_3)
    SHX0_3 = SetGhostedEntityAlpha
    SHX1_3 = 1
    SHX0_3(SHX1_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "resetghostalpha"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = SetGhostedEntityAlpha
    SHX1_3 = 254
    SHX0_3(SHX1_3)
    SHX0_3 = SetLocalPlayerAsGhost
    SHX1_3 = false
    SHX0_3(SHX1_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "setalpha"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    SHX0_3 = SetEntityAlpha
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX2_3 = 0
    SHX3_3 = false
    SHX0_3(SHX1_3, SHX2_3, SHX3_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "resetalpha"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = ResetEntityAlpha
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX0_3(SHX1_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "fadescreen"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = DoScreenFadeOut
    SHX1_3 = 1500
    SHX0_3(SHX1_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "die"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = SetEntityHealth
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX2_3 = 0
    SHX0_3(SHX1_3, SHX2_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "fadeinscreen"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = DoScreenFadeIn
    SHX1_3 = 1500
    SHX0_3(SHX1_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "spawnobj"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    while true do
      SHX0_3 = HasModelLoaded
      SHX1_3 = GetHashKey
      SHX2_3 = "prop_generator_03b"
      SHX1_3, SHX2_3, SHX3_3 = SHX1_3(SHX2_3)
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3)
      if SHX0_3 then
        break
      end
      SHX0_3 = RequestModel
      SHX1_3 = GetHashKey
      SHX2_3 = "prop_generator_03b"
      SHX1_3, SHX2_3, SHX3_3 = SHX1_3(SHX2_3)
      SHX0_3(SHX1_3, SHX2_3, SHX3_3)
      SHX0_3 = Wait
      SHX1_3 = 1
      SHX0_3(SHX1_3)
    end
    SHX0_3 = CreateObject
    SHX1_3 = GetHashKey
    SHX2_3 = "prop_generator_03b"
    SHX1_3 = SHX1_3(SHX2_3)
    SHX2_3 = GetEntityCoords
    SHX3_3 = PlayerPedId
    SHX3_3 = SHX3_3()
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = true
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3)
    SHX1_3 = print
    SHX2_3 = SHX0_3
    SHX1_3(SHX2_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "spawnobj2"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    while true do
      SHX0_3 = HasModelLoaded
      SHX1_3 = GetHashKey
      SHX2_3 = "prop_generator_03b"
      SHX1_3, SHX2_3, SHX3_3 = SHX1_3(SHX2_3)
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3)
      if SHX0_3 then
        break
      end
      SHX0_3 = RequestModel
      SHX1_3 = GetHashKey
      SHX2_3 = "prop_generator_03b"
      SHX1_3, SHX2_3, SHX3_3 = SHX1_3(SHX2_3)
      SHX0_3(SHX1_3, SHX2_3, SHX3_3)
      SHX0_3 = Wait
      SHX1_3 = 1
      SHX0_3(SHX1_3)
    end
    SHX0_3 = CreateObject
    SHX1_3 = GetHashKey
    SHX2_3 = "prop_generator_03b"
    SHX1_3 = SHX1_3(SHX2_3)
    SHX2_3 = GetEntityCoords
    SHX3_3 = PlayerPedId
    SHX3_3 = SHX3_3()
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = true
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3)
    SHX1_3 = print
    SHX2_3 = SHX0_3
    SHX1_3(SHX2_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "pickup"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3
    SHX0_3 = table
    SHX0_3 = SHX0_3.unpack
    SHX1_3 = GetEntityCoords
    SHX2_3 = PlayerPedId
    SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3 = SHX2_3()
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3)
    SHX0_3, SHX1_3, SHX2_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3)
    SHX3_3 = CreatePickup
    SHX4_3 = 1850631618
    SHX5_3 = SHX0_3
    SHX6_3 = SHX1_3
    SHX7_3 = SHX2_3
    SHX8_3 = 0
    SHX9_3 = 0
    SHX10_3 = true
    SHX11_3 = GetHashKey
    SHX12_3 = "WEAPON_BULLPUPSHOTGUN"
    SHX11_3, SHX12_3 = SHX11_3(SHX12_3)
    SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "noneeded"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    while true do
      SHX0_3 = HasModelLoaded
      SHX1_3 = GetHashKey
      SHX2_3 = "csb_stripper_02"
      SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX1_3(SHX2_3)
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
      if SHX0_3 then
        break
      end
      SHX0_3 = RequestModel
      SHX1_3 = GetHashKey
      SHX2_3 = "csb_stripper_02"
      SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX1_3(SHX2_3)
      SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
      SHX0_3 = Wait
      SHX1_3 = 10
      SHX0_3(SHX1_3)
    end
    SHX0_3 = table
    SHX0_3 = SHX0_3.unpack
    SHX1_3 = GetEntityCoords
    SHX2_3 = PlayerPedId
    SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX2_3()
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    SHX0_3, SHX1_3, SHX2_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    SHX3_3 = CreatePed_Raw
    SHX4_3 = 21
    SHX5_3 = GetHashKey
    SHX6_3 = "csb_stripper_02"
    SHX5_3 = SHX5_3(SHX6_3)
    SHX6_3 = SHX0_3
    SHX7_3 = SHX1_3
    SHX8_3 = SHX2_3
    SHX9_3 = 0
    SHX10_3 = true
    SHX11_3 = true
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    SHX4_3 = SetEntityAsNoLongerNeeded
    SHX5_3 = SHX3_3
    SHX4_3(SHX5_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "spawnlped"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    while true do
      SHX0_3 = HasModelLoaded
      SHX1_3 = GetHashKey
      SHX2_3 = "csb_stripper_02"
      SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX1_3(SHX2_3)
      SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
      if SHX0_3 then
        break
      end
      SHX0_3 = RequestModel
      SHX1_3 = GetHashKey
      SHX2_3 = "csb_stripper_02"
      SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX1_3(SHX2_3)
      SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
      SHX0_3 = Wait
      SHX1_3 = 10
      SHX0_3(SHX1_3)
    end
    SHX0_3 = table
    SHX0_3 = SHX0_3.unpack
    SHX1_3 = GetEntityCoords
    SHX2_3 = PlayerPedId
    SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX2_3()
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    SHX0_3, SHX1_3, SHX2_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    SHX3_3 = CreatePed
    SHX4_3 = 21
    SHX5_3 = GetHashKey
    SHX6_3 = "csb_stripper_02"
    SHX5_3 = SHX5_3(SHX6_3)
    SHX6_3 = SHX0_3
    SHX7_3 = SHX1_3
    SHX8_3 = SHX2_3
    SHX9_3 = 0
    SHX10_3 = false
    SHX11_3 = false
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "invisl"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = true
    SHX1_3 = CreateThread
    function SHX2_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4
      while true do
        SHX0_4 = SHX0_3
        if not SHX0_4 then
          break
        end
        SHX0_4 = SetEntityLocallyInvisible
        SHX1_4 = PlayerPedId
        SHX1_4 = SHX1_4()
        SHX0_4(SHX1_4)
        SHX0_4 = Wait
        SHX1_4 = 1
        SHX0_4(SHX1_4)
      end
    end
    SHX1_3(SHX2_3)
    SHX1_3 = Wait
    SHX2_3 = 10000
    SHX1_3(SHX2_3)
    SHX0_3 = false
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "invis2"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    while true do
      SHX0_3 = SetPlayerInvisibleLocally
      SHX1_3 = PlayerPedId
      SHX1_3 = SHX1_3()
      SHX2_3 = true
      SHX0_3(SHX1_3, SHX2_3)
      SHX0_3 = Wait
      SHX1_3 = 1
      SHX0_3(SHX1_3)
    end
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "snow"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = Citizen
    SHX0_3 = SHX0_3.CreateThread
    function SHX1_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4
      while true do
        SHX0_4 = SetWeatherTypePersist
        SHX1_4 = "XMAS"
        SHX0_4(SHX1_4)
        SHX0_4 = SetWeatherTypeNowPersist
        SHX1_4 = "XMAS"
        SHX0_4(SHX1_4)
        SHX0_4 = SetWeatherTypeNow
        SHX1_4 = "XMAS"
        SHX0_4(SHX1_4)
        SHX0_4 = SetOverrideWeather
        SHX1_4 = "XMAS"
        SHX0_4(SHX1_4)
        SHX0_4 = Citizen
        SHX0_4 = SHX0_4.Wait
        SHX1_4 = 1
        SHX0_4(SHX1_4)
      end
    end
    SHX0_3(SHX1_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "sound"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX0_3 = GetEntityCoords
    SHX1_3 = GetPlayerPed
    SHX2_3 = -1
    SHX1_3 = SHX1_3(SHX2_3)
    SHX2_3 = true
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
    SHX1_3 = GetSoundId
    SHX1_3 = SHX1_3()
    SHX2_3 = true
    SHX3_3 = PlaySoundFromCoord
    SHX4_3 = SHX1_3
    SHX5_3 = "VEHICLES_HORNS_AMBULANCE_WARNING"
    SHX6_3 = SHX0_3.x
    SHX7_3 = SHX0_3.y
    SHX8_3 = SHX0_3.z
    SHX9_3 = nil
    SHX10_3 = SHX2_3
    SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
    SHX3_3 = Citizen
    SHX3_3 = SHX3_3.Wait
    SHX4_3 = 5000
    SHX3_3(SHX4_3)
    SHX3_3 = StopSound
    SHX4_3 = SHX1_3
    SHX3_3(SHX4_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "sound3"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX0_3 = GetEntityCoords
    SHX1_3 = GetPlayerPed
    SHX2_3 = -1
    SHX1_3 = SHX1_3(SHX2_3)
    SHX2_3 = true
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
    SHX1_3 = GetSoundId
    SHX1_3 = SHX1_3()
    SHX2_3 = true
    SHX3_3 = PlaySoundFromCoord
    SHX4_3 = SHX1_3
    SHX5_3 = "RESIDENT_VEHICLES_SIREN_WAIL_01"
    SHX6_3 = SHX0_3.x
    SHX7_3 = SHX0_3.y
    SHX8_3 = SHX0_3.z
    SHX9_3 = nil
    SHX10_3 = SHX2_3
    SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
    SHX3_3 = Citizen
    SHX3_3 = SHX3_3.Wait
    SHX4_3 = 5000
    SHX3_3(SHX4_3)
    SHX3_3 = StopSound
    SHX4_3 = SHX1_3
    SHX3_3(SHX4_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "sound2"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
    SHX0_3 = PlaySound
    SHX1_3 = -1
    SHX2_3 = "Checkpoint_Hit"
    SHX3_3 = "GTAO_FM_Events_Soundset"
    SHX4_3 = true
    SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "vehf"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3
    SHX0_3 = pairs
    SHX1_3 = GetGamePool
    SHX2_3 = "CVehicle"
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3 = SHX1_3(SHX2_3)
    SHX0_3, SHX1_3, SHX2_3, SHX3_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3)
    for SHX4_3, SHX5_3 in SHX0_3, SHX1_3, SHX2_3, SHX3_3 do
      SHX6_3 = ApplyForceToEntity
      SHX7_3 = SHX5_3
      SHX8_3 = 3
      SHX9_3 = 0.0
      SHX10_3 = 0.0
      SHX11_3 = -100.0
      SHX12_3 = 0.0
      SHX13_3 = 0.0
      SHX14_3 = 0.0
      SHX15_3 = 0
      SHX16_3 = 0
      SHX17_3 = 1
      SHX18_3 = 1
      SHX19_3 = 0
      SHX20_3 = 1
      SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3)
    end
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "lockvehicles"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3
    SHX0_3 = pairs
    SHX1_3 = GetGamePool
    SHX2_3 = "CVehicle"
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3 = SHX1_3(SHX2_3)
    SHX0_3, SHX1_3, SHX2_3, SHX3_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3)
    for SHX4_3, SHX5_3 in SHX0_3, SHX1_3, SHX2_3, SHX3_3 do
      SHX6_3 = SetVehicleDoorsLockedForAllPlayers
      SHX7_3 = SHX5_3
      SHX8_3 = true
      SHX6_3(SHX7_3, SHX8_3)
    end
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "reqc"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX0_3 = pairs
    SHX1_3 = GetGamePool
    SHX2_3 = "CVehicle"
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3 = SHX1_3(SHX2_3)
    SHX0_3, SHX1_3, SHX2_3, SHX3_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
    for SHX4_3, SHX5_3 in SHX0_3, SHX1_3, SHX2_3, SHX3_3 do
      SHX6_3 = NetworkRequestControlOfEntity
      SHX7_3 = SHX5_3
      SHX6_3(SHX7_3)
    end
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "attach"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3, SHX26_3, SHX27_3
    SHX0_3 = print
    SHX1_3 = "attaching"
    SHX0_3(SHX1_3)
    SHX0_3 = pairs
    SHX1_3 = GetActivePlayers
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3, SHX26_3, SHX27_3 = SHX1_3()
    SHX0_3, SHX1_3, SHX2_3, SHX3_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3, SHX26_3, SHX27_3)
    for SHX4_3, SHX5_3 in SHX0_3, SHX1_3, SHX2_3, SHX3_3 do
      SHX6_3 = GetPlayerPed
      SHX7_3 = SHX5_3
      SHX6_3 = SHX6_3(SHX7_3)
      SHX7_3 = PlayerPedId
      SHX7_3 = SHX7_3()
      if SHX6_3 ~= SHX7_3 then
        SHX6_3 = pairs
        SHX7_3 = GetGamePool
        SHX8_3 = "CVehicle"
        SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3, SHX26_3, SHX27_3 = SHX7_3(SHX8_3)
        SHX6_3, SHX7_3, SHX8_3, SHX9_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3, SHX26_3, SHX27_3)
        for SHX10_3, SHX11_3 in SHX6_3, SHX7_3, SHX8_3, SHX9_3 do
          SHX12_3 = AttachEntityToEntity
          SHX13_3 = SHX11_3
          SHX14_3 = GetPlayerPed
          SHX15_3 = SHX5_3
          SHX14_3 = SHX14_3(SHX15_3)
          SHX15_3 = 0
          SHX16_3 = 0.0
          SHX17_3 = 0.0
          SHX18_3 = 0.0
          SHX19_3 = 0.0
          SHX20_3 = 0.0
          SHX21_3 = 0.0
          SHX22_3 = 0
          SHX23_3 = false
          SHX24_3 = false
          SHX25_3 = false
          SHX26_3 = 0
          SHX27_3 = 0
          SHX12_3(SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3, SHX18_3, SHX19_3, SHX20_3, SHX21_3, SHX22_3, SHX23_3, SHX24_3, SHX25_3, SHX26_3, SHX27_3)
        end
        break
      end
    end
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "wep"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX0_3 = SHX5_1
    if "gta5" == SHX0_3 then
      SHX0_3 = GiveWeaponToPed
      SHX1_3 = PlayerPedId
      SHX1_3 = SHX1_3()
      SHX2_3 = GetHashKey
      SHX3_3 = "WEAPON_RPG"
      SHX2_3 = SHX2_3(SHX3_3)
      SHX3_3 = 999999
      SHX4_3 = false
      SHX5_3 = true
      SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3)
    else
      SHX0_3 = SHX5_1
      if "rdr3" == SHX0_3 then
        SHX0_3 = GiveWeaponToPed
        SHX1_3 = PlayerPedId
        SHX1_3 = SHX1_3()
        SHX2_3 = GetHashKey
        SHX3_3 = "weapon_revolver_cattleman"
        SHX2_3 = SHX2_3(SHX3_3)
        SHX3_3 = 999999
        SHX4_3 = false
        SHX5_3 = true
        SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3)
      end
    end
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "wep2"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX0_3 = GiveWeaponToPed
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX2_3 = GetHashKey
    SHX3_3 = "weapon_pistol"
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = 999999
    SHX4_3 = false
    SHX5_3 = true
    SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "wepjo"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX0_3 = print
    SHX1_3 = "given"
    SHX0_3(SHX1_3)
    SHX0_3 = GiveWeaponToPed
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX2_3 = -238086004
    SHX3_3 = 99999
    SHX4_3 = false
    SHX5_3 = true
    SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "infammo"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX0_3 = GiveWeaponToPed
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX2_3 = GetHashKey
    SHX3_3 = "WEAPON_APPISTOL"
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = -1
    SHX4_3 = false
    SHX5_3 = true
    SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "par"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX0_3 = GiveWeaponToPed
    SHX1_3 = GetPlayerPed
    SHX2_3 = -1
    SHX1_3 = SHX1_3(SHX2_3)
    SHX2_3 = GetHashKey
    SHX3_3 = "gadget_parachute"
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = 1
    SHX4_3 = false
    SHX5_3 = false
    SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "clip"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    SHX0_3 = SHX1_1
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.log
    SHX2_3 = SHX4_1
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.clipScreen
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = "info"
    SHX0_3(SHX1_3, SHX2_3, SHX3_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "detect"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
    SHX0_3 = print
    SHX1_3 = "testing"
    SHX0_3(SHX1_3)
    SHX0_3 = SHX0_1
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.detection
    SHX2_3 = "test"
    SHX3_3 = nil
    SHX4_3 = nil
    SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = SHX5_1
  if "gta5" == SHX0_2 then
    SHX0_2 = SetCanAttackFriendly
    SHX1_2 = PlayerPedId
    SHX1_2 = SHX1_2()
    SHX2_2 = true
    SHX3_2 = false
    SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  end
  SHX0_2 = RegisterCommand
  SHX1_2 = "fall"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX0_3 = table
    SHX0_3 = SHX0_3.unpack
    SHX1_3 = GetEntityCoords
    SHX2_3 = PlayerPedId
    SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3 = SHX2_3()
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
    SHX0_3, SHX1_3, SHX2_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
    SHX3_3 = SetEntityCoords
    SHX4_3 = PlayerPedId
    SHX4_3 = SHX4_3()
    SHX5_3 = SHX0_3
    SHX6_3 = SHX1_3
    SHX7_3 = SHX2_3 - 5
    SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = RegisterCommand
  SHX1_2 = "tp"
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX0_3 = table
    SHX0_3 = SHX0_3.unpack
    SHX1_3 = GetEntityCoords
    SHX2_3 = PlayerPedId
    SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3 = SHX2_3()
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
    SHX0_3, SHX1_3, SHX2_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
    SHX3_3 = SetEntityCoords
    SHX4_3 = PlayerPedId
    SHX4_3 = SHX4_3()
    SHX5_3 = SHX0_3
    SHX6_3 = SHX1_3
    SHX7_3 = SHX2_3
    SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3)
  end
  SHX0_2(SHX1_2, SHX2_2)
  SHX0_2 = false
  SHX1_2 = 1.5
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX0_3 = table
    SHX0_3 = SHX0_3.unpack
    SHX1_3 = GetEntityCoords
    SHX2_3 = GetPlayerPed
    SHX3_3 = -1
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = true
    SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3 = SHX1_3(SHX2_3, SHX3_3)
    SHX0_3, SHX1_3, SHX2_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3)
    SHX3_3 = SHX0_3
    SHX4_3 = SHX1_3
    SHX5_3 = SHX2_3
    return SHX3_3, SHX4_3, SHX5_3
  end
  getPosition = SHX2_2
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3
    SHX0_3 = GetGameplayCamRelativeHeading
    SHX0_3 = SHX0_3()
    SHX1_3 = GetEntityHeading
    SHX2_3 = GetPlayerPed
    SHX3_3 = -1
    SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3 = SHX2_3(SHX3_3)
    SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3)
    SHX0_3 = SHX0_3 + SHX1_3
    SHX1_3 = GetGameplayCamRelativePitch
    SHX1_3 = SHX1_3()
    SHX2_3 = math
    SHX2_3 = SHX2_3.sin
    SHX3_3 = math
    SHX3_3 = SHX3_3.pi
    SHX3_3 = SHX0_3 * SHX3_3
    SHX3_3 = SHX3_3 / 180.0
    SHX2_3 = SHX2_3(SHX3_3)
    SHX2_3 = -SHX2_3
    SHX3_3 = math
    SHX3_3 = SHX3_3.cos
    SHX4_3 = math
    SHX4_3 = SHX4_3.pi
    SHX4_3 = SHX0_3 * SHX4_3
    SHX4_3 = SHX4_3 / 180.0
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = math
    SHX4_3 = SHX4_3.sin
    SHX5_3 = math
    SHX5_3 = SHX5_3.pi
    SHX5_3 = SHX1_3 * SHX5_3
    SHX5_3 = SHX5_3 / 180.0
    SHX4_3 = SHX4_3(SHX5_3)
    SHX5_3 = math
    SHX5_3 = SHX5_3.sqrt
    SHX6_3 = SHX2_3 * SHX2_3
    SHX7_3 = SHX3_3 * SHX3_3
    SHX6_3 = SHX6_3 + SHX7_3
    SHX7_3 = SHX4_3 * SHX4_3
    SHX6_3 = SHX6_3 + SHX7_3
    SHX5_3 = SHX5_3(SHX6_3)
    if 0 ~= SHX5_3 then
      SHX2_3 = SHX2_3 / SHX5_3
      SHX3_3 = SHX3_3 / SHX5_3
      SHX4_3 = SHX4_3 / SHX5_3
    end
    SHX6_3 = SHX2_3
    SHX7_3 = SHX3_3
    SHX8_3 = SHX4_3
    return SHX6_3, SHX7_3, SHX8_3
  end
  getCamDirection = SHX2_2
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = SHX0_2
    return SHX0_3
  end
  isNoclip = SHX2_2
  SHX2_2 = RegisterCommand
  SHX3_2 = "noclip"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX0_3 = PlayerId
    SHX0_3 = SHX0_3()
    SHX1_3 = PlayerPedId
    SHX2_3 = "desactivado"
    SHX3_3 = SHX0_2
    SHX3_3 = not SHX3_3
    SHX0_2 = SHX3_3
    SHX3_3 = SHX0_2
    if SHX3_3 then
      SHX2_3 = "activado"
    end
    SHX3_3 = TriggerEvent
    SHX4_3 = "chatMessage"
    SHX5_3 = "Noclip ^2^*"
    SHX6_3 = SHX2_3
    SHX5_3 = SHX5_3 .. SHX6_3
    SHX3_3(SHX4_3, SHX5_3)
    SHX3_3 = SetEntityVisible
    SHX4_3 = GetPlayerPed
    SHX5_3 = -1
    SHX4_3 = SHX4_3(SHX5_3)
    SHX5_3 = true
    SHX6_3 = 0
    SHX3_3(SHX4_3, SHX5_3, SHX6_3)
  end
  SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = 0
  SHX3_2 = Citizen
  SHX3_2 = SHX3_2.CreateThread
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3
    while true do
      SHX0_3 = Citizen
      SHX0_3 = SHX0_3.Wait
      SHX1_3 = 0
      SHX0_3(SHX1_3)
      SHX0_3 = SHX0_2
      if SHX0_3 then
        SHX0_3 = GetPlayerPed
        SHX1_3 = -1
        SHX0_3 = SHX0_3(SHX1_3)
        SHX1_3 = getPosition
        SHX1_3, SHX2_3, SHX3_3 = SHX1_3()
        SHX4_3 = getCamDirection
        SHX4_3, SHX5_3, SHX6_3 = SHX4_3()
        SHX7_3 = SHX1_2
        SHX8_3 = SetEntityVisible
        SHX9_3 = GetPlayerPed
        SHX10_3 = -1
        SHX9_3 = SHX9_3(SHX10_3)
        SHX10_3 = false
        SHX11_3 = 0
        SHX8_3(SHX9_3, SHX10_3, SHX11_3)
        SHX8_3 = SetEntityVelocity
        SHX9_3 = SHX0_3
        SHX10_3 = 1.0E-4
        SHX11_3 = 1.0E-4
        SHX12_3 = 1.0E-4
        SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3)
        SHX8_3 = IsControlPressed
        SHX9_3 = 0
        SHX10_3 = 32
        SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
        if SHX8_3 then
          SHX8_3 = SHX7_3 * SHX4_3
          SHX1_3 = SHX1_3 + SHX8_3
          SHX8_3 = SHX7_3 * SHX5_3
          SHX2_3 = SHX2_3 + SHX8_3
          SHX8_3 = SHX7_3 * SHX6_3
          SHX3_3 = SHX3_3 + SHX8_3
        end
        SHX8_3 = IsControlPressed
        SHX9_3 = 0
        SHX10_3 = 269
        SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
        if SHX8_3 then
          SHX8_3 = SHX7_3 * SHX4_3
          SHX1_3 = SHX1_3 - SHX8_3
          SHX8_3 = SHX7_3 * SHX5_3
          SHX2_3 = SHX2_3 - SHX8_3
          SHX8_3 = SHX7_3 * SHX6_3
          SHX3_3 = SHX3_3 - SHX8_3
        end
        SHX8_3 = IsControlPressed
        SHX9_3 = 0
        SHX10_3 = 34
        SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
        if SHX8_3 then
          SHX1_3 = SHX1_3 - 1
        end
        SHX8_3 = IsControlPressed
        SHX9_3 = 0
        SHX10_3 = 9
        SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
        if SHX8_3 then
          SHX1_3 = SHX1_3 + 1
        end
        SHX8_3 = IsControlPressed
        SHX9_3 = 0
        SHX10_3 = 203
        SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
        if SHX8_3 then
          SHX3_3 = SHX3_3 + 1
        end
        SHX8_3 = IsControlPressed
        SHX9_3 = 0
        SHX10_3 = 210
        SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
        if SHX8_3 then
          SHX3_3 = SHX3_3 - 1
        end
        SHX8_3 = IsControlPressed
        SHX9_3 = 0
        SHX10_3 = 21
        SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
        if SHX8_3 then
          SHX8_3 = 3.0
          SHX1_2 = SHX8_3
        else
          SHX8_3 = 1.5
          SHX1_2 = SHX8_3
        end
        SHX8_3 = SetEntityCoordsNoOffset
        SHX9_3 = SHX0_3
        SHX10_3 = SHX1_3
        SHX11_3 = SHX2_3
        SHX12_3 = SHX3_3
        SHX13_3 = true
        SHX14_3 = true
        SHX15_3 = true
        SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3)
      end
    end
  end
  SHX3_2(SHX4_2)
  SHX3_2 = RegisterCommand
  SHX4_2 = "pro"
  function SHX5_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    SHX0_3 = TriggerServerEvent
    SHX1_3 = "Reaper:ProAddonAutoWhitelist"
    SHX2_3 = "all"
    SHX3_3 = true
    SHX0_3(SHX1_3, SHX2_3, SHX3_3)
  end
  SHX3_2(SHX4_2, SHX5_2)
  SHX3_2 = RegisterCommand
  SHX4_2 = "disablepro"
  function SHX5_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = GlobalState
    SHX0_3.ProAddonEnabled = false
    SHX0_3 = print
    SHX1_3 = GlobalState
    SHX1_3 = SHX1_3.ProAddonEnabled
    SHX0_3(SHX1_3)
  end
  SHX3_2(SHX4_2, SHX5_2)
  SHX3_2 = RegisterCommand
  SHX4_2 = "testevent"
  function SHX5_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = TriggerServerEvent
    SHX1_3 = "testevent"
    SHX2_3 = "this is a test bruh ok"
    SHX0_3(SHX1_3, SHX2_3)
  end
  SHX3_2(SHX4_2, SHX5_2)
  SHX3_2 = exports
  SHX3_2 = SHX3_2.chat
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSharedObject
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = AddEventHandler
  SHX5_2 = "onResourceStart"
  function SHX6_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3
    if "chat" == SHX0_3 then
      SHX1_3 = exports
      SHX1_3 = SHX1_3.chat
      SHX2_3 = SHX1_3
      SHX1_3 = SHX1_3.getSharedObject
      SHX1_3 = SHX1_3(SHX2_3)
      SHX3_2 = SHX1_3
    end
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = RegisterCommand
  SHX5_2 = "openinv"
  function SHX6_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = exports
    SHX0_3 = SHX0_3.chat
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.openInventory
    SHX2_3 = "test"
    SHX0_3(SHX1_3, SHX2_3)
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = RegisterCommand
  SHX5_2 = "thread"
  function SHX6_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = CreateThread
    function SHX1_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4
      SHX0_4 = print
      SHX1_4 = "hello"
      SHX0_4(SHX1_4)
    end
    SHX0_3(SHX1_3)
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = RegisterCommand
  SHX5_2 = "testexport"
  function SHX6_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3
    SHX0_3 = print
    SHX1_3 = "spawm"
    SHX2_3 = SHX3_2.Game
    SHX2_3 = SHX2_3.SpawnVehicle
    SHX3_3 = "blista"
    SHX2_3, SHX3_3 = SHX2_3(SHX3_3)
    SHX0_3(SHX1_3, SHX2_3, SHX3_3)
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = RegisterCommand
  SHX5_2 = "export_mult_arg"
  function SHX6_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
    SHX0_3 = SHX3_2.Game
    SHX0_3 = SHX0_3.GetClosestPlayer
    SHX1_3 = 69
    SHX0_3, SHX1_3 = SHX0_3(SHX1_3)
    SHX2_3 = print
    SHX3_3 = SHX0_3
    SHX4_3 = SHX1_3
    SHX2_3(SHX3_3, SHX4_3)
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = RegisterCommand
  SHX5_2 = "triggernonnetevent"
  function SHX6_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = TriggerServerEvent
    SHX1_3 = "Reaper:UpdateFlaggedEvents"
    SHX0_3(SHX1_3)
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = RegisterCommand
  SHX5_2 = "testnative"
  function SHX6_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = print
    SHX1_3 = "val"
    SHX2_3 = TestNative
    SHX2_3 = SHX2_3()
    SHX0_3(SHX1_3, SHX2_3)
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = RegisterCommand
  SHX5_2 = "head"
  function SHX6_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX0_3 = SetPedComponentVariation
    SHX1_3 = PlayerPedId
    SHX1_3 = SHX1_3()
    SHX2_3 = 0
    SHX3_3 = 1
    SHX4_3 = 1
    SHX5_3 = 1
    SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3)
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = RegisterCommand
  SHX5_2 = "mumble"
  function SHX6_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = MumbleSetTalkerProximity
    SHX1_3 = 30
    SHX0_3(SHX1_3)
    SHX0_3 = print
    SHX1_3 = "set"
    SHX0_3(SHX1_3)
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = RegisterCommand
  SHX5_2 = "mumble2"
  function SHX6_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = MumbleSetTalkerProximity
    SHX1_3 = 45
    SHX0_3(SHX1_3)
    SHX0_3 = print
    SHX1_3 = "set"
    SHX0_3(SHX1_3)
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = RegisterCommand
  SHX5_2 = "mumble3"
  function SHX6_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = MumbleSetTalkerProximity
    SHX1_3 = 6
    SHX0_3(SHX1_3)
    SHX0_3 = print
    SHX1_3 = "set"
    SHX0_3(SHX1_3)
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = RegisterCommand
  SHX5_2 = "bypass"
  function SHX6_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3
    SHX0_3 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    SHX1_3 = "REAPER_OT_OT"
    SHX2_3 = 8186484168865098
    SHX3_3 = 4887
    SHX4_3 = nil
    function SHX5_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4
      SHX0_4 = {}
      SHX4_3 = SHX0_4
      SHX0_4 = 0
      SHX1_4 = 127
      SHX2_4 = 1
      for SHX3_4 = SHX0_4, SHX1_4, SHX2_4 do
        SHX4_4 = -1
        repeat
          SHX4_4 = SHX4_4 + 2
          SHX5_4 = 2 * SHX3_4
          SHX5_4 = SHX5_4 + 1
          SHX5_4 = SHX4_4 * SHX5_4
          SHX5_4 = SHX5_4 % 256
        until 1 == SHX5_4
        SHX5_4 = SHX4_3
        SHX5_4[SHX3_4] = SHX4_4
      end
    end
    function SHX6_3(SHX0_4)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4, SHX8_4, SHX9_4
      SHX1_4 = SHX0_4
      SHX2_4 = SHX1_3
      SHX1_4 = SHX1_4 .. SHX2_4
      SHX2_4 = 5381
      SHX3_4 = 1
      SHX4_4 = #SHX1_4
      SHX5_4 = 1
      for SHX6_4 = SHX3_4, SHX4_4, SHX5_4 do
        SHX7_4 = string
        SHX7_4 = SHX7_4.byte
        SHX8_4 = SHX1_4
        SHX9_4 = SHX6_4
        SHX7_4 = SHX7_4(SHX8_4, SHX9_4)
        SHX8_4 = SHX2_4 * 33
        SHX2_4 = SHX8_4 ~ SHX7_4
      end
      return SHX2_4
    end
    ReaperSecurityHash = SHX6_3
    function SHX6_3(SHX0_4)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4
      SHX1_4 = SHX4_3
      if not SHX1_4 then
        SHX1_4 = SHX5_3
        SHX1_4()
      end
      SHX1_4 = SHX2_3
      SHX2_4 = SHX3_3
      SHX2_4 = SHX2_4 + 16384
      SHX4_4 = SHX0_4
      SHX3_4 = SHX0_4.gsub
      SHX5_4 = "."
      function SHX6_4(SHX0_5)
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX1_5, SHX2_5, SHX3_5, SHX4_5, SHX5_5, SHX6_5, SHX7_5, SHX8_5
        SHX1_5 = SHX1_4
        SHX1_5 = SHX1_5 % 274877906944
        SHX2_5 = SHX1_4
        SHX2_5 = SHX2_5 - SHX1_5
        SHX2_5 = SHX2_5 / 274877906944
        SHX3_5 = SHX2_5 % 128
        SHX4_5 = string
        SHX4_5 = SHX4_5.byte
        SHX5_5 = SHX0_5
        SHX4_5 = SHX4_5(SHX5_5)
        SHX5_5 = SHX4_3
        SHX5_5 = SHX5_5[SHX3_5]
        SHX5_5 = SHX4_5 * SHX5_5
        SHX6_5 = SHX2_5 - SHX3_5
        SHX6_5 = SHX6_5 / 128
        SHX5_5 = SHX5_5 - SHX6_5
        SHX5_5 = SHX5_5 % 256
        SHX6_5 = SHX2_4
        SHX6_5 = SHX1_5 * SHX6_5
        SHX6_5 = SHX6_5 + SHX2_5
        SHX6_5 = SHX6_5 + SHX5_5
        SHX6_5 = SHX6_5 + SHX4_5
        SHX1_4 = SHX6_5
        SHX6_5 = string
        SHX6_5 = SHX6_5.format
        SHX7_5 = "%02x"
        SHX8_5 = SHX5_5
        return SHX6_5(SHX7_5, SHX8_5)
      end
      return SHX3_4(SHX4_4, SHX5_4, SHX6_4)
    end
    ReaperEncrypt = SHX6_3
    function SHX6_3(SHX0_4)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4
      SHX1_4 = SHX4_3
      if not SHX1_4 then
        SHX1_4 = SHX5_3
        SHX1_4()
      end
      SHX1_4 = SHX2_3
      SHX2_4 = SHX3_3
      SHX2_4 = SHX2_4 + 16384
      SHX4_4 = SHX0_4
      SHX3_4 = SHX0_4.gsub
      SHX5_4 = "%x%x"
      function SHX6_4(SHX0_5)
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX1_5, SHX2_5, SHX3_5, SHX4_5, SHX5_5, SHX6_5, SHX7_5
        SHX1_5 = SHX1_4
        SHX1_5 = SHX1_5 % 274877906944
        SHX2_5 = SHX1_4
        SHX2_5 = SHX2_5 - SHX1_5
        SHX2_5 = SHX2_5 / 274877906944
        SHX3_5 = SHX2_5 % 128
        SHX4_5 = tonumber
        SHX5_5 = SHX0_5
        SHX6_5 = 16
        SHX4_5 = SHX4_5(SHX5_5, SHX6_5)
        SHX5_5 = SHX2_5 - SHX3_5
        SHX5_5 = SHX5_5 / 128
        SHX5_5 = SHX4_5 + SHX5_5
        SHX6_5 = 2 * SHX3_5
        SHX6_5 = SHX6_5 + 1
        SHX5_5 = SHX5_5 * SHX6_5
        SHX5_5 = SHX5_5 % 256
        SHX6_5 = SHX2_4
        SHX6_5 = SHX1_5 * SHX6_5
        SHX6_5 = SHX6_5 + SHX2_5
        SHX6_5 = SHX6_5 + SHX4_5
        SHX6_5 = SHX6_5 + SHX5_5
        SHX1_4 = SHX6_5
        SHX6_5 = string
        SHX6_5 = SHX6_5.char
        SHX7_5 = SHX5_5
        return SHX6_5(SHX7_5)
      end
      return SHX3_4(SHX4_4, SHX5_4, SHX6_4)
    end
    ReaperDecrypt = SHX6_3
    SHX6_3 = GetPlayerServerId
    SHX7_3 = PlayerId
    SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = SHX7_3()
    SHX6_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
    SHX7_3 = GetGameTimer
    SHX7_3 = SHX7_3()
    SHX8_3 = math
    SHX8_3 = SHX8_3.random
    SHX9_3 = 1
    SHX10_3 = 99999
    SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
    SHX7_3 = SHX7_3 + SHX8_3
    path = "=?:-1"
    hashedFunction = 698454563465465465
    failed_check = 0
    SHX8_3 = ReaperSecurityHash
    SHX9_3 = "testevent"
    SHX10_3 = SHX7_3
    SHX11_3 = hashedFunction
    SHX12_3 = "chat"
    SHX13_3 = SHX6_3
    SHX9_3 = SHX9_3 .. SHX10_3 .. SHX11_3 .. SHX12_3 .. SHX13_3
    SHX8_3 = SHX8_3(SHX9_3)
    SHX9_3 = GetInvokingResource
    SHX9_3 = SHX9_3()
    if not SHX9_3 then
      SHX9_3 = "none"
    end
    SHX10_3 = msgpack
    SHX10_3 = SHX10_3.pack_args
    SHX11_3 = "R"
    SHX12_3 = {}
    SHX12_3.v = 1
    SHX12_3.id = SHX7_3
    SHX12_3.source = SHX6_3
    SHX12_3.key = SHX8_3
    SHX13_3 = path
    SHX12_3.path = SHX13_3
    SHX13_3 = hashedFunction
    SHX12_3.key2 = SHX13_3
    SHX13_3 = ReaperSecurityHash
    SHX14_3 = SHX7_3
    SHX15_3 = failed_check
    SHX16_3 = ""
    SHX14_3 = SHX14_3 .. SHX15_3 .. SHX16_3
    SHX13_3 = SHX13_3(SHX14_3)
    SHX12_3.key3 = SHX13_3
    SHX12_3.resource = "chat"
    SHX12_3.invoking_resource = SHX9_3
    SHX13_3 = "test"
    SHX10_3 = SHX10_3(SHX11_3, SHX12_3, SHX13_3)
    SHX11_3 = TriggerServerEventInternal
    SHX12_3 = "testevent"
    SHX13_3 = SHX10_3
    SHX14_3 = string
    SHX14_3 = SHX14_3.len
    SHX15_3 = SHX10_3
    SHX14_3, SHX15_3, SHX16_3 = SHX14_3(SHX15_3)
    SHX11_3(SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = NetworkSetFriendlyFireOption
  SHX5_2 = true
  SHX4_2(SHX5_2)
end
SHX7_1 = GetConvar
SHX8_1 = "reaper_test_server"
SHX9_1 = "false"
SHX7_1 = SHX7_1(SHX8_1, SHX9_1)
if "true" == SHX7_1 then
  SHX7_1 = SHX6_1
  SHX7_1()
end
SHX8_1 = SHX2_1
SHX7_1 = SHX2_1.onNet
SHX9_1 = "RegisterTestCommands"
function SHX10_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX6_1
  SHX0_2()
end
SHX7_1(SHX8_1, SHX9_1, SHX10_1)
SHX7_1 = GetConvar
SHX8_1 = "reaper_test_server"
SHX9_1 = "false"
SHX7_1 = SHX7_1(SHX8_1, SHX9_1)
if "true" == SHX7_1 then
  SHX7_1 = RegisterCommand
  SHX8_1 = "test_native_rules"
  function SHX9_1()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2
    SHX0_2 = print
    SHX1_2 = "^3=== Testing Native Rule System ===^7"
    SHX0_2(SHX1_2)
    SHX0_2 = {}
    SHX0_2.id = "rule-weapon-1"
    SHX0_2.type = "and"
    SHX1_2 = {}
    SHX2_2 = {}
    SHX2_2.field = "req.resource"
    SHX2_2.op = "notIn"
    SHX3_2 = {}
    SHX4_2 = "esx_weaponshop"
    SHX5_2 = "police_armory"
    SHX6_2 = "admin_menu"
    SHX3_2[1] = SHX4_2
    SHX3_2[2] = SHX5_2
    SHX3_2[3] = SHX6_2
    SHX2_2.value = SHX3_2
    SHX3_2 = {}
    SHX3_2.field = "req.params.2"
    SHX3_2.op = "in"
    SHX4_2 = {}
    SHX5_2 = "weapon_rpg"
    SHX6_2 = "weapon_minigun"
    SHX7_2 = "weapon_railgun"
    SHX4_2[1] = SHX5_2
    SHX4_2[2] = SHX6_2
    SHX4_2[3] = SHX7_2
    SHX3_2.value = SHX4_2
    SHX1_2[1] = SHX2_2
    SHX1_2[2] = SHX3_2
    SHX0_2.rules = SHX1_2
    SHX1_2 = {}
    SHX2_2 = {}
    SHX2_2.resource = "some_cheat"
    SHX3_2 = {}
    SHX4_2 = PlayerPedId
    SHX4_2 = SHX4_2()
    SHX3_2[1] = SHX4_2
    SHX3_2[2] = "weapon_rpg"
    SHX3_2[3] = 100
    SHX2_2.params = SHX3_2
    SHX1_2.req = SHX2_2
    SHX2_2 = print
    SHX3_2 = "^2Test 1 - Block unauthorized weapon (should match):^7"
    SHX2_2(SHX3_2)
    SHX2_2 = NativeRules
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.evaluateRule
    SHX4_2 = SHX0_2
    SHX5_2 = SHX1_2
    SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2)
    SHX3_2 = print
    SHX4_2 = "  Result:"
    SHX5_2 = SHX2_2
    if SHX2_2 then
      SHX6_2 = "^2PASS^7"
      if SHX6_2 then
        goto SHX_LABEL_65
      end
    end
    SHX6_2 = "^1FAIL^7"
    -- [FIX IF ERROR] Move ::SHX_LABEL_65:: outside nested blocks until all 'goto SHX_LABEL_65' can see it
    ::SHX_LABEL_65::
    SHX3_2(SHX4_2, SHX5_2, SHX6_2)
    SHX3_2 = {}
    SHX3_2.id = "rule-complex-1"
    SHX3_2.type = "and"
    SHX4_2 = {}
    SHX5_2 = {}
    SHX5_2.isGroup = true
    SHX5_2.type = "or"
    SHX6_2 = {}
    SHX7_2 = {}
    SHX7_2.field = "req.resource"
    SHX7_2.op = "contains"
    SHX7_2.value = "cheat"
    SHX8_2 = {}
    SHX8_2.field = "req.executionId"
    SHX8_2.op = "regex"
    SHX8_2.value = "^unknown"
    SHX6_2[1] = SHX7_2
    SHX6_2[2] = SHX8_2
    SHX5_2.rules = SHX6_2
    SHX6_2 = {}
    SHX6_2.field = "req.params.2"
    SHX6_2.op = "eq"
    SHX6_2.value = "true"
    SHX4_2[1] = SHX5_2
    SHX4_2[2] = SHX6_2
    SHX3_2.rules = SHX4_2
    SHX4_2 = {}
    SHX5_2 = {}
    SHX5_2.resource = "my_cheat_menu"
    SHX5_2.executionId = "normal123"
    SHX6_2 = {}
    SHX7_2 = PlayerPedId
    SHX7_2 = SHX7_2()
    SHX6_2[1] = SHX7_2
    SHX6_2[2] = "true"
    SHX5_2.params = SHX6_2
    SHX4_2.req = SHX5_2
    SHX5_2 = print
    SHX6_2 = "^2Test 2 - Nested OR inside AND (should match):^7"
    SHX5_2(SHX6_2)
    SHX5_2 = NativeRules
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.evaluateRule
    SHX7_2 = SHX3_2
    SHX8_2 = SHX4_2
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    SHX6_2 = print
    SHX7_2 = "  Result:"
    SHX8_2 = SHX5_2
    if SHX5_2 then
      SHX9_2 = "^2PASS^7"
      if SHX9_2 then
        goto SHX_LABEL_128
      end
    end
    SHX9_2 = "^1FAIL^7"
    -- [FIX IF ERROR] Move ::SHX_LABEL_128:: outside nested blocks until all 'goto SHX_LABEL_128' can see it
    ::SHX_LABEL_128::
    SHX6_2(SHX7_2, SHX8_2, SHX9_2)
    SHX6_2 = {}
    SHX6_2.id = "rule-exists-1"
    SHX6_2.type = "or"
    SHX7_2 = {}
    SHX8_2 = {}
    SHX8_2.field = "req.resource"
    SHX8_2.op = "notExists"
    SHX8_2.value = nil
    SHX9_2 = {}
    SHX9_2.field = "req.executionId"
    SHX9_2.op = "notExists"
    SHX9_2.value = nil
    SHX7_2[1] = SHX8_2
    SHX7_2[2] = SHX9_2
    SHX6_2.rules = SHX7_2
    SHX7_2 = {}
    SHX8_2 = {}
    SHX8_2.executionId = "12345"
    SHX7_2.req = SHX8_2
    SHX8_2 = print
    SHX9_2 = "^2Test 3 - Check missing fields (should match):^7"
    SHX8_2(SHX9_2)
    SHX8_2 = NativeRules
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.evaluateRule
    SHX10_2 = SHX6_2
    SHX11_2 = SHX7_2
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2)
    SHX9_2 = print
    SHX10_2 = "  Result:"
    SHX11_2 = SHX8_2
    if SHX8_2 then
      SHX12_2 = "^2PASS^7"
      if SHX12_2 then
        goto SHX_LABEL_170
      end
    end
    SHX12_2 = "^1FAIL^7"
    -- [FIX IF ERROR] Move ::SHX_LABEL_170:: outside nested blocks until all 'goto SHX_LABEL_170' can see it
    ::SHX_LABEL_170::
    SHX9_2(SHX10_2, SHX11_2, SHX12_2)
    SHX9_2 = {}
    SHX10_2 = {}
    SHX10_2.resource = "esx_weaponshop"
    SHX11_2 = {}
    SHX12_2 = PlayerPedId
    SHX12_2 = SHX12_2()
    SHX11_2[1] = SHX12_2
    SHX11_2[2] = "weapon_rpg"
    SHX10_2.params = SHX11_2
    SHX9_2.req = SHX10_2
    SHX10_2 = print
    SHX11_2 = "^2Test 4 - Authorized resource (should NOT match):^7"
    SHX10_2(SHX11_2)
    SHX10_2 = NativeRules
    SHX11_2 = SHX10_2
    SHX10_2 = SHX10_2.evaluateRule
    SHX12_2 = SHX0_2
    SHX13_2 = SHX9_2
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2)
    SHX11_2 = print
    SHX12_2 = "  Result:"
    SHX13_2 = SHX10_2
    if not SHX10_2 then
      SHX14_2 = "^2PASS^7"
      if SHX14_2 then
        goto SHX_LABEL_201
      end
    end
    SHX14_2 = "^1FAIL^7"
    -- [FIX IF ERROR] Move ::SHX_LABEL_201:: outside nested blocks until all 'goto SHX_LABEL_201' can see it
    ::SHX_LABEL_201::
    SHX11_2(SHX12_2, SHX13_2, SHX14_2)
    SHX11_2 = print
    SHX12_2 = "^3=== All Tests Complete ===^7"
    SHX11_2(SHX12_2)
  end
  SHX7_1(SHX8_1, SHX9_1)
end
