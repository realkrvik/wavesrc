-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = Falcon
Falcon = SHX0_1
SHX0_1 = Falcon
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.new
SHX2_1 = "StateBags"
SHX3_1 = {}
SHX3_1.max_history_size = 60
SHX3_1.interval_seconds = 60
SHX3_1.track_subtypes = true
SHX3_1.track_sources = true
SHX0_1 = SHX0_1(SHX1_1, SHX2_1, SHX3_1)
SHX1_1 = AddStateBagChangeHandler
SHX2_1 = nil
SHX3_1 = nil
function SHX4_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX3_2 = SHX0_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.track
  SHX5_2 = SHX1_2
  SHX6_2 = SHX0_2
  SHX7_2 = false
  SHX8_2 = {}
  SHX8_2.value = SHX2_2
  SHX9_2 = os
  SHX9_2 = SHX9_2.time
  SHX9_2 = SHX9_2()
  SHX8_2.timestamp = SHX9_2
  SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX2_1 = SHX0_1
SHX1_1 = SHX0_1.registerHTTPEndpoints
SHX3_1 = "/statebag"
SHX1_1(SHX2_1, SHX3_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/statebag/bags"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = tonumber
  SHX3_2 = SHX0_2.query
  SHX3_2 = SHX3_2.limit
  SHX2_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX2_2 = 20
  end
  SHX3_2 = SHX0_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSourceBreakdown
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX6_2 = {}
  SHX7_2 = SHX3_2.top_sources
  SHX6_2.top_bags = SHX7_2
  SHX7_2 = SHX3_2.total_unique_sources
  SHX6_2.total_unique_bags = SHX7_2
  SHX5_2.data = SHX6_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/statebag/keys"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = tonumber
  SHX3_2 = SHX0_2.query
  SHX3_2 = SHX3_2.limit
  SHX2_2 = SHX2_2(SHX3_2)
  if not SHX2_2 then
    SHX2_2 = 20
  end
  SHX3_2 = SHX0_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSubtypeBreakdown
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX6_2 = {}
  SHX7_2 = SHX3_2.top_subtypes
  SHX6_2.top_keys = SHX7_2
  SHX7_2 = SHX3_2.total_unique_subtypes
  SHX6_2.total_unique_keys = SHX7_2
  SHX5_2.data = SHX6_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/statebag/bag"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = SHX0_2.query
  SHX2_2 = SHX2_2.name
  if not SHX2_2 then
    SHX3_2 = SHX1_2.status
    SHX4_2 = 400
    SHX3_2 = SHX3_2(SHX4_2)
    SHX3_2 = SHX3_2.send
    SHX4_2 = {}
    SHX4_2.success = false
    SHX4_2.error = "Missing 'name' query parameter"
    SHX3_2(SHX4_2)
    return
  end
  SHX3_2 = SHX0_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSourceDetails
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  if not SHX3_2 then
    SHX4_2 = SHX1_2.status
    SHX5_2 = 404
    SHX4_2 = SHX4_2(SHX5_2)
    SHX4_2 = SHX4_2.send
    SHX5_2 = {}
    SHX5_2.success = false
    SHX5_2.error = "Bag not found"
    SHX4_2(SHX5_2)
    return
  end
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX6_2 = {}
  SHX6_2.bag_name = SHX2_2
  SHX7_2 = SHX3_2.total_count
  SHX6_2.total_changes = SHX7_2
  SHX7_2 = SHX3_2.subtypes
  SHX6_2.keys_changed = SHX7_2
  SHX5_2.data = SHX6_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.listen
SHX3_1 = "/statebag/key"
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = SHX0_2.query
  SHX2_2 = SHX2_2.name
  if not SHX2_2 then
    SHX3_2 = SHX1_2.status
    SHX4_2 = 400
    SHX3_2 = SHX3_2(SHX4_2)
    SHX3_2 = SHX3_2.send
    SHX4_2 = {}
    SHX4_2.success = false
    SHX4_2.error = "Missing 'name' query parameter"
    SHX3_2(SHX4_2)
    return
  end
  SHX3_2 = SHX0_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getSubtypeDetails
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  if not SHX3_2 then
    SHX4_2 = SHX1_2.status
    SHX5_2 = 404
    SHX4_2 = SHX4_2(SHX5_2)
    SHX4_2 = SHX4_2.send
    SHX5_2 = {}
    SHX5_2.success = false
    SHX5_2.error = "Key not found"
    SHX4_2(SHX5_2)
    return
  end
  SHX4_2 = SHX1_2.send
  SHX5_2 = {}
  SHX5_2.success = true
  SHX6_2 = {}
  SHX6_2.key_name = SHX2_2
  SHX7_2 = SHX3_2.count
  SHX6_2.total_changes = SHX7_2
  SHX5_2.data = SHX6_2
  SHX6_2 = os
  SHX6_2 = SHX6_2.time
  SHX6_2 = SHX6_2()
  SHX5_2.timestamp = SHX6_2
  SHX4_2(SHX5_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = Command
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.add
SHX3_1 = {}
SHX3_1.command = "statebagstats"
function SHX4_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX0_2 = SHX0_1
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.getStatistics
  SHX0_2 = SHX0_2(SHX1_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "=== StateBag Statistics ==="
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Total Changes: ^3%d^7"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX0_2.totals
  SHX5_2 = SHX5_2.count
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Server Uptime: ^3%d^7 minutes (^3%s^7 hours)"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX0_2.totals
  SHX5_2 = SHX5_2.uptime_minutes
  SHX6_2 = SHX0_2.totals
  SHX6_2 = SHX6_2.uptime_hours
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Unique Bags: ^3%d^7 | Unique Keys: ^3%d^7"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX0_2.totals
  SHX5_2 = SHX5_2.unique_sources
  SHX6_2 = SHX0_2.totals
  SHX6_2 = SHX6_2.unique_subtypes
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Current Minute: ^3%d^7 changes"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX0_2.current_interval
  SHX5_2 = SHX5_2.count
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Average per Minute: ^3%s^7 changes"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX0_2.averages
  SHX5_2 = SHX5_2.per_minute
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Average per Second: ^3%s^7 changes"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX0_2.averages
  SHX5_2 = SHX5_2.per_second
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "Last 5 Minutes: ^3%d^7 changes"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX0_2.last_intervals
  SHX5_2 = SHX5_2.count
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = ""
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "=== Top 10 Keys Changed ==="
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = ipairs
  SHX2_2 = SHX0_2.top_subtypes
  SHX1_2, SHX2_2, SHX3_2, SHX4_2 = SHX1_2(SHX2_2)
  for SHX5_2, SHX6_2 in SHX1_2, SHX2_2, SHX3_2, SHX4_2 do
    if SHX5_2 > 10 then
      break
    end
    SHX7_2 = Logger
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.log
    SHX9_2 = "^3#%d^7 - %s: ^3%d^7 changes"
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.format
    SHX11_2 = SHX5_2
    SHX12_2 = SHX6_2.name
    SHX13_2 = SHX6_2.count
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2)
    SHX10_2 = "info"
    SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  end
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = ""
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "=== Top 10 Bags Changed ==="
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = ipairs
  SHX2_2 = SHX0_2.top_sources
  SHX1_2, SHX2_2, SHX3_2, SHX4_2 = SHX1_2(SHX2_2)
  for SHX5_2, SHX6_2 in SHX1_2, SHX2_2, SHX3_2, SHX4_2 do
    if SHX5_2 > 10 then
      break
    end
    SHX7_2 = Logger
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.log
    SHX9_2 = "^3#%d^7 - %s: ^3%d^7 changes"
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.format
    SHX11_2 = SHX5_2
    SHX12_2 = SHX6_2.id
    SHX13_2 = SHX6_2.count
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2)
    SHX10_2 = "info"
    SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  end
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = ""
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = GetConvar
  SHX2_2 = "web_baseUrl"
  SHX3_2 = "http://your-server-ip:30120"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX2_2 = Logger
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.log
  SHX4_2 = "Access full stats at: ^3https://%s/ReaperV4/statebag/stats^7"
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.format
  SHX6_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = "info"
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = Logger
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.log
  SHX4_2 = "Access breakdown at: ^3https://%s/ReaperV4/statebag/keys^7"
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.format
  SHX6_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = "info"
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
end
SHX3_1.callback = SHX4_1
SHX3_1.hidden = false
SHX4_1 = {}
SHX5_1 = "Manage Server"
SHX4_1[1] = SHX5_1
SHX3_1.permissions = SHX4_1
SHX1_1(SHX2_1, SHX3_1)
SHX1_1 = RPC
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.on
SHX3_1 = "reaperStarted"
function SHX4_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2
  SHX0_2 = Logger
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.log
  SHX2_2 = "StateBag monitoring system initialized (Falcon-powered)"
  SHX3_2 = "info"
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = Logger
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.log
  SHX2_2 = "Access statebag stats at ^3/ReaperV4/statebag/stats^7 or ^3/ReaperV4/statebag/summary^7"
  SHX3_2 = "debug"
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
  SHX0_2 = Logger
  SHX1_2 = SHX0_2
  SHX0_2 = SHX0_2.log
  SHX2_2 = "Performance: Direct table updates, ~0.0001ms per change"
  SHX3_2 = "debug"
  SHX0_2(SHX1_2, SHX2_2, SHX3_2)
end
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
SHX1_1 = Logger
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.log
SHX3_1 = "StateBag monitor loaded with Falcon metrics engine"
SHX4_1 = "debug"
SHX1_1(SHX2_1, SHX3_1, SHX4_1)
