-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1
function SHX0_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = {}
  XmlParser = SHX0_2
  SHX0_2 = XmlParser
  function SHX1_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX2_3 = string
    SHX2_3 = SHX2_3.gsub
    SHX3_3 = SHX1_3
    SHX4_3 = "&"
    SHX5_3 = "&amp;"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    SHX1_3 = SHX2_3
    SHX2_3 = string
    SHX2_3 = SHX2_3.gsub
    SHX3_3 = SHX1_3
    SHX4_3 = "<"
    SHX5_3 = "&lt;"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    SHX1_3 = SHX2_3
    SHX2_3 = string
    SHX2_3 = SHX2_3.gsub
    SHX3_3 = SHX1_3
    SHX4_3 = ">"
    SHX5_3 = "&gt;"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    SHX1_3 = SHX2_3
    SHX2_3 = string
    SHX2_3 = SHX2_3.gsub
    SHX3_3 = SHX1_3
    SHX4_3 = "\""
    SHX5_3 = "&quot;"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    SHX1_3 = SHX2_3
    SHX2_3 = string
    SHX2_3 = SHX2_3.gsub
    SHX3_3 = SHX1_3
    SHX4_3 = "([^%w%&%;%p%\t% ])"
    function SHX5_3(SHX0_4)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_4, SHX2_4, SHX3_4, SHX4_4
      SHX1_4 = string
      SHX1_4 = SHX1_4.format
      SHX2_4 = "&#x%X;"
      SHX3_4 = string
      SHX3_4 = SHX3_4.byte
      SHX4_4 = SHX0_4
      SHX3_4, SHX4_4 = SHX3_4(SHX4_4)
      return SHX1_4(SHX2_4, SHX3_4, SHX4_4)
    end
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    SHX1_3 = SHX2_3
    return SHX1_3
  end
  SHX0_2.ToXmlString = SHX1_2
  SHX0_2 = XmlParser
  function SHX1_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX2_3 = string
    SHX2_3 = SHX2_3.gsub
    SHX3_3 = SHX1_3
    SHX4_3 = "&#x([%x]+)%;"
    function SHX5_3(SHX0_4)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_4, SHX2_4, SHX3_4, SHX4_4
      SHX1_4 = string
      SHX1_4 = SHX1_4.char
      SHX2_4 = tonumber
      SHX3_4 = SHX0_4
      SHX4_4 = 16
      SHX2_4, SHX3_4, SHX4_4 = SHX2_4(SHX3_4, SHX4_4)
      return SHX1_4(SHX2_4, SHX3_4, SHX4_4)
    end
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    SHX1_3 = SHX2_3
    SHX2_3 = string
    SHX2_3 = SHX2_3.gsub
    SHX3_3 = SHX1_3
    SHX4_3 = "&#([0-9]+)%;"
    function SHX5_3(SHX0_4)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_4, SHX2_4, SHX3_4, SHX4_4
      SHX1_4 = string
      SHX1_4 = SHX1_4.char
      SHX2_4 = tonumber
      SHX3_4 = SHX0_4
      SHX4_4 = 10
      SHX2_4, SHX3_4, SHX4_4 = SHX2_4(SHX3_4, SHX4_4)
      return SHX1_4(SHX2_4, SHX3_4, SHX4_4)
    end
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    SHX1_3 = SHX2_3
    SHX2_3 = string
    SHX2_3 = SHX2_3.gsub
    SHX3_3 = SHX1_3
    SHX4_3 = "&quot;"
    SHX5_3 = "\""
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    SHX1_3 = SHX2_3
    SHX2_3 = string
    SHX2_3 = SHX2_3.gsub
    SHX3_3 = SHX1_3
    SHX4_3 = "&apos;"
    SHX5_3 = "'"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    SHX1_3 = SHX2_3
    SHX2_3 = string
    SHX2_3 = SHX2_3.gsub
    SHX3_3 = SHX1_3
    SHX4_3 = "&gt;"
    SHX5_3 = ">"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    SHX1_3 = SHX2_3
    SHX2_3 = string
    SHX2_3 = SHX2_3.gsub
    SHX3_3 = SHX1_3
    SHX4_3 = "&lt;"
    SHX5_3 = "<"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    SHX1_3 = SHX2_3
    SHX2_3 = string
    SHX2_3 = SHX2_3.gsub
    SHX3_3 = SHX1_3
    SHX4_3 = "&amp;"
    SHX5_3 = "&"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3, SHX5_3)
    SHX1_3 = SHX2_3
    return SHX1_3
  end
  SHX0_2.FromXmlString = SHX1_2
  SHX0_2 = XmlParser
  function SHX1_2(SHX0_3, SHX1_3, SHX2_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX3_3 = string
    SHX3_3 = SHX3_3.gsub
    SHX4_3 = SHX2_3
    SHX5_3 = "(%w+)=([\"'])(.-)%2"
    function SHX6_3(SHX0_4, SHX1_4, SHX2_4)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4, SHX8_4
      SHX3_4 = SHX1_3
      SHX4_4 = SHX3_4
      SHX3_4 = SHX3_4.addProperty
      SHX5_4 = SHX0_4
      SHX6_4 = SHX0_3
      SHX7_4 = SHX6_4
      SHX6_4 = SHX6_4.FromXmlString
      SHX8_4 = SHX2_4
      SHX6_4, SHX7_4, SHX8_4 = SHX6_4(SHX7_4, SHX8_4)
      SHX3_4(SHX4_4, SHX5_4, SHX6_4, SHX7_4, SHX8_4)
    end
    SHX3_3(SHX4_3, SHX5_3, SHX6_3)
  end
  SHX0_2.ParseArgs = SHX1_2
  SHX0_2 = XmlParser
  function SHX1_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3
    SHX2_3 = {}
    SHX3_3 = newNode
    SHX3_3 = SHX3_3()
    SHX4_3 = table
    SHX4_3 = SHX4_3.insert
    SHX5_3 = SHX2_3
    SHX6_3 = SHX3_3
    SHX4_3(SHX5_3, SHX6_3)
    SHX4_3 = nil
    SHX5_3 = nil
    SHX6_3 = nil
    SHX7_3 = nil
    SHX8_3 = nil
    SHX9_3 = 1
    SHX10_3 = 1
    while true do
      SHX11_3 = string
      SHX11_3 = SHX11_3.find
      SHX12_3 = SHX1_3
      SHX13_3 = "<(%/?)([%w_:]+)(.-)(%/?)>"
      SHX14_3 = SHX9_3
      SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3 = SHX11_3(SHX12_3, SHX13_3, SHX14_3)
      SHX8_3 = SHX16_3
      SHX7_3 = SHX15_3
      SHX6_3 = SHX14_3
      SHX5_3 = SHX13_3
      SHX10_3 = SHX12_3
      SHX4_3 = SHX11_3
      if not SHX4_3 then
        break
      end
      SHX11_3 = string
      SHX11_3 = SHX11_3.sub
      SHX12_3 = SHX1_3
      SHX13_3 = SHX9_3
      SHX14_3 = SHX4_3 - 1
      SHX11_3 = SHX11_3(SHX12_3, SHX13_3, SHX14_3)
      SHX12_3 = string
      SHX12_3 = SHX12_3.find
      SHX13_3 = SHX11_3
      SHX14_3 = "^%s*$"
      SHX12_3 = SHX12_3(SHX13_3, SHX14_3)
      if not SHX12_3 then
        SHX13_3 = SHX3_3
        SHX12_3 = SHX3_3.value
        SHX12_3 = SHX12_3(SHX13_3)
        if not SHX12_3 then
          SHX12_3 = ""
        end
        SHX14_3 = SHX0_3
        SHX13_3 = SHX0_3.FromXmlString
        SHX15_3 = SHX11_3
        SHX13_3 = SHX13_3(SHX14_3, SHX15_3)
        SHX12_3 = SHX12_3 .. SHX13_3
        SHX13_3 = #SHX2_3
        SHX13_3 = SHX2_3[SHX13_3]
        SHX14_3 = SHX13_3
        SHX13_3 = SHX13_3.setValue
        SHX15_3 = SHX12_3
        SHX13_3(SHX14_3, SHX15_3)
      end
      if "/" == SHX8_3 then
        SHX12_3 = newNode
        SHX13_3 = SHX6_3
        SHX12_3 = SHX12_3(SHX13_3)
        SHX14_3 = SHX0_3
        SHX13_3 = SHX0_3.ParseArgs
        SHX15_3 = SHX12_3
        SHX16_3 = SHX7_3
        SHX13_3(SHX14_3, SHX15_3, SHX16_3)
        SHX14_3 = SHX3_3
        SHX13_3 = SHX3_3.addChild
        SHX15_3 = SHX12_3
        SHX13_3(SHX14_3, SHX15_3)
      elseif "" == SHX5_3 then
        SHX12_3 = newNode
        SHX13_3 = SHX6_3
        SHX12_3 = SHX12_3(SHX13_3)
        SHX14_3 = SHX0_3
        SHX13_3 = SHX0_3.ParseArgs
        SHX15_3 = SHX12_3
        SHX16_3 = SHX7_3
        SHX13_3(SHX14_3, SHX15_3, SHX16_3)
        SHX13_3 = table
        SHX13_3 = SHX13_3.insert
        SHX14_3 = SHX2_3
        SHX15_3 = SHX12_3
        SHX13_3(SHX14_3, SHX15_3)
        SHX3_3 = SHX12_3
      else
        SHX12_3 = table
        SHX12_3 = SHX12_3.remove
        SHX13_3 = SHX2_3
        SHX12_3 = SHX12_3(SHX13_3)
        SHX13_3 = #SHX2_3
        SHX3_3 = SHX2_3[SHX13_3]
        SHX13_3 = #SHX2_3
        if SHX13_3 < 1 then
          SHX13_3 = error
          SHX14_3 = "XmlParser: nothing to close with "
          SHX15_3 = SHX6_3
          SHX14_3 = SHX14_3 .. SHX15_3
          SHX13_3(SHX14_3)
        end
        SHX14_3 = SHX12_3
        SHX13_3 = SHX12_3.name
        SHX13_3 = SHX13_3(SHX14_3)
        if SHX13_3 ~= SHX6_3 then
          SHX13_3 = error
          SHX14_3 = "XmlParser: trying to close "
          SHX15_3 = SHX12_3.name
          SHX16_3 = " with "
          SHX17_3 = SHX6_3
          SHX14_3 = SHX14_3 .. SHX15_3 .. SHX16_3 .. SHX17_3
          SHX13_3(SHX14_3)
        end
        SHX14_3 = SHX3_3
        SHX13_3 = SHX3_3.addChild
        SHX15_3 = SHX12_3
        SHX13_3(SHX14_3, SHX15_3)
      end
      SHX9_3 = SHX10_3 + 1
    end
    SHX11_3 = string
    SHX11_3 = SHX11_3.sub
    SHX12_3 = SHX1_3
    SHX13_3 = SHX9_3
    SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
    SHX12_3 = #SHX2_3
    if SHX12_3 > 1 then
      SHX12_3 = error
      SHX13_3 = "XmlParser: unclosed "
      SHX14_3 = #SHX2_3
      SHX14_3 = SHX2_3[SHX14_3]
      SHX15_3 = SHX14_3
      SHX14_3 = SHX14_3.name
      SHX14_3 = SHX14_3(SHX15_3)
      SHX13_3 = SHX13_3 .. SHX14_3
      SHX12_3(SHX13_3)
    end
    return SHX3_3
  end
  SHX0_2.ParseXmlText = SHX1_2
  SHX0_2 = XmlParser
  return SHX0_2
end
newParser = SHX0_1
function SHX0_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = {}
  SHX1_2.___value = nil
  SHX1_2.___name = SHX0_2
  SHX2_2 = {}
  SHX1_2.___children = SHX2_2
  SHX2_2 = {}
  SHX1_2.___props = SHX2_2
  function SHX2_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3
    SHX1_3 = SHX0_3.___value
    return SHX1_3
  end
  SHX1_2.value = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    SHX0_3.___value = SHX1_3
  end
  SHX1_2.setValue = SHX2_2
  function SHX2_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3
    SHX1_3 = SHX0_3.___name
    return SHX1_3
  end
  SHX1_2.name = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    SHX0_3.___name = SHX1_3
  end
  SHX1_2.setName = SHX2_2
  function SHX2_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3
    SHX1_3 = SHX0_3.___children
    return SHX1_3
  end
  SHX1_2.children = SHX2_2
  function SHX2_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3
    SHX1_3 = SHX0_3.___children
    SHX1_3 = #SHX1_3
    return SHX1_3
  end
  SHX1_2.numChildren = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX3_3 = SHX1_3
    SHX2_3 = SHX1_3.name
    SHX2_3 = SHX2_3(SHX3_3)
    SHX2_3 = SHX0_3[SHX2_3]
    if nil ~= SHX2_3 then
      SHX2_3 = type
      SHX4_3 = SHX1_3
      SHX3_3 = SHX1_3.name
      SHX3_3 = SHX3_3(SHX4_3)
      SHX3_3 = SHX0_3[SHX3_3]
      SHX3_3 = SHX3_3.name
      SHX2_3 = SHX2_3(SHX3_3)
      if "function" == SHX2_3 then
        SHX2_3 = {}
        SHX3_3 = table
        SHX3_3 = SHX3_3.insert
        SHX4_3 = SHX2_3
        SHX6_3 = SHX1_3
        SHX5_3 = SHX1_3.name
        SHX5_3 = SHX5_3(SHX6_3)
        SHX5_3 = SHX0_3[SHX5_3]
        SHX3_3(SHX4_3, SHX5_3)
        SHX4_3 = SHX1_3
        SHX3_3 = SHX1_3.name
        SHX3_3 = SHX3_3(SHX4_3)
        SHX0_3[SHX3_3] = SHX2_3
      end
      SHX2_3 = table
      SHX2_3 = SHX2_3.insert
      SHX4_3 = SHX1_3
      SHX3_3 = SHX1_3.name
      SHX3_3 = SHX3_3(SHX4_3)
      SHX3_3 = SHX0_3[SHX3_3]
      SHX4_3 = SHX1_3
      SHX2_3(SHX3_3, SHX4_3)
    else
      SHX3_3 = SHX1_3
      SHX2_3 = SHX1_3.name
      SHX2_3 = SHX2_3(SHX3_3)
      SHX0_3[SHX2_3] = SHX1_3
    end
    SHX2_3 = table
    SHX2_3 = SHX2_3.insert
    SHX3_3 = SHX0_3.___children
    SHX4_3 = SHX1_3
    SHX2_3(SHX3_3, SHX4_3)
  end
  SHX1_2.addChild = SHX2_2
  function SHX2_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3
    SHX1_3 = SHX0_3.___props
    return SHX1_3
  end
  SHX1_2.properties = SHX2_2
  function SHX2_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3
    SHX1_3 = SHX0_3.___props
    SHX1_3 = #SHX1_3
    return SHX1_3
  end
  SHX1_2.numProperties = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3, SHX2_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX3_3 = "@"
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3 .. SHX4_3
    SHX4_3 = SHX0_3[SHX3_3]
    if nil ~= SHX4_3 then
      SHX4_3 = type
      SHX5_3 = SHX0_3[SHX3_3]
      SHX4_3 = SHX4_3(SHX5_3)
      if "string" == SHX4_3 then
        SHX4_3 = {}
        SHX5_3 = table
        SHX5_3 = SHX5_3.insert
        SHX6_3 = SHX4_3
        SHX7_3 = SHX0_3[SHX3_3]
        SHX5_3(SHX6_3, SHX7_3)
        SHX0_3[SHX3_3] = SHX4_3
      end
      SHX4_3 = table
      SHX4_3 = SHX4_3.insert
      SHX5_3 = SHX0_3[SHX3_3]
      SHX6_3 = SHX2_3
      SHX4_3(SHX5_3, SHX6_3)
    else
      SHX0_3[SHX3_3] = SHX2_3
    end
    SHX4_3 = table
    SHX4_3 = SHX4_3.insert
    SHX5_3 = SHX0_3.___props
    SHX6_3 = {}
    SHX6_3.name = SHX1_3
    SHX7_3 = SHX0_3[SHX1_3]
    SHX6_3.value = SHX7_3
    SHX4_3(SHX5_3, SHX6_3)
  end
  SHX1_2.addProperty = SHX2_2
  return SHX1_2
end
newNode = SHX0_1
