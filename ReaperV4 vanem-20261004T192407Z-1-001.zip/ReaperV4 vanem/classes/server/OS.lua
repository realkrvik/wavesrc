-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1
SHX0_1 = Logger
SHX1_1 = os
function SHX2_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX1_2 = SHX0_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "^1Reaper is shutting down the server - ^3%s"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX0_2 or SHX5_2
  if not SHX0_2 then
    SHX5_2 = "No Reason"
  end
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = "warn"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Wait
  SHX2_2 = 6000
  SHX1_2(SHX2_2)
  SHX1_2 = IsPrincipalAceAllowed
  SHX2_2 = "resource.ReaperV4"
  SHX3_2 = "command.quit"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  if false ~= SHX1_2 then
    goto SHX_LABEL_21
  end
  while true do
  end
  -- [FIX IF ERROR] Move ::SHX_LABEL_21:: outside nested blocks until all 'goto SHX_LABEL_21' can see it
  ::SHX_LABEL_21::
  SHX1_2 = ExecuteCommand
  SHX2_2 = "quit"
  SHX1_2(SHX2_2)
end
SHX1_1.exit = SHX2_1
