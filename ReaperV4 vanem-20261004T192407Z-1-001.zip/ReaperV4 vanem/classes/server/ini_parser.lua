-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1
SHX0_1 = class
SHX1_1 = "IniParserServer"
SHX0_1 = SHX0_1(SHX1_1)
SHX1_1 = LoadResourceFile
function SHX2_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = json
  SHX1_2 = SHX1_2.decode
  SHX2_2 = SHX1_1
  SHX3_2 = "ReaperV4"
  SHX4_2 = "data_files/weapons.json"
  SHX2_2, SHX3_2, SHX4_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX0_2.weapon_data = SHX1_2
end
SHX0_1.constructor = SHX2_1
function SHX2_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2
  SHX2_2 = SHX1_1
  SHX3_2 = "ReaperV4"
  SHX4_2 = "data_files/%s"
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.format
  SHX6_2 = SHX1_2
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2)
  if nil == SHX2_2 then
    SHX3_2 = {}
    return SHX3_2
  end
  SHX3_2 = {}
  SHX4_2 = SHX3_2
  SHX5_2 = pairs
  SHX6_2 = string
  SHX6_2 = SHX6_2.split
  SHX7_2 = SHX2_2
  SHX8_2 = "\n"
  SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2)
  for SHX9_2, SHX10_2 in SHX5_2, SHX6_2, SHX7_2, SHX8_2 do
    SHX12_2 = SHX10_2
    SHX11_2 = SHX10_2.match
    SHX13_2 = "^%s*(.-)%s*$"
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
    SHX10_2 = SHX11_2
    SHX12_2 = SHX10_2
    SHX11_2 = SHX10_2.match
    SHX13_2 = "^%[.-%]$"
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
    if SHX11_2 then
      SHX12_2 = SHX10_2
      SHX11_2 = SHX10_2.match
      SHX13_2 = "^%[(.-)%]$"
      SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
      SHX12_2 = {}
      SHX4_2 = SHX12_2
      SHX3_2[SHX11_2] = SHX4_2
    else
      SHX12_2 = SHX10_2
      SHX11_2 = SHX10_2.match
      SHX13_2 = "^[^%[%]=]+=[^%[%]=]*$"
      SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
      if SHX11_2 then
        SHX12_2 = SHX10_2
        SHX11_2 = SHX10_2.match
        SHX13_2 = "^(.-)=(.*)$"
        SHX11_2, SHX12_2 = SHX11_2(SHX12_2, SHX13_2)
        SHX14_2 = SHX11_2
        SHX13_2 = SHX11_2.match
        SHX15_2 = "^%s*(.-)%s*$"
        SHX13_2 = SHX13_2(SHX14_2, SHX15_2)
        SHX15_2 = SHX12_2
        SHX14_2 = SHX12_2.match
        SHX16_2 = "^%s*(.-)%s*$"
        SHX14_2 = SHX14_2(SHX15_2, SHX16_2)
        SHX4_2[SHX13_2] = SHX14_2
      end
    end
  end
  return SHX3_2
end
SHX0_1.parseFile = SHX2_1
SHX3_1 = SHX0_1
SHX2_1 = SHX0_1.new
SHX2_1 = SHX2_1(SHX3_1)
IniParser = SHX2_1
