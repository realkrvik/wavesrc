-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = class
SHX1_1 = "ExecutionCheck"
SHX0_1 = SHX0_1(SHX1_1)
ExecutionCheck = SHX0_1
SHX0_1 = ExecutionCheck
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = json
  SHX1_2 = SHX1_2.decode
  SHX2_2 = LoadResourceFile
  SHX3_2 = "ReaperV4"
  SHX4_2 = "cache/executions_list.json"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if not SHX2_2 then
    SHX2_2 = "{}"
  end
  SHX1_2 = SHX1_2(SHX2_2)
  SHX0_2.execution_list = SHX1_2
  SHX1_2 = {}
  SHX0_2.ignoredPlayers = SHX1_2
  SHX0_2.auto_whitelist_all = false
  SHX1_2 = {}
  SHX0_2.auto_whitelist_resource = SHX1_2
  SHX1_2 = AddEventHandler
  SHX2_2 = "ProAddon:AddWhitelister"
  function SHX3_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3
    SHX1_3 = source
    if "" == SHX1_3 then
      SHX1_3 = GetInvokingResource
      SHX1_3 = SHX1_3()
      if "ReaperV4" == SHX1_3 then
        goto SHX_LABEL_9
      end
    end
    return
    -- [FIX IF ERROR] Move ::SHX_LABEL_9:: outside nested blocks until all 'goto SHX_LABEL_9' can see it
    ::SHX_LABEL_9::
    SHX1_3 = SHX0_2.ignoredPlayers
    SHX2_3 = tostring
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX1_3[SHX2_3] = true
  end
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = ReaperAC
  SHX1_2 = SHX1_2.API
  SHX1_2 = SHX1_2.RegisterEventAsServerOnly
  SHX2_2 = "ProAddon:AddWhitelister"
  SHX1_2(SHX2_2)
  SHX1_2 = AddEventHandler
  SHX2_2 = "Reaper:ProAddonAutoWhitelist"
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3
    SHX2_3 = source
    if "" == SHX2_3 then
      SHX2_3 = GetInvokingResource
      SHX2_3 = SHX2_3()
      if "ReaperV4" == SHX2_3 then
        goto SHX_LABEL_9
      end
    end
    return
    -- [FIX IF ERROR] Move ::SHX_LABEL_9:: outside nested blocks until all 'goto SHX_LABEL_9' can see it
    ::SHX_LABEL_9::
    if "all" ~= SHX0_3 then
      SHX2_3 = GetResourceState
      SHX3_3 = SHX0_3
      SHX2_3 = SHX2_3(SHX3_3)
      if "started" == SHX2_3 then
        SHX2_3 = SHX0_2.auto_whitelist_resource
        SHX2_3[SHX0_3] = SHX1_3
      end
    end
    if "all" == SHX0_3 then
      SHX0_2.auto_whitelist_all = SHX1_3
    end
  end
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = ReaperAC
  SHX1_2 = SHX1_2.API
  SHX1_2 = SHX1_2.RegisterEventAsServerOnly
  SHX2_2 = "Reaper:ProAddonAutoWhitelist"
  SHX1_2(SHX2_2)
end
SHX0_1.constructor = SHX1_1
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = ExecutionCheck
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = json
  SHX1_2 = SHX1_2.decode
  SHX2_2 = LoadResourceFile
  SHX3_2 = "ReaperV4"
  SHX4_2 = "cache/executions_list.json"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if not SHX2_2 then
    SHX2_2 = "{}"
  end
  SHX1_2 = SHX1_2(SHX2_2)
  SHX0_2.execution_list = SHX1_2
end
SHX0_1.refresh_list = SHX1_1
SHX0_1 = ExecutionCheck
function SHX1_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2
  SHX7_2 = GetConvar
  SHX8_2 = "reaper_pro_addon_enabled"
  SHX9_2 = "false"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  if "false" == SHX7_2 then
    SHX7_2 = true
    return SHX7_2
  end
  SHX7_2 = SHX0_2.execution_list
  SHX7_2 = SHX7_2[SHX2_2]
  if nil == SHX7_2 then
    SHX7_2 = SHX0_2.execution_list
    SHX8_2 = {}
    SHX7_2[SHX2_2] = SHX8_2
  end
  SHX7_2 = SHX0_2.execution_list
  SHX7_2 = SHX7_2[SHX2_2]
  SHX8_2 = tostring
  SHX9_2 = SHX3_2
  SHX8_2 = SHX8_2(SHX9_2)
  SHX7_2 = SHX7_2[SHX8_2]
  if not SHX7_2 then
    SHX7_2 = false
  end
  SHX8_2 = Player
  SHX9_2 = SHX1_2
  SHX8_2 = SHX8_2(SHX9_2)
  if not SHX8_2 then
    SHX9_2 = false
    return SHX9_2
  end
  if not SHX7_2 then
    SHX9_2 = SHX0_2.ignoredPlayers
    SHX10_2 = tostring
    SHX12_2 = SHX8_2
    SHX11_2 = SHX8_2.getId
    SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX11_2(SHX12_2)
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    SHX9_2 = SHX9_2[SHX10_2]
    if not SHX9_2 then
      SHX9_2 = SHX0_2.auto_whitelist_all
      if not SHX9_2 then
        SHX9_2 = SHX0_2.auto_whitelist_resource
        SHX9_2 = SHX9_2[SHX5_2]
        if not SHX9_2 then
          goto SHX_LABEL_111
        end
      end
    end
    SHX9_2 = Logger
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.log
    SHX11_2 = "(^3%s('%s')^7) (^3%s^7) sent from (^3%s^7) by (^3%s^7) (^3id:%s^7) was auto whitelisted"
    SHX12_2 = SHX11_2
    SHX11_2 = SHX11_2.format
    SHX13_2 = SHX2_2
    SHX14_2 = SHX6_2
    SHX15_2 = SHX3_2
    SHX16_2 = SHX4_2
    SHX18_2 = SHX8_2
    SHX17_2 = SHX8_2.getName
    SHX17_2 = SHX17_2(SHX18_2)
    SHX19_2 = SHX8_2
    SHX18_2 = SHX8_2.getId
    SHX18_2, SHX19_2 = SHX18_2(SHX19_2)
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    SHX12_2 = "warn"
    SHX9_2(SHX10_2, SHX11_2, SHX12_2)
    SHX9_2 = SHX0_2.execution_list
    SHX9_2 = SHX9_2[SHX2_2]
    if not SHX9_2 then
      SHX9_2 = {}
    end
    SHX10_2 = tostring
    SHX11_2 = SHX3_2
    SHX10_2 = SHX10_2(SHX11_2)
    SHX11_2 = {}
    SHX11_2.type = SHX2_2
    SHX11_2.param = SHX6_2
    SHX11_2.resource = SHX5_2
    SHX11_2.path = SHX4_2
    SHX11_2.key = SHX3_2
    SHX13_2 = SHX8_2
    SHX12_2 = SHX8_2.getIdentifier
    SHX14_2 = "license"
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
    SHX11_2.license = SHX12_2
    SHX12_2 = SHX0_2.ignoredPlayers
    SHX13_2 = tostring
    SHX15_2 = SHX8_2
    SHX14_2 = SHX8_2.getId
    SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX14_2(SHX15_2)
    SHX13_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    SHX12_2 = SHX12_2[SHX13_2]
    SHX11_2.ignored_player = SHX12_2
    SHX12_2 = SHX0_2.auto_whitelist_all
    SHX11_2.auto_whitelist_all = SHX12_2
    SHX12_2 = SHX0_2.auto_whitelist_resource
    SHX12_2 = SHX12_2[SHX5_2]
    SHX11_2.auto_whitelist_resource = SHX12_2
    SHX9_2[SHX10_2] = SHX11_2
    SHX9_2 = json
    SHX9_2 = SHX9_2.encode
    SHX10_2 = SHX0_2.execution_list
    SHX9_2 = SHX9_2(SHX10_2)
    SHX10_2 = SaveResourceFile
    SHX11_2 = "ReaperV4"
    SHX12_2 = "cache/executions_list.json"
    SHX13_2 = SHX9_2
    SHX15_2 = SHX9_2
    SHX14_2 = SHX9_2.len
    SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX14_2(SHX15_2)
    SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    SHX10_2 = true
    return SHX10_2
    -- [FIX IF ERROR] Move ::SHX_LABEL_111:: outside nested blocks until all 'goto SHX_LABEL_111' can see it
    ::SHX_LABEL_111::
    SHX9_2 = RPC
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.emitLocal
    SHX11_2 = "Reaper:UnknownExecutionPath"
    SHX12_2 = {}
    SHX12_2.type = SHX2_2
    SHX12_2.resource = SHX5_2
    SHX12_2.param = SHX6_2
    SHX12_2.path = SHX4_2
    SHX12_2.key = SHX3_2
    SHX14_2 = SHX8_2
    SHX13_2 = SHX8_2.getId
    SHX13_2 = SHX13_2(SHX14_2)
    SHX12_2.source = SHX13_2
    SHX13_2 = "%s(%s)"
    SHX14_2 = SHX13_2
    SHX13_2 = SHX13_2.format
    SHX15_2 = SHX2_2
    SHX16_2 = SHX6_2
    SHX13_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2)
    SHX12_2.execution_type = SHX13_2
    SHX9_2(SHX10_2, SHX11_2, SHX12_2)
    SHX9_2 = false
    return SHX9_2
  end
  SHX9_2 = true
  return SHX9_2
end
SHX0_1.execution_valid = SHX1_1
SHX0_1 = ExecutionCheck
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX2_2 = SHX0_2.execution_list
  SHX3_2 = SHX1_2.type
  SHX2_2 = SHX2_2[SHX3_2]
  if nil == SHX2_2 then
    SHX2_2 = SHX0_2.execution_list
    SHX3_2 = SHX1_2.type
    SHX4_2 = {}
    SHX2_2[SHX3_2] = SHX4_2
  end
  SHX2_2 = SHX0_2.execution_list
  SHX3_2 = SHX1_2.type
  SHX2_2 = SHX2_2[SHX3_2]
  SHX3_2 = tostring
  SHX4_2 = SHX1_2.key
  SHX3_2 = SHX3_2(SHX4_2)
  SHX2_2[SHX3_2] = SHX1_2
  SHX2_2 = json
  SHX2_2 = SHX2_2.encode
  SHX3_2 = SHX0_2.execution_list
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SaveResourceFile
  SHX4_2 = "ReaperV4"
  SHX5_2 = "cache/executions_list.json"
  SHX6_2 = SHX2_2
  SHX8_2 = SHX2_2
  SHX7_2 = SHX2_2.len
  SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX7_2(SHX8_2)
  SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "(^3%s('%s')^7) (^3%s^7) sent from (^3%s^7) by (^3%s^7) (^3id:%s^7) was whitelisted"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX1_2.type
  SHX8_2 = SHX1_2.param
  SHX9_2 = SHX1_2.key
  SHX10_2 = SHX1_2.path
  SHX11_2 = SHX1_2.player_name
  SHX12_2 = SHX1_2.source
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  SHX6_2 = "info"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = true
  return SHX3_2
end
SHX0_1.add_execution = SHX1_1
SHX0_1 = ExecutionCheck
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.new
SHX0_1 = SHX0_1(SHX1_1)
ExecutionCheck = SHX0_1
