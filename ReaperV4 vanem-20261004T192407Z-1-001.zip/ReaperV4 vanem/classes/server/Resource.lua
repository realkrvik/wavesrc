-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1
SHX0_1 = class
SHX1_1 = "Resource"
SHX0_1 = SHX0_1(SHX1_1)
SHX1_1 = RPC
RPC = SHX1_1
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX0_2.name = SHX1_2
  SHX2_2 = GetResourceState
  SHX3_2 = SHX1_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX0_2.state = SHX2_2
  SHX2_2 = GetResourceMetadata
  SHX3_2 = SHX1_2
  SHX4_2 = "fx_version"
  SHX5_2 = 0
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX0_2.fx_version = SHX2_2
  SHX2_2 = GetResourceMetadata
  SHX3_2 = SHX1_2
  SHX4_2 = "game"
  SHX5_2 = 0
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX0_2.game = SHX2_2
  SHX2_2 = GetResourceMetadata
  SHX3_2 = SHX1_2
  SHX4_2 = "author"
  SHX5_2 = 0
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX0_2.author = SHX2_2
  SHX2_2 = GetResourceMetadata
  SHX3_2 = SHX1_2
  SHX4_2 = "version"
  SHX5_2 = 0
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX0_2.version = SHX2_2
  SHX2_2 = GetResourceMetadata
  SHX3_2 = SHX1_2
  SHX4_2 = "description"
  SHX5_2 = 0
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX0_2.description = SHX2_2
  SHX2_2 = GetResourceMetadata
  SHX3_2 = SHX1_2
  SHX4_2 = "this_is_a_map"
  SHX5_2 = 0
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX0_2.this_is_a_map = SHX2_2
  SHX2_2 = GetResourceMetadata
  SHX3_2 = SHX1_2
  SHX4_2 = "this_is_a_map"
  SHX5_2 = 0
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX0_2.lua54 = SHX2_2
  SHX2_2 = LoadResourceFile
  SHX3_2 = SHX1_2
  SHX4_2 = ".fxap"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = nil ~= SHX2_2
  SHX0_2.escrow_resource = SHX2_2
  SHX0_2.weapons_resource = false
  SHX2_2 = {}
  SHX0_2.vulnerabilities = SHX2_2
  SHX2_2 = {}
  SHX0_2.DATA_FILES = SHX2_2
  SHX2_2 = GetNumResourceMetadata
  SHX3_2 = SHX1_2
  SHX4_2 = "data_file_extra"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX3_2 = 0
  SHX4_2 = SHX2_2
  SHX5_2 = 1
  for SHX6_2 = SHX3_2, SHX4_2, SHX5_2 do
    SHX7_2 = GetResourceMetadata
    SHX8_2 = SHX1_2
    SHX9_2 = "data_file"
    SHX10_2 = SHX6_2
    SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2)
    SHX8_2 = GetResourceMetadata
    SHX9_2 = SHX1_2
    SHX10_2 = "data_file_extra"
    SHX11_2 = SHX6_2
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2)
    if not SHX8_2 then
      SHX8_2 = ""
    end
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.gsub
    SHX10_2 = "\""
    SHX11_2 = ""
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2)
    if "WEAPONINFO_FILE" == SHX7_2 then
      SHX0_2.weapons_resource = true
    end
    if SHX7_2 then
      SHX9_2 = SHX0_2.DATA_FILES
      SHX9_2 = SHX9_2[SHX7_2]
      if nil == SHX9_2 then
        SHX9_2 = SHX0_2.DATA_FILES
        SHX10_2 = {}
        SHX9_2[SHX7_2] = SHX10_2
      end
      SHX9_2 = table
      SHX9_2 = SHX9_2.insert
      SHX10_2 = SHX0_2.DATA_FILES
      SHX10_2 = SHX10_2[SHX7_2]
      SHX11_2 = SHX8_2
      SHX9_2(SHX10_2, SHX11_2)
    end
  end
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "^3%s^7 was just registered as a resource"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX8_2 = SHX1_2
  SHX7_2 = SHX1_2.gsub
  SHX9_2 = "%%20"
  SHX10_2 = " "
  SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  SHX6_2 = "debug"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
end
SHX0_1.constructor = SHX1_1
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = SHX0_2.name
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.gsub
  SHX3_2 = "%%20"
  SHX4_2 = " "
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  return SHX1_2
end
SHX0_1.getName = SHX1_1
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.state
  return SHX1_2
end
SHX0_1.getState = SHX1_1
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.version
  return SHX1_2
end
SHX0_1.getVersion = SHX1_1
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.escrow_resource
  return SHX1_2
end
SHX0_1.isEscrowLocked = SHX1_1
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.weapons_resource
  return SHX1_2
end
SHX0_1.isWeaponsResource = SHX1_1
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.DATA_FILES
  return SHX1_2
end
SHX0_1.getDataFiles = SHX1_1
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2
  SHX2_2 = SHX0_2.DATA_FILES
  SHX2_2 = SHX2_2[SHX1_2]
  if not SHX2_2 then
    SHX2_2 = {}
  end
  return SHX2_2
end
SHX0_1.getDataFile = SHX1_1
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  SHX2_2 = table
  SHX2_2 = SHX2_2.includes
  SHX3_2 = SHX0_2.vulnerabilities
  SHX4_2 = SHX1_2
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if not SHX2_2 then
    SHX2_2 = table
    SHX2_2 = SHX2_2.insert
    SHX3_2 = SHX0_2.vulnerabilities
    SHX4_2 = SHX1_2
    SHX2_2(SHX3_2, SHX4_2)
  end
  SHX2_2 = 1
  return SHX2_2
end
SHX0_1.addVulnerability = SHX1_1
SHX1_1 = {}
function SHX2_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = SHX1_1
  SHX1_2 = SHX1_2[SHX0_2]
  if nil == SHX1_2 then
    SHX1_2 = type
    SHX2_2 = SHX0_2
    SHX1_2 = SHX1_2(SHX2_2)
    if "string" == SHX1_2 then
      SHX1_2 = GetResourceState
      SHX2_2 = SHX0_2
      SHX1_2 = SHX1_2(SHX2_2)
      if "missing" ~= SHX1_2 then
        goto SHX_LABEL_17
      end
    end
    SHX1_2 = nil
    return SHX1_2
    -- [FIX IF ERROR] Move ::SHX_LABEL_17:: outside nested blocks until all 'goto SHX_LABEL_17' can see it
    ::SHX_LABEL_17::
    SHX1_2 = SHX1_1
    SHX2_2 = SHX0_1
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.new
    SHX4_2 = SHX0_2
    SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
    SHX1_2[SHX0_2] = SHX2_2
  end
  SHX1_2 = SHX1_1
  SHX1_2 = SHX1_2[SHX0_2]
  return SHX1_2
end
Resource = SHX2_1
function SHX2_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX1_1
  return SHX0_2
end
GetAllResources = SHX2_1
