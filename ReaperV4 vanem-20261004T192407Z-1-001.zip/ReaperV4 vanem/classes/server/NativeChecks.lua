-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = class
SHX1_1 = "NativeRulesServer"
SHX0_1 = SHX0_1(SHX1_1)
SHX1_1 = Logger
Logger = SHX1_1
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = {}
  SHX0_2.rules = SHX1_2
  SHX1_2 = {}
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = tostring
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = tostring
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX2_3 = SHX2_3 == SHX3_3
    return SHX2_3
  end
  SHX1_2.eq = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = tostring
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = tostring
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX2_3 = SHX2_3 ~= SHX3_3
    return SHX2_3
  end
  SHX1_2.neq = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = tonumber
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = tonumber
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    if nil == SHX2_3 or nil == SHX3_3 then
      SHX4_3 = false
      return SHX4_3
    end
    SHX4_3 = SHX2_3 > SHX3_3
    return SHX4_3
  end
  SHX1_2.gt = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = tonumber
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = tonumber
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    if nil == SHX2_3 or nil == SHX3_3 then
      SHX4_3 = false
      return SHX4_3
    end
    SHX4_3 = SHX2_3 < SHX3_3
    return SHX4_3
  end
  SHX1_2.lt = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = tonumber
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = tonumber
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    if nil == SHX2_3 or nil == SHX3_3 then
      SHX4_3 = false
      return SHX4_3
    end
    SHX4_3 = SHX2_3 >= SHX3_3
    return SHX4_3
  end
  SHX1_2.gte = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = tonumber
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = tonumber
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    if nil == SHX2_3 or nil == SHX3_3 then
      SHX4_3 = false
      return SHX4_3
    end
    SHX4_3 = SHX2_3 <= SHX3_3
    return SHX4_3
  end
  SHX1_2.lte = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3
    SHX2_3 = tostring
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = tostring
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.find
    SHX6_3 = SHX3_3
    SHX7_3 = 1
    SHX8_3 = true
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
    SHX4_3 = nil ~= SHX4_3
    return SHX4_3
  end
  SHX1_2.contains = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3
    SHX2_3 = tostring
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = tostring
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.find
    SHX6_3 = SHX3_3
    SHX7_3 = 1
    SHX8_3 = true
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
    SHX4_3 = nil == SHX4_3
    return SHX4_3
  end
  SHX1_2.notContains = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX2_3 = tostring
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = tostring
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.sub
    SHX6_3 = 1
    SHX7_3 = #SHX3_3
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    SHX4_3 = SHX4_3 == SHX3_3
    return SHX4_3
  end
  SHX1_2.startsWith = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = tostring
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = tostring
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.sub
    SHX6_3 = #SHX3_3
    SHX6_3 = -SHX6_3
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX4_3 = SHX4_3 == SHX3_3
    return SHX4_3
  end
  SHX1_2.endsWith = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = tostring
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = tostring
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.match
    SHX6_3 = SHX3_3
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX4_3 = nil ~= SHX4_3
    return SHX4_3
  end
  SHX1_2.regex = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = tostring
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = tostring
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.match
    SHX6_3 = SHX3_3
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX4_3 = nil == SHX4_3
    return SHX4_3
  end
  SHX1_2.notRegex = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX2_3 = type
    SHX3_3 = SHX1_3
    SHX2_3 = SHX2_3(SHX3_3)
    if "table" ~= SHX2_3 then
      SHX2_3 = false
      return SHX2_3
    end
    SHX2_3 = pairs
    SHX3_3 = SHX1_3
    SHX2_3, SHX3_3, SHX4_3, SHX5_3 = SHX2_3(SHX3_3)
    for SHX6_3, SHX7_3 in SHX2_3, SHX3_3, SHX4_3, SHX5_3 do
      SHX8_3 = tostring
      SHX9_3 = SHX0_3
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = SHX8_3
      SHX8_3 = SHX8_3.lower
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = tostring
      SHX10_3 = SHX7_3
      SHX9_3 = SHX9_3(SHX10_3)
      SHX10_3 = SHX9_3
      SHX9_3 = SHX9_3.lower
      SHX9_3 = SHX9_3(SHX10_3)
      if SHX8_3 == SHX9_3 then
        SHX8_3 = true
        return SHX8_3
      end
    end
    SHX2_3 = false
    return SHX2_3
  end
  SHX1_2["in"] = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX2_3 = type
    SHX3_3 = SHX1_3
    SHX2_3 = SHX2_3(SHX3_3)
    if "table" ~= SHX2_3 then
      SHX2_3 = true
      return SHX2_3
    end
    SHX2_3 = pairs
    SHX3_3 = SHX1_3
    SHX2_3, SHX3_3, SHX4_3, SHX5_3 = SHX2_3(SHX3_3)
    for SHX6_3, SHX7_3 in SHX2_3, SHX3_3, SHX4_3, SHX5_3 do
      SHX8_3 = tostring
      SHX9_3 = SHX0_3
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = SHX8_3
      SHX8_3 = SHX8_3.lower
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = tostring
      SHX10_3 = SHX7_3
      SHX9_3 = SHX9_3(SHX10_3)
      SHX10_3 = SHX9_3
      SHX9_3 = SHX9_3.lower
      SHX9_3 = SHX9_3(SHX10_3)
      if SHX8_3 == SHX9_3 then
        SHX8_3 = false
        return SHX8_3
      end
    end
    SHX2_3 = true
    return SHX2_3
  end
  SHX1_2.notIn = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3
    SHX2_3 = nil ~= SHX0_3
    return SHX2_3
  end
  SHX1_2.exists = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3
    SHX2_3 = nil == SHX0_3
    return SHX2_3
  end
  SHX1_2.notExists = SHX2_2
  SHX0_2.operators = SHX1_2
  while true do
    SHX1_2 = RPC
    if SHX1_2 then
      break
    end
    SHX1_2 = Wait
    SHX2_2 = 0
    SHX1_2(SHX2_2)
  end
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.on
  SHX3_2 = "configUpdated"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = SHX0_2
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.build_natives
    SHX0_3(SHX1_3)
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.register
  SHX3_2 = "native_evaluation_failed"
  function SHX4_2(SHX0_3, SHX1_3, SHX2_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3
    SHX3_3 = Player
    SHX4_3 = SHX0_3
    SHX3_3 = SHX3_3(SHX4_3)
    if nil == SHX3_3 then
      SHX4_3 = {}
      SHX4_3.success = false
      return SHX4_3
    end
    SHX4_3 = SHX0_2
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.getRuleById
    SHX6_3 = SHX1_3
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    if nil == SHX4_3 then
      SHX5_3 = {}
      SHX5_3.success = false
      return SHX5_3
    end
    SHX5_3 = SHX4_3.action
    if "debug" == SHX5_3 then
      SHX6_3 = SHX3_3
      SHX5_3 = SHX3_3.NewLog
      SHX7_3 = "^3%s^7 (^3id:%s^7) just executed ^3%s^7 from ^3%s^7 (^3execution:%s^7) (^3extended:%s^7)"
      SHX8_3 = SHX7_3
      SHX7_3 = SHX7_3.format
      SHX10_3 = SHX3_3
      SHX9_3 = SHX3_3.getName
      SHX9_3 = SHX9_3(SHX10_3)
      SHX11_3 = SHX3_3
      SHX10_3 = SHX3_3.getId
      SHX10_3 = SHX10_3(SHX11_3)
      SHX11_3 = SHX4_3.native
      SHX12_3 = SHX2_3.req
      SHX12_3 = SHX12_3.path
      SHX13_3 = SHX2_3.req
      SHX13_3 = SHX13_3.executionId
      SHX14_3 = SHX2_3.req
      SHX14_3 = SHX14_3.extendedExecutionId
      SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3)
      SHX8_3 = "info"
      SHX9_3 = "native_rules"
      SHX10_3 = {}
      SHX10_3.rule = SHX4_3
      SHX10_3.data = SHX2_3
      SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
      SHX5_3 = {}
      SHX5_3.success = true
      SHX5_3.continue = true
      return SHX5_3
    else
      SHX6_3 = SHX3_3
      SHX5_3 = SHX3_3.newDetection
      SHX7_3 = "failedNativeCheck"
      SHX8_3 = {}
      SHX8_3.rule = SHX4_3
      SHX8_3.data = SHX2_3
      SHX9_3 = {}
      SHX10_3 = SHX4_3.native
      SHX9_3[1] = SHX10_3
      SHX10_3 = SHX4_3.action
      SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
    end
    SHX5_3 = {}
    SHX5_3.success = true
    SHX5_3.continue = false
    return SHX5_3
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
SHX0_1.constructor = SHX1_1
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX1_2 = Settings
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.get
  SHX1_2 = SHX1_2(SHX2_2)
  function SHX2_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3
    if not SHX0_3 then
      SHX1_3 = nil
      return SHX1_3
    end
    SHX1_3 = SHX0_3.rules
    if SHX1_3 then
      SHX1_3 = type
      SHX2_3 = SHX0_3.rules
      SHX1_3 = SHX1_3(SHX2_3)
      if "table" == SHX1_3 then
        SHX1_3 = {}
        SHX2_3 = SHX0_3.id
        SHX1_3.id = SHX2_3
        SHX2_3 = SHX0_3.type
        SHX1_3.type = SHX2_3
        SHX2_3 = SHX0_3.isGroup
        SHX1_3.isGroup = SHX2_3
        SHX2_3 = table
        SHX2_3 = SHX2_3.map
        SHX3_3 = SHX0_3.rules
        function SHX4_3(SHX0_4)
          -- [AI CLEANUP] Decompiled Lua - Fix these:
          -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
          -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
          -- 3. Replace goto/label with while/repeat-until where possible
          -- 4. Remove decompiler comments, add meaningful ones
          -- 5. Fix indentation and formatting
          
          local SHX1_4, SHX2_4
          SHX1_4 = SHX2_2
          SHX2_4 = SHX0_4
          return SHX1_4(SHX2_4)
        end
        SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
        SHX1_3.rules = SHX2_3
        return SHX1_3
      end
    end
    SHX1_3 = {}
    SHX2_3 = SHX0_3.id
    SHX1_3.id = SHX2_3
    SHX2_3 = SHX0_3.field
    SHX1_3.field = SHX2_3
    SHX2_3 = SHX0_3.op
    SHX1_3.op = SHX2_3
    SHX2_3 = SHX0_3.value
    SHX1_3.value = SHX2_3
    return SHX1_3
  end
  SHX3_2 = json
  SHX3_2 = SHX3_2.encode
  SHX4_2 = table
  SHX4_2 = SHX4_2.map
  SHX5_2 = SHX1_2.native_rules
  function SHX6_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3
    SHX1_3 = {}
    SHX2_3 = SHX0_3.id
    SHX1_3.id = SHX2_3
    SHX2_3 = SHX0_3.name
    SHX1_3.name = SHX2_3
    SHX2_3 = SHX0_3.type
    SHX1_3.type = SHX2_3
    SHX2_3 = SHX0_3.native
    SHX1_3.native = SHX2_3
    SHX2_3 = table
    SHX2_3 = SHX2_3.map
    SHX3_3 = SHX0_3.rules
    if not SHX3_3 then
      SHX3_3 = {}
    end
    function SHX4_3(SHX0_4)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_4, SHX2_4
      SHX1_4 = SHX2_2
      SHX2_4 = SHX0_4
      return SHX1_4(SHX2_4)
    end
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
    SHX1_3.rules = SHX2_3
    return SHX1_3
  end
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  SHX4_2 = SetConvarReplicated
  SHX5_2 = "reaper_native_rules"
  SHX6_2 = SHX3_2
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = {}
  SHX0_2.rules = SHX4_2
  SHX4_2 = pairs
  SHX5_2 = SHX1_2.native_rules
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
  for SHX8_2, SHX9_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
    SHX10_2 = SHX0_2.rules
    SHX11_2 = SHX9_2.native
    SHX10_2 = SHX10_2[SHX11_2]
    if nil == SHX10_2 then
      SHX10_2 = SHX0_2.rules
      SHX11_2 = SHX9_2.native
      SHX12_2 = {}
      SHX10_2[SHX11_2] = SHX12_2
    end
    SHX10_2 = table
    SHX10_2 = SHX10_2.insert
    SHX11_2 = SHX0_2.rules
    SHX12_2 = SHX9_2.native
    SHX11_2 = SHX11_2[SHX12_2]
    SHX12_2 = SHX9_2
    SHX10_2(SHX11_2, SHX12_2)
  end
end
SHX0_1.build_natives = SHX1_1
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2
  SHX2_2 = SHX0_2.rules
  SHX2_2 = SHX2_2[SHX1_2]
  return SHX2_2
end
SHX0_1.getNativeRules = SHX1_1
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX3_2 = SHX1_2
  SHX4_2 = string
  SHX4_2 = SHX4_2.gmatch
  SHX5_2 = SHX2_2
  SHX6_2 = "[^.]+"
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2, SHX6_2)
  for SHX8_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
    SHX9_2 = type
    SHX10_2 = SHX3_2
    SHX9_2 = SHX9_2(SHX10_2)
    if "table" ~= SHX9_2 then
      SHX9_2 = nil
      return SHX9_2
    end
    SHX9_2 = tonumber
    SHX10_2 = SHX8_2
    SHX9_2 = SHX9_2(SHX10_2)
    if SHX9_2 then
      SHX3_2 = SHX3_2[SHX9_2]
    else
      SHX3_2 = SHX3_2[SHX8_2]
    end
  end
  return SHX3_2
end
SHX0_1.getFieldValue = SHX1_1
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX3_2 = SHX1_2.rules
  if SHX3_2 then
    SHX3_2 = type
    SHX4_2 = SHX1_2.rules
    SHX3_2 = SHX3_2(SHX4_2)
    if "table" == SHX3_2 then
      SHX3_2 = SHX1_2.type
      if "and" == SHX3_2 then
        SHX3_2 = ipairs
        SHX4_2 = SHX1_2.rules
        SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
        for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
          SHX10_2 = SHX0_2
          SHX9_2 = SHX0_2.evaluateRule
          SHX11_2 = SHX8_2
          SHX12_2 = SHX2_2
          SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2)
          if not SHX9_2 then
            SHX9_2 = false
            return SHX9_2
          end
        end
        SHX3_2 = true
        return SHX3_2
      else
        SHX3_2 = SHX1_2.type
        if "or" == SHX3_2 then
          SHX3_2 = ipairs
          SHX4_2 = SHX1_2.rules
          SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
          for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
            SHX10_2 = SHX0_2
            SHX9_2 = SHX0_2.evaluateRule
            SHX11_2 = SHX8_2
            SHX12_2 = SHX2_2
            SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2)
            if SHX9_2 then
              SHX9_2 = true
              return SHX9_2
            end
          end
          SHX3_2 = false
          return SHX3_2
        end
      end
    end
  end
  SHX3_2 = SHX1_2.field
  if SHX3_2 then
    SHX3_2 = SHX1_2.op
    if SHX3_2 then
      goto SHX_LABEL_58
    end
  end
  SHX3_2 = false
  return SHX3_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_58:: outside nested blocks until all 'goto SHX_LABEL_58' can see it
  ::SHX_LABEL_58::
  SHX4_2 = SHX0_2
  SHX3_2 = SHX0_2.getFieldValue
  SHX5_2 = SHX2_2
  SHX6_2 = SHX1_2.field
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX4_2 = SHX0_2.operators
  SHX5_2 = SHX1_2.op
  SHX4_2 = SHX4_2[SHX5_2]
  if not SHX4_2 then
    SHX5_2 = error
    SHX6_2 = "Unknown operator: "
    SHX7_2 = tostring
    SHX8_2 = SHX1_2.op
    SHX7_2 = SHX7_2(SHX8_2)
    SHX6_2 = SHX6_2 .. SHX7_2
    SHX5_2(SHX6_2)
  end
  SHX5_2 = SHX4_2
  SHX6_2 = SHX3_2
  SHX7_2 = SHX1_2.value
  return SHX5_2(SHX6_2, SHX7_2)
end
SHX0_1.evaluateRule = SHX1_1
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2
  SHX4_2 = SHX0_2
  SHX3_2 = SHX0_2.getNativeRules
  SHX5_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = nil
  if SHX3_2 then
    SHX5_2 = pairs
    SHX6_2 = SHX3_2
    SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2)
    for SHX9_2, SHX10_2 in SHX5_2, SHX6_2, SHX7_2, SHX8_2 do
      SHX12_2 = SHX0_2
      SHX11_2 = SHX0_2.evaluateRule
      SHX13_2 = SHX10_2
      SHX14_2 = SHX2_2
      SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2)
      if SHX11_2 then
        SHX4_2 = SHX10_2
        break
      end
    end
  end
  if SHX4_2 then
    SHX5_2 = Player
    SHX6_2 = SHX2_2.origin
    SHX6_2 = SHX6_2.player
    SHX5_2 = SHX5_2(SHX6_2)
    if SHX5_2 then
      SHX6_2 = SHX4_2.action
      if "debug" == SHX6_2 then
        SHX7_2 = SHX5_2
        SHX6_2 = SHX5_2.NewLog
        SHX8_2 = "^3%s^7 (^3id:%s^7) just executed ^3%s^7 from ^3%s^7 (^3execution:%s^7) (^3extended:%s^7)"
        SHX9_2 = SHX8_2
        SHX8_2 = SHX8_2.format
        SHX11_2 = SHX5_2
        SHX10_2 = SHX5_2.getName
        SHX10_2 = SHX10_2(SHX11_2)
        SHX12_2 = SHX5_2
        SHX11_2 = SHX5_2.getId
        SHX11_2 = SHX11_2(SHX12_2)
        SHX12_2 = SHX1_2
        SHX13_2 = SHX2_2.req
        SHX13_2 = SHX13_2.path
        SHX14_2 = SHX2_2.req
        SHX14_2 = SHX14_2.executionId
        SHX15_2 = SHX2_2.req
        SHX15_2 = SHX15_2.extendedExecutionId
        SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2)
        SHX9_2 = "info"
        SHX10_2 = "native_rules"
        SHX11_2 = {}
        SHX11_2.rule = SHX4_2
        SHX11_2.data = SHX2_2
        SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
        SHX6_2 = {}
        SHX6_2.success = true
        SHX6_2.continue = true
        return SHX6_2
      else
        SHX7_2 = SHX5_2
        SHX6_2 = SHX5_2.newDetection
        SHX8_2 = "failedNativeCheck"
        SHX9_2 = {}
        SHX9_2.rule = SHX4_2
        SHX9_2.data = SHX2_2
        SHX10_2 = {}
        SHX11_2 = SHX1_2
        SHX10_2[1] = SHX11_2
        SHX11_2 = SHX4_2.action
        SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
      end
    end
  end
  SHX5_2 = nil == SHX4_2
  return SHX5_2
end
SHX0_1.evaluateNative = SHX1_1
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2
  SHX2_2 = nil
  SHX3_2 = pairs
  SHX4_2 = SHX0_2.rules
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
  for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    SHX9_2 = pairs
    SHX10_2 = SHX8_2
    SHX9_2, SHX10_2, SHX11_2, SHX12_2 = SHX9_2(SHX10_2)
    for SHX13_2, SHX14_2 in SHX9_2, SHX10_2, SHX11_2, SHX12_2 do
      SHX15_2 = SHX14_2.id
      if SHX15_2 == SHX1_2 then
        SHX2_2 = SHX14_2
        break
      end
    end
  end
  return SHX2_2
end
SHX0_1.getRuleById = SHX1_1
SHX2_1 = SHX0_1
SHX1_1 = SHX0_1.new
SHX1_1 = SHX1_1(SHX2_1)
NativeRules = SHX1_1
