-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = class
SHX1_1 = "EventKeyLock"
SHX0_1 = SHX0_1(SHX1_1)
EventKeyLock = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = Security
Security = SHX0_1
SHX0_1 = EventKeyLock
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX1_2 = json
  SHX1_2 = SHX1_2.decode
  SHX2_2 = LoadResourceFile
  SHX3_2 = "ReaperV4"
  SHX4_2 = "cache/event_lock_client.json"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if not SHX2_2 then
    SHX2_2 = "{}"
  end
  SHX1_2 = SHX1_2(SHX2_2)
  SHX0_2.event_lock_keys_client = SHX1_2
  SHX1_2 = {}
  SHX2_2 = {}
  SHX1_2.server = SHX2_2
  SHX2_2 = {}
  SHX1_2.client = SHX2_2
  SHX0_2.key_locked_events = SHX1_2
  while true do
    SHX1_2 = RPC
    if SHX1_2 then
      break
    end
    SHX1_2 = Wait
    SHX2_2 = 0
    SHX1_2(SHX2_2)
  end
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.on
  SHX3_2 = "configUpdated"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = SHX0_2
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.refresh
    SHX0_3(SHX1_3)
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.register
  SHX3_2 = "key_lock:lock"
  function SHX4_2(SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3
    SHX5_3 = EventKeyLock
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.get_event_keys
    SHX7_3 = "client"
    SHX8_3 = SHX1_3
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    SHX5_3 = #SHX5_3
    if 0 ~= SHX5_3 then
      SHX5_3 = false
      return SHX5_3
    end
    SHX5_3 = EventKeyLock
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.lock_event
    SHX7_3 = "client"
    SHX8_3 = SHX1_3
    SHX9_3 = SHX2_3
    SHX10_3 = SHX0_3
    SHX11_3 = SHX3_3
    SHX12_3 = SHX4_3
    SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3)
    SHX5_3 = true
    return SHX5_3
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.register
  SHX3_2 = "key_lock:invalid_key"
  function SHX4_2(SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3, SHX17_3
    SHX5_3 = Player
    SHX6_3 = SHX0_3
    SHX5_3 = SHX5_3(SHX6_3)
    if nil == SHX5_3 then
      SHX6_3 = false
      return SHX6_3
    end
    SHX7_3 = SHX5_3
    SHX6_3 = SHX5_3.NewLog
    SHX8_3 = "^3%s^7 (^3id:%s^7) just triggered the event (^3%s^7) with an invalid key (^3%s^7) from (^3%s^7) and was blocked. ^1An invalid key can be caused by a modification made to the script, an event being triggered from multiple places in a script, or from a cheat. If you know this key is legit, you can allow the key by running the following command. ^3reaper eventlockadd client %s %s^7"
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.format
    SHX11_3 = SHX5_3
    SHX10_3 = SHX5_3.getName
    SHX10_3 = SHX10_3(SHX11_3)
    SHX12_3 = SHX5_3
    SHX11_3 = SHX5_3.getId
    SHX11_3 = SHX11_3(SHX12_3)
    SHX12_3 = SHX1_3
    SHX13_3 = SHX2_3
    SHX14_3 = "%s:%s"
    SHX15_3 = SHX14_3
    SHX14_3 = SHX14_3.format
    SHX16_3 = SHX3_3
    SHX17_3 = SHX4_3
    SHX14_3 = SHX14_3(SHX15_3, SHX16_3, SHX17_3)
    SHX15_3 = SHX1_3
    SHX16_3 = SHX2_3
    SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3, SHX14_3, SHX15_3, SHX16_3)
    SHX9_3 = "info"
    SHX10_3 = "event_key_locks"
    SHX11_3 = {}
    SHX11_3.event = SHX1_3
    SHX11_3.execution_key = SHX2_3
    SHX11_3.resource = SHX3_3
    SHX11_3.path = SHX4_3
    SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    SHX6_3 = SHX0_2.ban_for_invalid_key_lock
    if SHX6_3 then
      SHX7_3 = SHX5_3
      SHX6_3 = SHX5_3.newDetection
      SHX8_3 = "invalidKeyLock"
      SHX9_3 = {}
      SHX9_3.event = SHX1_3
      SHX9_3.execution_key = SHX2_3
      SHX9_3.resource = SHX3_3
      SHX9_3.path = SHX4_3
      SHX10_3 = {}
      SHX11_3 = SHX1_3
      SHX12_3 = SHX2_3
      SHX10_3[1] = SHX11_3
      SHX10_3[2] = SHX12_3
      SHX11_3 = "Ban Player"
      SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
    end
    SHX6_3 = true
    return SHX6_3
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "eventlockadd"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    SHX2_3 = SHX1_3[2]
    SHX3_3 = SHX1_3[3]
    SHX4_3 = SHX1_3[4]
    SHX5_3 = SHX3_3
    if "client" == SHX2_3 then
      SHX6_3 = Security
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.hash
      SHX8_3 = SHX5_3
      SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
      SHX5_3 = SHX6_3
    end
    if "client" ~= SHX2_3 then
      SHX6_3 = Logger
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.log
      SHX8_3 = "You have provided an invalid origin. ^3%s^7 is not a valid origin"
      SHX9_3 = SHX8_3
      SHX8_3 = SHX8_3.format
      SHX10_3 = SHX4_3
      SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
      SHX9_3 = "error"
      return SHX6_3(SHX7_3, SHX8_3, SHX9_3)
    end
    SHX6_3 = SHX0_2.key_locked_events
    SHX6_3 = SHX6_3[SHX2_3]
    SHX7_3 = tostring
    SHX8_3 = SHX5_3
    SHX7_3 = SHX7_3(SHX8_3)
    SHX6_3 = SHX6_3[SHX7_3]
    if nil == SHX6_3 then
      SHX6_3 = Logger
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.log
      SHX8_3 = "You have provided an invalid event. ^3%s^7 is not a valid event name"
      SHX9_3 = SHX8_3
      SHX8_3 = SHX8_3.format
      SHX10_3 = SHX4_3
      SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
      SHX9_3 = "error"
      return SHX6_3(SHX7_3, SHX8_3, SHX9_3)
    end
    if nil ~= SHX4_3 then
      SHX6_3 = #SHX4_3
      if 19 == SHX6_3 then
        goto SHX_LABEL_63
      end
      SHX6_3 = #SHX4_3
      if 20 == SHX6_3 then
        goto SHX_LABEL_63
      end
      SHX6_3 = #SHX4_3
      if 18 == SHX6_3 then
        goto SHX_LABEL_63
      end
      SHX6_3 = #SHX4_3
      if 17 == SHX6_3 then
        goto SHX_LABEL_63
      end
    end
    SHX6_3 = Logger
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.log
    SHX8_3 = "You have provided an invalid event key lock. ^3%s^7 is not a valid key"
    SHX9_3 = SHX8_3
    SHX8_3 = SHX8_3.format
    SHX10_3 = SHX4_3
    SHX8_3 = SHX8_3(SHX9_3, SHX10_3)
    SHX9_3 = "error"
    return SHX6_3(SHX7_3, SHX8_3, SHX9_3)
    -- [FIX IF ERROR] Move ::SHX_LABEL_63:: outside nested blocks until all 'goto SHX_LABEL_63' can see it
    ::SHX_LABEL_63::
    SHX6_3 = EventKeyLock
    SHX7_3 = SHX6_3
    SHX6_3 = SHX6_3.lock_event
    SHX8_3 = SHX2_3
    SHX9_3 = SHX3_3
    SHX10_3 = SHX4_3
    SHX11_3 = 0
    SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
  end
  SHX3_2.callback = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "origin"
  SHX6_2 = "event_name"
  SHX7_2 = "key"
  SHX4_2[1] = SHX5_2
  SHX4_2[2] = SHX6_2
  SHX4_2[3] = SHX7_2
  SHX3_2.args = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Update Config"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "eventlockrefresh"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX2_3 = EventKeyLock
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.refresh
    SHX2_3(SHX3_3)
    SHX2_3 = Logger
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.log
    SHX4_3 = "Successfully refreshed key locks."
    SHX5_3 = "info"
    SHX2_3(SHX3_3, SHX4_3, SHX5_3)
  end
  SHX3_2.callback = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Update Config"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.constructor = SHX1_1
SHX0_1 = EventKeyLock
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2
  while true do
    SHX1_2 = Security
    if SHX1_2 then
      break
    end
    SHX1_2 = Wait
    SHX2_2 = 0
    SHX1_2(SHX2_2)
  end
  SHX1_2 = Settings
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.get
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = SHX1_2.keyLockedEvents
  if not SHX2_2 then
    SHX2_2 = {}
  end
  SHX3_2 = json
  SHX3_2 = SHX3_2.decode
  SHX4_2 = HTTP
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.awaitSuccess
  SHX6_2 = "https://api.reaperac.com/api/v1/data/flaggedevents"
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = SHX4_2.body
  if not SHX4_2 then
    SHX4_2 = "{}"
  end
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = {}
  SHX5_2 = {}
  SHX4_2.client = SHX5_2
  SHX5_2 = {}
  SHX4_2.server = SHX5_2
  SHX5_2 = SHX1_2.ban_for_invalid_key_lock
  SHX0_2.ban_for_invalid_key_lock = SHX5_2
  SHX5_2 = {}
  SHX0_2.event_lock_keys_server = SHX5_2
  SHX5_2 = json
  SHX5_2 = SHX5_2.decode
  SHX6_2 = LoadResourceFile
  SHX7_2 = "ReaperV4"
  SHX8_2 = "cache/event_lock_client.json"
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  if not SHX6_2 then
    SHX6_2 = "{}"
  end
  SHX5_2 = SHX5_2(SHX6_2)
  SHX0_2.event_lock_keys_client = SHX5_2
  SHX5_2 = SetConvar
  SHX6_2 = "reaper_ban_for_invalid_key_lock"
  SHX7_2 = tostring
  SHX8_2 = SHX1_2.ban_for_invalid_key_lock
  SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX7_2(SHX8_2)
  SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
  SHX5_2 = pairs
  SHX6_2 = SHX3_2
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2)
  for SHX9_2, SHX10_2 in SHX5_2, SHX6_2, SHX7_2, SHX8_2 do
    SHX11_2 = {}
    SHX12_2 = pairs
    SHX13_2 = SHX10_2.key_lock_known_keys
    if not SHX13_2 then
      SHX13_2 = {}
    end
    SHX12_2, SHX13_2, SHX14_2, SHX15_2 = SHX12_2(SHX13_2)
    for SHX16_2, SHX17_2 in SHX12_2, SHX13_2, SHX14_2, SHX15_2 do
      SHX11_2[SHX16_2] = true
    end
    SHX12_2 = SHX10_2.event_origin
    if "server" == SHX12_2 then
    else
      SHX12_2 = SHX10_2.event_origin
      if "client" == SHX12_2 then
        SHX12_2 = SHX4_2.client
        SHX13_2 = tostring
        SHX14_2 = Security
        SHX15_2 = SHX14_2
        SHX14_2 = SHX14_2.hash
        SHX16_2 = SHX9_2
        SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX14_2(SHX15_2, SHX16_2)
        SHX13_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
        SHX12_2 = SHX12_2[SHX13_2]
        if nil == SHX12_2 then
          SHX12_2 = SHX4_2.client
          SHX13_2 = tostring
          SHX14_2 = Security
          SHX15_2 = SHX14_2
          SHX14_2 = SHX14_2.hash
          SHX16_2 = SHX9_2
          SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX14_2(SHX15_2, SHX16_2)
          SHX13_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
          SHX14_2 = {}
          SHX12_2[SHX13_2] = SHX14_2
        end
        SHX12_2 = SHX4_2.client
        SHX13_2 = tostring
        SHX14_2 = Security
        SHX15_2 = SHX14_2
        SHX14_2 = SHX14_2.hash
        SHX16_2 = SHX9_2
        SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX14_2(SHX15_2, SHX16_2)
        SHX13_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
        SHX12_2[SHX13_2] = SHX11_2
      end
    end
  end
  SHX5_2 = pairs
  SHX6_2 = SHX2_2
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2)
  for SHX9_2, SHX10_2 in SHX5_2, SHX6_2, SHX7_2, SHX8_2 do
    SHX11_2 = SHX4_2.client
    SHX12_2 = tostring
    SHX13_2 = Security
    SHX14_2 = SHX13_2
    SHX13_2 = SHX13_2.hash
    SHX15_2 = SHX9_2
    SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX13_2(SHX14_2, SHX15_2)
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
    SHX11_2 = SHX11_2[SHX12_2]
    if nil == SHX11_2 then
      SHX11_2 = SHX4_2.client
      SHX12_2 = tostring
      SHX13_2 = Security
      SHX14_2 = SHX13_2
      SHX13_2 = SHX13_2.hash
      SHX15_2 = SHX9_2
      SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX13_2(SHX14_2, SHX15_2)
      SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
      SHX13_2 = {}
      SHX11_2[SHX12_2] = SHX13_2
    end
    SHX11_2 = SHX4_2.server
    SHX12_2 = tostring
    SHX13_2 = SHX9_2
    SHX12_2 = SHX12_2(SHX13_2)
    SHX11_2 = SHX11_2[SHX12_2]
    if nil == SHX11_2 then
      SHX11_2 = SHX4_2.server
      SHX12_2 = tostring
      SHX13_2 = SHX9_2
      SHX12_2 = SHX12_2(SHX13_2)
      SHX13_2 = {}
      SHX11_2[SHX12_2] = SHX13_2
    end
  end
  SHX5_2 = pairs
  SHX6_2 = SHX0_2.event_lock_keys_client
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2)
  for SHX9_2, SHX10_2 in SHX5_2, SHX6_2, SHX7_2, SHX8_2 do
    SHX11_2 = SHX4_2.client
    SHX12_2 = tostring
    SHX13_2 = Security
    SHX14_2 = SHX13_2
    SHX13_2 = SHX13_2.hash
    SHX15_2 = SHX9_2
    SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX13_2(SHX14_2, SHX15_2)
    SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
    SHX11_2 = SHX11_2[SHX12_2]
    if nil == SHX11_2 then
      SHX11_2 = SHX4_2.client
      SHX12_2 = tostring
      SHX13_2 = Security
      SHX14_2 = SHX13_2
      SHX13_2 = SHX13_2.hash
      SHX15_2 = SHX9_2
      SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX13_2(SHX14_2, SHX15_2)
      SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
      SHX13_2 = {}
      SHX11_2[SHX12_2] = SHX13_2
    end
    SHX11_2 = pairs
    SHX12_2 = SHX10_2
    SHX11_2, SHX12_2, SHX13_2, SHX14_2 = SHX11_2(SHX12_2)
    for SHX15_2, SHX16_2 in SHX11_2, SHX12_2, SHX13_2, SHX14_2 do
      SHX17_2 = SHX4_2.client
      SHX18_2 = tostring
      SHX19_2 = Security
      SHX20_2 = SHX19_2
      SHX19_2 = SHX19_2.hash
      SHX21_2 = SHX9_2
      SHX19_2, SHX20_2, SHX21_2 = SHX19_2(SHX20_2, SHX21_2)
      SHX18_2 = SHX18_2(SHX19_2, SHX20_2, SHX21_2)
      SHX17_2 = SHX17_2[SHX18_2]
      SHX17_2[SHX15_2] = true
    end
  end
  SHX5_2 = pairs
  SHX6_2 = SHX0_2.event_lock_keys_server
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2)
  for SHX9_2, SHX10_2 in SHX5_2, SHX6_2, SHX7_2, SHX8_2 do
    SHX11_2 = SHX4_2.server
    SHX12_2 = tostring
    SHX13_2 = SHX9_2
    SHX12_2 = SHX12_2(SHX13_2)
    SHX11_2 = SHX11_2[SHX12_2]
    if nil == SHX11_2 then
      SHX11_2 = SHX4_2.server
      SHX12_2 = tostring
      SHX13_2 = SHX9_2
      SHX12_2 = SHX12_2(SHX13_2)
      SHX13_2 = {}
      SHX11_2[SHX12_2] = SHX13_2
    end
    SHX11_2 = pairs
    SHX12_2 = SHX10_2
    SHX11_2, SHX12_2, SHX13_2, SHX14_2 = SHX11_2(SHX12_2)
    for SHX15_2, SHX16_2 in SHX11_2, SHX12_2, SHX13_2, SHX14_2 do
      SHX17_2 = SHX4_2.server
      SHX18_2 = tostring
      SHX19_2 = SHX9_2
      SHX18_2 = SHX18_2(SHX19_2)
      SHX17_2 = SHX17_2[SHX18_2]
      SHX17_2[SHX15_2] = true
    end
  end
  SHX0_2.key_locked_events = SHX4_2
  SHX5_2 = SetConvarReplicated
  SHX6_2 = "reaper_event_lock_client"
  SHX7_2 = json
  SHX7_2 = SHX7_2.encode
  SHX8_2 = SHX4_2.client
  SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX7_2(SHX8_2)
  SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2)
end
SHX0_1.refresh = SHX1_1
SHX0_1 = EventKeyLock
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2
  if "server" == SHX1_2 then
    SHX3_2 = {}
    return SHX3_2
  elseif "client" == SHX1_2 then
    SHX3_2 = SHX0_2.event_lock_keys_client
    SHX3_2 = SHX3_2[SHX2_2]
    if not SHX3_2 then
      SHX3_2 = {}
    end
    return SHX3_2
  end
  SHX3_2 = {}
  return SHX3_2
end
SHX0_1.get_event_keys = SHX1_1
SHX0_1 = EventKeyLock
function SHX1_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  if "server" == SHX1_2 then
    SHX7_2 = false
    SHX8_2 = "SERVER_ORIGIN_NOT_SUPPORTED"
    return SHX7_2, SHX8_2
  elseif "client" == SHX1_2 then
    SHX7_2 = SHX0_2.key_locked_events
    SHX7_2 = SHX7_2.client
    SHX8_2 = tostring
    SHX9_2 = Security
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.hash
    SHX11_2 = SHX2_2
    SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX9_2(SHX10_2, SHX11_2)
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
    SHX7_2 = SHX7_2[SHX8_2]
    if nil == SHX7_2 then
      SHX7_2 = false
      SHX8_2 = "INVALID_EVENT_NAME"
      return SHX7_2, SHX8_2
    end
    SHX7_2 = SHX0_2.event_lock_keys_client
    SHX7_2 = SHX7_2[SHX2_2]
    if nil == SHX7_2 then
      SHX7_2 = SHX0_2.event_lock_keys_client
      SHX8_2 = {}
      SHX7_2[SHX2_2] = SHX8_2
    end
    SHX7_2 = Player
    SHX8_2 = SHX4_2 or SHX8_2
    if not SHX4_2 then
      SHX8_2 = 0
    end
    SHX7_2 = SHX7_2(SHX8_2)
    if SHX7_2 then
      SHX8_2 = SHX0_2.event_lock_keys_client
      SHX8_2 = SHX8_2[SHX2_2]
      SHX9_2 = {}
      SHX9_2.type = "auto"
      SHX11_2 = SHX7_2
      SHX10_2 = SHX7_2.getIdentifier
      SHX12_2 = "license"
      SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
      SHX9_2.player = SHX10_2
      SHX9_2.resource = SHX5_2
      SHX9_2.path = SHX6_2
      SHX8_2[SHX3_2] = SHX9_2
    else
      SHX8_2 = SHX0_2.event_lock_keys_client
      SHX8_2 = SHX8_2[SHX2_2]
      SHX9_2 = {}
      SHX9_2.type = "manual"
      SHX8_2[SHX3_2] = SHX9_2
    end
    SHX8_2 = SaveResourceFile
    SHX9_2 = "ReaperV4"
    SHX10_2 = "cache/event_lock_client.json"
    SHX11_2 = json
    SHX11_2 = SHX11_2.encode
    SHX12_2 = SHX0_2.event_lock_keys_client
    SHX11_2, SHX12_2, SHX13_2 = SHX11_2(SHX12_2)
    SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
    SHX8_2 = Logger
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.log
    SHX10_2 = "Successfully added ^3%s^7 as a key for the event ^3%s^7"
    SHX11_2 = SHX10_2
    SHX10_2 = SHX10_2.format
    SHX12_2 = SHX3_2
    SHX13_2 = SHX2_2
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2)
    SHX11_2 = "info"
    SHX8_2(SHX9_2, SHX10_2, SHX11_2)
    SHX9_2 = SHX0_2
    SHX8_2 = SHX0_2.refresh
    SHX8_2(SHX9_2)
    SHX8_2 = true
    SHX9_2 = ""
    return SHX8_2, SHX9_2
  end
  SHX7_2 = false
  SHX8_2 = "INVALID_ORIGIN"
  return SHX7_2, SHX8_2
end
SHX0_1.lock_event = SHX1_1
SHX0_1 = EventKeyLock
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
end
SHX0_1.add_execution = SHX1_1
SHX0_1 = EventKeyLock
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.new
SHX0_1 = SHX0_1(SHX1_1)
EventKeyLock = SHX0_1
