-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1
SHX0_1 = os
SHX0_1 = SHX0_1.nanotime
SHX1_1 = {}
function SHX2_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX3_2 = SHX0_1
  SHX3_2 = SHX3_2()
  SHX4_2 = 1
  SHX5_2 = SHX0_2
  SHX6_2 = 1
  for SHX7_2 = SHX4_2, SHX5_2, SHX6_2 do
    SHX8_2 = SHX2_2
    SHX8_2()
  end
  SHX4_2 = SHX1_1
  SHX4_2 = #SHX4_2
  SHX5_2 = SHX4_2 + 1
  SHX4_2 = SHX1_1
  SHX6_2 = {}
  SHX7_2 = SHX0_1
  SHX7_2 = SHX7_2()
  SHX7_2 = SHX7_2 - SHX3_2
  SHX7_2 = SHX7_2 / SHX0_2
  SHX8_2 = SHX1_2
  SHX6_2[1] = SHX7_2
  SHX6_2[2] = SHX8_2
  SHX4_2[SHX5_2] = SHX6_2
end
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX1_2 = print
  SHX2_2 = "Average results from %d iterations (ms)"
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.format
  SHX4_2 = SHX0_2
  SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  SHX1_2 = table
  SHX1_2 = SHX1_2.sort
  SHX2_2 = SHX1_1
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3
    SHX2_3 = SHX0_3[1]
    SHX3_3 = SHX1_3[1]
    SHX2_3 = SHX2_3 < SHX3_3
    return SHX2_3
  end
  SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = 1
  SHX2_2 = SHX1_1
  SHX2_2 = #SHX2_2
  SHX3_2 = 1
  for SHX4_2 = SHX1_2, SHX2_2, SHX3_2 do
    SHX5_2 = SHX1_1
    SHX5_2 = SHX5_2[SHX4_2]
    SHX6_2 = print
    SHX7_2 = "#%d - %.4f\t(%s)"
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.format
    SHX9_2 = SHX4_2
    SHX10_2 = SHX5_2[1]
    SHX10_2 = SHX10_2 / 1000000.0
    SHX11_2 = SHX5_2[2]
    SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2)
    SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  end
  SHX1_2 = table
  SHX1_2 = SHX1_2.wipe
  SHX2_2 = SHX1_1
  SHX1_2(SHX2_2)
end
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX2_2 = pairs
  SHX3_2 = SHX1_2
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX8_2 = SHX2_1
    SHX9_2 = SHX0_2
    SHX10_2 = SHX6_2
    SHX11_2 = SHX7_2
    SHX8_2(SHX9_2, SHX10_2, SHX11_2)
  end
  SHX2_2 = SHX3_1
  SHX3_2 = SHX0_2
  SHX2_2(SHX3_2)
end
Benchmark = SHX4_1
