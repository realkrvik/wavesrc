-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1
SHX0_1 = string
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX3_2 = string
  SHX3_2 = SHX3_2.gsub
  SHX4_2 = SHX1_2
  SHX5_2 = "[%(%)%.%+%-%*%?%[%]%^%$%%]"
  SHX6_2 = "%%%1"
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX1_2 = SHX3_2
  SHX3_2 = string
  SHX3_2 = SHX3_2.gsub
  SHX4_2 = SHX2_2
  SHX5_2 = "[%%]"
  SHX6_2 = "%%%%"
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX2_2 = SHX3_2
  SHX3_2 = string
  SHX3_2 = SHX3_2.gsub
  SHX4_2 = SHX0_2
  SHX5_2 = SHX1_2
  SHX6_2 = SHX2_2
  return SHX3_2(SHX4_2, SHX5_2, SHX6_2)
end
SHX0_1.replace = SHX1_1
SHX0_1 = string
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = string
  SHX2_2 = SHX2_2.sub
  SHX3_2 = SHX0_2
  SHX4_2 = 1
  SHX5_2 = string
  SHX5_2 = SHX5_2.len
  SHX6_2 = SHX1_2
  SHX5_2, SHX6_2 = SHX5_2(SHX6_2)
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  SHX2_2 = SHX2_2 == SHX1_2
  return SHX2_2
end
SHX0_1.starts = SHX1_1
SHX0_1 = string
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = tonumber
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if not SHX1_2 then
    SHX1_2 = GetHashKey
    SHX2_2 = SHX0_2
    SHX1_2 = SHX1_2(SHX2_2)
  end
  return SHX1_2
end
SHX0_1.toHash = SHX1_1
SHX0_1 = string
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  if nil == SHX1_2 then
    SHX1_2 = "%s"
  end
  SHX2_2 = {}
  SHX3_2 = string
  SHX3_2 = SHX3_2.gmatch
  SHX4_2 = SHX0_2
  SHX5_2 = "([^"
  SHX6_2 = SHX1_2
  SHX7_2 = "]+)"
  SHX5_2 = SHX5_2 .. SHX6_2 .. SHX7_2
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2, SHX5_2)
  for SHX7_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    SHX8_2 = table
    SHX8_2 = SHX8_2.insert
    SHX9_2 = SHX2_2
    SHX10_2 = SHX7_2
    SHX8_2(SHX9_2, SHX10_2)
  end
  return SHX2_2
end
SHX0_1.split = SHX1_1
