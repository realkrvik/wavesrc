-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1
SHX0_1 = class
SHX1_1 = "System"
SHX0_1 = SHX0_1(SHX1_1)
System = SHX0_1
SHX0_1 = System
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = os
  SHX1_2 = SHX1_2.getenv
  SHX2_2 = "os"
  SHX1_2 = SHX1_2(SHX2_2)
  if "Windows_NT" == SHX1_2 or "Windows" == SHX1_2 then
    SHX2_2 = "Windows"
    if SHX2_2 then
      goto SHX_LABEL_13
    end
  end
  SHX2_2 = "Linux"
  -- [FIX IF ERROR] Move ::SHX_LABEL_13:: outside nested blocks until all 'goto SHX_LABEL_13' can see it
  ::SHX_LABEL_13::
  SHX0_2.os = SHX2_2
end
SHX0_1.constructor = SHX1_1
SHX0_1 = System
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.os
  return SHX1_2
end
SHX0_1.getOs = SHX1_1
SHX0_1 = System
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX1_2 = "web_barUrl_failed"
  while "web_barUrl_failed" == SHX1_2 do
    SHX2_2 = GetConvar
    SHX3_2 = "web_baseUrl"
    SHX4_2 = "web_barUrl_failed"
    SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
    SHX1_2 = SHX2_2
    SHX2_2 = Wait
    SHX3_2 = 250
    SHX2_2(SHX3_2)
  end
  SHX2_2 = Logger
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.log
  SHX4_2 = "Base url fetched as %s"
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.format
  SHX6_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = "debug"
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  return SHX1_2
end
SHX0_1.getBaseUrl = SHX1_1
SHX0_1 = System
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.new
SHX0_1 = SHX0_1(SHX1_1)
System = SHX0_1
