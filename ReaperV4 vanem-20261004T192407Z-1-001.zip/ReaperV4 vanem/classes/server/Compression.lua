-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1
SHX0_1 = class
SHX1_1 = "LZ4"
SHX0_1 = SHX0_1(SHX1_1)
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
end
SHX0_1.constructor = SHX1_1
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX3_2 = string
  SHX3_2 = SHX3_2.find
  SHX4_2 = SHX1_2
  SHX5_2 = SHX2_2
  SHX6_2 = 0
  SHX7_2 = true
  return SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2)
end
SHX0_1.plainFind = SHX1_1
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  SHX2_2 = {}
  SHX2_2.Offset = 0
  SHX2_2.Source = SHX1_2
  SHX3_2 = string
  SHX3_2 = SHX3_2.len
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  SHX2_2.Length = SHX3_2
  SHX2_2.IsFinished = false
  SHX2_2.LastUnreadBytes = 0
  function SHX3_2(SHX0_3, SHX1_3, SHX2_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX3_3 = SHX1_3 or nil
    if not SHX1_3 then
      SHX3_3 = 1
    end
    SHX4_3 = true
    if nil ~= SHX2_3 then
      SHX4_3 = SHX2_3
    end
    SHX5_3 = string
    SHX5_3 = SHX5_3.sub
    SHX6_3 = SHX0_3.Source
    SHX7_3 = SHX0_3.Offset
    SHX7_3 = SHX7_3 + 1
    SHX8_3 = SHX0_3.Offset
    SHX8_3 = SHX8_3 + SHX3_3
    SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    SHX6_3 = string
    SHX6_3 = SHX6_3.len
    SHX7_3 = SHX5_3
    SHX6_3 = SHX6_3(SHX7_3)
    SHX7_3 = SHX3_3 - SHX6_3
    if SHX4_3 then
      SHX9_3 = SHX0_3
      SHX8_3 = SHX0_3.seek
      SHX10_3 = SHX3_3
      SHX8_3(SHX9_3, SHX10_3)
    end
    SHX0_3.LastUnreadBytes = SHX7_3
    return SHX5_3
  end
  SHX2_2.read = SHX3_2
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = SHX1_3 or nil
    if not SHX1_3 then
      SHX2_3 = 1
    end
    SHX3_3 = math
    SHX3_3 = SHX3_3.clamp
    SHX4_3 = SHX0_3.Offset
    SHX4_3 = SHX4_3 + SHX2_3
    SHX5_3 = 0
    SHX6_3 = SHX0_3.Length
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3)
    SHX0_3.Offset = SHX3_3
    SHX3_3 = SHX0_3.Offset
    SHX4_3 = SHX0_3.Length
    SHX3_3 = SHX3_3 >= SHX4_3
    SHX0_3.IsFinished = SHX3_3
  end
  SHX2_2.seek = SHX3_2
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = SHX0_3.Source
    SHX3_3 = SHX1_3
    SHX2_3 = SHX2_3 .. SHX3_3
    SHX0_3.Source = SHX2_3
    SHX2_3 = string
    SHX2_3 = SHX2_3.len
    SHX3_3 = SHX0_3.Source
    SHX2_3 = SHX2_3(SHX3_3)
    SHX0_3.Length = SHX2_3
    SHX3_3 = SHX0_3
    SHX2_3 = SHX0_3.seek
    SHX4_3 = 0
    SHX2_3(SHX3_3, SHX4_3)
  end
  SHX2_2.append = SHX3_2
  function SHX3_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3
    SHX2_3 = SHX0_3
    SHX1_3 = SHX0_3.seek
    SHX3_3 = SHX0_3.Length
    SHX1_3(SHX2_3, SHX3_3)
  end
  SHX2_2.toEnd = SHX3_2
  return SHX2_2
end
SHX0_1.streamer = SHX1_1
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2
  SHX2_2 = {}
  SHX3_2 = SHX0_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.streamer
  SHX5_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX3_2.Length
  if SHX4_2 > 12 then
    SHX5_2 = SHX3_2
    SHX4_2 = SHX3_2.read
    SHX6_2 = 4
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    SHX5_2 = SHX4_2
    SHX6_2 = SHX4_2
    SHX7_2 = ""
    SHX8_2 = ""
    SHX9_2 = true
    repeat
      SHX9_2 = true
      SHX11_2 = SHX3_2
      SHX10_2 = SHX3_2.read
      SHX10_2 = SHX10_2(SHX11_2)
      SHX11_2 = SHX0_1
      SHX12_2 = SHX11_2
      SHX11_2 = SHX11_2.plainFind
      SHX13_2 = SHX5_2
      SHX14_2 = SHX10_2
      SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2)
      if SHX11_2 then
        SHX12_2 = SHX3_2
        SHX11_2 = SHX3_2.read
        SHX13_2 = 3
        SHX14_2 = false
        SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2)
        SHX12_2 = string
        SHX12_2 = SHX12_2.len
        SHX13_2 = SHX11_2
        SHX12_2 = SHX12_2(SHX13_2)
        if SHX12_2 < 3 then
          SHX12_2 = SHX10_2
          SHX13_2 = SHX11_2
          SHX12_2 = SHX12_2 .. SHX13_2
          SHX8_2 = SHX12_2
          SHX13_2 = SHX3_2
          SHX12_2 = SHX3_2.seek
          SHX14_2 = 3
          SHX12_2(SHX13_2, SHX14_2)
        else
          SHX12_2 = SHX10_2
          SHX13_2 = SHX11_2
          SHX12_2 = SHX12_2 .. SHX13_2
          SHX7_2 = SHX12_2
          SHX12_2 = SHX0_1
          SHX13_2 = SHX12_2
          SHX12_2 = SHX12_2.plainFind
          SHX14_2 = SHX5_2
          SHX15_2 = SHX7_2
          SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2)
          if SHX12_2 then
            SHX14_2 = SHX3_2
            SHX13_2 = SHX3_2.seek
            SHX15_2 = 3
            SHX13_2(SHX14_2, SHX15_2)
            repeat
              SHX14_2 = SHX3_2
              SHX13_2 = SHX3_2.read
              SHX15_2 = 1
              SHX16_2 = false
              SHX13_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2)
              SHX14_2 = SHX7_2
              SHX15_2 = SHX13_2
              SHX14_2 = SHX14_2 .. SHX15_2
              SHX15_2 = SHX0_1
              SHX16_2 = SHX15_2
              SHX15_2 = SHX15_2.plainFind
              SHX17_2 = SHX5_2
              SHX18_2 = SHX14_2
              SHX15_2 = SHX15_2(SHX16_2, SHX17_2, SHX18_2)
              if SHX15_2 then
                SHX7_2 = SHX14_2
                SHX12_2 = SHX15_2
                SHX17_2 = SHX3_2
                SHX16_2 = SHX3_2.seek
                SHX18_2 = 1
                SHX16_2(SHX17_2, SHX18_2)
              end
              SHX16_2 = SHX0_1
              SHX17_2 = SHX16_2
              SHX16_2 = SHX16_2.plainFind
              SHX18_2 = SHX5_2
              SHX19_2 = SHX14_2
              SHX16_2 = SHX16_2(SHX17_2, SHX18_2, SHX19_2)
              if not SHX16_2 then
                break
              end
              SHX16_2 = SHX3_2.IsFinished
            until SHX16_2
            SHX13_2 = string
            SHX13_2 = SHX13_2.len
            SHX14_2 = SHX7_2
            SHX13_2 = SHX13_2(SHX14_2)
            SHX14_2 = true
            SHX15_2 = SHX3_2.Length
            SHX16_2 = SHX3_2.Offset
            SHX15_2 = SHX15_2 - SHX16_2
            if SHX15_2 <= 5 then
              SHX8_2 = SHX7_2
              SHX14_2 = false
            end
            if SHX14_2 then
              SHX9_2 = false
              SHX15_2 = string
              SHX15_2 = SHX15_2.len
              SHX16_2 = SHX5_2
              SHX15_2 = SHX15_2(SHX16_2)
              SHX15_2 = SHX15_2 - SHX12_2
              SHX16_2 = SHX5_2
              SHX17_2 = SHX7_2
              SHX16_2 = SHX16_2 .. SHX17_2
              SHX5_2 = SHX16_2
              SHX16_2 = table
              SHX16_2 = SHX16_2.insert
              SHX17_2 = SHX2_2
              SHX18_2 = {}
              SHX18_2.Literal = SHX6_2
              SHX19_2 = string
              SHX19_2 = SHX19_2.len
              SHX20_2 = SHX6_2
              SHX19_2 = SHX19_2(SHX20_2)
              SHX18_2.LiteralLength = SHX19_2
              SHX19_2 = SHX15_2 + 1
              SHX18_2.MatchOffset = SHX19_2
              SHX18_2.MatchLength = SHX13_2
              SHX16_2(SHX17_2, SHX18_2)
              SHX6_2 = ""
            end
          else
            SHX8_2 = SHX10_2
          end
        end
      else
        SHX8_2 = SHX10_2
      end
      if SHX9_2 then
        SHX11_2 = SHX6_2
        SHX12_2 = SHX8_2
        SHX11_2 = SHX11_2 .. SHX12_2
        SHX6_2 = SHX11_2
        SHX11_2 = SHX5_2
        SHX12_2 = SHX10_2
        SHX11_2 = SHX11_2 .. SHX12_2
        SHX5_2 = SHX11_2
      end
      SHX11_2 = SHX3_2.IsFinished
    until SHX11_2
    SHX10_2 = table
    SHX10_2 = SHX10_2.insert
    SHX11_2 = SHX2_2
    SHX12_2 = {}
    SHX12_2.Literal = SHX6_2
    SHX13_2 = string
    SHX13_2 = SHX13_2.len
    SHX14_2 = SHX6_2
    SHX13_2 = SHX13_2(SHX14_2)
    SHX12_2.LiteralLength = SHX13_2
    SHX10_2(SHX11_2, SHX12_2)
  else
    SHX4_2 = SHX3_2.Source
    SHX5_2 = {}
    SHX5_2.Literal = SHX4_2
    SHX6_2 = string
    SHX6_2 = SHX6_2.len
    SHX7_2 = SHX4_2
    SHX6_2 = SHX6_2(SHX7_2)
    SHX5_2.LiteralLength = SHX6_2
    SHX2_2[1] = SHX5_2
  end
  SHX4_2 = string
  SHX4_2 = SHX4_2.rep
  SHX5_2 = "\000"
  SHX6_2 = 4
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  function SHX5_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3
    SHX1_3 = SHX4_2
    SHX2_3 = SHX0_3
    SHX1_3 = SHX1_3 .. SHX2_3
    SHX4_2 = SHX1_3
  end
  SHX6_2 = pairs
  SHX7_2 = SHX2_2
  SHX6_2, SHX7_2, SHX8_2, SHX9_2 = SHX6_2(SHX7_2)
  for SHX10_2, SHX11_2 in SHX6_2, SHX7_2, SHX8_2, SHX9_2 do
    SHX12_2 = SHX11_2.LiteralLength
    SHX13_2 = SHX11_2.MatchLength
    if not SHX13_2 then
      SHX13_2 = 4
    end
    SHX13_2 = SHX13_2 - 4
    SHX14_2 = math
    SHX14_2 = SHX14_2.clamp
    SHX15_2 = SHX12_2
    SHX16_2 = 0
    SHX17_2 = 15
    SHX14_2 = SHX14_2(SHX15_2, SHX16_2, SHX17_2)
    SHX15_2 = math
    SHX15_2 = SHX15_2.clamp
    SHX16_2 = SHX13_2
    SHX17_2 = 0
    SHX18_2 = 15
    SHX15_2 = SHX15_2(SHX16_2, SHX17_2, SHX18_2)
    SHX16_2 = bit32
    SHX17_2 = SHX16_2
    SHX16_2 = SHX16_2.lshift
    SHX18_2 = SHX14_2
    SHX19_2 = 4
    SHX16_2 = SHX16_2(SHX17_2, SHX18_2, SHX19_2)
    SHX16_2 = SHX16_2 + SHX15_2
    SHX17_2 = SHX5_2
    SHX18_2 = string
    SHX18_2 = SHX18_2.pack
    SHX19_2 = "<I1"
    SHX20_2 = SHX16_2
    SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX18_2(SHX19_2, SHX20_2)
    SHX17_2(SHX18_2, SHX19_2, SHX20_2, SHX21_2)
    if SHX12_2 >= 15 then
      SHX12_2 = SHX12_2 - 15
      repeat
        SHX17_2 = math
        SHX17_2 = SHX17_2.clamp
        SHX18_2 = SHX12_2
        SHX19_2 = 0
        SHX20_2 = 255
        SHX17_2 = SHX17_2(SHX18_2, SHX19_2, SHX20_2)
        SHX18_2 = SHX5_2
        SHX19_2 = string
        SHX19_2 = SHX19_2.pack
        SHX20_2 = "<I1"
        SHX21_2 = SHX17_2
        SHX19_2, SHX20_2, SHX21_2 = SHX19_2(SHX20_2, SHX21_2)
        SHX18_2(SHX19_2, SHX20_2, SHX21_2)
        if 255 == SHX17_2 then
          SHX12_2 = SHX12_2 - 255
        end
        SHX18_2 = 255
      until SHX17_2 < SHX18_2
    end
    SHX17_2 = SHX5_2
    SHX18_2 = SHX11_2.Literal
    SHX17_2(SHX18_2)
    SHX17_2 = #SHX2_2
    if SHX10_2 ~= SHX17_2 then
      SHX17_2 = SHX5_2
      SHX18_2 = string
      SHX18_2 = SHX18_2.pack
      SHX19_2 = "<I2"
      SHX20_2 = SHX11_2.MatchOffset
      SHX18_2, SHX19_2, SHX20_2, SHX21_2 = SHX18_2(SHX19_2, SHX20_2)
      SHX17_2(SHX18_2, SHX19_2, SHX20_2, SHX21_2)
      if SHX13_2 >= 15 then
        SHX13_2 = SHX13_2 - 15
        repeat
          SHX17_2 = math
          SHX17_2 = SHX17_2.clamp
          SHX18_2 = SHX13_2
          SHX19_2 = 0
          SHX20_2 = 255
          SHX17_2 = SHX17_2(SHX18_2, SHX19_2, SHX20_2)
          SHX18_2 = SHX5_2
          SHX19_2 = string
          SHX19_2 = SHX19_2.pack
          SHX20_2 = "<I1"
          SHX21_2 = SHX17_2
          SHX19_2, SHX20_2, SHX21_2 = SHX19_2(SHX20_2, SHX21_2)
          SHX18_2(SHX19_2, SHX20_2, SHX21_2)
          if 255 == SHX17_2 then
            SHX13_2 = SHX13_2 - 255
          end
          SHX18_2 = 255
        until SHX17_2 < SHX18_2
      end
    end
  end
  SHX6_2 = string
  SHX6_2 = SHX6_2.len
  SHX7_2 = SHX4_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX6_2 = SHX6_2 - 4
  SHX7_2 = SHX3_2.Length
  SHX8_2 = string
  SHX8_2 = SHX8_2.pack
  SHX9_2 = "<I4"
  SHX10_2 = SHX6_2
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  SHX9_2 = string
  SHX9_2 = SHX9_2.pack
  SHX10_2 = "<I4"
  SHX11_2 = SHX7_2
  SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
  SHX10_2 = SHX4_2
  SHX8_2 = SHX8_2 .. SHX9_2 .. SHX10_2
  return SHX8_2
end
SHX0_1.compress_chunk = SHX1_1
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX2_2 = {}
  SHX3_2 = 90000
  SHX4_2 = 1
  SHX5_2 = #SHX1_2
  SHX6_2 = SHX3_2
  for SHX7_2 = SHX4_2, SHX5_2, SHX6_2 do
    SHX9_2 = SHX1_2
    SHX8_2 = SHX1_2.sub
    SHX10_2 = SHX7_2
    SHX11_2 = SHX7_2 + SHX3_2
    SHX11_2 = SHX11_2 - 1
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2)
    SHX9_2 = table
    SHX9_2 = SHX9_2.insert
    SHX10_2 = SHX2_2
    SHX12_2 = SHX0_2
    SHX11_2 = SHX0_2.compress_chunk
    SHX13_2 = SHX8_2
    SHX11_2, SHX12_2, SHX13_2 = SHX11_2(SHX12_2, SHX13_2)
    SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  end
  SHX4_2 = msgpack
  SHX4_2 = SHX4_2.pack_args
  SHX5_2 = SHX2_2
  SHX4_2 = SHX4_2(SHX5_2)
  return SHX4_2
end
SHX0_1.compress = SHX1_1
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX2_2 = table
  SHX2_2 = SHX2_2.unpack
  SHX3_2 = msgpack
  SHX3_2 = SHX3_2.unpack
  SHX4_2 = SHX1_2
  SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX3_2(SHX4_2)
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  SHX3_2 = ""
  SHX4_2 = pairs
  SHX5_2 = SHX2_2
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
  for SHX8_2, SHX9_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
    SHX10_2 = SHX3_2
    SHX11_2 = SHX0_1
    SHX12_2 = SHX11_2
    SHX11_2 = SHX11_2.decompress_chunk
    SHX13_2 = SHX9_2
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
    SHX10_2 = SHX10_2 .. SHX11_2
    SHX3_2 = SHX10_2
  end
  return SHX3_2
end
SHX0_1.decompress = SHX1_1
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.streamer
  SHX4_2 = SHX1_2
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX3_2 = string
  SHX3_2 = SHX3_2.unpack
  SHX4_2 = "<I4"
  SHX6_2 = SHX2_2
  SHX5_2 = SHX2_2.read
  SHX7_2 = 4
  SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
  SHX4_2 = string
  SHX4_2 = SHX4_2.unpack
  SHX5_2 = "<I4"
  SHX7_2 = SHX2_2
  SHX6_2 = SHX2_2.read
  SHX8_2 = 4
  SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
  SHX5_2 = string
  SHX5_2 = SHX5_2.unpack
  SHX6_2 = "<I4"
  SHX8_2 = SHX2_2
  SHX7_2 = SHX2_2.read
  SHX9_2 = 4
  SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
  if 0 == SHX3_2 then
    SHX7_2 = SHX2_2
    SHX6_2 = SHX2_2.read
    SHX8_2 = SHX4_2
    return SHX6_2(SHX7_2, SHX8_2)
  end
  SHX6_2 = SHX0_1
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.streamer
  SHX8_2 = ""
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  repeat
    SHX7_2 = string
    SHX7_2 = SHX7_2.byte
    SHX9_2 = SHX2_2
    SHX8_2 = SHX2_2.read
    SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2 = SHX8_2(SHX9_2)
    SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
    SHX8_2 = bit32
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.rshift
    SHX10_2 = SHX7_2
    SHX11_2 = 4
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2)
    SHX9_2 = bit32
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.band
    SHX11_2 = SHX7_2
    SHX12_2 = 15
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2)
    SHX9_2 = SHX9_2 + 4
    if SHX8_2 >= 15 then
      repeat
        SHX10_2 = string
        SHX10_2 = SHX10_2.byte
        SHX12_2 = SHX2_2
        SHX11_2 = SHX2_2.read
        SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2 = SHX11_2(SHX12_2)
        SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
        SHX8_2 = SHX8_2 + SHX10_2
      until 255 ~= SHX10_2
    end
    SHX11_2 = SHX2_2
    SHX10_2 = SHX2_2.read
    SHX12_2 = SHX8_2
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
    SHX12_2 = SHX6_2
    SHX11_2 = SHX6_2.append
    SHX13_2 = SHX10_2
    SHX11_2(SHX12_2, SHX13_2)
    SHX12_2 = SHX6_2
    SHX11_2 = SHX6_2.toEnd
    SHX11_2(SHX12_2)
    SHX11_2 = SHX6_2.Length
    if SHX4_2 > SHX11_2 then
      SHX11_2 = string
      SHX11_2 = SHX11_2.unpack
      SHX12_2 = "<I2"
      SHX14_2 = SHX2_2
      SHX13_2 = SHX2_2.read
      SHX15_2 = 2
      SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2 = SHX13_2(SHX14_2, SHX15_2)
      SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
      if SHX9_2 >= 19 then
        repeat
          SHX12_2 = string
          SHX12_2 = SHX12_2.byte
          SHX14_2 = SHX2_2
          SHX13_2 = SHX2_2.read
          SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2 = SHX13_2(SHX14_2)
          SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2)
          SHX9_2 = SHX9_2 + SHX12_2
        until 255 ~= SHX12_2
      end
      SHX13_2 = SHX6_2
      SHX12_2 = SHX6_2.seek
      SHX14_2 = -SHX11_2
      SHX12_2(SHX13_2, SHX14_2)
      SHX12_2 = SHX6_2.Offset
      SHX14_2 = SHX6_2
      SHX13_2 = SHX6_2.read
      SHX15_2 = SHX9_2
      SHX13_2 = SHX13_2(SHX14_2, SHX15_2)
      SHX14_2 = SHX6_2.LastUnreadBytes
      SHX15_2 = nil
      if SHX14_2 then
        repeat
          SHX6_2.Offset = SHX12_2
          SHX17_2 = SHX6_2
          SHX16_2 = SHX6_2.read
          SHX18_2 = SHX14_2
          SHX16_2 = SHX16_2(SHX17_2, SHX18_2)
          SHX15_2 = SHX16_2
          SHX14_2 = SHX6_2.LastUnreadBytes
          SHX16_2 = SHX13_2
          SHX17_2 = SHX15_2
          SHX16_2 = SHX16_2 .. SHX17_2
          SHX13_2 = SHX16_2
        until SHX14_2 <= 0
      end
      SHX17_2 = SHX6_2
      SHX16_2 = SHX6_2.append
      SHX18_2 = SHX13_2
      SHX16_2(SHX17_2, SHX18_2)
      SHX17_2 = SHX6_2
      SHX16_2 = SHX6_2.toEnd
      SHX16_2(SHX17_2)
    end
    SHX11_2 = SHX6_2.Length
  until SHX4_2 <= SHX11_2
  SHX7_2 = SHX6_2.Source
  return SHX7_2
end
SHX0_1.decompress_chunk = SHX1_1
SHX2_1 = SHX0_1
SHX1_1 = SHX0_1.new
SHX1_1 = SHX1_1(SHX2_1)
LZ4 = SHX1_1
