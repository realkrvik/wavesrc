-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = class
SHX1_1 = "Settings"
SHX0_1 = SHX0_1(SHX1_1)
Settings = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = Security
Security = SHX0_1
SHX0_1 = Settings
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2
  SHX0_2.settings = SHX1_2
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.build
  SHX2_2(SHX3_2)
end
SHX0_1.constructor = SHX1_1
SHX0_1 = Settings
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX1_2 = {}
  SHX2_2 = pairs
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.weaponRules
  SHX3_2 = SHX3_2.autoAntiWeaponSpawn
  SHX3_2 = SHX3_2.ignoredWeapons
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX8_2 = tostring
    SHX9_2 = GetHashKey
    SHX10_2 = SHX7_2
    SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX9_2(SHX10_2)
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
    SHX1_2[SHX8_2] = true
  end
  SHX2_2 = {}
  SHX3_2 = pairs
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.weaponRules
  SHX4_2 = SHX4_2.blacklistedWeapons
  SHX4_2 = SHX4_2.weapons
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
  for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    SHX9_2 = tostring
    SHX10_2 = GetHashKey
    SHX11_2 = SHX8_2
    SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX10_2(SHX11_2)
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2)
    SHX10_2 = SHX0_2.settings
    SHX10_2 = SHX10_2.weaponRules
    SHX10_2 = SHX10_2.blacklistedWeapons
    SHX10_2 = SHX10_2.action
    SHX2_2[SHX9_2] = SHX10_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.generalRules
  SHX3_2 = SHX3_2.antiFreeCam2
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.generalRules
    SHX4_2 = {}
    SHX4_2.enabled = false
    SHX4_2.action = "none"
    SHX3_2.antiFreeCam2 = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.generalRules
  SHX3_2 = SHX3_2.antiFreeCam3
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.generalRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiFreeCam3_enabled"
    SHX7_2 = "false"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiFreeCam3_action"
    SHX7_2 = "Ban Player"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.action = SHX5_2
    SHX3_2.antiFreeCam3 = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.generalRules
  SHX3_2 = SHX3_2.antiRepairVehicle
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.generalRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiRepairVehicle_enabled"
    SHX7_2 = "false"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiRepairVehicle_action"
    SHX7_2 = "Kick Player"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.action = SHX5_2
    SHX3_2.antiRepairVehicle = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.generalRules
  SHX3_2 = SHX3_2.antiHitboxModifier
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.generalRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiHitboxModifier_enabled"
    SHX7_2 = "false"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiHitboxModifier_action"
    SHX7_2 = "Kick Player"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.action = SHX5_2
    SHX3_2.antiHitboxModifier = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.generalRules
  SHX3_2 = SHX3_2.antiSoloSession
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.generalRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiSoloSession_enabled"
    SHX7_2 = "false"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiSoloSession_action"
    SHX7_2 = "Kick Player"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.action = SHX5_2
    SHX3_2.antiSoloSession = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.generalRules
  SHX3_2 = SHX3_2.antiAimAssistRpf
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.generalRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiAimAssistRpf_enabled"
    SHX7_2 = "false"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiAimAssistRpf_action"
    SHX7_2 = "Kick Player"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.action = SHX5_2
    SHX3_2.antiAimAssistRpf = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.generalRules
  SHX3_2 = SHX3_2.unauthorizedAnimationLoaded
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.generalRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_unauthorizedAnimationLoaded_enabled"
    SHX7_2 = "false"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_unauthorizedAnimationLoaded_action"
    SHX7_2 = "Ban Player"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.action = SHX5_2
    SHX3_2.unauthorizedAnimationLoaded = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.entityRules
  SHX3_2 = SHX3_2.maxEntitySpawnDistance
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.entityRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_flag_max_entity_spawn_distance"
    SHX7_2 = "false"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_flag_max_entity_spawn_distance_action"
    SHX7_2 = "Log Player"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.action = SHX5_2
    SHX5_2 = GetConvarInt
    SHX6_2 = "reaper_flag_max_entity_spawn_distance_value"
    SHX7_2 = 50
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.max_distance = SHX5_2
    SHX3_2.maxEntitySpawnDistance = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.generalRules
  SHX3_2 = SHX3_2.blacklistedCommands
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.generalRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_blacklistedCommands_enabled"
    SHX7_2 = "true"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_blacklistedCommands_action"
    SHX7_2 = "Ban Player"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.action = SHX5_2
    SHX3_2.blacklistedCommands = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.generalRules
  SHX3_2 = SHX3_2.antiNativeSpoofer
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.generalRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_run_native_spoof_checks"
    SHX7_2 = "false"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX4_2.action = "Ban Player"
    SHX3_2.antiNativeSpoofer = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.generalRules
  SHX3_2 = SHX3_2.antiAimBot
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.generalRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiAimBot_enabled"
    SHX7_2 = "false"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiAimBot_action"
    SHX7_2 = "Ban Player"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.action = SHX5_2
    SHX3_2.antiAimBot = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.generalRules
  SHX3_2 = SHX3_2.antiClothingChanger
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.generalRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiClothingChanger_enabled"
    SHX7_2 = "false"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiClothingChanger_action"
    SHX7_2 = "Ban Player"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.action = SHX5_2
    SHX3_2.antiClothingChanger = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.weaponRules
  SHX3_2 = SHX3_2.antiWeaponComponentModifier
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.weaponRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiWeaponComponentModifier_enabled"
    SHX7_2 = "false"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiWeaponComponentModifier_action"
    SHX7_2 = "Ban Player"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.action = SHX5_2
    SHX3_2.antiWeaponComponentModifier = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.entityRules
  SHX3_2 = SHX3_2.antiAttachEntities
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.entityRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiAttachEntities_enabled"
    SHX7_2 = "false"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiAttachEntities_action"
    SHX7_2 = "Ban Player"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.action = SHX5_2
    SHX3_2.antiAttachEntities = SHX4_2
  end
  SHX3_2 = SHX0_2.settings
  SHX3_2 = SHX3_2.generalRules
  SHX3_2 = SHX3_2.antiPedSpeedModifier
  if nil == SHX3_2 then
    SHX3_2 = SHX0_2.settings
    SHX3_2 = SHX3_2.generalRules
    SHX4_2 = {}
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiPedSpeedModifier_enabled"
    SHX7_2 = "false"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX5_2 = "true" == SHX5_2
    SHX4_2.enabled = SHX5_2
    SHX5_2 = GetConvar
    SHX6_2 = "reaper_antiPedSpeedModifier_action"
    SHX7_2 = "Ban Player"
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX4_2.action = SHX5_2
    SHX3_2.antiPedSpeedModifier = SHX4_2
  end
  SHX3_2 = {}
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.alerts
  SHX4_2 = SHX4_2.recordScreenSwitch
  SHX3_2.ScreenRecord = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiSpectate
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiSpectate = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.weaponRules
  SHX4_2 = SHX4_2.antiWeaponModifier
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiWeaponModifier = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.weaponRules
  SHX4_2 = SHX4_2.autoAntiWeaponSpawn
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiWeaponSpawn = SHX4_2
  SHX3_2.antiWeaponSpawnIgnoredWeapons = SHX1_2
  SHX3_2.blacklistedWeapon = SHX2_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiTeleport
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiTeleport = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiTeleport
  SHX4_2 = SHX4_2.maxDistance
  SHX3_2.antiTeleportMaxDistance = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiNoClip
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiNoClip = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiNoClip
  SHX4_2 = SHX4_2.maxHeight
  SHX3_2.antiNoClipMaxDistance = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiGodMode
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiGodMode = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiNoCriticalHits
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiNoCriticalHits = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiInfiniteCombatRoll
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiInfiniteCombatRoll = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiFreeCam
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiFreeCam = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiFreeCam2
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiFreeCam2 = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiFreeCam3
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiFreeCam3 = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiInvisible
  if not SHX4_2 then
    SHX4_2 = {}
  end
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiInvisible = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.blacklistedTextures
  if not SHX4_2 then
    SHX4_2 = {}
  end
  SHX4_2 = SHX4_2.enabled
  SHX3_2.blacklistedTextures = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.blacklistedCommands
  SHX3_2.blacklistedCommands = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.blacklistedLabels
  if not SHX4_2 then
    SHX4_2 = {}
  end
  SHX4_2 = SHX4_2.enabled
  SHX3_2.blacklistedLabels = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.onScreenMenuDetection
  if not SHX4_2 then
    SHX4_2 = {}
  end
  SHX4_2 = SHX4_2.enabled
  SHX3_2.onScreenMenuDetection = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiSkinChanger
  if not SHX4_2 then
    SHX4_2 = {}
  end
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiSkinChanger = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiAttach
  if not SHX4_2 then
    SHX4_2 = {}
  end
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiAttach = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiVoiceExploits
  SHX3_2.antiVoiceExploits = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.entityRules
  SHX4_2 = SHX4_2.vehicles
  SHX4_2 = SHX4_2.antiSpawnIsolated
  SHX3_2.antiSpawnIsolated = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiSoloSession
  if not SHX4_2 then
    SHX4_2 = {}
  end
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiSoloSession = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiDevTools
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiDevTools = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiWarpIntoVehicle
  if not SHX4_2 then
    SHX4_2 = {}
  end
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiWarpIntoVehicle = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiRepairVehicle
  if not SHX4_2 then
    SHX4_2 = {}
  end
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiRepairVehicle = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiVehicleModifier
  if not SHX4_2 then
    SHX4_2 = {}
  end
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiVehicleModifier = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiHitboxModifier
  if not SHX4_2 then
    SHX4_2 = {}
  end
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiHitboxModifier = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.unauthorizedAnimationLoaded
  if not SHX4_2 then
    SHX4_2 = {}
  end
  SHX4_2 = SHX4_2.enabled
  SHX3_2.unauthorizedAnimationLoaded = SHX4_2
  SHX4_2 = GetConvar
  SHX5_2 = "reaper_anti_npc_vehicle_attach"
  SHX6_2 = "false"
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = "true" == SHX4_2
  SHX3_2.antiNPCVehicleAttach = SHX4_2
  SHX4_2 = GetConvar
  SHX5_2 = "reaper_heartbeat_checks"
  SHX6_2 = "false"
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = "true" == SHX4_2
  SHX3_2.heartbeat = SHX4_2
  SHX4_2 = GetConvarInt
  SHX5_2 = "reaper_max_aimbot_flags"
  SHX6_2 = 3
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX3_2.max_aimbot_flags = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiAimBot
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiAimBot = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiClothingChanger
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiClothingChanger = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.weaponRules
  SHX4_2 = SHX4_2.antiWeaponComponentModifier
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiWeaponComponentModifier = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.AdvancedExecutionCheck
  SHX3_2.pro_addon = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.entityRules
  SHX4_2 = SHX4_2.antiAttachEntities
  SHX3_2.antiAttachEntities = SHX4_2
  SHX4_2 = SHX0_2.settings
  SHX4_2 = SHX4_2.generalRules
  SHX4_2 = SHX4_2.antiPedSpeedModifier
  SHX4_2 = SHX4_2.enabled
  SHX3_2.antiPedSpeedModifier = SHX4_2
  SHX4_2 = {}
  SHX5_2 = pairs
  SHX6_2 = SHX3_2
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2)
  for SHX9_2, SHX10_2 in SHX5_2, SHX6_2, SHX7_2, SHX8_2 do
    SHX11_2 = Security
    SHX12_2 = SHX11_2
    SHX11_2 = SHX11_2.hash
    SHX13_2 = SHX9_2
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
    SHX4_2[SHX11_2] = SHX10_2
  end
  SHX5_2 = json
  SHX5_2 = SHX5_2.encode
  SHX6_2 = SHX4_2
  SHX5_2 = SHX5_2(SHX6_2)
  SHX4_2 = SHX5_2
  SHX5_2 = {}
  SHX6_2 = pairs
  SHX7_2 = SHX0_2.settings
  SHX7_2 = SHX7_2.ignoredClientEvents
  if not SHX7_2 then
    SHX7_2 = {}
  end
  SHX6_2, SHX7_2, SHX8_2, SHX9_2 = SHX6_2(SHX7_2)
  for SHX10_2, SHX11_2 in SHX6_2, SHX7_2, SHX8_2, SHX9_2 do
    SHX5_2[SHX10_2] = true
  end
  SHX6_2 = pairs
  SHX7_2 = SHX0_2.settings
  SHX7_2 = SHX7_2.ignoredServerEvents
  if not SHX7_2 then
    SHX7_2 = {}
  end
  SHX6_2, SHX7_2, SHX8_2, SHX9_2 = SHX6_2(SHX7_2)
  for SHX10_2, SHX11_2 in SHX6_2, SHX7_2, SHX8_2, SHX9_2 do
    SHX5_2[SHX10_2] = true
  end
  SHX6_2 = json
  SHX6_2 = SHX6_2.encode
  SHX7_2 = SHX5_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX7_2 = Cache
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.get
  SHX9_2 = "events_cache"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  if SHX7_2 ~= SHX6_2 then
    SHX7_2 = SetConvarReplicated
    SHX8_2 = "Reaper_IgnoredEvents"
    SHX9_2 = SHX6_2
    SHX7_2(SHX8_2, SHX9_2)
    SHX7_2 = Cache
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.set
    SHX9_2 = "events_cache"
    SHX10_2 = SHX6_2
    SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  end
  SHX7_2 = SHX0_2.settings
  SHX8_2 = {}
  SHX8_2.config = SHX4_2
  SHX9_2 = Security
  SHX10_2 = SHX9_2
  SHX9_2 = SHX9_2.hash
  SHX11_2 = SHX4_2
  SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
  SHX8_2.key = SHX9_2
  SHX9_2 = Cache
  SHX10_2 = SHX9_2
  SHX9_2 = SHX9_2.get
  SHX11_2 = "serverId"
  SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
  SHX8_2.serverId = SHX9_2
  SHX7_2.client = SHX8_2
  SHX7_2 = RPC
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.emitNet
  SHX9_2 = "Reaper:UpdateConfig"
  SHX10_2 = -1
  SHX11_2 = json
  SHX11_2 = SHX11_2.encode
  SHX12_2 = SHX0_2.settings
  SHX12_2 = SHX12_2.client
  SHX11_2, SHX12_2, SHX13_2 = SHX11_2(SHX12_2)
  SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  SHX7_2 = SetConvarReplicated
  SHX8_2 = "reaper_config"
  SHX9_2 = json
  SHX9_2 = SHX9_2.encode
  SHX10_2 = SHX0_2.settings
  SHX10_2 = SHX10_2.client
  SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX9_2(SHX10_2)
  SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  SHX7_2 = Logger
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.setLevel
  SHX9_2 = GetConvarInt
  SHX10_2 = "reaper_log_level"
  SHX11_2 = 0
  SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX9_2(SHX10_2, SHX11_2)
  SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  SHX7_2 = Logger
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.log
  SHX9_2 = "settings built"
  SHX10_2 = "debug"
  SHX7_2(SHX8_2, SHX9_2, SHX10_2)
end
SHX0_1.build = SHX1_1
SHX0_1 = Settings
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.settings
  return SHX1_2
end
SHX0_1.get = SHX1_1
SHX0_1 = Settings
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2
  SHX0_2.settings = SHX1_2
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.build
  SHX2_2(SHX3_2)
end
SHX0_1.set = SHX1_1
SHX0_1 = Settings
Settings = SHX0_1
