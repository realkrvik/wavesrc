-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1
SHX0_1 = class
SHX1_1 = "Resources"
SHX0_1 = SHX0_1(SHX1_1)
Resources = SHX0_1
SHX0_1 = RPC
RPC = SHX0_1
SHX0_1 = Resources
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX0_2.key = SHX1_2
  SHX0_2.vulnerableResources = nil
  SHX2_2 = {}
  SHX0_2.cache = SHX2_2
  SHX2_2 = {}
  SHX0_2.resources = SHX2_2
  SHX0_2.resources_loaded = false
  SHX2_2 = 0
  SHX3_2 = GetNumResources
  SHX3_2 = SHX3_2()
  SHX3_2 = SHX3_2 - 1
  SHX4_2 = 1
  for SHX5_2 = SHX2_2, SHX3_2, SHX4_2 do
    SHX6_2 = Resource
    SHX7_2 = GetResourceByFindIndex
    SHX8_2 = SHX5_2
    SHX7_2, SHX8_2 = SHX7_2(SHX8_2)
    SHX6_2(SHX7_2, SHX8_2)
  end
  SHX0_2.resources_loaded = true
end
SHX0_1.constructor = SHX1_1
SHX0_1 = Resources
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.resources_loaded
  return SHX1_2
end
SHX0_1.loaded = SHX1_1
SHX0_1 = Resources
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = SHX0_2.vulnerableResources
  if nil == SHX1_2 then
    SHX1_2 = json
    SHX1_2 = SHX1_2.decode
    SHX2_2 = HTTP
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.await
    SHX4_2 = "https://api.reaperac.com/api/v1/data/vulnerableresources"
    SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
    SHX2_2 = SHX2_2.body
    if not SHX2_2 then
      SHX2_2 = "{}"
    end
    SHX1_2 = SHX1_2(SHX2_2)
    SHX0_2.vulnerableResources = SHX1_2
  end
  SHX1_2 = SHX0_2.vulnerableResources
  return SHX1_2
end
SHX0_1.getVulnerableResources = SHX1_1
SHX0_1 = Resources
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  SHX2_2 = SHX0_2.cache
  SHX2_2 = SHX2_2[SHX1_2]
  SHX3_2 = SHX0_2.cache
  SHX4_2 = SHX2_2 or SHX4_2
  if not SHX2_2 then
    SHX4_2 = {}
  end
  SHX3_2[SHX1_2] = SHX4_2
  SHX3_2 = SHX0_2.cache
  SHX3_2 = SHX3_2[SHX1_2]
  return SHX3_2
end
SHX0_1.isVulnerable = SHX1_1
SHX0_1 = Resources
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2
  SHX1_2 = {}
  SHX2_2 = 0
  SHX3_2 = GetNumResources
  SHX3_2 = SHX3_2()
  SHX3_2 = SHX3_2 - 1
  SHX4_2 = 1
  for SHX5_2 = SHX2_2, SHX3_2, SHX4_2 do
    SHX6_2 = GetResourceByFindIndex
    SHX7_2 = SHX5_2
    SHX6_2 = SHX6_2(SHX7_2)
    SHX7_2 = GetResourcePath
    SHX8_2 = SHX6_2
    SHX7_2 = SHX7_2(SHX8_2)
    SHX8_2 = LoadResourceFile
    SHX9_2 = SHX6_2
    SHX10_2 = "fxmanifest.lua"
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
    if not SHX8_2 then
      SHX9_2 = LoadResourceFile
      SHX10_2 = SHX6_2
      SHX11_2 = "__resource.lua"
      SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
      SHX8_2 = SHX9_2
    end
    if SHX8_2 then
      SHX9_2 = GetResourceState
      SHX10_2 = SHX6_2
      SHX9_2 = SHX9_2(SHX10_2)
      if "stopped" ~= SHX9_2 and "ReaperV4" ~= SHX6_2 then
        SHX9_2 = table
        SHX9_2 = SHX9_2.insert
        SHX10_2 = SHX1_2
        SHX11_2 = {}
        SHX13_2 = SHX7_2
        SHX12_2 = SHX7_2.sub
        SHX14_2 = string
        SHX14_2 = SHX14_2.find
        SHX15_2 = SHX7_2
        SHX16_2 = "//"
        SHX14_2 = SHX14_2(SHX15_2, SHX16_2)
        SHX14_2 = SHX14_2 + 2
        SHX15_2 = #SHX7_2
        SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2)
        SHX11_2.path = SHX12_2
        SHX11_2.name = SHX6_2
        SHX12_2 = string
        SHX12_2 = SHX12_2.match
        SHX13_2 = SHX8_2
        SHX14_2 = "@ReaperV4/imports/bypass.lua"
        SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
        SHX12_2 = nil ~= SHX12_2
        SHX11_2.protected = SHX12_2
        SHX12_2 = string
        SHX12_2 = SHX12_2.match
        SHX13_2 = SHX8_2
        SHX14_2 = "client_scripts"
        SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
        if not SHX12_2 then
          SHX12_2 = string
          SHX12_2 = SHX12_2.match
          SHX13_2 = SHX8_2
          SHX14_2 = "client_script"
          SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
          if not SHX12_2 then
            SHX12_2 = string
            SHX12_2 = SHX12_2.match
            SHX13_2 = SHX8_2
            SHX14_2 = "server_script"
            SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
            if not SHX12_2 then
              SHX12_2 = string
              SHX12_2 = SHX12_2.match
              SHX13_2 = SHX8_2
              SHX14_2 = "server_scripts"
              SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
            end
          end
        end
        SHX11_2.needs_protected = SHX12_2
        SHX12_2 = Resources
        SHX13_2 = SHX12_2
        SHX12_2 = SHX12_2.isVulnerable
        SHX14_2 = SHX6_2
        SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
        SHX11_2.vulnerabilities = SHX12_2
        SHX9_2(SHX10_2, SHX11_2)
      end
    end
  end
  return SHX1_2
end
SHX0_1.getData = SHX1_1
function SHX0_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = 1
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX0_3 = SHX1_2
    if not SHX0_3 then
      SHX0_3 = nil
      return SHX0_3
    end
    SHX0_3 = string
    SHX0_3 = SHX0_3.find
    SHX1_3 = SHX0_2
    SHX2_3 = "\r?\n"
    SHX3_3 = SHX1_2
    SHX0_3, SHX1_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3)
    SHX2_3 = nil
    if SHX0_3 then
      SHX3_3 = SHX0_2
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.sub
      SHX5_3 = SHX1_2
      SHX6_3 = SHX0_3 - 1
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      SHX2_3 = SHX3_3
      SHX3_3 = SHX1_3 + 1
      SHX1_2 = SHX3_3
    else
      SHX3_3 = SHX0_2
      SHX4_3 = SHX3_3
      SHX3_3 = SHX3_3.sub
      SHX5_3 = SHX1_2
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX2_3 = SHX3_3
      SHX3_3 = nil
      SHX1_2 = SHX3_3
    end
    return SHX2_3
  end
  return SHX2_2
end
SHX1_1 = Resources
function SHX2_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2
  SHX4_2 = Cache
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.get
  SHX6_2 = tostring
  SHX7_2 = Security
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.hash
  SHX9_2 = SHX1_2
  SHX10_2 = SHX2_2
  SHX11_2 = SHX3_2
  SHX9_2 = SHX9_2 .. SHX10_2 .. SHX11_2
  SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2)
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2)
  if SHX4_2 then
    return SHX4_2
  end
  SHX5_2 = 0
  SHX6_2 = nil
  SHX7_2 = LoadResourceFile
  SHX8_2 = SHX1_2
  SHX9_2 = SHX2_2
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX8_2 = GetResourcePath
  SHX9_2 = SHX1_2
  SHX8_2 = SHX8_2(SHX9_2)
  if nil ~= SHX7_2 then
    SHX9_2 = io
    SHX9_2 = SHX9_2.open
    SHX10_2 = SHX8_2
    SHX11_2 = "/"
    SHX12_2 = SHX2_2
    SHX10_2 = SHX10_2 .. SHX11_2 .. SHX12_2
    SHX11_2 = "r"
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
    if nil ~= SHX9_2 then
      SHX6_2 = ""
      SHX10_2 = SHX0_1
      SHX12_2 = SHX9_2
      SHX11_2 = SHX9_2.read
      SHX13_2 = "a"
      SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2 = SHX11_2(SHX12_2, SHX13_2)
      SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2)
      for SHX14_2 in SHX10_2, SHX11_2, SHX12_2, SHX13_2 do
        SHX5_2 = SHX5_2 + 1
        SHX15_2 = SHX3_2 - 3
        if SHX5_2 > SHX15_2 then
          SHX15_2 = SHX3_2 + 3
          if SHX5_2 < SHX15_2 then
            if SHX5_2 == SHX3_2 then
              SHX15_2 = SHX6_2
              SHX16_2 = "^3[%s]     %s^7\n"
              SHX17_2 = SHX16_2
              SHX16_2 = SHX16_2.format
              SHX18_2 = SHX5_2
              SHX20_2 = SHX14_2
              SHX19_2 = SHX14_2.gsub
              SHX21_2 = "\n"
              SHX22_2 = ""
              SHX19_2, SHX20_2, SHX21_2, SHX22_2 = SHX19_2(SHX20_2, SHX21_2, SHX22_2)
              SHX16_2 = SHX16_2(SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2)
              SHX15_2 = SHX15_2 .. SHX16_2
              SHX6_2 = SHX15_2
            else
              SHX15_2 = SHX6_2
              SHX16_2 = "[%s]     %s\n"
              SHX17_2 = SHX16_2
              SHX16_2 = SHX16_2.format
              SHX18_2 = SHX5_2
              SHX20_2 = SHX14_2
              SHX19_2 = SHX14_2.gsub
              SHX21_2 = "\n"
              SHX22_2 = ""
              SHX19_2, SHX20_2, SHX21_2, SHX22_2 = SHX19_2(SHX20_2, SHX21_2, SHX22_2)
              SHX16_2 = SHX16_2(SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2)
              SHX15_2 = SHX15_2 .. SHX16_2
              SHX6_2 = SHX15_2
            end
          end
        end
      end
      SHX11_2 = SHX9_2
      SHX10_2 = SHX9_2.close
      SHX10_2(SHX11_2)
    end
  end
  if SHX6_2 then
    SHX10_2 = SHX6_2
    SHX9_2 = SHX6_2.len
    SHX9_2 = SHX9_2(SHX10_2)
    SHX10_2 = 1500
    if SHX9_2 > SHX10_2 then
      SHX10_2 = SHX6_2
      SHX9_2 = SHX6_2.sub
      SHX11_2 = 1
      SHX12_2 = 1500
      SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2)
      SHX10_2 = "..."
      SHX9_2 = SHX9_2 .. SHX10_2
      SHX6_2 = SHX9_2
    end
  end
  SHX9_2 = Cache
  SHX10_2 = SHX9_2
  SHX9_2 = SHX9_2.set
  SHX11_2 = tostring
  SHX12_2 = Security
  SHX13_2 = SHX12_2
  SHX12_2 = SHX12_2.hash
  SHX14_2 = SHX1_2
  SHX15_2 = SHX2_2
  SHX16_2 = SHX3_2
  SHX14_2 = SHX14_2 .. SHX15_2 .. SHX16_2
  SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2 = SHX12_2(SHX13_2, SHX14_2)
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2)
  SHX12_2 = SHX6_2
  SHX9_2(SHX10_2, SHX11_2, SHX12_2)
  return SHX6_2
end
SHX1_1.getCodeNearLine = SHX2_1
SHX1_1 = Resources
function SHX2_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2
  SHX4_2 = tostring
  SHX5_2 = "getCodeOnLine_"
  SHX6_2 = Security
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.hash
  SHX8_2 = SHX1_2
  SHX9_2 = SHX2_2
  SHX10_2 = SHX3_2
  SHX8_2 = SHX8_2 .. SHX9_2 .. SHX10_2
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX5_2 = SHX5_2 .. SHX6_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = Cache
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.get
  SHX7_2 = SHX4_2
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  if SHX5_2 then
    return SHX5_2
  end
  SHX6_2 = GetResourcePath
  SHX7_2 = SHX1_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX7_2 = nil
  SHX8_2 = io
  SHX8_2 = SHX8_2.open
  SHX9_2 = SHX6_2
  SHX10_2 = "/"
  SHX11_2 = SHX2_2
  SHX9_2 = SHX9_2 .. SHX10_2 .. SHX11_2
  SHX10_2 = "r"
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  if nil ~= SHX8_2 then
    SHX9_2 = 0
    SHX10_2 = SHX0_1
    SHX12_2 = SHX8_2
    SHX11_2 = SHX8_2.read
    SHX13_2 = "a"
    SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2 = SHX11_2(SHX12_2, SHX13_2)
    SHX10_2, SHX11_2, SHX12_2, SHX13_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2)
    for SHX14_2 in SHX10_2, SHX11_2, SHX12_2, SHX13_2 do
      SHX9_2 = SHX9_2 + 1
      if SHX9_2 == SHX3_2 then
        SHX7_2 = SHX14_2
        break
      end
    end
    SHX11_2 = SHX8_2
    SHX10_2 = SHX8_2.close
    SHX10_2(SHX11_2)
  end
  return SHX7_2
end
SHX1_1.getCodeOnLine = SHX2_1
SHX1_1 = Resources
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.new
SHX1_1 = SHX1_1(SHX2_1)
Resources = SHX1_1
