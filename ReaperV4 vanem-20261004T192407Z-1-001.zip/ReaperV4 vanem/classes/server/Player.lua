-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1
SHX0_1 = class
SHX1_1 = "Player"
SHX0_1 = SHX0_1(SHX1_1)
SHX1_1 = Player
SHX2_1 = RPC
RPC = SHX2_1
SHX2_1 = Logger
Logger = SHX2_1
SHX2_1 = Security
Security = SHX2_1
function SHX2_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  if 1 == SHX0_2 or true == SHX0_2 then
    SHX1_2 = true
    return SHX1_2
  else
    SHX1_2 = false
    return SHX1_2
  end
end
function SHX3_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  if nil == SHX1_2 then
    return
  end
  SHX2_2 = GetPlayerName
  SHX3_2 = SHX1_2
  SHX2_2 = SHX2_2(SHX3_2)
  if nil == SHX2_2 then
    return
  end
  SHX3_2 = GetPlayerIdentifierByType
  SHX4_2 = SHX1_2
  SHX5_2 = "license"
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = GetPlayerIdentifierByType
  SHX5_2 = SHX1_2
  SHX6_2 = "license2"
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = GetPlayerIdentifierByType
  SHX6_2 = SHX1_2
  SHX7_2 = "discord"
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX6_2 = GetPlayerIdentifierByType
  SHX7_2 = SHX1_2
  SHX8_2 = "fivem"
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = GetPlayerIdentifierByType
  SHX8_2 = SHX1_2
  SHX9_2 = "steam"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX8_2 = GetPlayerIdentifierByType
  SHX9_2 = SHX1_2
  SHX10_2 = "ip"
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  SHX9_2 = GetPlayerIdentifierByType
  SHX10_2 = SHX1_2
  SHX11_2 = "xbox"
  SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
  if SHX3_2 then
    SHX11_2 = SHX3_2
    SHX10_2 = SHX3_2.gsub
    SHX12_2 = "license:"
    SHX13_2 = ""
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2)
    SHX3_2 = SHX10_2
  end
  if SHX4_2 then
    SHX11_2 = SHX4_2
    SHX10_2 = SHX4_2.gsub
    SHX12_2 = "license2:"
    SHX13_2 = ""
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2)
    SHX4_2 = SHX10_2
  end
  if SHX5_2 then
    SHX11_2 = SHX5_2
    SHX10_2 = SHX5_2.gsub
    SHX12_2 = "discord:"
    SHX13_2 = ""
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2)
    SHX5_2 = SHX10_2
  end
  if SHX6_2 then
    SHX11_2 = SHX6_2
    SHX10_2 = SHX6_2.gsub
    SHX12_2 = "fivem:"
    SHX13_2 = ""
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2)
    SHX6_2 = SHX10_2
  end
  if SHX7_2 then
    SHX11_2 = SHX7_2
    SHX10_2 = SHX7_2.gsub
    SHX12_2 = "steam:"
    SHX13_2 = ""
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2)
    SHX7_2 = SHX10_2
  end
  if SHX8_2 then
    SHX11_2 = SHX8_2
    SHX10_2 = SHX8_2.gsub
    SHX12_2 = "ip:"
    SHX13_2 = ""
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2)
    SHX8_2 = SHX10_2
  end
  if SHX9_2 then
    SHX11_2 = SHX9_2
    SHX10_2 = SHX9_2.gsub
    SHX12_2 = "xbox:"
    SHX13_2 = ""
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2)
    SHX9_2 = SHX10_2
  end
  SHX0_2.source = SHX1_2
  SHX0_2.name = SHX2_2
  SHX10_2 = {}
  SHX10_2.license = SHX3_2
  SHX10_2.license2 = SHX4_2
  SHX10_2.discord = SHX5_2
  SHX10_2.fivem = SHX6_2
  SHX10_2.steam = SHX7_2
  SHX10_2.ip = SHX8_2
  SHX10_2.xbox = SHX9_2
  SHX0_2.identifiers = SHX10_2
  SHX10_2 = {}
  SHX0_2.metadata = SHX10_2
  SHX10_2 = {}
  SHX0_2.metadata_ttl = SHX10_2
  SHX10_2 = {}
  SHX0_2.cache = SHX10_2
  SHX10_2 = {}
  SHX11_2 = SHX1_1
  SHX12_2 = SHX0_2.source
  SHX11_2 = SHX11_2(SHX12_2)
  SHX11_2 = SHX11_2.state
  SHX10_2.state = SHX11_2
  SHX0_2.private = SHX10_2
  SHX10_2 = GetPlayerGuid
  SHX11_2 = SHX1_2
  SHX10_2 = SHX10_2(SHX11_2)
  SHX0_2.guid = SHX10_2
end
SHX0_1.constructor = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.name
  return SHX1_2
end
SHX0_1.getName = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = GetPlayerPing
  SHX2_2 = SHX0_2.source
  return SHX1_2(SHX2_2)
end
SHX0_1.getPing = SHX3_1
function SHX3_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2
  SHX2_2 = SHX0_2.identifiers
  SHX2_2 = SHX2_2[SHX1_2]
  return SHX2_2
end
SHX0_1.getIdentifier = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.identifiers
  return SHX1_2
end
SHX0_1.getIdentifiers = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.guid
  return SHX1_2
end
SHX0_1.getGuid = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.source
  return SHX1_2
end
SHX0_1.getId = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.private
  SHX1_2 = SHX1_2.key
  return SHX1_2
end
SHX0_1.getKey = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2
  SHX3_2 = SHX0_2.metadata
  SHX3_2 = SHX3_2[SHX1_2]
  SHX4_2 = SHX0_2.metadata_ttl
  SHX4_2 = SHX4_2[SHX1_2]
  if SHX4_2 then
    SHX4_2 = GetGameTimer
    SHX4_2 = SHX4_2()
    SHX5_2 = SHX0_2.metadata_ttl
    SHX5_2 = SHX5_2[SHX1_2]
    if SHX4_2 > SHX5_2 then
      SHX3_2 = nil
    end
  end
  if nil == SHX3_2 then
    SHX3_2 = SHX2_2
  end
  return SHX3_2
end
SHX0_1.getMeta = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2
  SHX4_2 = SHX0_2.metadata
  SHX4_2[SHX1_2] = SHX2_2
  if SHX3_2 then
    SHX4_2 = SHX0_2.metadata_ttl
    SHX5_2 = SHX3_2 * 1000
    SHX6_2 = GetGameTimer
    SHX6_2 = SHX6_2()
    SHX5_2 = SHX5_2 + SHX6_2
    SHX4_2[SHX1_2] = SHX5_2
  end
end
SHX0_1.setMeta = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2
  SHX3_2 = GetGameTimer
  SHX3_2 = SHX3_2()
  SHX4_2 = SHX1_2
  SHX5_2 = "_synced"
  SHX4_2 = SHX4_2 .. SHX5_2
  SHX6_2 = SHX0_2
  SHX5_2 = SHX0_2.getMeta
  SHX7_2 = SHX4_2
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  if SHX5_2 ~= SHX2_2 then
    SHX6_2 = SHX0_2.private
    SHX6_2 = SHX6_2.state
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.set
    SHX8_2 = "reaper:"
    SHX9_2 = Security
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.hash
    SHX11_2 = SHX1_2
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
    SHX8_2 = SHX8_2 .. SHX9_2
    SHX9_2 = {}
    SHX10_2 = Security
    SHX11_2 = SHX10_2
    SHX10_2 = SHX10_2.hash
    SHX12_2 = SHX1_2
    SHX13_2 = tostring
    SHX14_2 = SHX2_2
    SHX13_2 = SHX13_2(SHX14_2)
    SHX14_2 = SHX3_2
    SHX12_2 = SHX12_2 .. SHX13_2 .. SHX14_2
    SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
    SHX9_2.key = SHX10_2
    SHX9_2.key2 = SHX3_2
    SHX9_2.key3 = SHX2_2
    SHX10_2 = true
    SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
    SHX7_2 = SHX0_2
    SHX6_2 = SHX0_2.setMeta
    SHX8_2 = SHX4_2
    SHX9_2 = SHX2_2
    SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  end
end
SHX0_1.setSyncedState = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX3_2 = SHX0_2.private
  SHX3_2 = SHX3_2.state
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.get
  SHX5_2 = "reaper:"
  SHX6_2 = Security
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.hash
  SHX8_2 = SHX1_2
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX5_2 = SHX5_2 .. SHX6_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  if nil ~= SHX3_2 then
    SHX4_2 = Security
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.hash
    SHX6_2 = SHX1_2
    SHX7_2 = tostring
    SHX8_2 = SHX3_2.key3
    SHX7_2 = SHX7_2(SHX8_2)
    SHX8_2 = SHX3_2.key2
    SHX6_2 = SHX6_2 .. SHX7_2 .. SHX8_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    SHX5_2 = SHX3_2.key
    if SHX4_2 == SHX5_2 then
      goto SHX_LABEL_26
    end
  end
  return SHX2_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_26:: outside nested blocks until all 'goto SHX_LABEL_26' can see it
  ::SHX_LABEL_26::
  SHX4_2 = SHX3_2.key3
  return SHX4_2
end
SHX0_1.getSyncedState = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = GetPlayerPed
  SHX2_2 = SHX0_2.source
  return SHX1_2(SHX2_2)
end
SHX0_1.getPed = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = GetEntityModel
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getPed
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.getPedModel = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = GetEntityCoords
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getPed
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.getCoords = SHX3_1
function SHX3_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getCoords
  SHX2_2 = SHX2_2(SHX3_2)
  SHX4_2 = SHX0_2
  SHX3_2 = SHX0_2.getHeading
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = vec3
  SHX5_2 = SHX2_2.x
  SHX6_2 = math
  SHX6_2 = SHX6_2.newsin
  SHX7_2 = SHX3_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX6_2 = SHX1_2 * SHX6_2
  SHX5_2 = SHX5_2 - SHX6_2
  SHX6_2 = SHX2_2.y
  SHX7_2 = math
  SHX7_2 = SHX7_2.newcos
  SHX8_2 = SHX3_2
  SHX7_2 = SHX7_2(SHX8_2)
  SHX7_2 = SHX1_2 * SHX7_2
  SHX6_2 = SHX6_2 + SHX7_2
  SHX7_2 = SHX2_2.z
  return SHX4_2(SHX5_2, SHX6_2, SHX7_2)
end
SHX0_1.getCoordsInFront = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = GetEntityHeading
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getPed
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.getHeading = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = GetSelectedPedWeapon
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getPed
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.getWeapon = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = _ENV
  SHX2_2 = "NetworkGetVoiceProximityOverrideForPlayer"
  SHX1_2 = SHX1_2[SHX2_2]
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getId
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.getVoiceProximity = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = GetPlayerWeaponDamageModifier
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getId
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.getWeaponDamageModifier = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = GetPlayerInvincible
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getId
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.isInvincible = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = GetVehiclePedIsIn
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getPed
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = false
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = 0 ~= SHX1_2
  return SHX1_2
end
SHX0_1.isInVehicle = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = SHX0_2
  SHX1_2 = SHX0_2.getCamFocusPos
  SHX1_2 = SHX1_2(SHX2_2)
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getCoords
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = 15
  SHX5_2 = SHX0_2
  SHX4_2 = SHX0_2.isInVehicle
  SHX4_2 = SHX4_2(SHX5_2)
  if SHX4_2 then
    SHX3_2 = 40
  end
  SHX4_2 = SHX2_1
  SHX5_2 = IsPlayerInFreeCamMode
  SHX7_2 = SHX0_2
  SHX6_2 = SHX0_2.getId
  SHX6_2, SHX7_2 = SHX6_2(SHX7_2)
  SHX5_2, SHX6_2, SHX7_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  if SHX4_2 then
    SHX4_2 = GetDistanceBetweenCoords
    SHX5_2 = SHX1_2
    SHX6_2 = SHX2_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    SHX4_2 = SHX3_2 < SHX4_2
  end
  return SHX4_2
end
SHX0_1.isInFreeCam = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = GetPlayerFocusPos
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getId
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.getCamFocusPos = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = SHX2_1
  SHX2_2 = IsEntityVisible
  SHX4_2 = SHX0_2
  SHX3_2 = SHX0_2.getPed
  SHX3_2, SHX4_2 = SHX3_2(SHX4_2)
  SHX2_2, SHX3_2, SHX4_2 = SHX2_2(SHX3_2, SHX4_2)
  return SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
SHX0_1.isVisible = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX3_2 = SetPedConfigFlag
  SHX5_2 = SHX0_2
  SHX4_2 = SHX0_2.getPed
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = SHX1_2
  SHX6_2 = SHX2_2
  return SHX3_2(SHX4_2, SHX5_2, SHX6_2)
end
SHX0_1.setPedConfig = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX4_2 = SetEntityCoords
  SHX6_2 = SHX0_2
  SHX5_2 = SHX0_2.getPed
  SHX5_2 = SHX5_2(SHX6_2)
  SHX6_2 = SHX1_2
  SHX7_2 = SHX2_2
  SHX8_2 = SHX3_2
  return SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
end
SHX0_1.setCoords = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = RPC
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.emitNet
  SHX4_2 = SHX1_2
  SHX5_2 = SHX0_2.source
  SHX6_2 = ...
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  SHX2_2 = 1
  return SHX2_2
end
SHX0_1.emit = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX5_2 = RPC
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.await
  SHX7_2 = SHX1_2
  SHX8_2 = SHX0_2.source
  SHX9_2 = SHX2_2
  SHX10_2 = SHX3_2
  SHX11_2 = SHX4_2
  return SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
end
SHX0_1.rpc_await = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = Settings
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.get
  SHX1_2 = SHX1_2(SHX2_2)
  SHX1_2 = SHX1_2.grantedAccess
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getIdentifier
  SHX4_2 = "fivem"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX3_2 = SHX2_2 or SHX3_2
  if not SHX2_2 then
    SHX3_2 = ""
  end
  SHX3_2 = SHX1_2[SHX3_2]
  return SHX3_2
end
SHX0_1.getCfxInfo = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = Settings
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.get
  SHX1_2 = SHX1_2(SHX2_2)
  SHX1_2 = SHX1_2.grantedAccess
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getIdentifier
  SHX4_2 = "fivem"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX3_2 = tostring
  SHX4_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2)
  if not SHX3_2 then
    SHX3_2 = ""
  end
  SHX3_2 = SHX1_2[SHX3_2]
  if not SHX3_2 then
    SHX3_2 = {}
    SHX4_2 = {}
    SHX3_2.allowedRoles = SHX4_2
  end
  SHX4_2 = SHX3_2.allowedRoles
  return SHX4_2
end
SHX0_1.getPerms = SHX3_1
function SHX3_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getPerms
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SHX0_2.cache
  SHX4_2 = "hasPerm:"
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2 .. SHX5_2
  SHX3_2 = SHX3_2[SHX4_2]
  if true ~= SHX3_2 and false ~= SHX3_2 then
    SHX4_2 = pairs
    SHX5_2 = SHX2_2
    SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
    for SHX8_2, SHX9_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
      if "All Permissions" == SHX9_2 or SHX9_2 == SHX1_2 then
        SHX3_2 = true
        break
      end
    end
  end
  return SHX3_2
end
SHX0_1.hasPerm = SHX3_1
function SHX3_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2, SHX27_2, SHX28_2, SHX29_2
  while true do
    SHX2_2 = Settings
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.get
    SHX2_2 = SHX2_2(SHX3_2)
    if nil ~= SHX2_2 then
      break
    end
    SHX2_2 = Wait
    SHX3_2 = 1000
    SHX2_2(SHX3_2)
  end
  SHX2_2 = Settings
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.get
  SHX2_2 = SHX2_2(SHX3_2)
  SHX2_2 = SHX2_2.permissions
  SHX2_2 = SHX2_2.bypassRules
  SHX4_2 = SHX0_2
  SHX3_2 = SHX0_2.getIdentifier
  SHX5_2 = "license"
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX5_2 = SHX0_2
  SHX4_2 = SHX0_2.getIdentifier
  SHX6_2 = "discord"
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX6_2 = SHX0_2
  SHX5_2 = SHX0_2.getIdentifier
  SHX7_2 = "steam"
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  if "blacklistedEntity" == SHX1_2 then
    SHX1_2 = "blacklistedEntities"
  elseif "blacklistedParticle" == SHX1_2 then
    SHX1_2 = "blacklistedParticles"
  elseif "blacklistedExplosion" == SHX1_2 then
    SHX1_2 = "BlacklistedExplosions"
  elseif "blacklistedWeapon" == SHX1_2 then
    SHX1_2 = "blacklistedWeapons"
  end
  SHX6_2 = false
  SHX7_2 = pairs
  SHX8_2 = SHX2_2
  SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX7_2(SHX8_2)
  for SHX11_2, SHX12_2 in SHX7_2, SHX8_2, SHX9_2, SHX10_2 do
    SHX13_2 = pairs
    SHX14_2 = SHX12_2.bypassTargetDetections
    SHX13_2, SHX14_2, SHX15_2, SHX16_2 = SHX13_2(SHX14_2)
    for SHX17_2, SHX18_2 in SHX13_2, SHX14_2, SHX15_2, SHX16_2 do
      if "ALL_DETECTIONS" == SHX18_2 or SHX1_2 == SHX18_2 then
        SHX19_2 = pairs
        SHX20_2 = SHX12_2.bypassTargets
        SHX19_2, SHX20_2, SHX21_2, SHX22_2 = SHX19_2(SHX20_2)
        for SHX23_2, SHX24_2 in SHX19_2, SHX20_2, SHX21_2, SHX22_2 do
          SHX25_2 = table
          SHX25_2 = SHX25_2.unpack
          SHX26_2 = string
          SHX26_2 = SHX26_2.split
          SHX27_2 = SHX24_2
          SHX28_2 = "="
          SHX26_2, SHX27_2, SHX28_2, SHX29_2 = SHX26_2(SHX27_2, SHX28_2)
          SHX25_2, SHX26_2 = SHX25_2(SHX26_2, SHX27_2, SHX28_2, SHX29_2)
          if "ace" == SHX25_2 then
            SHX27_2 = IsPlayerAceAllowed
            SHX29_2 = SHX0_2
            SHX28_2 = SHX0_2.getId
            SHX28_2 = SHX28_2(SHX29_2)
            SHX29_2 = SHX26_2
            SHX27_2 = SHX27_2(SHX28_2, SHX29_2)
          end
          if SHX27_2 or SHX26_2 == SHX3_2 or SHX26_2 == SHX5_2 or SHX26_2 == SHX4_2 then
            SHX6_2 = true
            break
          end
        end
      end
    end
  end
  return SHX6_2
end
SHX0_1.isBypassed = SHX3_1
function SHX3_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  SHX2_2 = DropPlayer
  SHX3_2 = SHX0_2.source
  SHX4_2 = SHX1_2
  SHX2_2(SHX3_2, SHX4_2)
end
SHX0_1.kick = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.await
  SHX3_2 = "ScreenshotScreen"
  SHX4_2 = SHX0_2.source
  SHX5_2 = nil
  SHX6_2 = 50000
  SHX7_2 = 50000
  return SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
end
SHX0_1.getScreenshot = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.await
  SHX3_2 = "ClipScreen"
  SHX4_2 = SHX0_2.source
  SHX5_2 = nil
  SHX6_2 = 50000
  SHX7_2 = 50000
  return SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
end
SHX0_1.getScreenRecording = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.await
  SHX3_2 = "Get_OCR"
  SHX4_2 = SHX0_2.source
  SHX5_2 = nil
  SHX6_2 = 50000
  SHX7_2 = 20000
  return SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
end
SHX0_1.getOCR = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = RPC
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.await
  SHX4_2 = "invokeCPlayer"
  SHX6_2 = SHX0_2
  SHX5_2 = SHX0_2.getId
  SHX5_2 = SHX5_2(SHX6_2)
  SHX6_2 = {}
  SHX7_2 = SHX1_2
  SHX8_2 = ...
  SHX6_2[1] = SHX7_2
  SHX6_2[2] = SHX8_2
  return SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
end
SHX0_1.invokeCPlayer = SHX3_1
function SHX3_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX2_2 = SHX0_2
  SHX1_2 = SHX0_2.getIdentifier
  SHX3_2 = "fivem"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  if nil == SHX1_2 then
    SHX2_2 = false
    SHX3_2 = "You do not have FiveM linked"
    return SHX2_2, SHX3_2
  end
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getMeta
  SHX4_2 = "access_token"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if SHX2_2 then
    SHX2_2 = true
    SHX4_2 = SHX0_2
    SHX3_2 = SHX0_2.getMeta
    SHX5_2 = "access_token"
    SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX3_2(SHX4_2, SHX5_2)
    return SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  end
  SHX2_2 = HTTP
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.await
  SHX4_2 = "https://api.reaperac.com/api/v1/access/grant"
  SHX5_2 = "POST"
  SHX6_2 = json
  SHX6_2 = SHX6_2.encode
  SHX7_2 = {}
  SHX8_2 = Cache
  SHX9_2 = SHX8_2
  SHX8_2 = SHX8_2.get
  SHX10_2 = "secret"
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  SHX7_2.server_secret = SHX8_2
  SHX8_2 = tonumber
  SHX9_2 = SHX1_2
  SHX8_2 = SHX8_2(SHX9_2)
  SHX7_2.fivemId = SHX8_2
  SHX8_2 = Cache
  SHX9_2 = SHX8_2
  SHX8_2 = SHX8_2.get
  SHX10_2 = "serverId"
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  SHX7_2.serverId = SHX8_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX7_2 = {}
  SHX7_2["Content-Type"] = "application/json"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
  SHX3_2 = SHX2_2.status
  if 200 ~= SHX3_2 then
    SHX3_2 = false
    SHX4_2 = "This server responded with error code %s"
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.format
    SHX6_2 = SHX2_2.status
    SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX4_2(SHX5_2, SHX6_2)
    return SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  end
  SHX3_2 = json
  SHX3_2 = SHX3_2.decode
  SHX4_2 = SHX2_2.body
  SHX3_2 = SHX3_2(SHX4_2)
  SHX5_2 = SHX0_2
  SHX4_2 = SHX0_2.setMeta
  SHX6_2 = "access_token"
  SHX7_2 = SHX3_2.access_token
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = true
  SHX5_2 = SHX3_2.access_token
  return SHX4_2, SHX5_2
end
SHX0_1.getAccessToken = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  if "log" ~= SHX1_2 and "kick" ~= SHX1_2 and "ban" ~= SHX1_2 then
    SHX3_2 = true
    SHX4_2 = "Invalid Action"
    return SHX3_2, SHX4_2
  end
  SHX3_2 = type
  SHX4_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2)
  if "string" ~= SHX3_2 then
    SHX3_2 = true
    SHX4_2 = "Invalid Reason"
    return SHX3_2, SHX4_2
  end
  SHX3_2 = RPC
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.emitLocal
  SHX5_2 = "Reaper:NewDetection"
  SHX6_2 = {}
  SHX6_2.type = "customDetection"
  SHX7_2 = {}
  SHX6_2.data = SHX7_2
  SHX7_2 = {}
  SHX8_2 = SHX2_2
  SHX7_2[1] = SHX8_2
  SHX6_2.params = SHX7_2
  SHX6_2.action = SHX1_2
  SHX8_2 = SHX0_2
  SHX7_2 = SHX0_2.getId
  SHX7_2, SHX8_2 = SHX7_2(SHX8_2)
  SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  SHX3_2 = false
  return SHX3_2
end
SHX0_1.addDetection = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX5_2 = RPC
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.emitLocal
  SHX7_2 = "Reaper:NewDetection"
  SHX8_2 = {}
  SHX8_2.type = SHX1_2
  SHX9_2 = SHX2_2 or SHX9_2
  if not SHX2_2 then
    SHX9_2 = {}
  end
  SHX8_2.data = SHX9_2
  SHX9_2 = SHX3_2 or SHX9_2
  if not SHX3_2 then
    SHX9_2 = {}
  end
  SHX8_2.params = SHX9_2
  SHX8_2.action = SHX4_2
  SHX10_2 = SHX0_2
  SHX9_2 = SHX0_2.getId
  SHX9_2, SHX10_2 = SHX9_2(SHX10_2)
  SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  SHX5_2 = false
  return SHX5_2
end
SHX0_1.newDetection = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  SHX7_2 = SHX0_2
  SHX6_2 = SHX0_2.getIdentifier
  SHX8_2 = "license"
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX4_2.identifier = SHX6_2
  SHX6_2 = Logger
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.NewLog
  SHX8_2 = SHX1_2
  SHX9_2 = SHX2_2
  SHX10_2 = SHX3_2
  SHX11_2 = SHX4_2
  SHX12_2 = SHX5_2
  return SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
end
SHX0_1.NewLog = SHX3_1
SHX3_1 = {}
SHX4_1 = CreateThread
function SHX5_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  while true do
    SHX0_2 = pairs
    SHX1_2 = SHX3_1
    SHX0_2, SHX1_2, SHX2_2, SHX3_2 = SHX0_2(SHX1_2)
    for SHX4_2, SHX5_2 in SHX0_2, SHX1_2, SHX2_2, SHX3_2 do
      SHX6_2 = Wait
      SHX7_2 = 1000
      SHX6_2(SHX7_2)
      SHX6_2 = SHX5_2.source
      if SHX6_2 then
        SHX6_2 = GetPlayerName
        SHX7_2 = SHX5_2.source
        SHX6_2 = SHX6_2(SHX7_2)
        if nil == SHX6_2 then
          SHX6_2 = SHX5_2.source
          if SHX6_2 then
            SHX6_2 = "id:"
            SHX7_2 = SHX5_2.source
            SHX6_2 = SHX6_2 .. SHX7_2
            SHX7_2 = SHX3_1
            SHX6_2 = SHX7_2[SHX6_2]
            if SHX6_2 then
              SHX6_2 = EmitPipe
              SHX7_2 = "Reaper:playerLeft"
              SHX8_2 = "id:"
              SHX9_2 = SHX5_2.source
              SHX8_2 = SHX8_2 .. SHX9_2
              SHX6_2(SHX7_2, SHX8_2)
              SHX6_2 = "id:"
              SHX7_2 = SHX5_2.source
              SHX6_2 = SHX6_2 .. SHX7_2
              SHX7_2 = SHX3_1
              SHX6_2 = SHX7_2[SHX6_2]
              SHX6_2 = SHX6_2.identifiers
              if SHX6_2 then
                SHX6_2 = RPC
                SHX7_2 = SHX6_2
                SHX6_2 = SHX6_2.emitLocal
                SHX8_2 = "Reaper:PlayerDropped"
                SHX9_2 = SHX5_2.source
                SHX10_2 = "id:"
                SHX11_2 = SHX5_2.source
                SHX10_2 = SHX10_2 .. SHX11_2
                SHX11_2 = SHX3_1
                SHX10_2 = SHX11_2[SHX10_2]
                SHX10_2 = SHX10_2.identifiers
                SHX10_2 = SHX10_2.license
                SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2)
              end
              SHX6_2 = "id:"
              SHX7_2 = SHX5_2.source
              SHX6_2 = SHX6_2 .. SHX7_2
              SHX7_2 = SHX3_1
              SHX7_2[SHX6_2] = nil
            end
          end
        end
      end
    end
    SHX0_2 = Wait
    SHX1_2 = 1000
    SHX0_2(SHX1_2)
  end
end
SHX4_1(SHX5_1)
function SHX4_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX1_2 = tonumber
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if nil == SHX1_2 then
    return
  end
  if 0 == SHX0_2 then
    return
  end
  SHX1_2 = "id:"
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2 .. SHX2_2
  SHX2_2 = SHX3_1
  SHX1_2 = SHX2_2[SHX1_2]
  if nil == SHX1_2 then
    SHX1_2 = "id:"
    SHX2_2 = SHX0_2
    SHX1_2 = SHX1_2 .. SHX2_2
    SHX2_2 = SHX3_1
    SHX3_2 = SHX0_1
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.new
    SHX5_2 = SHX0_2
    SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
    SHX2_2[SHX1_2] = SHX3_2
  end
  SHX1_2 = "id:"
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2 .. SHX2_2
  SHX2_2 = SHX3_1
  SHX1_2 = SHX2_2[SHX1_2]
  SHX2_2 = SHX1_2.source
  if nil == SHX2_2 then
    return
  end
  SHX2_2 = "id:"
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2 .. SHX3_2
  SHX3_2 = SHX3_1
  SHX2_2 = SHX3_2[SHX2_2]
  return SHX2_2
end
Player = SHX4_1
SHX4_1 = AddEventHandler
SHX5_1 = "playerDropped"
function SHX6_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX0_2 = source
  SHX1_2 = GetPlayerIdentifierByType
  SHX2_2 = SHX0_2
  SHX3_2 = "license"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.gsub
  SHX3_2 = "license:"
  SHX4_2 = ""
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX2_2 = EmitPipe
  SHX3_2 = "Reaper:playerLeft"
  SHX4_2 = "id:"
  SHX5_2 = SHX0_2
  SHX4_2 = SHX4_2 .. SHX5_2
  SHX2_2(SHX3_2, SHX4_2)
  SHX2_2 = RPC
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.emitLocal
  SHX4_2 = "Reaper:PlayerDropped"
  SHX5_2 = SHX0_2
  SHX6_2 = SHX1_2
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  SHX2_2 = "id:"
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2 .. SHX3_2
  SHX3_2 = SHX3_1
  SHX3_2[SHX2_2] = nil
end
SHX4_1(SHX5_1, SHX6_1)
function SHX4_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2
  SHX0_2 = table
  SHX0_2 = SHX0_2.filter
  SHX1_2 = SHX3_1
  function SHX2_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3
    SHX1_3 = SHX0_3.identifiers
    SHX1_3 = nil ~= SHX1_3
    return SHX1_3
  end
  return SHX0_2(SHX1_2, SHX2_2)
end
Players = SHX4_1
SHX4_1 = exports
SHX5_1 = "InvokeSPlayer"
function SHX6_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX2_2 = Player
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2)
  if nil == SHX2_2 then
    SHX3_2 = nil
    return SHX3_2
  end
  SHX3_2 = type
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  if "string" == SHX3_2 then
    SHX3_2 = SHX2_2[SHX1_2]
    if nil ~= SHX3_2 then
      goto SHX_LABEL_19
    end
  end
  SHX3_2 = "INVALID_METHOD"
  return SHX3_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_19:: outside nested blocks until all 'goto SHX_LABEL_19' can see it
  ::SHX_LABEL_19::
  SHX3_2 = SHX2_2[SHX1_2]
  SHX4_2 = SHX2_2
  SHX5_2 = ...
  return SHX3_2(SHX4_2, SHX5_2)
end
SHX4_1(SHX5_1, SHX6_1)
