-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1
SHX0_1 = class
SHX1_1 = "Falcon"
SHX0_1 = SHX0_1(SHX1_1)
SHX1_1 = Logger
Logger = SHX1_1
SHX1_1 = RPC
RPC = SHX1_1
SHX1_1 = os
SHX1_1 = SHX1_1.time
SHX2_1 = table
SHX2_1 = SHX2_1.insert
SHX3_1 = table
SHX3_1 = SHX3_1.remove
SHX4_1 = string
SHX4_1 = SHX4_1.format
SHX5_1 = math
SHX5_1 = SHX5_1.floor
SHX6_1 = math
SHX6_1 = SHX6_1.min
SHX7_1 = pairs
SHX8_1 = ipairs
function SHX9_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  if not SHX2_2 then
    SHX3_2 = {}
    SHX2_2 = SHX3_2
  end
  SHX0_2.name = SHX1_2
  SHX3_2 = SHX1_1
  SHX3_2 = SHX3_2()
  SHX0_2.start_time = SHX3_2
  SHX3_2 = SHX2_2.max_history_size
  if not SHX3_2 then
    SHX3_2 = 60
  end
  SHX0_2.max_history_size = SHX3_2
  SHX3_2 = SHX2_2.interval_seconds
  if not SHX3_2 then
    SHX3_2 = 60
  end
  SHX0_2.interval_seconds = SHX3_2
  SHX3_2 = SHX2_2.track_subtypes
  SHX3_2 = false ~= SHX3_2
  SHX0_2.track_subtypes = SHX3_2
  SHX3_2 = SHX2_2.track_sources
  SHX3_2 = false ~= SHX3_2
  SHX0_2.track_sources = SHX3_2
  SHX3_2 = {}
  SHX4_2 = SHX1_1
  SHX4_2 = SHX4_2()
  SHX3_2.timestamp = SHX4_2
  SHX3_2.count = 0
  SHX3_2.blocked = 0
  SHX3_2.elapsed = 0
  SHX0_2.current_interval = SHX3_2
  SHX3_2 = {}
  SHX0_2.history = SHX3_2
  SHX0_2.total_count = 0
  SHX0_2.total_blocked = 0
  SHX3_2 = {}
  SHX0_2.subtypes = SHX3_2
  SHX3_2 = {}
  SHX0_2.sources = SHX3_2
  SHX3_2 = {}
  SHX0_2.metadata = SHX3_2
  SHX3_2 = 1
  SHX4_2 = SHX0_2.max_history_size
  SHX5_2 = 1
  for SHX6_2 = SHX3_2, SHX4_2, SHX5_2 do
    SHX7_2 = SHX2_1
    SHX8_2 = SHX0_2.history
    SHX9_2 = {}
    SHX10_2 = SHX1_1
    SHX10_2 = SHX10_2()
    SHX11_2 = SHX0_2.max_history_size
    SHX11_2 = SHX11_2 - SHX6_2
    SHX12_2 = SHX0_2.interval_seconds
    SHX11_2 = SHX11_2 * SHX12_2
    SHX10_2 = SHX10_2 - SHX11_2
    SHX9_2.timestamp = SHX10_2
    SHX9_2.count = 0
    SHX9_2.blocked = 0
    SHX9_2.rate = 0
    SHX7_2(SHX8_2, SHX9_2)
  end
  SHX4_2 = SHX0_2
  SHX3_2 = SHX0_2.startIntervalThread
  SHX3_2(SHX4_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = SHX4_1
  SHX6_2 = "Falcon metrics tracker '^3%s^7' initialized"
  SHX7_2 = SHX1_2
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX6_2 = "debug"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
end
SHX0_1.constructor = SHX9_1
function SHX9_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = CreateThread
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    while true do
      SHX0_3 = Wait
      SHX1_3 = SHX0_2.interval_seconds
      SHX1_3 = SHX1_3 * 1000
      SHX0_3(SHX1_3)
      SHX0_3 = SHX0_2
      SHX1_3 = SHX0_3
      SHX0_3 = SHX0_3.saveCurrentInterval
      SHX0_3(SHX1_3)
    end
  end
  SHX1_2(SHX2_2)
end
SHX0_1.startIntervalThread = SHX9_1
function SHX9_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX1_2 = SHX1_1
  SHX1_2 = SHX1_2()
  SHX2_2 = {}
  SHX3_2 = SHX0_2.current_interval
  SHX3_2 = SHX3_2.timestamp
  SHX2_2.timestamp = SHX3_2
  SHX3_2 = SHX0_2.current_interval
  SHX3_2 = SHX3_2.count
  SHX2_2.count = SHX3_2
  SHX3_2 = SHX0_2.current_interval
  SHX3_2 = SHX3_2.blocked
  SHX2_2.blocked = SHX3_2
  SHX3_2 = SHX0_2.current_interval
  SHX3_2 = SHX3_2.count
  SHX4_2 = SHX0_2.interval_seconds
  SHX3_2 = SHX3_2 / SHX4_2
  SHX2_2.rate = SHX3_2
  SHX3_2 = SHX2_1
  SHX4_2 = SHX0_2.history
  SHX5_2 = SHX2_2
  SHX3_2(SHX4_2, SHX5_2)
  SHX3_2 = SHX0_2.history
  SHX3_2 = #SHX3_2
  SHX4_2 = SHX0_2.max_history_size
  if SHX3_2 > SHX4_2 then
    SHX3_2 = SHX3_1
    SHX4_2 = SHX0_2.history
    SHX5_2 = 1
    SHX3_2(SHX4_2, SHX5_2)
  end
  SHX3_2 = {}
  SHX3_2.timestamp = SHX1_2
  SHX3_2.count = 0
  SHX3_2.blocked = 0
  SHX3_2.elapsed = 0
  SHX0_2.current_interval = SHX3_2
end
SHX0_1.saveCurrentInterval = SHX9_1
function SHX9_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX5_2, SHX6_2, SHX7_2, SHX8_2
  if not SHX3_2 then
    SHX3_2 = false
  end
  SHX5_2 = SHX0_2.current_interval
  SHX6_2 = SHX0_2.current_interval
  SHX6_2 = SHX6_2.count
  SHX6_2 = SHX6_2 + 1
  SHX5_2.count = SHX6_2
  if SHX3_2 then
    SHX5_2 = SHX0_2.current_interval
    SHX6_2 = SHX0_2.current_interval
    SHX6_2 = SHX6_2.blocked
    SHX6_2 = SHX6_2 + 1
    SHX5_2.blocked = SHX6_2
  end
  SHX5_2 = SHX0_2.total_count
  SHX5_2 = SHX5_2 + 1
  SHX0_2.total_count = SHX5_2
  if SHX3_2 then
    SHX5_2 = SHX0_2.total_blocked
    SHX5_2 = SHX5_2 + 1
    SHX0_2.total_blocked = SHX5_2
  end
  SHX5_2 = SHX0_2.track_subtypes
  if SHX5_2 and SHX1_2 then
    SHX5_2 = tostring
    SHX6_2 = SHX1_2
    SHX5_2 = SHX5_2(SHX6_2)
    SHX6_2 = SHX0_2.subtypes
    SHX6_2 = SHX6_2[SHX5_2]
    if not SHX6_2 then
      SHX6_2 = SHX0_2.subtypes
      SHX7_2 = {}
      SHX7_2.name = SHX1_2
      SHX7_2.count = 0
      SHX7_2.blocked = 0
      SHX6_2[SHX5_2] = SHX7_2
    end
    SHX6_2 = SHX0_2.subtypes
    SHX6_2 = SHX6_2[SHX5_2]
    SHX7_2 = SHX0_2.subtypes
    SHX7_2 = SHX7_2[SHX5_2]
    SHX7_2 = SHX7_2.count
    SHX7_2 = SHX7_2 + 1
    SHX6_2.count = SHX7_2
    if SHX3_2 then
      SHX6_2 = SHX0_2.subtypes
      SHX6_2 = SHX6_2[SHX5_2]
      SHX7_2 = SHX0_2.subtypes
      SHX7_2 = SHX7_2[SHX5_2]
      SHX7_2 = SHX7_2.blocked
      SHX7_2 = SHX7_2 + 1
      SHX6_2.blocked = SHX7_2
    end
  end
  SHX5_2 = SHX0_2.track_sources
  if SHX5_2 and SHX2_2 then
    SHX5_2 = tostring
    SHX6_2 = SHX2_2
    SHX5_2 = SHX5_2(SHX6_2)
    SHX6_2 = SHX0_2.sources
    SHX6_2 = SHX6_2[SHX5_2]
    if not SHX6_2 then
      SHX6_2 = SHX0_2.sources
      SHX7_2 = {}
      SHX7_2.id = SHX2_2
      SHX7_2.count = 0
      SHX7_2.blocked = 0
      SHX8_2 = {}
      SHX7_2.subtypes = SHX8_2
      SHX6_2[SHX5_2] = SHX7_2
    end
    SHX6_2 = SHX0_2.sources
    SHX6_2 = SHX6_2[SHX5_2]
    SHX7_2 = SHX0_2.sources
    SHX7_2 = SHX7_2[SHX5_2]
    SHX7_2 = SHX7_2.count
    SHX7_2 = SHX7_2 + 1
    SHX6_2.count = SHX7_2
    if SHX3_2 then
      SHX6_2 = SHX0_2.sources
      SHX6_2 = SHX6_2[SHX5_2]
      SHX7_2 = SHX0_2.sources
      SHX7_2 = SHX7_2[SHX5_2]
      SHX7_2 = SHX7_2.blocked
      SHX7_2 = SHX7_2 + 1
      SHX6_2.blocked = SHX7_2
    end
    if SHX1_2 then
      SHX6_2 = tostring
      SHX7_2 = SHX1_2
      SHX6_2 = SHX6_2(SHX7_2)
      SHX7_2 = SHX0_2.sources
      SHX7_2 = SHX7_2[SHX5_2]
      SHX7_2 = SHX7_2.subtypes
      SHX7_2 = SHX7_2[SHX6_2]
      if not SHX7_2 then
        SHX7_2 = SHX0_2.sources
        SHX7_2 = SHX7_2[SHX5_2]
        SHX7_2 = SHX7_2.subtypes
        SHX8_2 = {}
        SHX8_2.name = SHX1_2
        SHX8_2.count = 0
        SHX7_2[SHX6_2] = SHX8_2
      end
      SHX7_2 = SHX0_2.sources
      SHX7_2 = SHX7_2[SHX5_2]
      SHX7_2 = SHX7_2.subtypes
      SHX7_2 = SHX7_2[SHX6_2]
      SHX8_2 = SHX0_2.sources
      SHX8_2 = SHX8_2[SHX5_2]
      SHX8_2 = SHX8_2.subtypes
      SHX8_2 = SHX8_2[SHX6_2]
      SHX8_2 = SHX8_2.count
      SHX8_2 = SHX8_2 + 1
      SHX7_2.count = SHX8_2
    end
  end
  if SHX4_2 then
    SHX5_2 = SHX0_2.metadata
    SHX6_2 = SHX0_2.total_count
    SHX5_2[SHX6_2] = SHX4_2
  end
end
SHX0_1.track = SHX9_1
function SHX9_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2
  if not SHX2_2 then
    SHX2_2 = 10
  end
  SHX3_2 = {}
  SHX4_2 = SHX7_1
  SHX5_2 = SHX1_2
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
  for SHX8_2, SHX9_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
    SHX10_2 = type
    SHX11_2 = SHX9_2
    SHX10_2 = SHX10_2(SHX11_2)
    if "table" == SHX10_2 then
      SHX10_2 = SHX9_2.count
      if SHX10_2 then
        SHX10_2 = SHX2_1
        SHX11_2 = SHX3_2
        SHX12_2 = SHX9_2
        SHX10_2(SHX11_2, SHX12_2)
      end
    end
  end
  SHX4_2 = table
  SHX4_2 = SHX4_2.sort
  SHX5_2 = SHX3_2
  function SHX6_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3
    SHX2_3 = SHX0_3.count
    SHX3_3 = SHX1_3.count
    SHX2_3 = SHX2_3 > SHX3_3
    return SHX2_3
  end
  SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = {}
  SHX5_2 = 1
  SHX6_2 = SHX6_1
  SHX7_2 = SHX2_2
  SHX8_2 = #SHX3_2
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
  SHX7_2 = 1
  for SHX8_2 = SHX5_2, SHX6_2, SHX7_2 do
    SHX9_2 = SHX2_1
    SHX10_2 = SHX4_2
    SHX11_2 = SHX3_2[SHX8_2]
    SHX9_2(SHX10_2, SHX11_2)
  end
  return SHX4_2
end
SHX0_1.getTopItems = SHX9_1
function SHX9_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2, SHX20_2, SHX21_2, SHX22_2, SHX23_2, SHX24_2, SHX25_2, SHX26_2
  SHX1_2 = SHX1_1
  SHX1_2 = SHX1_2()
  SHX2_2 = SHX0_2.start_time
  SHX2_2 = SHX1_2 - SHX2_2
  SHX3_2 = SHX2_2 / 60
  SHX4_2 = SHX3_2 / 60
  if SHX3_2 > 0 then
    SHX5_2 = SHX0_2.total_count
    SHX5_2 = SHX5_2 / SHX3_2
    if SHX5_2 then
      goto SHX_LABEL_18
    end
  end
  SHX5_2 = 0
  -- [FIX IF ERROR] Move ::SHX_LABEL_18:: outside nested blocks until all 'goto SHX_LABEL_18' can see it
  ::SHX_LABEL_18::
  if SHX3_2 > 0 then
    SHX6_2 = SHX0_2.total_blocked
    SHX6_2 = SHX6_2 / SHX3_2
    if SHX6_2 then
      goto SHX_LABEL_26
    end
  end
  SHX6_2 = 0
  -- [FIX IF ERROR] Move ::SHX_LABEL_26:: outside nested blocks until all 'goto SHX_LABEL_26' can see it
  ::SHX_LABEL_26::
  SHX7_2 = SHX0_2.current_interval
  SHX7_2 = SHX7_2.count
  SHX8_2 = SHX0_2.current_interval
  SHX8_2 = SHX8_2.blocked
  SHX9_2 = SHX6_1
  SHX10_2 = 5
  SHX11_2 = SHX0_2.history
  SHX11_2 = #SHX11_2
  SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
  SHX10_2 = math
  SHX10_2 = SHX10_2.max
  SHX11_2 = 1
  SHX12_2 = SHX0_2.history
  SHX12_2 = #SHX12_2
  SHX12_2 = SHX12_2 - SHX9_2
  SHX12_2 = SHX12_2 + 1
  SHX10_2 = SHX10_2(SHX11_2, SHX12_2)
  SHX11_2 = SHX0_2.history
  SHX11_2 = #SHX11_2
  SHX12_2 = 1
  for SHX13_2 = SHX10_2, SHX11_2, SHX12_2 do
    SHX14_2 = SHX0_2.history
    SHX14_2 = SHX14_2[SHX13_2]
    SHX14_2 = SHX14_2.count
    SHX7_2 = SHX7_2 + SHX14_2
    SHX14_2 = SHX0_2.history
    SHX14_2 = SHX14_2[SHX13_2]
    SHX14_2 = SHX14_2.blocked
    SHX8_2 = SHX8_2 + SHX14_2
  end
  SHX10_2 = SHX0_2.current_interval
  SHX10_2 = SHX10_2.count
  SHX11_2 = SHX6_1
  SHX12_2 = 2
  SHX13_2 = SHX0_2.history
  SHX13_2 = #SHX13_2
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
  SHX12_2 = math
  SHX12_2 = SHX12_2.max
  SHX13_2 = 1
  SHX14_2 = SHX0_2.history
  SHX14_2 = #SHX14_2
  SHX14_2 = SHX14_2 - SHX11_2
  SHX14_2 = SHX14_2 + 1
  SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
  SHX13_2 = SHX0_2.history
  SHX13_2 = #SHX13_2
  SHX14_2 = 1
  for SHX15_2 = SHX12_2, SHX13_2, SHX14_2 do
    SHX16_2 = SHX0_2.history
    SHX16_2 = SHX16_2[SHX15_2]
    SHX16_2 = SHX16_2.count
    SHX10_2 = SHX10_2 + SHX16_2
  end
  SHX12_2 = SHX6_1
  SHX13_2 = 2
  SHX14_2 = SHX0_2.history
  SHX14_2 = #SHX14_2
  SHX14_2 = SHX14_2 + 1
  SHX12_2 = SHX12_2(SHX13_2, SHX14_2)
  SHX12_2 = SHX10_2 / SHX12_2
  SHX13_2 = SHX0_2.current_interval
  SHX13_2 = SHX13_2.count
  SHX14_2 = SHX6_1
  SHX15_2 = 60
  SHX16_2 = SHX0_2.history
  SHX16_2 = #SHX16_2
  SHX14_2 = SHX14_2(SHX15_2, SHX16_2)
  SHX15_2 = math
  SHX15_2 = SHX15_2.max
  SHX16_2 = 1
  SHX17_2 = SHX0_2.history
  SHX17_2 = #SHX17_2
  SHX17_2 = SHX17_2 - SHX14_2
  SHX17_2 = SHX17_2 + 1
  SHX15_2 = SHX15_2(SHX16_2, SHX17_2)
  SHX16_2 = SHX0_2.history
  SHX16_2 = #SHX16_2
  SHX17_2 = 1
  for SHX18_2 = SHX15_2, SHX16_2, SHX17_2 do
    SHX19_2 = SHX0_2.history
    SHX19_2 = SHX19_2[SHX18_2]
    SHX19_2 = SHX19_2.count
    SHX13_2 = SHX13_2 + SHX19_2
  end
  SHX15_2 = SHX6_1
  SHX16_2 = 60
  SHX17_2 = SHX0_2.history
  SHX17_2 = #SHX17_2
  SHX17_2 = SHX17_2 + 1
  SHX15_2 = SHX15_2(SHX16_2, SHX17_2)
  SHX15_2 = SHX13_2 / SHX15_2
  SHX16_2 = {}
  SHX17_2 = SHX2_1
  SHX18_2 = SHX16_2
  SHX19_2 = SHX0_2.current_interval
  SHX19_2 = SHX19_2.count
  SHX17_2(SHX18_2, SHX19_2)
  SHX17_2 = math
  SHX17_2 = SHX17_2.max
  SHX18_2 = 1
  SHX19_2 = SHX0_2.history
  SHX19_2 = #SHX19_2
  SHX19_2 = SHX19_2 - SHX14_2
  SHX19_2 = SHX19_2 + 1
  SHX17_2 = SHX17_2(SHX18_2, SHX19_2)
  SHX18_2 = SHX0_2.history
  SHX18_2 = #SHX18_2
  SHX19_2 = 1
  for SHX20_2 = SHX17_2, SHX18_2, SHX19_2 do
    SHX21_2 = SHX2_1
    SHX22_2 = SHX16_2
    SHX23_2 = SHX0_2.history
    SHX23_2 = SHX23_2[SHX20_2]
    SHX23_2 = SHX23_2.count
    SHX21_2(SHX22_2, SHX23_2)
  end
  SHX17_2 = table
  SHX17_2 = SHX17_2.sort
  SHX18_2 = SHX16_2
  SHX17_2(SHX18_2)
  SHX17_2 = 0
  SHX18_2 = #SHX16_2
  if SHX18_2 > 0 then
    SHX19_2 = SHX18_2 % 2
    if 0 == SHX19_2 then
      SHX19_2 = SHX18_2 / 2
      SHX19_2 = SHX16_2[SHX19_2]
      SHX20_2 = SHX18_2 / 2
      SHX20_2 = SHX20_2 + 1
      SHX20_2 = SHX16_2[SHX20_2]
      SHX19_2 = SHX19_2 + SHX20_2
      SHX17_2 = SHX19_2 / 2
    else
      SHX19_2 = SHX5_1
      SHX20_2 = SHX18_2 / 2
      SHX19_2 = SHX19_2(SHX20_2)
      SHX19_2 = SHX19_2 + 1
      SHX17_2 = SHX16_2[SHX19_2]
    end
  end
  SHX19_2 = SHX0_2.total_count
  if SHX19_2 > 0 then
    SHX19_2 = SHX0_2.total_blocked
    SHX20_2 = SHX0_2.total_count
    SHX19_2 = SHX19_2 / SHX20_2
    SHX19_2 = SHX19_2 * 100
    if SHX19_2 then
      goto SHX_LABEL_204
    end
  end
  SHX19_2 = 0
  -- [FIX IF ERROR] Move ::SHX_LABEL_204:: outside nested blocks until all 'goto SHX_LABEL_204' can see it
  ::SHX_LABEL_204::
  SHX20_2 = {}
  SHX21_2 = SHX0_2.name
  SHX20_2.name = SHX21_2
  SHX21_2 = {}
  SHX22_2 = SHX0_2.current_interval
  SHX22_2 = SHX22_2.timestamp
  SHX21_2.timestamp = SHX22_2
  SHX22_2 = SHX0_2.current_interval
  SHX22_2 = SHX22_2.count
  SHX21_2.count = SHX22_2
  SHX22_2 = SHX0_2.current_interval
  SHX22_2 = SHX22_2.blocked
  SHX21_2.blocked = SHX22_2
  SHX22_2 = SHX0_2.current_interval
  SHX22_2 = SHX22_2.timestamp
  SHX22_2 = SHX1_2 - SHX22_2
  SHX21_2.elapsed_seconds = SHX22_2
  SHX20_2.current_interval = SHX21_2
  SHX21_2 = {}
  SHX22_2 = SHX0_2.total_count
  SHX21_2.count = SHX22_2
  SHX22_2 = SHX0_2.total_blocked
  SHX21_2.blocked = SHX22_2
  SHX22_2 = SHX0_2.total_count
  SHX23_2 = SHX0_2.total_blocked
  SHX22_2 = SHX22_2 - SHX23_2
  SHX21_2.allowed = SHX22_2
  SHX22_2 = SHX4_1
  SHX23_2 = "%.2f%%"
  SHX24_2 = SHX19_2
  SHX22_2 = SHX22_2(SHX23_2, SHX24_2)
  SHX21_2.block_rate = SHX22_2
  SHX21_2.uptime_seconds = SHX2_2
  SHX22_2 = SHX5_1
  SHX23_2 = SHX3_2
  SHX22_2 = SHX22_2(SHX23_2)
  SHX21_2.uptime_minutes = SHX22_2
  SHX22_2 = SHX4_1
  SHX23_2 = "%.2f"
  SHX24_2 = SHX4_2
  SHX22_2 = SHX22_2(SHX23_2, SHX24_2)
  SHX21_2.uptime_hours = SHX22_2
  SHX22_2 = table
  SHX22_2 = SHX22_2.count
  SHX23_2 = SHX0_2.subtypes
  SHX22_2 = SHX22_2(SHX23_2)
  SHX21_2.unique_subtypes = SHX22_2
  SHX22_2 = table
  SHX22_2 = SHX22_2.count
  SHX23_2 = SHX0_2.sources
  SHX22_2 = SHX22_2(SHX23_2)
  SHX21_2.unique_sources = SHX22_2
  SHX20_2.totals = SHX21_2
  SHX21_2 = {}
  SHX22_2 = SHX4_1
  SHX23_2 = "%.2f"
  SHX24_2 = SHX5_2
  SHX22_2 = SHX22_2(SHX23_2, SHX24_2)
  SHX21_2.per_minute = SHX22_2
  SHX22_2 = SHX4_1
  SHX23_2 = "%.2f"
  SHX24_2 = SHX6_2
  SHX22_2 = SHX22_2(SHX23_2, SHX24_2)
  SHX21_2.blocked_per_minute = SHX22_2
  SHX22_2 = SHX4_1
  SHX23_2 = "%.2f"
  SHX24_2 = SHX5_2 / 60
  SHX22_2 = SHX22_2(SHX23_2, SHX24_2)
  SHX21_2.per_second = SHX22_2
  SHX21_2.last_2_min = SHX12_2
  SHX21_2.last_hour = SHX15_2
  SHX21_2.median_last_hour = SHX17_2
  SHX20_2.averages = SHX21_2
  SHX21_2 = {}
  SHX21_2.count = SHX7_2
  SHX21_2.blocked = SHX8_2
  SHX22_2 = SHX4_1
  SHX23_2 = "%.2f"
  SHX24_2 = SHX6_1
  SHX25_2 = 5
  SHX26_2 = SHX0_2.history
  SHX26_2 = #SHX26_2
  SHX26_2 = SHX26_2 + 1
  SHX24_2 = SHX24_2(SHX25_2, SHX26_2)
  SHX24_2 = SHX7_2 / SHX24_2
  SHX22_2 = SHX22_2(SHX23_2, SHX24_2)
  SHX21_2.avg_per_interval = SHX22_2
  SHX20_2.last_intervals = SHX21_2
  SHX22_2 = SHX0_2
  SHX21_2 = SHX0_2.getTopItems
  SHX23_2 = SHX0_2.subtypes
  SHX24_2 = 20
  SHX21_2 = SHX21_2(SHX22_2, SHX23_2, SHX24_2)
  SHX20_2.top_subtypes = SHX21_2
  SHX22_2 = SHX0_2
  SHX21_2 = SHX0_2.getTopItems
  SHX23_2 = SHX0_2.sources
  SHX24_2 = 20
  SHX21_2 = SHX21_2(SHX22_2, SHX23_2, SHX24_2)
  SHX20_2.top_sources = SHX21_2
  SHX21_2 = SHX0_2.history
  SHX20_2.history = SHX21_2
  return SHX20_2
end
SHX0_1.getStatistics = SHX9_1
function SHX9_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX2_2 = SHX0_2
  SHX1_2 = SHX0_2.getStatistics
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = {}
  SHX3_2 = SHX0_2.name
  SHX2_2.name = SHX3_2
  SHX3_2 = SHX1_2.totals
  SHX3_2 = SHX3_2.count
  SHX2_2.total_count = SHX3_2
  SHX3_2 = SHX1_2.totals
  SHX3_2 = SHX3_2.blocked
  SHX2_2.total_blocked = SHX3_2
  SHX3_2 = SHX1_2.totals
  SHX3_2 = SHX3_2.allowed
  SHX2_2.total_allowed = SHX3_2
  SHX3_2 = SHX1_2.totals
  SHX3_2 = SHX3_2.block_rate
  SHX2_2.block_rate = SHX3_2
  SHX3_2 = SHX1_2.totals
  SHX3_2 = SHX3_2.uptime_minutes
  SHX2_2.uptime_minutes = SHX3_2
  SHX3_2 = SHX1_2.current_interval
  SHX3_2 = SHX3_2.count
  SHX2_2.current_interval_count = SHX3_2
  SHX3_2 = SHX1_2.averages
  SHX3_2 = SHX3_2.per_minute
  SHX2_2.avg_per_minute = SHX3_2
  SHX3_2 = SHX1_2.totals
  SHX3_2 = SHX3_2.unique_subtypes
  SHX2_2.unique_subtypes = SHX3_2
  SHX3_2 = SHX1_2.totals
  SHX3_2 = SHX3_2.unique_sources
  SHX2_2.unique_sources = SHX3_2
  return SHX2_2
end
SHX0_1.getSummary = SHX9_1
function SHX9_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = {}
  SHX4_2 = SHX0_2
  SHX3_2 = SHX0_2.getTopItems
  SHX5_2 = SHX0_2.subtypes
  SHX6_2 = SHX1_2 or SHX6_2
  if not SHX1_2 then
    SHX6_2 = 20
  end
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX2_2.top_subtypes = SHX3_2
  SHX3_2 = table
  SHX3_2 = SHX3_2.count
  SHX4_2 = SHX0_2.subtypes
  SHX3_2 = SHX3_2(SHX4_2)
  SHX2_2.total_unique_subtypes = SHX3_2
  return SHX2_2
end
SHX0_1.getSubtypeBreakdown = SHX9_1
function SHX9_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX2_2 = tostring
  SHX3_2 = SHX1_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SHX0_2.subtypes
  SHX3_2 = SHX3_2[SHX2_2]
  if not SHX3_2 then
    SHX4_2 = nil
    return SHX4_2
  end
  SHX4_2 = {}
  SHX4_2.subtype = SHX1_2
  SHX5_2 = SHX3_2.name
  SHX4_2.name = SHX5_2
  SHX5_2 = SHX3_2.count
  SHX4_2.count = SHX5_2
  SHX5_2 = SHX3_2.blocked
  SHX4_2.blocked = SHX5_2
  return SHX4_2
end
SHX0_1.getSubtypeDetails = SHX9_1
function SHX9_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = {}
  SHX4_2 = SHX0_2
  SHX3_2 = SHX0_2.getTopItems
  SHX5_2 = SHX0_2.sources
  SHX6_2 = SHX1_2 or SHX6_2
  if not SHX1_2 then
    SHX6_2 = 20
  end
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX2_2.top_sources = SHX3_2
  SHX3_2 = table
  SHX3_2 = SHX3_2.count
  SHX4_2 = SHX0_2.sources
  SHX3_2 = SHX3_2(SHX4_2)
  SHX2_2.total_unique_sources = SHX3_2
  return SHX2_2
end
SHX0_1.getSourceBreakdown = SHX9_1
function SHX9_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX2_2 = tostring
  SHX3_2 = SHX1_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SHX0_2.sources
  SHX3_2 = SHX3_2[SHX2_2]
  if not SHX3_2 then
    SHX4_2 = nil
    return SHX4_2
  end
  SHX4_2 = {}
  SHX5_2 = SHX7_1
  SHX6_2 = SHX3_2.subtypes
  SHX5_2, SHX6_2, SHX7_2, SHX8_2 = SHX5_2(SHX6_2)
  for SHX9_2, SHX10_2 in SHX5_2, SHX6_2, SHX7_2, SHX8_2 do
    SHX11_2 = SHX2_1
    SHX12_2 = SHX4_2
    SHX13_2 = SHX10_2
    SHX11_2(SHX12_2, SHX13_2)
  end
  SHX5_2 = table
  SHX5_2 = SHX5_2.sort
  SHX6_2 = SHX4_2
  function SHX7_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3
    SHX2_3 = SHX0_3.count
    SHX3_3 = SHX1_3.count
    SHX2_3 = SHX2_3 > SHX3_3
    return SHX2_3
  end
  SHX5_2(SHX6_2, SHX7_2)
  SHX5_2 = {}
  SHX5_2.source = SHX1_2
  SHX6_2 = SHX3_2.id
  SHX5_2.id = SHX6_2
  SHX6_2 = SHX3_2.count
  SHX5_2.total_count = SHX6_2
  SHX6_2 = SHX3_2.blocked
  SHX5_2.total_blocked = SHX6_2
  SHX5_2.subtypes = SHX4_2
  return SHX5_2
end
SHX0_1.getSourceDetails = SHX9_1
function SHX9_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX1_2 = SHX1_1
  SHX1_2 = SHX1_2()
  SHX0_2.start_time = SHX1_2
  SHX1_2 = {}
  SHX2_2 = SHX1_1
  SHX2_2 = SHX2_2()
  SHX1_2.timestamp = SHX2_2
  SHX1_2.count = 0
  SHX1_2.blocked = 0
  SHX1_2.elapsed = 0
  SHX0_2.current_interval = SHX1_2
  SHX1_2 = {}
  SHX0_2.history = SHX1_2
  SHX0_2.total_count = 0
  SHX0_2.total_blocked = 0
  SHX1_2 = {}
  SHX0_2.subtypes = SHX1_2
  SHX1_2 = {}
  SHX0_2.sources = SHX1_2
  SHX1_2 = {}
  SHX0_2.metadata = SHX1_2
  SHX1_2 = 1
  SHX2_2 = SHX0_2.max_history_size
  SHX3_2 = 1
  for SHX4_2 = SHX1_2, SHX2_2, SHX3_2 do
    SHX5_2 = SHX2_1
    SHX6_2 = SHX0_2.history
    SHX7_2 = {}
    SHX8_2 = SHX1_1
    SHX8_2 = SHX8_2()
    SHX9_2 = SHX0_2.max_history_size
    SHX9_2 = SHX9_2 - SHX4_2
    SHX10_2 = SHX0_2.interval_seconds
    SHX9_2 = SHX9_2 * SHX10_2
    SHX8_2 = SHX8_2 - SHX9_2
    SHX7_2.timestamp = SHX8_2
    SHX7_2.count = 0
    SHX7_2.blocked = 0
    SHX7_2.rate = 0
    SHX5_2(SHX6_2, SHX7_2)
  end
  SHX1_2 = Logger
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = SHX4_1
  SHX4_2 = "Falcon metrics tracker '^3%s^7' reset"
  SHX5_2 = SHX0_2.name
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = "info"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
SHX0_1.reset = SHX9_1
function SHX9_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX2_2 = SHX0_2
  SHX3_2 = HTTP
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.listen
  SHX5_2 = SHX1_2
  SHX6_2 = "/stats"
  SHX5_2 = SHX5_2 .. SHX6_2
  function SHX6_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX2_3 = SHX2_2
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.getStatistics
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_3.send
    SHX4_3 = {}
    SHX4_3.success = true
    SHX4_3.data = SHX2_3
    SHX5_3 = SHX1_1
    SHX5_3 = SHX5_3()
    SHX4_3.timestamp = SHX5_3
    SHX3_3(SHX4_3)
  end
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = HTTP
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.listen
  SHX5_2 = SHX1_2
  SHX6_2 = "/summary"
  SHX5_2 = SHX5_2 .. SHX6_2
  function SHX6_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX2_3 = SHX2_2
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.getSummary
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_3.send
    SHX4_3 = {}
    SHX4_3.success = true
    SHX4_3.data = SHX2_3
    SHX5_3 = SHX1_1
    SHX5_3 = SHX5_3()
    SHX4_3.timestamp = SHX5_3
    SHX3_3(SHX4_3)
  end
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = HTTP
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.listen
  SHX5_2 = SHX1_2
  SHX6_2 = "/subtypes"
  SHX5_2 = SHX5_2 .. SHX6_2
  function SHX6_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = tonumber
    SHX3_3 = SHX0_3.query
    SHX3_3 = SHX3_3.limit
    SHX2_3 = SHX2_3(SHX3_3)
    if not SHX2_3 then
      SHX2_3 = 20
    end
    SHX3_3 = SHX2_2
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.getSubtypeBreakdown
    SHX5_3 = SHX2_3
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    SHX4_3 = SHX1_3.send
    SHX5_3 = {}
    SHX5_3.success = true
    SHX5_3.data = SHX3_3
    SHX6_3 = SHX1_1
    SHX6_3 = SHX6_3()
    SHX5_3.timestamp = SHX6_3
    SHX4_3(SHX5_3)
  end
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = HTTP
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.listen
  SHX5_2 = SHX1_2
  SHX6_2 = "/subtype"
  SHX5_2 = SHX5_2 .. SHX6_2
  function SHX6_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = SHX0_3.query
    SHX2_3 = SHX2_3.name
    if not SHX2_3 then
      SHX2_3 = SHX0_3.query
      SHX2_3 = SHX2_3.type
    end
    if not SHX2_3 then
      SHX3_3 = SHX1_3.status
      SHX4_3 = 400
      SHX3_3 = SHX3_3(SHX4_3)
      SHX3_3 = SHX3_3.send
      SHX4_3 = {}
      SHX4_3.success = false
      SHX4_3.error = "Missing 'name' or 'type' query parameter"
      SHX3_3(SHX4_3)
      return
    end
    SHX3_3 = SHX2_2
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.getSubtypeDetails
    SHX5_3 = SHX2_3
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if not SHX3_3 then
      SHX4_3 = SHX1_3.status
      SHX5_3 = 404
      SHX4_3 = SHX4_3(SHX5_3)
      SHX4_3 = SHX4_3.send
      SHX5_3 = {}
      SHX5_3.success = false
      SHX5_3.error = "Subtype not found"
      SHX4_3(SHX5_3)
      return
    end
    SHX4_3 = SHX1_3.send
    SHX5_3 = {}
    SHX5_3.success = true
    SHX5_3.data = SHX3_3
    SHX6_3 = SHX1_1
    SHX6_3 = SHX6_3()
    SHX5_3.timestamp = SHX6_3
    SHX4_3(SHX5_3)
  end
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = HTTP
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.listen
  SHX5_2 = SHX1_2
  SHX6_2 = "/sources"
  SHX5_2 = SHX5_2 .. SHX6_2
  function SHX6_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = tonumber
    SHX3_3 = SHX0_3.query
    SHX3_3 = SHX3_3.limit
    SHX2_3 = SHX2_3(SHX3_3)
    if not SHX2_3 then
      SHX2_3 = 20
    end
    SHX3_3 = SHX2_2
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.getSourceBreakdown
    SHX5_3 = SHX2_3
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    SHX4_3 = SHX1_3.send
    SHX5_3 = {}
    SHX5_3.success = true
    SHX5_3.data = SHX3_3
    SHX6_3 = SHX1_1
    SHX6_3 = SHX6_3()
    SHX5_3.timestamp = SHX6_3
    SHX4_3(SHX5_3)
  end
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = HTTP
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.listen
  SHX5_2 = SHX1_2
  SHX6_2 = "/source"
  SHX5_2 = SHX5_2 .. SHX6_2
  function SHX6_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = SHX0_3.query
    SHX2_3 = SHX2_3.id
    if not SHX2_3 then
      SHX2_3 = SHX0_3.query
      SHX2_3 = SHX2_3.name
    end
    if not SHX2_3 then
      SHX3_3 = SHX1_3.status
      SHX4_3 = 400
      SHX3_3 = SHX3_3(SHX4_3)
      SHX3_3 = SHX3_3.send
      SHX4_3 = {}
      SHX4_3.success = false
      SHX4_3.error = "Missing 'id' or 'name' query parameter"
      SHX3_3(SHX4_3)
      return
    end
    SHX3_3 = SHX2_2
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.getSourceDetails
    SHX5_3 = SHX2_3
    SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
    if not SHX3_3 then
      SHX4_3 = SHX1_3.status
      SHX5_3 = 404
      SHX4_3 = SHX4_3(SHX5_3)
      SHX4_3 = SHX4_3.send
      SHX5_3 = {}
      SHX5_3.success = false
      SHX5_3.error = "Source not found"
      SHX4_3(SHX5_3)
      return
    end
    SHX4_3 = SHX1_3.send
    SHX5_3 = {}
    SHX5_3.success = true
    SHX5_3.data = SHX3_3
    SHX6_3 = SHX1_1
    SHX6_3 = SHX6_3()
    SHX5_3.timestamp = SHX6_3
    SHX4_3(SHX5_3)
  end
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = Logger
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = SHX4_1
  SHX6_2 = "Falcon '^3%s^7' HTTP endpoints registered at ^3%s/*^7"
  SHX7_2 = SHX0_2.name
  SHX8_2 = SHX1_2
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX6_2 = "debug"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
end
SHX0_1.registerHTTPEndpoints = SHX9_1
Falcon = SHX0_1
