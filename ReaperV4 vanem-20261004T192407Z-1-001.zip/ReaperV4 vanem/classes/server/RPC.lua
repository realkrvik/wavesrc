-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = class
SHX1_1 = "RPC"
SHX0_1 = SHX0_1(SHX1_1)
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX2_2 = SHX0_2
  SHX3_2 = SHX1_2 or SHX3_2
  if not SHX1_2 then
    SHX3_2 = "f0ad51e9-048479cf-9fba5eee-83b7f0b2-1c28924a"
  end
  SHX2_2 = SHX2_2 .. SHX3_2
  SHX0_2 = SHX2_2
  SHX2_2 = 5381
  SHX3_2 = 1
  SHX4_2 = #SHX0_2
  SHX5_2 = 1
  for SHX6_2 = SHX3_2, SHX4_2, SHX5_2 do
    SHX7_2 = string
    SHX7_2 = SHX7_2.byte
    SHX8_2 = SHX0_2
    SHX9_2 = SHX6_2
    SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
    SHX8_2 = SHX2_2 * 33
    SHX2_2 = SHX8_2 ~ SHX7_2
  end
  return SHX2_2
end
function SHX2_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = "__reaper_cb_%s"
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.format
  SHX3_2 = SHX1_1
  SHX4_2 = SHX0_2
  SHX3_2, SHX4_2 = SHX3_2(SHX4_2)
  return SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
function SHX3_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX0_2.test = SHX1_2
  SHX2_2 = SHX0_2.private
  SHX3_2 = {}
  SHX2_2.eventHandlers = SHX3_2
  SHX2_2 = SHX0_2.private
  SHX3_2 = {}
  SHX4_2 = {}
  SHX3_2.events = SHX4_2
  SHX2_2.cache = SHX3_2
  SHX2_2 = SHX0_2.private
  SHX2_2 = SHX2_2.cache
  SHX3_2 = GetCurrentResourceName
  SHX3_2 = SHX3_2()
  SHX2_2.resource = SHX3_2
  SHX2_2 = SHX0_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.onNet
  SHX4_2 = SHX2_1
  SHX5_2 = SHX0_2.private
  SHX5_2 = SHX5_2.cache
  SHX5_2 = SHX5_2.resource
  SHX4_2 = SHX4_2(SHX5_2)
  function SHX5_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = SHX0_2.private
    SHX2_3 = SHX2_3.cache
    SHX2_3 = SHX2_3.events
    SHX2_3 = SHX2_3[SHX0_3]
    if SHX2_3 then
      SHX2_3 = source
      if "" == SHX2_3 then
        SHX3_3 = SHX0_2.private
        SHX3_3 = SHX3_3.cache
        SHX3_3 = SHX3_3.events
        SHX3_3 = SHX3_3[SHX0_3]
        SHX4_3 = table
        SHX4_3 = SHX4_3.unpack
        SHX5_3 = msgpack
        SHX5_3 = SHX5_3.unpack
        SHX6_3 = SHX1_3
        SHX5_3, SHX6_3 = SHX5_3(SHX6_3)
        SHX4_3, SHX5_3, SHX6_3 = SHX4_3(SHX5_3, SHX6_3)
        return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      else
        SHX3_3 = SHX1_3.key
        SHX4_3 = Security
        SHX5_3 = SHX4_3
        SHX4_3 = SHX4_3.hash
        SHX6_3 = SHX1_3.data
        SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
        if SHX3_3 ~= SHX4_3 then
          SHX3_3 = SHX0_2.private
          SHX3_3 = SHX3_3.cache
          SHX3_3 = SHX3_3.events
          SHX3_3 = SHX3_3[SHX0_3]
          SHX4_3 = "KEY_MISSMATCH"
          return SHX3_3(SHX4_3)
        end
        SHX3_3 = SHX0_2.private
        SHX3_3 = SHX3_3.cache
        SHX3_3 = SHX3_3.events
        SHX3_3 = SHX3_3[SHX0_3]
        SHX4_3 = table
        SHX4_3 = SHX4_3.unpack
        SHX5_3 = msgpack
        SHX5_3 = SHX5_3.unpack
        SHX6_3 = SHX1_3.data
        SHX5_3, SHX6_3 = SHX5_3(SHX6_3)
        SHX4_3, SHX5_3, SHX6_3 = SHX4_3(SHX5_3, SHX6_3)
        return SHX3_3(SHX4_3, SHX5_3, SHX6_3)
      end
    end
  end
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
end
SHX0_1.constructor = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX2_2 = SHX0_2.private
  SHX2_2 = SHX2_2.eventHandlers
  SHX2_2 = SHX2_2[SHX1_2]
  if nil == SHX2_2 then
    SHX2_2 = 0
    return SHX2_2
  end
  SHX2_2 = table
  SHX2_2 = SHX2_2.pack
  SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = ...
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  SHX3_2 = pairs
  SHX4_2 = SHX0_2.private
  SHX4_2 = SHX4_2.eventHandlers
  SHX4_2 = SHX4_2[SHX1_2]
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2)
  for SHX7_2, SHX8_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    SHX9_2 = CreateThread
    function SHX10_2()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_3, SHX1_3, SHX2_3
      SHX0_3 = SHX8_2.callback
      SHX1_3 = table
      SHX1_3 = SHX1_3.unpack
      SHX2_3 = SHX2_2
      SHX1_3, SHX2_3 = SHX1_3(SHX2_3)
      SHX0_3(SHX1_3, SHX2_3)
    end
    SHX9_2(SHX10_2)
  end
  SHX3_2 = 1
  return SHX3_2
end
SHX0_1.emit = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX2_2 = msgpack
  SHX2_2 = SHX2_2.pack_args
  SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2 = ...
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
  SHX3_2 = string
  SHX3_2 = SHX3_2.len
  SHX4_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = 50000
  if SHX3_2 >= SHX4_2 then
    SHX4_2 = Logger
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.log
    SHX6_2 = "The event %s has a large event payload size. Size: %s"
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.format
    SHX8_2 = SHX1_2
    SHX9_2 = SHX3_2
    SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
    SHX7_2 = "warn"
    SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  end
  SHX4_2 = TriggerEvent
  SHX5_2 = SHX1_2
  SHX6_2, SHX7_2, SHX8_2, SHX9_2 = ...
  return SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
end
SHX0_1.emitLocal = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX3_2 = msgpack
  SHX3_2 = SHX3_2.pack_args
  SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = ...
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  SHX4_2 = string
  SHX4_2 = SHX4_2.len
  SHX5_2 = SHX3_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = 50000
  if SHX4_2 >= SHX5_2 then
    SHX5_2 = Logger
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.log
    SHX7_2 = "The event %s has a large event payload size. Size: %s"
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.format
    SHX9_2 = SHX1_2
    SHX10_2 = SHX4_2
    SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2)
    SHX8_2 = "warn"
    SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  end
  SHX5_2 = TriggerClientEvent
  SHX6_2 = SHX1_2
  SHX7_2 = SHX2_2
  SHX8_2, SHX9_2, SHX10_2 = ...
  SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
end
SHX0_1.emitNet = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX3_2 = GetGameTimer
  SHX3_2 = SHX3_2()
  SHX4_2 = SHX0_2.private
  SHX4_2 = SHX4_2.eventHandlers
  SHX4_2 = SHX4_2[SHX1_2]
  if nil == SHX4_2 then
    SHX4_2 = SHX0_2.private
    SHX4_2 = SHX4_2.eventHandlers
    SHX5_2 = {}
    SHX4_2[SHX1_2] = SHX5_2
  end
  SHX4_2 = table
  SHX4_2 = SHX4_2.insert
  SHX5_2 = SHX0_2.private
  SHX5_2 = SHX5_2.eventHandlers
  SHX5_2 = SHX5_2[SHX1_2]
  SHX6_2 = {}
  SHX6_2.id = SHX3_2
  SHX6_2.callback = SHX2_2
  SHX4_2(SHX5_2, SHX6_2)
end
SHX0_1.on = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2
  SHX3_2 = RegisterNetEvent
  SHX4_2 = SHX1_2
  SHX5_2 = SHX2_2
  return SHX3_2(SHX4_2, SHX5_2)
end
SHX0_1.onNet = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2
  SHX4_2 = AddEventHandler
  SHX5_2 = SHX1_2
  SHX6_2 = SHX2_2
  return SHX4_2(SHX5_2, SHX6_2)
end
SHX0_1.onLocal = SHX3_1
function SHX3_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2
  SHX2_2 = RemoveEventHandler
  SHX3_2 = SHX1_2
  SHX2_2(SHX3_2)
end
SHX0_1.remove = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX3_2 = SHX0_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.onNet
  SHX5_2 = SHX2_1
  SHX6_2 = SHX1_2
  SHX5_2 = SHX5_2(SHX6_2)
  function SHX6_2(SHX0_3, SHX1_3, SHX2_3, ...)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3
    SHX3_3 = source
    if "" == SHX3_3 then
      SHX4_3 = SHX0_1
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.emitLocal
      SHX6_3 = SHX2_1
      SHX7_3 = SHX0_3
      SHX6_3 = SHX6_3(SHX7_3)
      SHX7_3 = SHX1_3
      SHX8_3 = msgpack
      SHX8_3 = SHX8_3.pack_args
      SHX9_3 = SHX2_2
      SHX10_3 = source
      SHX11_3 = SHX2_3
      SHX12_3, SHX13_3 = ...
      SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3 = SHX9_3(SHX10_3, SHX11_3, SHX12_3, SHX13_3)
      SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3)
      SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3)
    else
      SHX4_3 = nil
      SHX5_3 = SHX2_3.key
      SHX6_3 = Security
      SHX7_3 = SHX6_3
      SHX6_3 = SHX6_3.hash
      SHX8_3 = SHX2_3.data
      SHX6_3 = SHX6_3(SHX7_3, SHX8_3)
      if SHX5_3 == SHX6_3 then
        SHX5_3 = msgpack
        SHX5_3 = SHX5_3.pack_args
        SHX6_3 = SHX2_2
        SHX7_3 = source
        SHX8_3 = table
        SHX8_3 = SHX8_3.unpack
        SHX9_3 = msgpack
        SHX9_3 = SHX9_3.unpack
        SHX10_3 = SHX2_3.data
        SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3 = SHX9_3(SHX10_3)
        SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3)
        SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3 = SHX6_3(SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3)
        SHX5_3 = SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3, SHX13_3)
        SHX4_3 = SHX5_3
      else
        SHX5_3 = msgpack
        SHX5_3 = SHX5_3.pack_args
        SHX6_3 = "KEY_MISSMATCH"
        SHX5_3 = SHX5_3(SHX6_3)
        SHX4_3 = SHX5_3
      end
      SHX5_3 = SHX0_1
      SHX6_3 = SHX5_3
      SHX5_3 = SHX5_3.emitNet
      SHX7_3 = SHX2_1
      SHX8_3 = SHX0_3
      SHX7_3 = SHX7_3(SHX8_3)
      SHX8_3 = SHX3_3
      SHX9_3 = SHX1_3
      SHX10_3 = {}
      SHX11_3 = Security
      SHX12_3 = SHX11_3
      SHX11_3 = SHX11_3.hash
      SHX13_3 = SHX4_3
      SHX11_3 = SHX11_3(SHX12_3, SHX13_3)
      SHX10_3.key = SHX11_3
      SHX10_3.data = SHX4_3
      SHX5_3(SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3)
    end
  end
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
end
SHX0_1.register = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX6_2 = promise
  SHX6_2 = SHX6_2.new
  SHX6_2 = SHX6_2()
  SHX7_2 = GetGameTimer
  SHX7_2 = SHX7_2()
  SHX8_2 = math
  SHX8_2 = SHX8_2.random
  SHX9_2 = 1
  SHX10_2 = 9999999999
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  SHX7_2 = SHX7_2 + SHX8_2
  SHX8_2 = SHX0_2.private
  SHX8_2 = SHX8_2.cache
  SHX8_2 = SHX8_2.events
  function SHX9_2(...)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = SHX0_2.private
    SHX0_3 = SHX0_3.cache
    SHX0_3 = SHX0_3.events
    SHX1_3 = SHX7_2
    SHX0_3[SHX1_3] = nil
    SHX0_3 = SHX6_2
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.resolve
    SHX2_3 = ...
    SHX0_3(SHX1_3, SHX2_3)
  end
  SHX8_2[SHX7_2] = SHX9_2
  SHX8_2 = CreateThread
  function SHX9_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    SHX0_3 = GetGameTimer
    SHX0_3 = SHX0_3()
    while true do
      SHX1_3 = SHX0_2.private
      SHX1_3 = SHX1_3.cache
      SHX1_3 = SHX1_3.events
      SHX2_3 = SHX7_2
      SHX1_3 = SHX1_3[SHX2_3]
      if nil == SHX1_3 then
        break
      end
      SHX1_3 = GetGameTimer
      SHX1_3 = SHX1_3()
      SHX1_3 = SHX1_3 - SHX0_3
      SHX2_3 = SHX5_2
      if not SHX2_3 then
        SHX2_3 = 10000
      end
      if SHX1_3 > SHX2_3 then
        SHX1_3 = Logger
        SHX2_3 = SHX1_3
        SHX1_3 = SHX1_3.log
        SHX3_3 = "[^3callback.await^7] [^3"
        SHX4_3 = SHX1_2
        SHX5_3 = "^7] - Failed to receive response from client (^3id:"
        SHX6_3 = SHX2_2
        SHX7_3 = "^7)"
        SHX3_3 = SHX3_3 .. SHX4_3 .. SHX5_3 .. SHX6_3 .. SHX7_3
        SHX4_3 = "warn"
        SHX1_3(SHX2_3, SHX3_3, SHX4_3)
        SHX1_3 = SHX6_2
        SHX2_3 = SHX1_3
        SHX1_3 = SHX1_3.resolve
        SHX3_3 = "RESPONSE_FAILED"
        SHX1_3(SHX2_3, SHX3_3)
        break
      end
      SHX1_3 = msgpack
      SHX1_3 = SHX1_3.pack_args
      SHX2_3 = table
      SHX2_3 = SHX2_3.unpack
      SHX3_3 = SHX3_2
      if not SHX3_3 then
        SHX3_3 = {}
      end
      SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3 = SHX2_3(SHX3_3)
      SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3)
      SHX2_3 = SHX0_1
      SHX3_3 = SHX2_3
      SHX2_3 = SHX2_3.emitNet
      SHX4_3 = SHX2_1
      SHX5_3 = SHX1_2
      SHX4_3 = SHX4_3(SHX5_3)
      SHX5_3 = SHX2_2
      SHX6_3 = SHX0_2.private
      SHX6_3 = SHX6_3.cache
      SHX6_3 = SHX6_3.resource
      SHX7_3 = SHX7_2
      SHX8_3 = {}
      SHX8_3.data = SHX1_3
      SHX9_3 = Security
      SHX10_3 = SHX9_3
      SHX9_3 = SHX9_3.hash
      SHX11_3 = SHX1_3
      SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
      SHX8_3.key = SHX9_3
      SHX2_3(SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3)
      SHX2_3 = Wait
      SHX3_3 = SHX4_2
      if not SHX3_3 then
        SHX3_3 = 2000
      end
      SHX2_3(SHX3_3)
    end
  end
  SHX8_2(SHX9_2)
  if SHX6_2 then
    SHX8_2 = Citizen
    SHX8_2 = SHX8_2.Await
    SHX9_2 = SHX6_2
    return SHX8_2(SHX9_2)
  end
end
SHX0_1.await = SHX3_1
function SHX3_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX5_2 = promise
  SHX5_2 = SHX5_2.new
  SHX5_2 = SHX5_2()
  SHX6_2 = GetGameTimer
  SHX6_2 = SHX6_2()
  SHX7_2 = math
  SHX7_2 = SHX7_2.random
  SHX8_2 = 1
  SHX9_2 = 9999999999
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX6_2 = SHX6_2 + SHX7_2
  SHX7_2 = SHX0_2.private
  SHX7_2 = SHX7_2.cache
  SHX7_2 = SHX7_2.events
  function SHX8_2(...)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = SHX0_2.private
    SHX0_3 = SHX0_3.cache
    SHX0_3 = SHX0_3.events
    SHX1_3 = SHX6_2
    SHX0_3[SHX1_3] = nil
    SHX0_3 = SHX5_2
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.resolve
    SHX2_3 = ...
    SHX0_3(SHX1_3, SHX2_3)
  end
  SHX7_2[SHX6_2] = SHX8_2
  SHX7_2 = CreateThread
  function SHX8_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX0_3 = GetGameTimer
    SHX0_3 = SHX0_3()
    while true do
      SHX1_3 = SHX0_2.private
      SHX1_3 = SHX1_3.cache
      SHX1_3 = SHX1_3.events
      SHX2_3 = SHX6_2
      SHX1_3 = SHX1_3[SHX2_3]
      if nil == SHX1_3 then
        break
      end
      SHX1_3 = GetGameTimer
      SHX1_3 = SHX1_3()
      SHX1_3 = SHX1_3 - SHX0_3
      SHX2_3 = SHX4_2
      if not SHX2_3 then
        SHX2_3 = 10000
      end
      if SHX1_3 > SHX2_3 then
        SHX1_3 = Logger
        SHX2_3 = SHX1_3
        SHX1_3 = SHX1_3.log
        SHX3_3 = "[^3callback.await^7] [^3"
        SHX4_3 = SHX1_2
        SHX5_3 = "^7] - Failed to receive response from server -> server"
        SHX3_3 = SHX3_3 .. SHX4_3 .. SHX5_3
        SHX4_3 = "warn"
        SHX1_3(SHX2_3, SHX3_3, SHX4_3)
        SHX1_3 = SHX5_2
        SHX2_3 = SHX1_3
        SHX1_3 = SHX1_3.resolve
        SHX3_3 = "RESPONSE_FAILED"
        SHX1_3(SHX2_3, SHX3_3)
        break
      end
      SHX1_3 = SHX0_1
      SHX2_3 = SHX1_3
      SHX1_3 = SHX1_3.emitLocal
      SHX3_3 = SHX2_1
      SHX4_3 = SHX1_2
      SHX3_3 = SHX3_3(SHX4_3)
      SHX4_3 = SHX0_2.private
      SHX4_3 = SHX4_3.cache
      SHX4_3 = SHX4_3.resource
      SHX5_3 = SHX6_2
      SHX6_3 = table
      SHX6_3 = SHX6_3.unpack
      SHX7_3 = SHX2_2
      if not SHX7_3 then
        SHX7_3 = {}
      end
      SHX6_3, SHX7_3 = SHX6_3(SHX7_3)
      SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3)
      SHX1_3 = Wait
      SHX2_3 = SHX3_2
      if not SHX2_3 then
        SHX2_3 = 2000
      end
      SHX1_3(SHX2_3)
    end
  end
  SHX7_2(SHX8_2)
  if SHX5_2 then
    SHX7_2 = Citizen
    SHX7_2 = SHX7_2.Await
    SHX8_2 = SHX5_2
    return SHX7_2(SHX8_2)
  end
end
SHX0_1.awaitLocal = SHX3_1
SHX4_1 = SHX0_1
SHX3_1 = SHX0_1.new
SHX5_1 = true
SHX3_1 = SHX3_1(SHX4_1, SHX5_1)
RPC = SHX3_1
SHX3_1 = exports
SHX4_1 = "InvokeSRPC"
function SHX5_1(SHX0_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = type
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if "string" == SHX1_2 then
    SHX1_2 = SHX0_1
    SHX1_2 = SHX1_2[SHX0_2]
    if nil ~= SHX1_2 then
      goto SHX_LABEL_13
    end
  end
  SHX1_2 = "INVALID_METHOD"
  return SHX1_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_13:: outside nested blocks until all 'goto SHX_LABEL_13' can see it
  ::SHX_LABEL_13::
  SHX1_2 = RPC
  SHX1_2 = SHX1_2[SHX0_2]
  SHX2_2 = RPC
  SHX3_2 = ...
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX3_1(SHX4_1, SHX5_1)
