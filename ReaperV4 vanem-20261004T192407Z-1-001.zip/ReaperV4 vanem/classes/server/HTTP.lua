-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1
SHX0_1 = class
SHX1_1 = "HTTP"
SHX0_1 = SHX0_1(SHX1_1)
HTTP = SHX0_1
SHX0_1 = GetConvar
SHX1_1 = "gamename"
SHX2_1 = "gta5"
SHX0_1 = SHX0_1(SHX1_1, SHX2_1)
SHX1_1 = HTTP
function SHX2_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2
  SHX1_2 = {}
  SHX0_2.handlers = SHX1_2
  SHX1_2 = SetHttpHandler
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3
    SHX2_3 = SHX0_3.path
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.split
    SHX4_3 = "?"
    SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
    SHX3_3 = SHX2_3[1]
    SHX0_3.path = SHX3_3
    SHX3_3 = {}
    SHX0_3.query = SHX3_3
    SHX3_3 = SHX2_3[2]
    if SHX3_3 then
      SHX3_3 = pairs
      SHX4_3 = SHX2_3[2]
      SHX5_3 = SHX4_3
      SHX4_3 = SHX4_3.split
      SHX6_3 = "&"
      SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3 = SHX4_3(SHX5_3, SHX6_3)
      SHX3_3, SHX4_3, SHX5_3, SHX6_3 = SHX3_3(SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3, SHX12_3)
      for SHX7_3, SHX8_3 in SHX3_3, SHX4_3, SHX5_3, SHX6_3 do
        SHX9_3 = string
        SHX9_3 = SHX9_3.match
        SHX10_3 = SHX8_3
        SHX11_3 = "="
        SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
        if SHX9_3 then
          SHX10_3 = SHX8_3
          SHX9_3 = SHX8_3.split
          SHX11_3 = "="
          SHX9_3 = SHX9_3(SHX10_3, SHX11_3)
          SHX10_3 = SHX0_3.query
          SHX11_3 = SHX9_3[1]
          SHX12_3 = SHX9_3[2]
          SHX10_3[SHX11_3] = SHX12_3
        end
      end
    end
    SHX3_3 = SHX0_2.handlers
    SHX4_3 = SHX0_3.path
    SHX3_3 = SHX3_3[SHX4_3]
    SHX4_3 = SHX0_3.address
    SHX5_3 = SHX4_3
    SHX4_3 = SHX4_3.split
    SHX6_3 = ":"
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX4_3 = SHX4_3[1]
    SHX5_3 = Logger
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.log
    SHX7_3 = "^3%s^7 just went to ^3%s^7"
    SHX8_3 = SHX7_3
    SHX7_3 = SHX7_3.format
    SHX9_3 = SHX4_3
    SHX10_3 = SHX0_3.path
    SHX7_3 = SHX7_3(SHX8_3, SHX9_3, SHX10_3)
    SHX8_3 = "debug"
    SHX5_3(SHX6_3, SHX7_3, SHX8_3)
    if SHX3_3 then
      SHX1_3.status_code = 200
      SHX5_3 = SHX1_3.send
      SHX1_3.writeBody = SHX5_3
      function SHX5_3(SHX0_4)
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4
        SHX1_4 = type
        SHX2_4 = SHX0_4
        SHX1_4 = SHX1_4(SHX2_4)
        SHX2_4 = "text"
        if "table" == SHX1_4 then
          SHX2_4 = "application/json"
          SHX3_4 = json
          SHX3_4 = SHX3_4.encode
          SHX4_4 = SHX0_4
          SHX3_4 = SHX3_4(SHX4_4)
          SHX0_4 = SHX3_4
        end
        SHX3_4 = SHX1_3.writeHead
        SHX4_4 = SHX1_3.status_code
        SHX5_4 = {}
        SHX5_4["Content-Type"] = SHX2_4
        SHX3_4(SHX4_4, SHX5_4)
        SHX3_4 = SHX1_3.writeBody
        SHX4_4 = SHX0_4
        SHX3_4(SHX4_4)
        SHX3_4 = SHX1_3
        return SHX3_4
      end
      SHX1_3.send = SHX5_3
      function SHX5_3(SHX0_4)
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX1_4
        SHX1_3.status_code = SHX0_4
        SHX1_4 = SHX1_3
        return SHX1_4
      end
      SHX1_3.status = SHX5_3
      SHX5_3 = SHX0_3.headers
      SHX5_3 = SHX5_3["Content-Length"]
      if not SHX5_3 then
        SHX5_3 = SHX0_3.headers
        SHX5_3 = SHX5_3["content-length"]
        if not SHX5_3 then
          goto SHX_LABEL_75
        end
      end
      SHX5_3 = SHX0_3.setDataHandler
      function SHX6_3(SHX0_4)
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX1_4, SHX2_4, SHX3_4
        SHX0_3.body = SHX0_4
        SHX1_4 = SHX3_3.callback
        SHX2_4 = SHX0_3
        SHX3_4 = SHX1_3
        SHX1_4(SHX2_4, SHX3_4)
      end
      SHX5_3(SHX6_3)
      goto SHX_LABEL_92
      -- [FIX IF ERROR] Move ::SHX_LABEL_75:: outside nested blocks until all 'goto SHX_LABEL_75' can see it
      ::SHX_LABEL_75::
      SHX5_3 = SHX3_3.callback
      SHX6_3 = SHX0_3
      SHX7_3 = SHX1_3
      SHX5_3(SHX6_3, SHX7_3)
    else
      SHX5_3 = SHX1_3.writeHead
      SHX6_3 = 404
      SHX7_3 = {}
      SHX7_3["Content-Type"] = "text"
      SHX5_3(SHX6_3, SHX7_3)
      SHX5_3 = SHX1_3.send
      SHX6_3 = "Route /ReaperV4"
      SHX7_3 = SHX0_3.path
      SHX8_3 = " not found."
      SHX6_3 = SHX6_3 .. SHX7_3 .. SHX8_3
      SHX5_3(SHX6_3)
    end
    -- [FIX IF ERROR] Move ::SHX_LABEL_92:: outside nested blocks until all 'goto SHX_LABEL_92' can see it
    ::SHX_LABEL_92::
  end
  SHX1_2(SHX2_2)
end
SHX1_1.constructor = SHX2_1
SHX1_1 = HTTP
function SHX2_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2
  SHX3_2 = SHX0_2.handlers
  SHX4_2 = {}
  SHX4_2.method = "GET"
  SHX4_2.callback = SHX2_2
  SHX3_2[SHX1_2] = SHX4_2
end
SHX1_1.listen = SHX2_1
SHX1_1 = HTTP
function SHX2_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2
  SHX5_2 = nil
  SHX6_2 = SHX4_2 or SHX6_2
  if not SHX4_2 then
    SHX6_2 = {}
  end
  SHX7_2 = SHX0_1
  SHX6_2["cfx-game-build"] = SHX7_2
  SHX7_2 = Cache
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.get
  SHX9_2 = "version"
  SHX10_2 = "unknown"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  SHX6_2["reaper-version"] = SHX7_2
  SHX6_2["reaper-resource"] = "true"
  SHX7_2 = Cache
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.get
  SHX9_2 = "branch"
  SHX10_2 = "unknown"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  SHX6_2["reaper-branch"] = SHX7_2
  SHX7_2 = Cache
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.get
  SHX9_2 = "serverId"
  SHX10_2 = "unknown"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  SHX6_2.serverId = SHX7_2
  SHX7_2 = Cache
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.get
  SHX9_2 = "dbId"
  SHX10_2 = "unknown"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  SHX6_2.dbId = SHX7_2
  SHX7_2 = Cache
  SHX8_2 = SHX7_2
  SHX7_2 = SHX7_2.get
  SHX9_2 = "secret"
  SHX10_2 = "unknown"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2)
  SHX6_2.secret = SHX7_2
  SHX7_2 = GetConvar
  SHX8_2 = "web_baseUrl"
  SHX9_2 = "unknown"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  SHX6_2.web_baseUrl = SHX7_2
  SHX7_2 = PerformHttpRequest
  SHX8_2 = SHX1_2
  function SHX9_2(SHX0_3, SHX1_3, SHX2_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX3_3
    SHX3_3 = {}
    SHX3_3.status = SHX0_3
    SHX3_3.body = SHX1_3
    SHX3_3.headers = SHX2_3
    SHX5_2 = SHX3_3
  end
  SHX10_2 = SHX2_2 or SHX10_2
  if not SHX2_2 then
    SHX10_2 = "GET"
  end
  SHX11_2 = SHX3_2 or SHX11_2
  if not SHX3_2 then
    SHX11_2 = ""
  end
  SHX12_2 = SHX6_2
  SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2)
  SHX7_2 = 10000
  SHX8_2 = 0
  while not SHX5_2 and SHX7_2 > SHX8_2 do
    SHX9_2 = Citizen
    SHX9_2 = SHX9_2.Wait
    SHX10_2 = 25
    SHX9_2(SHX10_2)
    SHX8_2 = SHX8_2 + 25
  end
  if not SHX5_2 then
    SHX9_2 = Logger
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.log
    SHX11_2 = "^1%s^7 timed out after 10 seconds"
    SHX12_2 = SHX11_2
    SHX11_2 = SHX11_2.format
    SHX13_2 = SHX1_2
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
    SHX12_2 = "warn"
    SHX9_2(SHX10_2, SHX11_2, SHX12_2)
    SHX9_2 = {}
    SHX9_2.status = 0
    SHX9_2.body = nil
    SHX10_2 = {}
    SHX9_2.headers = SHX10_2
    return SHX9_2
  end
  SHX9_2 = Logger
  SHX10_2 = SHX9_2
  SHX9_2 = SHX9_2.log
  SHX11_2 = "^3%s^7 just returned status code ^3%s^7"
  SHX12_2 = SHX11_2
  SHX11_2 = SHX11_2.format
  SHX13_2 = SHX1_2
  SHX14_2 = SHX5_2.status
  SHX11_2 = SHX11_2(SHX12_2, SHX13_2, SHX14_2)
  SHX12_2 = "debug"
  SHX9_2(SHX10_2, SHX11_2, SHX12_2)
  return SHX5_2
end
SHX1_1.await = SHX2_1
SHX1_1 = HTTP
function SHX2_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX7_2 = SHX0_2
  SHX6_2 = SHX0_2.await
  SHX8_2 = SHX1_2
  SHX9_2 = SHX2_2
  SHX10_2 = SHX3_2
  SHX11_2 = SHX4_2
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  if nil == SHX5_2 then
    SHX5_2 = 1
  else
    SHX5_2 = SHX5_2 + 1
  end
  if SHX5_2 >= 3 then
    return SHX6_2
  end
  SHX7_2 = SHX6_2.status
  if 200 ~= SHX7_2 then
    SHX7_2 = Logger
    SHX8_2 = SHX7_2
    SHX7_2 = SHX7_2.log
    SHX9_2 = "Failed to receive a successful request from ^3%s^7, retrying in 5 seconds."
    SHX10_2 = SHX9_2
    SHX9_2 = SHX9_2.format
    SHX11_2 = SHX1_2
    SHX9_2 = SHX9_2(SHX10_2, SHX11_2)
    SHX10_2 = "warn"
    SHX7_2(SHX8_2, SHX9_2, SHX10_2)
    SHX7_2 = Wait
    SHX8_2 = 5000
    SHX7_2(SHX8_2)
    SHX8_2 = SHX0_2
    SHX7_2 = SHX0_2.awaitSuccess
    SHX9_2 = SHX1_2
    SHX10_2 = SHX2_2
    SHX11_2 = SHX3_2
    SHX12_2 = SHX4_2
    SHX13_2 = SHX5_2
    SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2)
  end
  return SHX6_2
end
SHX1_1.awaitSuccess = SHX2_1
SHX1_1 = HTTP
function SHX2_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX5_2, SHX6_2
  SHX5_2 = CreateThread
  function SHX6_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3
    SHX0_3 = HTTP
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.await
    SHX2_3 = SHX1_2
    SHX3_3 = SHX2_2
    SHX4_3 = SHX3_2
    SHX5_3 = SHX4_2
    SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3)
  end
  SHX5_2(SHX6_2)
end
SHX1_1.request = SHX2_1
SHX1_1 = HTTP
SHX2_1 = SHX1_1
SHX1_1 = SHX1_1.new
SHX1_1 = SHX1_1(SHX2_1)
HTTP = SHX1_1
