-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1
SHX0_1 = class
SHX1_1 = "Features"
SHX0_1 = SHX0_1(SHX1_1)
Features = SHX0_1
SHX0_1 = Features
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = {}
  SHX0_2.features = SHX1_2
  SHX0_2.load_attempts = 0
end
SHX0_1.constructor = SHX1_1
SHX0_1 = Features
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2
  SHX2_2 = SHX0_2.features
  SHX2_2 = SHX2_2[SHX1_2]
  if not SHX2_2 then
    SHX2_2 = false
  end
  return SHX2_2
end
SHX0_1.enabled = SHX1_1
SHX0_1 = Features
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  if SHX1_2 then
    SHX0_2.load_attempts = 0
  end
  SHX2_2 = SHX0_2.load_attempts
  SHX2_2 = SHX2_2 + 1
  SHX0_2.load_attempts = SHX2_2
  SHX2_2 = SHX0_2.load_attempts
  if SHX2_2 >= 3 then
    SHX2_2 = Logger
    SHX3_2 = SHX2_2
    SHX2_2 = SHX2_2.log
    SHX4_2 = "Failed to load features from ^3https://api.reaperac.com"
    SHX5_2 = "error"
    return SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  end
  SHX2_2 = HTTP
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.await
  SHX4_2 = "https://api.reaperac.com/api/v1/features/api/v1/features"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX3_2 = SHX2_2.status
  if 200 ~= SHX3_2 then
    SHX3_2 = Logger
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.log
    SHX5_2 = "Failed to load features from ^3https://api.reaperac.com/api/v1/features^7, retrying in 5 seconds."
    SHX6_2 = "warn"
    SHX3_2(SHX4_2, SHX5_2, SHX6_2)
    SHX3_2 = Wait
    SHX4_2 = 5000
    SHX3_2(SHX4_2)
    SHX4_2 = SHX0_2
    SHX3_2 = SHX0_2.load
    return SHX3_2(SHX4_2)
  end
  SHX3_2 = json
  SHX3_2 = SHX3_2.decode
  SHX4_2 = SHX2_2.body
  SHX3_2 = SHX3_2(SHX4_2)
  if nil == SHX3_2 then
    SHX4_2 = Logger
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.log
    SHX6_2 = "Failed to decode response from ^3https://api.reaperac.com/api/v1/features^7, retrying in 5 seconds."
    SHX7_2 = "warn"
    SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX4_2 = Wait
    SHX5_2 = 5000
    SHX4_2(SHX5_2)
    SHX5_2 = SHX0_2
    SHX4_2 = SHX0_2.load
    return SHX4_2(SHX5_2)
  end
  SHX0_2.features = SHX3_2
end
SHX0_1.load = SHX1_1
SHX0_1 = Features
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.new
SHX0_1 = SHX0_1(SHX1_1)
Features = SHX0_1
