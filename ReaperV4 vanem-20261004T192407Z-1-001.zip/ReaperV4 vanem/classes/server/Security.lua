-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = class
SHX1_1 = "Security"
SHX0_1 = SHX0_1(SHX1_1)
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2
  SHX0_2.key = SHX1_2
  SHX2_2 = {}
  SHX0_2.encrypt_cache = SHX2_2
end
SHX0_1.constructor = SHX1_1
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX3_2 = SHX1_2
  SHX4_2 = SHX2_2 or SHX4_2
  if not SHX2_2 then
    SHX4_2 = SHX0_2.key
  end
  SHX3_2 = SHX3_2 .. SHX4_2
  SHX1_2 = SHX3_2
  SHX3_2 = 5381
  SHX4_2 = 1
  SHX5_2 = #SHX1_2
  SHX6_2 = 1
  for SHX7_2 = SHX4_2, SHX5_2, SHX6_2 do
    SHX8_2 = string
    SHX8_2 = SHX8_2.byte
    SHX9_2 = SHX1_2
    SHX10_2 = SHX7_2
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
    SHX9_2 = SHX3_2 * 33
    SHX3_2 = SHX9_2 ~ SHX8_2
  end
  return SHX3_2
end
SHX0_1.hash = SHX1_1
SHX1_1 = 8186484168865099
SHX2_1 = 4997
SHX3_1 = nil
function SHX4_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  if SHX2_2 then
    SHX3_2 = SHX0_2.encrypt_cache
    SHX5_2 = SHX0_2
    SHX4_2 = SHX0_2.hash
    SHX6_2 = SHX1_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    SHX3_2 = SHX3_2[SHX4_2]
    if SHX3_2 then
      SHX3_2 = SHX0_2.encrypt_cache
      SHX5_2 = SHX0_2
      SHX4_2 = SHX0_2.hash
      SHX6_2 = SHX1_2
      SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
      SHX3_2 = SHX3_2[SHX4_2]
      return SHX3_2
    end
  end
  SHX3_2 = SHX3_1
  if not SHX3_2 then
    SHX3_2 = {}
    SHX3_1 = SHX3_2
    SHX3_2 = 0
    SHX4_2 = 127
    SHX5_2 = 1
    for SHX6_2 = SHX3_2, SHX4_2, SHX5_2 do
      SHX7_2 = -1
      repeat
        SHX7_2 = SHX7_2 + 2
        SHX8_2 = 2 * SHX6_2
        SHX8_2 = SHX8_2 + 1
        SHX8_2 = SHX7_2 * SHX8_2
        SHX8_2 = SHX8_2 % 256
      until 1 == SHX8_2
      SHX8_2 = SHX3_1
      SHX8_2[SHX6_2] = SHX7_2
    end
  end
  SHX3_2 = SHX1_1
  SHX4_2 = SHX2_1
  SHX4_2 = 16384 + SHX4_2
  SHX6_2 = SHX1_2
  SHX5_2 = SHX1_2.gsub
  SHX7_2 = "."
  function SHX8_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX1_3 = SHX3_2
    SHX1_3 = SHX1_3 % 274877906944
    SHX2_3 = SHX3_2
    SHX2_3 = SHX2_3 - SHX1_3
    SHX2_3 = SHX2_3 / 274877906944
    SHX3_3 = SHX2_3 % 128
    SHX5_3 = SHX0_3
    SHX4_3 = SHX0_3.byte
    SHX4_3 = SHX4_3(SHX5_3)
    SHX0_3 = SHX4_3
    SHX4_3 = SHX3_1
    SHX4_3 = SHX4_3[SHX3_3]
    SHX4_3 = SHX0_3 * SHX4_3
    SHX5_3 = SHX2_3 - SHX3_3
    SHX5_3 = SHX5_3 / 128
    SHX4_3 = SHX4_3 - SHX5_3
    SHX4_3 = SHX4_3 % 256
    SHX5_3 = SHX4_2
    SHX5_3 = SHX1_3 * SHX5_3
    SHX5_3 = SHX5_3 + SHX2_3
    SHX5_3 = SHX5_3 + SHX4_3
    SHX5_3 = SHX5_3 + SHX0_3
    SHX3_2 = SHX5_3
    SHX5_3 = "%02x"
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.format
    SHX7_3 = SHX4_3
    return SHX5_3(SHX6_3, SHX7_3)
  end
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  if SHX2_2 then
    SHX6_2 = SHX0_2.encrypt_cache
    SHX8_2 = SHX0_2
    SHX7_2 = SHX0_2.hash
    SHX9_2 = SHX1_2
    SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
    SHX6_2[SHX7_2] = SHX5_2
  end
  return SHX5_2
end
SHX0_1.encrypt = SHX4_1
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = SHX1_1
  SHX3_2 = SHX2_1
  SHX3_2 = 16384 + SHX3_2
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.gsub
  SHX6_2 = "%x%x"
  function SHX7_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX1_3 = SHX2_2
    SHX1_3 = SHX1_3 % 274877906944
    SHX2_3 = SHX2_2
    SHX2_3 = SHX2_3 - SHX1_3
    SHX2_3 = SHX2_3 / 274877906944
    SHX3_3 = SHX2_3 % 128
    SHX4_3 = tonumber
    SHX5_3 = SHX0_3
    SHX6_3 = 16
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX0_3 = SHX4_3
    SHX4_3 = SHX2_3 - SHX3_3
    SHX4_3 = SHX4_3 / 128
    SHX4_3 = SHX0_3 + SHX4_3
    SHX5_3 = 2 * SHX3_3
    SHX5_3 = SHX5_3 + 1
    SHX4_3 = SHX4_3 * SHX5_3
    SHX4_3 = SHX4_3 % 256
    SHX5_3 = SHX3_2
    SHX5_3 = SHX1_3 * SHX5_3
    SHX5_3 = SHX5_3 + SHX2_3
    SHX5_3 = SHX5_3 + SHX0_3
    SHX5_3 = SHX5_3 + SHX4_3
    SHX2_2 = SHX5_3
    SHX5_3 = string
    SHX5_3 = SHX5_3.char
    SHX6_3 = SHX4_3
    return SHX5_3(SHX6_3)
  end
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  return SHX4_2
end
SHX0_1.decrypt = SHX4_1
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  if nil == SHX1_2 then
    SHX1_2 = "xxxxxxxx-xxxxxxxx-xxxxxxxx-xxxxxxxx-xxxxxxxx"
  end
  SHX2_2 = string
  SHX2_2 = SHX2_2.gsub
  SHX3_2 = SHX1_2
  SHX4_2 = "[xy]"
  function SHX5_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3
    if "x" == SHX0_3 then
      SHX1_3 = math
      SHX1_3 = SHX1_3.random
      SHX2_3 = 0
      SHX3_3 = 15
      SHX1_3 = SHX1_3(SHX2_3, SHX3_3)
      if SHX1_3 then
        goto SHX_LABEL_15
      end
    end
    SHX1_3 = math
    SHX1_3 = SHX1_3.random
    SHX2_3 = 8
    SHX3_3 = 11
    SHX1_3 = SHX1_3(SHX2_3, SHX3_3)
    -- [FIX IF ERROR] Move ::SHX_LABEL_15:: outside nested blocks until all 'goto SHX_LABEL_15' can see it
    ::SHX_LABEL_15::
    SHX2_3 = string
    SHX2_3 = SHX2_3.format
    SHX3_3 = "%x"
    SHX4_3 = SHX1_3
    return SHX2_3(SHX3_3, SHX4_3)
  end
  return SHX2_2(SHX3_2, SHX4_2, SHX5_2)
end
SHX0_1.genUUID = SHX4_1
SHX5_1 = SHX0_1
SHX4_1 = SHX0_1.new
SHX6_1 = "f0ad51e9-048479cf-9fba5eee-83b7f0b2-1c28924a"
SHX4_1 = SHX4_1(SHX5_1, SHX6_1)
Security = SHX4_1
