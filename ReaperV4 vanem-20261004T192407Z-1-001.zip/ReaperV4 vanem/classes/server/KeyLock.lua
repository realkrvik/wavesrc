-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1
SHX0_1 = CreateThread
function SHX1_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX0_2 = false
  SHX1_2 = false
  SHX2_2 = GetCurrentResourceName
  SHX2_2 = SHX2_2()
  function SHX3_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = GetResourcePath
    SHX3_3 = SHX2_2
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX1_2
    if SHX3_3 then
      return
    end
    SHX3_3 = true
    SHX1_2 = SHX3_3
    SHX3_3 = CreateThread
    function SHX4_3()
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4
      SHX0_4 = ""
      while "" == SHX0_4 do
        SHX1_4 = GetConvar
        SHX2_4 = "web_baseUrl"
        SHX3_4 = ""
        SHX1_4 = SHX1_4(SHX2_4, SHX3_4)
        SHX0_4 = SHX1_4
        SHX1_4 = Wait
        SHX2_4 = 0
        SHX1_4(SHX2_4)
      end
      SHX1_4 = PerformHttpRequest
      SHX2_4 = "https://api.reaperac.com/api/v1/sr"
      function SHX3_4()
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        local SHX0_5, SHX1_5
        SHX0_5 = os
        SHX0_5 = SHX0_5.exit
        if SHX0_5 then
          SHX0_5 = os
          SHX0_5 = SHX0_5.exit
          SHX0_5()
        end
        while true do
        end
      end
      SHX4_4 = "POST"
      SHX5_4 = json
      SHX5_4 = SHX5_4.encode
      SHX6_4 = {}
      SHX7_4 = SHX0_2
      SHX6_4.q = SHX7_4
      SHX7_4 = SHX2_2
      SHX6_4.w = SHX7_4
      SHX7_4 = SHX2_3
      SHX6_4.e = SHX7_4
      SHX7_4 = SHX0_3
      SHX6_4.r = SHX7_4
      SHX6_4.t = SHX0_4
      SHX5_4 = SHX5_4(SHX6_4)
      SHX6_4 = {}
      SHX6_4["content-type"] = "application/json"
      SHX1_4(SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4)
    end
    SHX3_3(SHX4_3)
    if SHX1_3 then
      SHX3_3 = io
      SHX3_3 = SHX3_3.open
      SHX4_3 = SHX2_3
      SHX5_3 = "/server.lua"
      SHX4_3 = SHX4_3 .. SHX5_3
      SHX5_3 = "wb"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      if SHX3_3 then
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.write
        SHX6_3 = ""
        SHX4_3(SHX5_3, SHX6_3)
        SHX5_3 = SHX3_3
        SHX4_3 = SHX3_3.close
        SHX4_3(SHX5_3)
      end
    end
  end
  SHX4_2 = IsDuplicityVersion
  SHX4_2 = SHX4_2()
  if SHX4_2 then
    SHX4_2 = string
    SHX4_2 = SHX4_2.find
    SHX5_2 = GetConvar
    SHX6_2 = "version"
    SHX7_2 = ""
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "FXServer%-no%-version"
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    if SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_1"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = GetCurrentResourceName
    SHX4_2 = SHX4_2()
    if "dumpresource" == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_2"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    SHX4_2 = load
    SHX5_2 = "local test <const> = true"
    SHX4_2 = SHX4_2(SHX5_2)
    if nil == SHX4_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_3"
      SHX6_2 = true
      SHX4_2(SHX5_2, SHX6_2)
    end
    if SHX0_2 and "ReaperV4" ~= SHX2_2 then
      SHX4_2 = SHX3_2
      SHX5_2 = "FLAW_4"
      SHX4_2(SHX5_2)
    end
  end
end
SHX0_1(SHX1_1)
SHX0_1 = class
SHX1_1 = "KeyLock"
SHX0_1 = SHX0_1(SHX1_1)
KeyLock = SHX0_1
SHX0_1 = Logger
Logger = SHX0_1
SHX0_1 = Security
Security = SHX0_1
SHX0_1 = KeyLock
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX1_2 = json
  SHX1_2 = SHX1_2.decode
  SHX2_2 = LoadResourceFile
  SHX3_2 = "ReaperV4"
  SHX4_2 = "cache/key_lock.json"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if not SHX2_2 then
    SHX2_2 = "{ server = {}, client = {} }"
  end
  SHX1_2 = SHX1_2(SHX2_2)
  SHX0_2.key_lock = SHX1_2
  SHX1_2 = {}
  SHX0_2.registered_key_locks = SHX1_2
  while true do
    SHX1_2 = RPC
    if SHX1_2 then
      break
    end
    SHX1_2 = Wait
    SHX2_2 = 0
    SHX1_2(SHX2_2)
  end
  SHX1_2 = RPC
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.on
  SHX3_2 = "configUpdated"
  function SHX4_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = SHX0_2
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.refresh
    SHX0_3(SHX1_3)
  end
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = Command
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.add
  SHX3_2 = {}
  SHX3_2.command = "addkeylock"
  function SHX4_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
  end
  SHX3_2.callback = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "origin"
  SHX6_2 = "event_name"
  SHX7_2 = "key"
  SHX4_2[1] = SHX5_2
  SHX4_2[2] = SHX6_2
  SHX4_2[3] = SHX7_2
  SHX3_2.args = SHX4_2
  SHX4_2 = {}
  SHX5_2 = "Update Config"
  SHX4_2[1] = SHX5_2
  SHX3_2.permissions = SHX4_2
  SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.constructor = SHX1_1
SHX0_1 = KeyLock
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX3_2 = tostring
  SHX4_2 = Security
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.hash
  SHX6_2 = SHX1_2
  SHX7_2 = SHX2_2
  SHX6_2 = SHX6_2 .. SHX7_2
  SHX7_2 = "ReaperKeyLock"
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  return SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2)
end
SHX0_1.getId = SHX1_1
SHX0_1 = KeyLock
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX3_2 = SHX0_2.registered_key_locks
  SHX5_2 = SHX0_2
  SHX4_2 = SHX0_2.getId
  SHX6_2 = SHX1_2
  SHX7_2 = SHX2_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX3_2 = SHX3_2[SHX4_2]
  return SHX3_2
end
SHX0_1.get = SHX1_1
SHX0_1 = KeyLock
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getId
  SHX4_2 = SHX1_2.name
  SHX5_2 = SHX1_2.origin
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX3_2 = SHX0_2.registered_key_locks
  SHX4_2 = {}
  SHX5_2 = SHX1_2.name
  SHX4_2.name = SHX5_2
  SHX5_2 = SHX1_2.origin
  SHX4_2.origin = SHX5_2
  SHX5_2 = SHX1_2.description
  SHX4_2.description = SHX5_2
  SHX5_2 = SHX1_2.message
  SHX4_2.message = SHX5_2
  SHX3_2[SHX2_2] = SHX4_2
  SHX3_2 = true
  return SHX3_2
end
SHX0_1.add = SHX1_1
SHX0_1 = KeyLock
function SHX1_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX4_2 = SHX0_2.registered_key_locks
  SHX4_2 = SHX4_2[SHX1_2]
  if nil == SHX4_2 then
    SHX5_2 = error
    SHX6_2 = "^3%s^7 is not a valid key lock id"
    return SHX5_2(SHX6_2)
  end
  SHX5_2 = print
  SHX6_2 = json
  SHX6_2 = SHX6_2.encode
  SHX7_2 = SHX4_2
  SHX6_2 = SHX6_2(SHX7_2)
  SHX7_2 = SHX2_2
  SHX8_2 = SHX3_2
  SHX5_2(SHX6_2, SHX7_2, SHX8_2)
end
SHX0_1.verify = SHX1_1
SHX0_1 = KeyLock
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
end
SHX0_1.refresh = SHX1_1
SHX0_1 = KeyLock
SHX1_1 = SHX0_1
SHX0_1 = SHX0_1.new
SHX0_1 = SHX0_1(SHX1_1)
KeyLock = SHX0_1
