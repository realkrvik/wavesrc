-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1
SHX0_1 = GetCurrentResourceName
SHX0_1 = SHX0_1()
SHX1_1 = SaveResourceFile
function SHX2_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX4_2 = SHX0_1
  if SHX0_2 == SHX4_2 then
    SHX4_2 = SHX1_1
    SHX5_2 = SHX0_2
    SHX6_2 = SHX1_2
    SHX7_2 = SHX2_2
    SHX8_2 = SHX3_2
    return SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  end
  SHX4_2 = exports
  SHX4_2 = SHX4_2.ReaperV4
  SHX5_2 = SHX4_2
  SHX4_2 = SHX4_2.SaveResourceFile
  SHX6_2 = SHX0_2
  SHX7_2 = SHX1_2
  SHX8_2 = SHX2_2
  SHX9_2 = SHX3_2
  return SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2)
end
SaveResourceFile = SHX2_1
function SHX2_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX3_2 = vector3
  SHX4_2 = SHX0_2.x
  SHX5_2 = SHX0_2.y
  SHX6_2 = SHX0_2.z
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX4_2 = vector3
  SHX5_2 = SHX1_2.x
  SHX6_2 = SHX1_2.y
  SHX7_2 = SHX1_2.z
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  if SHX2_2 then
    SHX5_2 = SHX3_2 - SHX4_2
    SHX5_2 = #SHX5_2
    return SHX5_2
  else
    SHX5_2 = SHX3_2.xy
    SHX6_2 = SHX4_2.xy
    SHX5_2 = SHX5_2 - SHX6_2
    SHX5_2 = #SHX5_2
    return SHX5_2
  end
end
GetDistanceBetweenCoords = SHX2_1
function SHX2_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX0_2 = {}
  SHX1_2 = GetAllVehicles
  SHX1_2 = SHX1_2()
  SHX2_2 = GetAllObjects
  SHX2_2 = SHX2_2()
  SHX3_2 = GetAllPeds
  SHX3_2 = SHX3_2()
  SHX4_2 = table
  SHX4_2 = SHX4_2.concat_tab
  SHX5_2 = SHX1_2
  SHX6_2 = SHX2_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX0_2 = SHX4_2
  SHX4_2 = table
  SHX4_2 = SHX4_2.concat_tab
  SHX5_2 = SHX0_2
  SHX6_2 = SHX3_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX0_2 = SHX4_2
  return SHX0_2
end
GetAllEntities = SHX2_1
function SHX2_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = Citizen
  SHX2_2 = SHX2_2.InvokeNative
  SHX3_2 = 2107079555
  SHX4_2 = SHX0_2
  SHX5_2 = SHX1_2
  SHX6_2 = Citizen
  SHX6_2 = SHX6_2.ReturnResultAnyway
  SHX6_2 = SHX6_2()
  return SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
end
NetworkSetEntityOwner = SHX2_1
function SHX2_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = Citizen
  SHX1_2 = SHX1_2.InvokeNative
  SHX2_2 = -1814940775
  SHX3_2 = SHX0_2
  SHX4_2 = Citizen
  SHX4_2 = SHX4_2.ReturnResultAnyway
  SHX4_2 = SHX4_2()
  return SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
IsObjectAPickup = SHX2_1
function SHX2_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = Citizen
  SHX1_2 = SHX1_2.InvokeNative
  SHX2_2 = 227706051
  SHX3_2 = SHX0_2
  SHX4_2 = Citizen
  SHX4_2 = SHX4_2.ResultAsInteger
  SHX4_2 = SHX4_2()
  return SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
GetEntityTypeRaw = SHX2_1
SHX2_1 = GetNumResourceMetadata
function SHX3_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX2_2 = {}
  SHX3_2 = 0
  SHX4_2 = SHX2_1
  SHX5_2 = SHX0_2
  SHX6_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = SHX4_2 - 1
  SHX5_2 = 1
  for SHX6_2 = SHX3_2, SHX4_2, SHX5_2 do
    SHX7_2 = #SHX2_2
    SHX7_2 = SHX7_2 + 1
    SHX8_2 = GetResourceMetadata
    SHX9_2 = SHX0_2
    SHX10_2 = SHX1_2
    SHX11_2 = SHX6_2
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2)
    SHX2_2[SHX7_2] = SHX8_2
  end
  return SHX2_2
end
GetResourceMetaDataValues = SHX3_1
