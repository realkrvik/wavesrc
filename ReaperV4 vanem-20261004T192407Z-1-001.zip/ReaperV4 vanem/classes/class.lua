-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1
function SHX0_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX3_2 = type
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  if SHX3_2 ~= SHX2_2 then
    SHX4_2 = error
    SHX5_2 = "expected %s %s to have type '%s' (received %s)"
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.format
    SHX7_2 = type
    SHX8_2 = SHX0_2
    SHX7_2 = SHX7_2(SHX8_2)
    if "string" == SHX7_2 then
      SHX7_2 = "field"
      if SHX7_2 then
        goto SHX_LABEL_18
      end
    end
    SHX7_2 = "argument"
    -- [FIX IF ERROR] Move ::SHX_LABEL_18:: outside nested blocks until all 'goto SHX_LABEL_18' can see it
    ::SHX_LABEL_18::
    SHX8_2 = SHX0_2
    SHX9_2 = SHX2_2
    SHX10_2 = SHX3_2
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
    SHX6_2 = 3
    SHX4_2(SHX5_2, SHX6_2)
  end
  if "table" == SHX2_2 then
    SHX4_2 = table
    SHX4_2 = SHX4_2.type
    SHX5_2 = SHX1_2
    SHX4_2 = SHX4_2(SHX5_2)
    if "hash" ~= SHX4_2 then
      SHX4_2 = error
      SHX5_2 = "expected argument %s to have table.type 'hash' (received %s)"
      SHX6_2 = SHX5_2
      SHX5_2 = SHX5_2.format
      SHX7_2 = SHX0_2
      SHX8_2 = table
      SHX8_2 = SHX8_2.type
      SHX9_2 = SHX1_2
      SHX8_2, SHX9_2, SHX10_2 = SHX8_2(SHX9_2)
      SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
      SHX6_2 = 3
      SHX4_2(SHX5_2, SHX6_2)
    end
  end
  SHX4_2 = true
  return SHX4_2
end
SHX1_1 = {}
SHX2_1 = {}
SHX3_1 = debug
SHX3_1 = SHX3_1.getinfo
function SHX4_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = SHX2_1
  SHX1_2 = SHX1_2[SHX0_2]
  if not SHX1_2 then
    SHX1_2 = SHX0_2.constructor
  end
  SHX2_2 = SHX0_2.constructor
  if SHX2_2 then
    SHX2_2 = SHX2_1
    SHX3_2 = SHX0_2.constructor
    SHX2_2[SHX0_2] = SHX3_2
    SHX0_2.constructor = nil
  end
  return SHX1_2
end
function SHX5_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = ""
  return SHX0_2
end
function SHX6_1(SHX0_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX1_2 = SHX4_1
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = setmetatable
  SHX3_2 = {}
  SHX4_2 = {}
  SHX3_2.private = SHX4_2
  SHX4_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  if SHX1_2 then
    SHX3_2 = SHX0_2
    SHX4_2 = rawset
    SHX5_2 = SHX2_2
    SHX6_2 = "super"
    function SHX7_2(SHX0_3, ...)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX1_3, SHX2_3, SHX3_3
      SHX1_3 = getmetatable
      SHX2_3 = SHX3_2
      SHX1_3 = SHX1_3(SHX2_3)
      SHX3_2 = SHX1_3
      SHX1_3 = SHX4_1
      SHX2_3 = SHX3_2
      SHX1_3 = SHX1_3(SHX2_3)
      SHX1_2 = SHX1_3
      SHX1_3 = SHX1_2
      if SHX1_3 then
        SHX1_3 = SHX1_2
        SHX2_3 = SHX0_3
        SHX3_3 = ...
        return SHX1_3(SHX2_3, SHX3_3)
      end
    end
    SHX4_2(SHX5_2, SHX6_2, SHX7_2)
    SHX4_2 = SHX1_2
    SHX5_2 = SHX2_2
    SHX6_2, SHX7_2 = ...
    SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  end
  SHX3_2 = rawset
  SHX4_2 = SHX2_2
  SHX5_2 = "super"
  SHX6_2 = nil
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = next
  SHX4_2 = SHX2_2.private
  SHX3_2 = SHX3_2(SHX4_2)
  if SHX3_2 then
    SHX3_2 = table
    SHX3_2 = SHX3_2.clone
    SHX4_2 = SHX2_2.private
    SHX3_2 = SHX3_2(SHX4_2)
    SHX4_2 = table
    SHX4_2 = SHX4_2.wipe
    SHX5_2 = SHX2_2.private
    SHX4_2(SHX5_2)
    SHX4_2 = setmetatable
    SHX5_2 = SHX2_2.private
    SHX6_2 = {}
    SHX6_2.__metatable = "private"
    SHX7_2 = SHX5_1
    SHX6_2.__tostring = SHX7_2
    function SHX7_2(SHX0_3, SHX1_3)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX2_3, SHX3_3, SHX4_3
      SHX2_3 = SHX3_1
      SHX3_3 = 2
      SHX4_3 = "n"
      SHX2_3 = SHX2_3(SHX3_3, SHX4_3)
      SHX3_3 = SHX2_3.namewhat
      if "local" == SHX3_3 then
        return
      end
      SHX3_3 = SHX3_2
      SHX3_3 = SHX3_3[SHX1_3]
      return SHX3_3
    end
    SHX6_2.__index = SHX7_2
    function SHX7_2(SHX0_3, SHX1_3, SHX2_3)
      -- [AI CLEANUP] Decompiled Lua - Fix these:
      -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
      -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
      -- 3. Replace goto/label with while/repeat-until where possible
      -- 4. Remove decompiler comments, add meaningful ones
      -- 5. Fix indentation and formatting
      
      local SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
      SHX3_3 = SHX3_1
      SHX4_3 = 2
      SHX5_3 = "n"
      SHX3_3 = SHX3_3(SHX4_3, SHX5_3)
      SHX4_3 = SHX3_3.namewhat
      if "method" ~= SHX4_3 then
        SHX4_3 = error
        SHX5_3 = "cannot set value of private field '%s'"
        SHX6_3 = SHX5_3
        SHX5_3 = SHX5_3.format
        SHX7_3 = SHX1_3
        SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
        SHX6_3 = 2
        SHX4_3(SHX5_3, SHX6_3)
      end
      SHX4_3 = SHX3_2
      SHX4_3[SHX1_3] = SHX2_3
    end
    SHX6_2.__newindex = SHX7_2
    SHX4_2(SHX5_2, SHX6_2)
  else
    SHX2_2.private = nil
  end
  return SHX2_2
end
SHX1_1.new = SHX6_1
function SHX6_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2
  SHX2_2 = getmetatable
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX2_2 = SHX2_2 == SHX1_2
  return SHX2_2
end
SHX1_1.isClass = SHX6_1
function SHX6_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  SHX2_2 = getmetatable
  SHX3_2 = SHX0_2
  SHX2_2 = SHX2_2(SHX3_2)
  while SHX2_2 do
    if SHX2_2 == SHX1_2 then
      SHX3_2 = true
      return SHX3_2
    end
    SHX3_2 = getmetatable
    SHX4_2 = SHX2_2
    SHX3_2 = SHX3_2(SHX4_2)
    SHX2_2 = SHX3_2
  end
  SHX3_2 = false
  return SHX3_2
end
SHX1_1.instanceOf = SHX6_1
function SHX6_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX0_1
  SHX3_2 = 1
  SHX4_2 = SHX0_2
  SHX5_2 = "string"
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = table
  SHX2_2 = SHX2_2.clone
  SHX3_2 = SHX1_1
  SHX2_2 = SHX2_2(SHX3_2)
  SHX2_2.__name = SHX0_2
  SHX2_2.__index = SHX2_2
  if SHX1_2 then
    SHX3_2 = SHX0_1
    SHX4_2 = "super"
    SHX5_2 = SHX1_2
    SHX6_2 = "table"
    SHX3_2(SHX4_2, SHX5_2, SHX6_2)
    SHX3_2 = setmetatable
    SHX4_2 = SHX2_2
    SHX5_2 = SHX1_2
    SHX3_2(SHX4_2, SHX5_2)
  end
  return SHX2_2
end
class = SHX6_1
