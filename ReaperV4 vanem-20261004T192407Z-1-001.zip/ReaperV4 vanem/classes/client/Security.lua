-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1, SHX21_1, SHX22_1, SHX23_1
SHX0_1 = class
SHX1_1 = "SecurityClient"
SHX0_1 = SHX0_1(SHX1_1)
SHX1_1 = Wait
SHX2_1 = GetGameTimer
SHX3_1 = tostring
SHX4_1 = CreateThread
SHX5_1 = GetConvar
SHX6_1 = string
SHX6_1 = SHX6_1.byte
SHX7_1 = string
SHX7_1 = SHX7_1.gsub
SHX8_1 = math
SHX8_1 = SHX8_1.random
SHX9_1 = json
SHX9_1 = SHX9_1.encode
SHX10_1 = string
SHX10_1 = SHX10_1.format
SHX11_1 = nil
SHX12_1 = Citizen
SHX12_1 = SHX12_1.InvokeFunctionReference
SHX13_1 = SHX5_1
SHX14_1 = "reaperSecurityKey"
SHX13_1 = SHX13_1(SHX14_1)
SHX14_1 = Player
SHX15_1 = Logger
SHX16_1 = RPC
SHX17_1 = false
SHX19_1 = SHX16_1
SHX18_1 = SHX16_1.on
SHX20_1 = "reaperReady"
function SHX21_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = true
  SHX17_1 = SHX0_2
end
SHX18_1(SHX19_1, SHX20_1, SHX21_1)
SHX18_1 = SHX5_1
SHX19_1 = "reaper_test_server"
SHX20_1 = "false"
SHX18_1 = SHX18_1(SHX19_1, SHX20_1)
if "true" == SHX18_1 then
  SHX19_1 = SHX14_1
  SHX18_1 = SHX14_1.set
  SHX20_1 = "start_detections"
  SHX21_1 = true
  SHX18_1(SHX19_1, SHX20_1, SHX21_1)
end
function SHX18_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX0_2.key = SHX1_2
  SHX2_2 = {}
  SHX0_2.detections = SHX2_2
  SHX2_2 = {}
  SHX0_2.active_detections = SHX2_2
  SHX2_2 = SHX0_2.private
  SHX3_2 = {}
  SHX2_2.cache = SHX3_2
  SHX2_2 = {}
  SHX0_2.encrypt_cache = SHX2_2
  SHX2_2 = SHX14_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.get
  SHX4_2 = "config"
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX0_2.config = SHX2_2
  SHX2_2 = SHX16_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.onNet
  SHX4_2 = "Reaper:NewDetection"
  function SHX5_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX1_3 = SHX0_2
    SHX2_3 = SHX1_3
    SHX1_3 = SHX1_3.detection
    SHX3_3 = SHX0_3.type
    SHX4_3 = SHX0_3.params
    SHX5_3 = SHX0_3.data
    SHX6_3 = SHX0_3.action
    SHX1_3(SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3)
  end
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  function SHX2_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    SHX0_3 = SHX14_1
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.get
    SHX2_3 = "config"
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
    SHX0_2.config = SHX0_3
    SHX1_3 = {}
    SHX2_3 = pairs
    SHX3_3 = SHX0_2.detections
    SHX2_3, SHX3_3, SHX4_3, SHX5_3 = SHX2_3(SHX3_3)
    for SHX6_3, SHX7_3 in SHX2_3, SHX3_3, SHX4_3, SHX5_3 do
      SHX8_3 = SHX3_1
      SHX9_3 = SHX11_1
      SHX10_3 = SHX9_3
      SHX9_3 = SHX9_3.hash
      SHX11_3 = SHX6_3
      SHX9_3, SHX10_3, SHX11_3 = SHX9_3(SHX10_3, SHX11_3)
      SHX8_3 = SHX8_3(SHX9_3, SHX10_3, SHX11_3)
      SHX9_3 = SHX0_3[SHX8_3]
      if SHX9_3 then
        SHX1_3[SHX6_3] = SHX7_3
      end
    end
    SHX0_2.active_detections = SHX1_3
  end
  SHX0_2.SetupDetections = SHX2_2
  SHX2_2 = SHX16_1
  SHX3_2 = SHX2_2
  SHX2_2 = SHX2_2.on
  SHX4_2 = "configUpdated"
  SHX5_2 = SHX0_2.SetupDetections
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = SHX4_1
  function SHX3_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3, SHX11_3
    while true do
      SHX0_3 = SHX17_1
      if SHX0_3 then
        SHX0_3 = SHX14_1
        SHX1_3 = SHX0_3
        SHX0_3 = SHX0_3.get
        SHX2_3 = "start_detections"
        SHX3_3 = false
        SHX0_3 = SHX0_3(SHX1_3, SHX2_3, SHX3_3)
        if SHX0_3 then
          break
        end
      end
      SHX0_3 = SHX1_1
      SHX1_3 = 1000
      SHX0_3(SHX1_3)
    end
    SHX0_3 = SHX14_1
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.set
    SHX2_3 = "running_detections"
    SHX3_3 = true
    SHX0_3(SHX1_3, SHX2_3, SHX3_3)
    while true do
      SHX0_3 = SHX1_1
      SHX1_3 = 500
      SHX0_3(SHX1_3)
      SHX0_3 = SHX2_1
      SHX0_3 = SHX0_3()
      SHX1_3 = nil
      SHX2_3 = pairs
      SHX3_3 = SHX0_2.active_detections
      SHX2_3, SHX3_3, SHX4_3, SHX5_3 = SHX2_3(SHX3_3)
      for SHX6_3, SHX7_3 in SHX2_3, SHX3_3, SHX4_3, SHX5_3 do
        SHX8_3 = SHX0_2.private
        SHX8_3 = SHX8_3.cache
        SHX9_3 = "lastRan:"
        SHX10_3 = SHX6_3
        SHX9_3 = SHX9_3 .. SHX10_3
        SHX8_3 = SHX8_3[SHX9_3]
        if not SHX8_3 then
          SHX8_3 = 0
        end
        SHX9_3 = SHX0_3 - SHX8_3
        SHX10_3 = SHX7_3.time
        if SHX9_3 > SHX10_3 then
          SHX9_3 = SHX0_2.private
          SHX9_3 = SHX9_3.cache
          SHX10_3 = "lastRan:"
          SHX11_3 = SHX6_3
          SHX10_3 = SHX10_3 .. SHX11_3
          SHX9_3[SHX10_3] = SHX0_3
          SHX9_3 = SHX4_1
          function SHX10_3()
            -- [AI CLEANUP] Decompiled Lua - Fix these:
            -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
            -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
            -- 3. Replace goto/label with while/repeat-until where possible
            -- 4. Remove decompiler comments, add meaningful ones
            -- 5. Fix indentation and formatting
            
            local SHX0_4, SHX1_4, SHX2_4, SHX3_4, SHX4_4, SHX5_4, SHX6_4, SHX7_4, SHX8_4, SHX9_4, SHX10_4, SHX11_4, SHX12_4, SHX13_4, SHX14_4
            SHX0_4 = pcall
            SHX1_4 = SHX7_3.callback
            SHX2_4 = SHX0_2.config
            SHX0_4, SHX1_4, SHX2_4, SHX3_4 = SHX0_4(SHX1_4, SHX2_4)
            if SHX1_4 then
              SHX4_4 = SHX7_3.disableVerify
              if true ~= SHX4_4 then
                SHX4_4 = SHX1_1
                SHX5_4 = 800
                SHX4_4(SHX5_4)
                SHX4_4 = pcall
                SHX5_4 = SHX7_3.callback
                SHX6_4 = SHX0_2.config
                SHX4_4, SHX5_4, SHX6_4, SHX7_4 = SHX4_4(SHX5_4, SHX6_4)
                SHX3_4 = SHX7_4
                SHX2_4 = SHX6_4
                SHX1_4 = SHX5_4
                SHX0_4 = SHX4_4
              end
            end
            if not SHX0_4 then
              SHX4_4 = SHX0_2
              SHX5_4 = SHX4_4
              SHX4_4 = SHX4_4.detection
              SHX6_4 = "detectionExecutionFailed"
              SHX7_4 = {}
              SHX8_4 = SHX6_3
              SHX7_4[1] = SHX8_4
              SHX8_4 = {}
              SHX8_4.error = SHX1_4
              SHX9_4 = SHX6_3
              SHX8_4.detection = SHX9_4
              SHX4_4(SHX5_4, SHX6_4, SHX7_4, SHX8_4)
            end
            if SHX0_4 and SHX1_4 then
              SHX4_4 = pairs
              SHX5_4 = SHX7_3.hooks
              SHX4_4, SHX5_4, SHX6_4, SHX7_4 = SHX4_4(SHX5_4)
              for SHX8_4, SHX9_4 in SHX4_4, SHX5_4, SHX6_4, SHX7_4 do
                SHX10_4 = msgpack
                SHX10_4 = SHX10_4.pack
                SHX11_4 = ""
                SHX10_4 = SHX10_4(SHX11_4)
                SHX11_4 = SHX12_1
                SHX12_4 = SHX9_4.__cfx_functionReference
                SHX13_4 = SHX10_4
                SHX14_4 = #SHX10_4
                SHX11_4 = SHX11_4(SHX12_4, SHX13_4, SHX14_4)
                SHX12_4 = msgpack
                SHX12_4 = SHX12_4.unpack
                SHX13_4 = SHX11_4
                SHX12_4 = SHX12_4(SHX13_4)
                SHX12_4 = SHX12_4[1]
                if SHX1_4 and false == SHX12_4 then
                  SHX1_4 = false
                end
              end
              if SHX1_4 then
                SHX4_4 = SHX7_3.detected
                if SHX4_4 then
                  SHX4_4 = SHX7_3.detected
                  SHX5_4 = SHX2_4
                  SHX6_4 = SHX3_4
                  SHX4_4(SHX5_4, SHX6_4)
                end
                SHX4_4 = SHX0_2
                SHX5_4 = SHX4_4
                SHX4_4 = SHX4_4.detection
                SHX6_4 = SHX6_3
                SHX7_4 = SHX2_4
                SHX8_4 = SHX3_4
                SHX4_4(SHX5_4, SHX6_4, SHX7_4, SHX8_4)
              end
            end
          end
          SHX9_3(SHX10_3)
        end
      end
      if nil == SHX1_3 then
        SHX2_3 = SetLocalStateValue
        SHX3_3 = "ReaperHeartbeat"
        SHX4_3 = {}
        SHX4_3.time = SHX0_3
        SHX5_3 = SHX0_2
        SHX6_3 = SHX5_3
        SHX5_3 = SHX5_3.hash
        SHX7_3 = "time:"
        SHX8_3 = SHX0_3
        SHX7_3 = SHX7_3 .. SHX8_3
        SHX5_3 = SHX5_3(SHX6_3, SHX7_3)
        SHX4_3.key = SHX5_3
        SHX2_3(SHX3_3, SHX4_3)
      end
    end
  end
  SHX2_2(SHX3_2)
end
SHX0_1.constructor = SHX18_1
SHX18_1 = 8186484168865099
SHX19_1 = 4997
SHX20_1 = nil
function SHX21_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  if SHX2_2 then
    SHX3_2 = SHX0_2.encrypt_cache
    SHX5_2 = SHX0_2
    SHX4_2 = SHX0_2.hash
    SHX6_2 = SHX1_2
    SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
    SHX3_2 = SHX3_2[SHX4_2]
    if SHX3_2 then
      SHX3_2 = SHX0_2.encrypt_cache
      SHX5_2 = SHX0_2
      SHX4_2 = SHX0_2.hash
      SHX6_2 = SHX1_2
      SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
      SHX3_2 = SHX3_2[SHX4_2]
      return SHX3_2
    end
  end
  SHX3_2 = SHX20_1
  if not SHX3_2 then
    SHX3_2 = {}
    SHX20_1 = SHX3_2
    SHX3_2 = 0
    SHX4_2 = 127
    SHX5_2 = 1
    for SHX6_2 = SHX3_2, SHX4_2, SHX5_2 do
      SHX7_2 = -1
      repeat
        SHX7_2 = SHX7_2 + 2
        SHX8_2 = 2 * SHX6_2
        SHX8_2 = SHX8_2 + 1
        SHX8_2 = SHX7_2 * SHX8_2
        SHX8_2 = SHX8_2 % 256
      until 1 == SHX8_2
      SHX8_2 = SHX20_1
      SHX8_2[SHX6_2] = SHX7_2
    end
  end
  SHX3_2 = SHX18_1
  SHX4_2 = SHX19_1
  SHX4_2 = 16384 + SHX4_2
  SHX6_2 = SHX1_2
  SHX5_2 = SHX1_2.gsub
  SHX7_2 = "."
  function SHX8_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX1_3 = SHX3_2
    SHX1_3 = SHX1_3 % 274877906944
    SHX2_3 = SHX3_2
    SHX2_3 = SHX2_3 - SHX1_3
    SHX2_3 = SHX2_3 / 274877906944
    SHX3_3 = SHX2_3 % 128
    SHX5_3 = SHX0_3
    SHX4_3 = SHX0_3.byte
    SHX4_3 = SHX4_3(SHX5_3)
    SHX0_3 = SHX4_3
    SHX4_3 = SHX20_1
    SHX4_3 = SHX4_3[SHX3_3]
    SHX4_3 = SHX0_3 * SHX4_3
    SHX5_3 = SHX2_3 - SHX3_3
    SHX5_3 = SHX5_3 / 128
    SHX4_3 = SHX4_3 - SHX5_3
    SHX4_3 = SHX4_3 % 256
    SHX5_3 = SHX4_2
    SHX5_3 = SHX1_3 * SHX5_3
    SHX5_3 = SHX5_3 + SHX2_3
    SHX5_3 = SHX5_3 + SHX4_3
    SHX5_3 = SHX5_3 + SHX0_3
    SHX3_2 = SHX5_3
    SHX5_3 = "%02x"
    SHX6_3 = SHX5_3
    SHX5_3 = SHX5_3.format
    SHX7_3 = SHX4_3
    return SHX5_3(SHX6_3, SHX7_3)
  end
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  if SHX2_2 then
    SHX6_2 = SHX0_2.encrypt_cache
    SHX8_2 = SHX0_2
    SHX7_2 = SHX0_2.hash
    SHX9_2 = SHX1_2
    SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
    SHX6_2[SHX7_2] = SHX5_2
  end
  return SHX5_2
end
SHX0_1.encrypt = SHX21_1
function SHX21_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX2_2 = SHX18_1
  SHX3_2 = SHX19_1
  SHX3_2 = 16384 + SHX3_2
  SHX5_2 = SHX1_2
  SHX4_2 = SHX1_2.gsub
  SHX6_2 = "%x%x"
  function SHX7_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX1_3 = SHX2_2
    SHX1_3 = SHX1_3 % 274877906944
    SHX2_3 = SHX2_2
    SHX2_3 = SHX2_3 - SHX1_3
    SHX2_3 = SHX2_3 / 274877906944
    SHX3_3 = SHX2_3 % 128
    SHX4_3 = tonumber
    SHX5_3 = SHX0_3
    SHX6_3 = 16
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX0_3 = SHX4_3
    SHX4_3 = SHX2_3 - SHX3_3
    SHX4_3 = SHX4_3 / 128
    SHX4_3 = SHX0_3 + SHX4_3
    SHX5_3 = 2 * SHX3_3
    SHX5_3 = SHX5_3 + 1
    SHX4_3 = SHX4_3 * SHX5_3
    SHX4_3 = SHX4_3 % 256
    SHX5_3 = SHX3_2
    SHX5_3 = SHX1_3 * SHX5_3
    SHX5_3 = SHX5_3 + SHX2_3
    SHX5_3 = SHX5_3 + SHX0_3
    SHX5_3 = SHX5_3 + SHX4_3
    SHX2_2 = SHX5_3
    SHX5_3 = string
    SHX5_3 = SHX5_3.char
    SHX6_3 = SHX4_3
    return SHX5_3(SHX6_3)
  end
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  return SHX4_2
end
SHX0_1.decrypt = SHX21_1
function SHX21_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX3_2 = SHX1_2
  SHX4_2 = SHX2_2 or SHX4_2
  if not SHX2_2 then
    SHX4_2 = SHX0_2.key
  end
  SHX3_2 = SHX3_2 .. SHX4_2
  SHX1_2 = SHX3_2
  SHX3_2 = 5381
  SHX4_2 = 1
  SHX5_2 = #SHX1_2
  SHX6_2 = 1
  for SHX7_2 = SHX4_2, SHX5_2, SHX6_2 do
    SHX8_2 = SHX6_1
    SHX9_2 = SHX1_2
    SHX10_2 = SHX7_2
    SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
    SHX9_2 = SHX3_2 * 33
    SHX3_2 = SHX9_2 ~ SHX8_2
  end
  return SHX3_2
end
SHX0_1.hash = SHX21_1
function SHX21_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  if nil == SHX1_2 then
    SHX1_2 = "xxxxxxxx-xxxxxxxx-xxxxxxxx-xxxxxxxx-xxxxxxxx"
  end
  SHX2_2 = SHX7_1
  SHX3_2 = SHX1_2
  SHX4_2 = "[xy]"
  function SHX5_2(SHX0_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX1_3, SHX2_3, SHX3_3, SHX4_3
    if "x" == SHX0_3 then
      SHX1_3 = SHX8_1
      SHX2_3 = 0
      SHX3_3 = 15
      SHX1_3 = SHX1_3(SHX2_3, SHX3_3)
      if SHX1_3 then
        goto SHX_LABEL_13
      end
    end
    SHX1_3 = SHX8_1
    SHX2_3 = 8
    SHX3_3 = 11
    SHX1_3 = SHX1_3(SHX2_3, SHX3_3)
    -- [FIX IF ERROR] Move ::SHX_LABEL_13:: outside nested blocks until all 'goto SHX_LABEL_13' can see it
    ::SHX_LABEL_13::
    SHX2_3 = SHX10_1
    SHX3_3 = "%x"
    SHX4_3 = SHX1_3
    return SHX2_3(SHX3_3, SHX4_3)
  end
  return SHX2_2(SHX3_2, SHX4_2, SHX5_2)
end
SHX0_1.genUUID = SHX21_1
function SHX21_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX3_2 = SHX0_2.detections
  SHX4_2 = SHX1_2.detection
  SHX3_2 = SHX3_2[SHX4_2]
  if nil ~= SHX3_2 then
    SHX3_2 = error
    SHX4_2 = "%s has already been registered as a detection"
    SHX5_2 = SHX4_2
    SHX4_2 = SHX4_2.format
    SHX6_2 = SHX1_2.detection
    SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2, SHX6_2)
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2)
  end
  SHX3_2 = SHX15_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "^3%s ^7was just registered as a detection vector"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX1_2.detection
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX6_2 = "debug"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX1_2.callback = SHX2_2
  SHX3_2 = {}
  SHX1_2.hooks = SHX3_2
  SHX3_2 = SHX0_2.detections
  SHX4_2 = SHX1_2.detection
  SHX3_2[SHX4_2] = SHX1_2
  SHX3_2 = SHX0_2.SetupDetections
  SHX3_2()
end
SHX0_1.addDetection = SHX21_1
function SHX21_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX3_2 = SHX15_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.log
  SHX5_2 = "^3%s^7 was just registered as a detection hook for %s"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX2_2
  SHX8_2 = SHX1_2
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX6_2 = "debug"
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = SHX0_2.detections
  SHX3_2 = SHX3_2[SHX1_2]
  if nil == SHX3_2 then
    SHX3_2 = SHX15_1
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.log
    SHX5_2 = "SecurityClient:addDetectionHook -> ^3%s^7 is not a valid detection name"
    SHX6_2 = SHX5_2
    SHX5_2 = SHX5_2.format
    SHX7_2 = SHX1_2
    SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
    SHX6_2 = "error"
    return SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  end
  SHX3_2 = SHX0_2.detections
  SHX3_2 = SHX3_2[SHX1_2]
  SHX3_2 = SHX3_2.hooks
  SHX4_2 = SHX0_2.detections
  SHX4_2 = SHX4_2[SHX1_2]
  SHX4_2 = SHX4_2.hooks
  SHX4_2 = #SHX4_2
  SHX4_2 = SHX4_2 + 1
  SHX3_2[SHX4_2] = SHX2_2
end
SHX0_1.addDetectionHook = SHX21_1
function SHX21_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2
  SHX6_2 = SHX0_2
  SHX5_2 = SHX0_2.genUUID
  SHX5_2 = SHX5_2(SHX6_2)
  SHX6_2 = SHX3_2 or SHX6_2
  if not SHX3_2 then
    SHX6_2 = {}
  end
  SHX7_2 = SHX5_1
  SHX8_2 = "reaper_send_full_state_change_data"
  SHX9_2 = "false"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  if "false" == SHX7_2 then
    SHX7_2 = {}
    SHX8_2 = GetLastStateRecorderData
    SHX9_2 = 45
    SHX8_2 = SHX8_2(SHX9_2)
    SHX7_2.state_recorder = SHX8_2
    SHX8_2 = SHX2_1
    SHX8_2 = SHX8_2()
    SHX7_2.current_time = SHX8_2
    SHX6_2.default_data = SHX7_2
  else
    SHX7_2 = {}
    SHX8_2 = GetLastStateRecorderData
    SHX8_2 = SHX8_2()
    SHX7_2.state_recorder = SHX8_2
    SHX8_2 = SHX2_1
    SHX8_2 = SHX8_2()
    SHX7_2.current_time = SHX8_2
    SHX6_2.default_data = SHX7_2
  end
  SHX7_2 = SHX5_1
  SHX8_2 = "reaper_send_state_data"
  SHX9_2 = "false"
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2)
  if "true" == SHX7_2 then
    SHX7_2 = SHX6_2.default_data
    SHX8_2 = SHX14_1
    SHX9_2 = SHX8_2
    SHX8_2 = SHX8_2.getAllStateData
    SHX8_2 = SHX8_2(SHX9_2)
    SHX7_2.state_data = SHX8_2
  end
  SHX8_2 = SHX0_2
  SHX7_2 = SHX0_2.encrypt
  SHX9_2 = SHX9_1
  SHX10_2 = {}
  SHX10_2.type = SHX1_2
  SHX11_2 = SHX6_2 or SHX11_2
  if not SHX6_2 then
    SHX11_2 = {}
  end
  SHX10_2.data = SHX11_2
  SHX11_2 = SHX2_2 or SHX11_2
  if not SHX2_2 then
    SHX11_2 = {}
  end
  SHX10_2.params = SHX11_2
  SHX10_2.key = SHX5_2
  SHX10_2.action = SHX4_2
  SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2 = SHX9_2(SHX10_2)
  SHX7_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
  SHX8_2 = SHX16_1
  SHX9_2 = SHX8_2
  SHX8_2 = SHX8_2.await
  SHX10_2 = "Reaper:NewDetection"
  SHX11_2 = SHX13_1
  SHX10_2 = SHX10_2 .. SHX11_2
  SHX11_2 = SHX7_2
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2)
  if "RESPONSE_FAILED" == SHX8_2 then
    SHX9_2 = print
    SHX10_2 = "QuitGame SecurityClient:detection 1"
    SHX11_2 = SHX1_2
    SHX12_2 = json
    SHX12_2 = SHX12_2.encode
    SHX13_2 = SHX6_2
    SHX12_2 = SHX12_2(SHX13_2)
    SHX13_2 = json
    SHX13_2 = SHX13_2.encode
    SHX14_2 = SHX2_2
    SHX13_2 = SHX13_2(SHX14_2)
    SHX14_2 = SHX4_2
    SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2)
    SHX9_2 = QuitGame
    SHX9_2()
    SHX9_2 = SHX1_1
    SHX10_2 = 8000
    SHX9_2(SHX10_2)
    while true do
    end
  end
  if nil ~= SHX8_2 then
    SHX9_2 = SHX8_2.key
    if SHX9_2 == SHX5_2 then
      goto SHX_LABEL_105
    end
  end
  SHX9_2 = print
  SHX10_2 = "QuitGame SecurityClient:detection 2"
  SHX9_2(SHX10_2)
  SHX9_2 = QuitGame
  SHX9_2()
  SHX9_2 = SHX1_1
  SHX10_2 = 8000
  SHX9_2(SHX10_2)
  while true do
  end
  -- [FIX IF ERROR] Move ::SHX_LABEL_105:: outside nested blocks until all 'goto SHX_LABEL_105' can see it
  ::SHX_LABEL_105::
  return SHX8_2
end
SHX0_1.detection = SHX21_1
SHX22_1 = SHX0_1
SHX21_1 = SHX0_1.new
SHX23_1 = "f0ad51e9-048479cf-9fba5eee-83b7f0b2-1c28924a"
SHX21_1 = SHX21_1(SHX22_1, SHX23_1)
Security = SHX21_1
SHX11_1 = Security
SHX21_1 = SHX4_1
function SHX22_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX1_1
  SHX1_2 = 5000
  SHX0_2(SHX1_2)
  SHX0_2 = _G
  SHX0_2.Security = nil
end
SHX21_1(SHX22_1)
