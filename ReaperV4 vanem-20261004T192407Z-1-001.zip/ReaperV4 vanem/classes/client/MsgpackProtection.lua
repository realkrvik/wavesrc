-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1
SHX0_1 = class
SHX1_1 = "MsgpackProtection"
SHX0_1 = SHX0_1(SHX1_1)
SHX1_1 = nil
SHX2_1 = CreateThread
function SHX3_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  while true do
    SHX0_2 = _G
    SHX0_2 = SHX0_2.Security
    if nil ~= SHX0_2 then
      break
    end
    SHX0_2 = Wait
    SHX1_2 = 20
    SHX0_2(SHX1_2)
  end
  SHX0_2 = _G
  SHX0_2 = SHX0_2.Security
  SHX1_1 = SHX0_2
end
SHX2_1(SHX3_1)
SHX2_1 = Logger
SHX3_1 = msgpack
SHX3_1 = SHX3_1.pack
SHX4_1 = msgpack
SHX4_1 = SHX4_1.unpack
SHX5_1 = msgpack
SHX5_1 = SHX5_1.pack_args
SHX6_1 = table
SHX6_1 = SHX6_1.pack
SHX7_1 = table
SHX7_1 = SHX7_1.unpack
SHX8_1 = string
SHX8_1 = SHX8_1.byte
SHX9_1 = GetNetworkTimeAccurate
SHX10_1 = math
SHX10_1 = SHX10_1.random
function SHX11_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX0_2.master_key = "test"
  SHX1_2 = {}
  SHX0_2.used_nonces = SHX1_2
  SHX0_2.nonce_cleanup_interval = 300000
  SHX1_2 = SHX9_1
  SHX1_2 = SHX1_2()
  SHX0_2.last_nonce_cleanup = SHX1_2
  SHX1_2 = {}
  SHX1_2.total_protected = 0
  SHX1_2.total_validated = 0
  SHX1_2.validation_failures = 0
  SHX1_2.tampering_detected = 0
  SHX1_2.replay_attacks_blocked = 0
  SHX0_2.stats = SHX1_2
end
SHX0_1.constructor = SHX11_1
function SHX11_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  SHX0_2.master_key = SHX1_2
end
SHX0_1.setMasterKey = SHX11_1
function SHX11_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2
  if not SHX2_2 then
    SHX2_2 = 0
  end
  SHX3_2 = 3432918353
  SHX4_2 = 461845907
  SHX5_2 = SHX2_2
  SHX6_2 = #SHX1_2
  SHX7_2 = SHX6_2 % 4
  SHX8_2 = SHX6_2 - SHX7_2
  SHX8_2 = SHX8_2 // 4
  SHX9_2 = 0
  SHX10_2 = SHX8_2 - 1
  SHX11_2 = 1
  for SHX12_2 = SHX9_2, SHX10_2, SHX11_2 do
    SHX13_2 = string
    SHX13_2 = SHX13_2.unpack
    SHX14_2 = "<I4"
    SHX15_2 = SHX1_2
    SHX16_2 = SHX12_2 * 4
    SHX16_2 = SHX16_2 + 1
    SHX13_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2)
    SHX14_2 = SHX13_2 * SHX3_2
    SHX13_2 = SHX14_2 & 4294967295
    SHX14_2 = SHX13_2 << 15
    SHX15_2 = SHX13_2 >> 17
    SHX14_2 = SHX14_2 | SHX15_2
    SHX14_2 = SHX14_2 * SHX4_2
    SHX13_2 = SHX14_2 & 4294967295
    SHX14_2 = SHX5_2 ~ SHX13_2
    SHX5_2 = SHX14_2 & 4294967295
    SHX14_2 = SHX5_2 << 13
    SHX15_2 = SHX5_2 >> 19
    SHX14_2 = SHX14_2 | SHX15_2
    SHX14_2 = SHX14_2 * 5
    SHX14_2 = SHX14_2 + 3864292196
    SHX5_2 = SHX14_2 & 4294967295
  end
  SHX9_2 = 0
  SHX10_2 = SHX8_2 * 4
  SHX10_2 = SHX10_2 + 1
  if SHX7_2 >= 3 then
    SHX11_2 = SHX8_1
    SHX12_2 = SHX1_2
    SHX13_2 = SHX10_2 + 2
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
    SHX11_2 = SHX11_2 << 16
    SHX11_2 = SHX9_2 ~ SHX11_2
    SHX9_2 = SHX11_2 & 4294967295
  end
  if SHX7_2 >= 2 then
    SHX11_2 = SHX8_1
    SHX12_2 = SHX1_2
    SHX13_2 = SHX10_2 + 1
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
    SHX11_2 = SHX11_2 << 8
    SHX11_2 = SHX9_2 ~ SHX11_2
    SHX9_2 = SHX11_2 & 4294967295
  end
  if SHX7_2 >= 1 then
    SHX11_2 = SHX8_1
    SHX12_2 = SHX1_2
    SHX13_2 = SHX10_2
    SHX11_2 = SHX11_2(SHX12_2, SHX13_2)
    SHX11_2 = SHX9_2 ~ SHX11_2
    SHX9_2 = SHX11_2 & 4294967295
    SHX11_2 = SHX9_2 * SHX3_2
    SHX9_2 = SHX11_2 & 4294967295
    SHX11_2 = SHX9_2 << 15
    SHX12_2 = SHX9_2 >> 17
    SHX11_2 = SHX11_2 | SHX12_2
    SHX11_2 = SHX11_2 * SHX4_2
    SHX9_2 = SHX11_2 & 4294967295
    SHX11_2 = SHX5_2 ~ SHX9_2
    SHX5_2 = SHX11_2 & 4294967295
  end
  SHX11_2 = SHX5_2 ~ SHX6_2
  SHX5_2 = SHX11_2 & 4294967295
  SHX11_2 = SHX5_2 >> 16
  SHX11_2 = SHX5_2 ~ SHX11_2
  SHX5_2 = SHX11_2 & 4294967295
  SHX11_2 = SHX5_2 * 2246822507
  SHX5_2 = SHX11_2 & 4294967295
  SHX11_2 = SHX5_2 >> 13
  SHX11_2 = SHX5_2 ~ SHX11_2
  SHX5_2 = SHX11_2 & 4294967295
  SHX11_2 = SHX5_2 * 3266489909
  SHX5_2 = SHX11_2 & 4294967295
  SHX11_2 = SHX5_2 >> 16
  SHX11_2 = SHX5_2 ~ SHX11_2
  SHX5_2 = SHX11_2 & 4294967295
  return SHX5_2
end
SHX0_1.murmur3 = SHX11_1
function SHX11_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX3_2 = SHX1_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.hash
  SHX5_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX5_2 = SHX0_2
  SHX4_2 = SHX0_2.murmur3
  SHX6_2 = SHX1_2
  SHX7_2 = SHX3_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX6_2 = SHX0_2
  SHX5_2 = SHX0_2.murmur3
  SHX7_2 = SHX2_2
  SHX8_2 = SHX1_2
  SHX7_2 = SHX7_2 .. SHX8_2
  SHX8_2 = SHX4_2
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2)
  SHX6_2 = tostring
  SHX7_2 = SHX5_2
  return SHX6_2(SHX7_2)
end
SHX0_1.generateSignature = SHX11_1
function SHX11_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX1_2 = {}
  SHX2_2 = table
  SHX2_2 = SHX2_2.insert
  SHX3_2 = SHX1_2
  SHX4_2 = tostring
  SHX5_2 = SHX9_1
  SHX5_2, SHX6_2, SHX7_2 = SHX5_2()
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
  SHX2_2 = table
  SHX2_2 = SHX2_2.insert
  SHX3_2 = SHX1_2
  SHX4_2 = tostring
  SHX5_2 = SHX10_1
  SHX6_2 = 1000000
  SHX7_2 = 9999999
  SHX5_2, SHX6_2, SHX7_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
  SHX2_2 = table
  SHX2_2 = SHX2_2.insert
  SHX3_2 = SHX1_2
  SHX4_2 = tostring
  SHX5_2 = SHX1_1
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.genUUID
  SHX5_2, SHX6_2, SHX7_2 = SHX5_2(SHX6_2)
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
  SHX2_2 = table
  SHX2_2 = SHX2_2.insert
  SHX3_2 = SHX1_2
  SHX4_2 = tostring
  SHX5_2 = SHX10_1
  SHX6_2 = 1000000
  SHX7_2 = 9999999
  SHX5_2, SHX6_2, SHX7_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2)
  SHX2_2 = table
  SHX2_2 = SHX2_2.concat
  SHX3_2 = SHX1_2
  SHX4_2 = "-"
  return SHX2_2(SHX3_2, SHX4_2)
end
SHX0_1.generateNonce = SHX11_1
function SHX11_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX2_2 = SHX9_1
  SHX2_2 = SHX2_2()
  SHX3_2 = SHX0_2.last_nonce_cleanup
  SHX3_2 = SHX2_2 - SHX3_2
  SHX4_2 = SHX0_2.nonce_cleanup_interval
  if SHX3_2 > SHX4_2 then
    SHX3_2 = SHX0_2.nonce_cleanup_interval
    SHX3_2 = SHX2_2 - SHX3_2
    SHX4_2 = pairs
    SHX5_2 = SHX0_2.used_nonces
    SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2)
    for SHX8_2, SHX9_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
      if SHX9_2 < SHX3_2 then
        SHX10_2 = SHX0_2.used_nonces
        SHX10_2[SHX8_2] = nil
      end
    end
    SHX0_2.last_nonce_cleanup = SHX2_2
  end
  SHX3_2 = SHX0_2.used_nonces
  SHX3_2 = SHX3_2[SHX1_2]
  SHX3_2 = nil ~= SHX3_2
  return SHX3_2
end
SHX0_1.isNonceUsed = SHX11_1
function SHX11_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2
  SHX2_2 = SHX0_2.used_nonces
  SHX3_2 = SHX9_1
  SHX3_2 = SHX3_2()
  SHX2_2[SHX1_2] = SHX3_2
end
SHX0_1.markNonceUsed = SHX11_1
function SHX11_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX3_2 = SHX0_2.master_key
  if not SHX3_2 then
    SHX3_2 = SHX2_1
    SHX4_2 = SHX3_2
    SHX3_2 = SHX3_2.log
    SHX5_2 = "[MsgpackProtection] Cannot protect data: master key not set"
    SHX6_2 = "error"
    SHX3_2(SHX4_2, SHX5_2, SHX6_2)
    SHX3_2 = nil
    SHX4_2 = nil
    return SHX3_2, SHX4_2
  end
  SHX4_2 = SHX0_2
  SHX3_2 = SHX0_2.generateNonce
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = SHX3_1
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = SHX0_2.master_key
  if SHX2_2 then
    SHX6_2 = SHX5_2
    SHX7_2 = SHX2_2
    SHX6_2 = SHX6_2 .. SHX7_2
    SHX5_2 = SHX6_2
  end
  SHX6_2 = SHX5_2
  SHX7_2 = SHX3_2
  SHX6_2 = SHX6_2 .. SHX7_2
  SHX5_2 = SHX6_2
  SHX7_2 = SHX0_2
  SHX6_2 = SHX0_2.generateSignature
  SHX8_2 = SHX4_2
  SHX9_2 = SHX5_2
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX7_2 = {}
  SHX7_2.signature = SHX6_2
  SHX7_2.nonce = SHX3_2
  SHX7_2.data = SHX4_2
  SHX8_2 = SHX9_1
  SHX8_2 = SHX8_2()
  SHX7_2.timestamp = SHX8_2
  SHX8_2 = SHX3_1
  SHX9_2 = SHX7_2
  SHX8_2 = SHX8_2(SHX9_2)
  SHX9_2 = SHX0_2.stats
  SHX10_2 = SHX0_2.stats
  SHX10_2 = SHX10_2.total_protected
  SHX10_2 = SHX10_2 + 1
  SHX9_2.total_protected = SHX10_2
  SHX9_2 = SHX8_2
  SHX10_2 = SHX3_2
  return SHX9_2, SHX10_2
end
SHX0_1.protect = SHX11_1
function SHX11_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2
  SHX4_2 = SHX0_2.master_key
  if not SHX4_2 then
    SHX4_2 = false
    SHX5_2 = nil
    SHX6_2 = "master_key_not_set"
    return SHX4_2, SHX5_2, SHX6_2
  end
  if not SHX3_2 then
    SHX3_2 = 300000
  end
  SHX4_2 = SHX0_2.stats
  SHX5_2 = SHX0_2.stats
  SHX5_2 = SHX5_2.total_validated
  SHX5_2 = SHX5_2 + 1
  SHX4_2.total_validated = SHX5_2
  SHX4_2 = pcall
  SHX5_2 = SHX4_1
  SHX6_2 = SHX1_2
  SHX4_2, SHX5_2 = SHX4_2(SHX5_2, SHX6_2)
  if not SHX4_2 then
    SHX6_2 = SHX0_2.stats
    SHX7_2 = SHX0_2.stats
    SHX7_2 = SHX7_2.validation_failures
    SHX7_2 = SHX7_2 + 1
    SHX6_2.validation_failures = SHX7_2
    SHX6_2 = false
    SHX7_2 = nil
    SHX8_2 = "invalid_msgpack_format"
    return SHX6_2, SHX7_2, SHX8_2
  end
  SHX6_2 = type
  SHX7_2 = SHX5_2
  SHX6_2 = SHX6_2(SHX7_2)
  if "table" == SHX6_2 then
    SHX6_2 = SHX5_2.signature
    if SHX6_2 then
      SHX6_2 = SHX5_2.nonce
      if SHX6_2 then
        SHX6_2 = SHX5_2.data
        if SHX6_2 then
          SHX6_2 = SHX5_2.timestamp
          if SHX6_2 then
            goto SHX_LABEL_60
          end
        end
      end
    end
  end
  SHX6_2 = SHX0_2.stats
  SHX7_2 = SHX0_2.stats
  SHX7_2 = SHX7_2.validation_failures
  SHX7_2 = SHX7_2 + 1
  SHX6_2.validation_failures = SHX7_2
  SHX6_2 = false
  SHX7_2 = nil
  SHX8_2 = "invalid_package_structure"
  return SHX6_2, SHX7_2, SHX8_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_60:: outside nested blocks until all 'goto SHX_LABEL_60' can see it
  ::SHX_LABEL_60::
  SHX6_2 = SHX9_1
  SHX6_2 = SHX6_2()
  SHX7_2 = SHX5_2.timestamp
  SHX7_2 = SHX6_2 - SHX7_2
  if SHX3_2 < SHX7_2 then
    SHX8_2 = SHX0_2.stats
    SHX9_2 = SHX0_2.stats
    SHX9_2 = SHX9_2.validation_failures
    SHX9_2 = SHX9_2 + 1
    SHX8_2.validation_failures = SHX9_2
    SHX8_2 = false
    SHX9_2 = nil
    SHX10_2 = "data_expired"
    return SHX8_2, SHX9_2, SHX10_2
  end
  SHX9_2 = SHX0_2
  SHX8_2 = SHX0_2.isNonceUsed
  SHX10_2 = SHX5_2.nonce
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  if SHX8_2 then
    SHX8_2 = SHX0_2.stats
    SHX9_2 = SHX0_2.stats
    SHX9_2 = SHX9_2.replay_attacks_blocked
    SHX9_2 = SHX9_2 + 1
    SHX8_2.replay_attacks_blocked = SHX9_2
    SHX8_2 = SHX0_2.stats
    SHX9_2 = SHX0_2.stats
    SHX9_2 = SHX9_2.validation_failures
    SHX9_2 = SHX9_2 + 1
    SHX8_2.validation_failures = SHX9_2
    SHX8_2 = false
    SHX9_2 = nil
    SHX10_2 = "replay_attack_detected"
    return SHX8_2, SHX9_2, SHX10_2
  end
  SHX8_2 = SHX0_2.master_key
  if SHX2_2 then
    SHX9_2 = SHX8_2
    SHX10_2 = SHX2_2
    SHX9_2 = SHX9_2 .. SHX10_2
    SHX8_2 = SHX9_2
  end
  SHX9_2 = SHX8_2
  SHX10_2 = SHX5_2.nonce
  SHX9_2 = SHX9_2 .. SHX10_2
  SHX8_2 = SHX9_2
  SHX10_2 = SHX0_2
  SHX9_2 = SHX0_2.generateSignature
  SHX11_2 = SHX5_2.data
  SHX12_2 = SHX8_2
  SHX9_2 = SHX9_2(SHX10_2, SHX11_2, SHX12_2)
  SHX10_2 = SHX5_2.signature
  if SHX9_2 ~= SHX10_2 then
    SHX10_2 = SHX0_2.stats
    SHX11_2 = SHX0_2.stats
    SHX11_2 = SHX11_2.tampering_detected
    SHX11_2 = SHX11_2 + 1
    SHX10_2.tampering_detected = SHX11_2
    SHX10_2 = SHX0_2.stats
    SHX11_2 = SHX0_2.stats
    SHX11_2 = SHX11_2.validation_failures
    SHX11_2 = SHX11_2 + 1
    SHX10_2.validation_failures = SHX11_2
    SHX10_2 = false
    SHX11_2 = nil
    SHX12_2 = "signature_mismatch_tampering_detected"
    return SHX10_2, SHX11_2, SHX12_2
  end
  SHX11_2 = SHX0_2
  SHX10_2 = SHX0_2.markNonceUsed
  SHX12_2 = SHX5_2.nonce
  SHX10_2(SHX11_2, SHX12_2)
  SHX10_2 = pcall
  SHX11_2 = SHX4_1
  SHX12_2 = SHX5_2.data
  SHX10_2, SHX11_2 = SHX10_2(SHX11_2, SHX12_2)
  if not SHX10_2 then
    SHX12_2 = SHX0_2.stats
    SHX13_2 = SHX0_2.stats
    SHX13_2 = SHX13_2.validation_failures
    SHX13_2 = SHX13_2 + 1
    SHX12_2.validation_failures = SHX13_2
    SHX12_2 = false
    SHX13_2 = nil
    SHX14_2 = "data_unpack_failed"
    return SHX12_2, SHX13_2, SHX14_2
  end
  SHX12_2 = true
  SHX13_2 = SHX11_2
  SHX14_2 = nil
  return SHX12_2, SHX13_2, SHX14_2
end
SHX0_1.validate = SHX11_1
function SHX11_1(SHX0_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = SHX6_1
  SHX2_2, SHX3_2, SHX4_2 = ...
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.protect
  SHX4_2 = SHX1_2
  return SHX2_2(SHX3_2, SHX4_2)
end
SHX0_1.protectArgs = SHX11_1
function SHX11_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX5_2 = SHX0_2
  SHX4_2 = SHX0_2.validate
  SHX6_2 = SHX1_2
  SHX7_2 = SHX2_2
  SHX8_2 = SHX3_2
  SHX4_2, SHX5_2, SHX6_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
  if not SHX4_2 then
    SHX7_2 = false
    SHX8_2 = SHX6_2
    return SHX7_2, SHX8_2
  end
  SHX7_2 = true
  SHX8_2 = SHX7_1
  SHX9_2 = SHX5_2
  SHX8_2, SHX9_2 = SHX8_2(SHX9_2)
  return SHX7_2, SHX8_2, SHX9_2
end
SHX0_1.validateArgs = SHX11_1
function SHX11_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = {}
  SHX2_2 = SHX0_2.stats
  SHX2_2 = SHX2_2.total_protected
  SHX1_2.total_protected = SHX2_2
  SHX2_2 = SHX0_2.stats
  SHX2_2 = SHX2_2.total_validated
  SHX1_2.total_validated = SHX2_2
  SHX2_2 = SHX0_2.stats
  SHX2_2 = SHX2_2.validation_failures
  SHX1_2.validation_failures = SHX2_2
  SHX2_2 = SHX0_2.stats
  SHX2_2 = SHX2_2.tampering_detected
  SHX1_2.tampering_detected = SHX2_2
  SHX2_2 = SHX0_2.stats
  SHX2_2 = SHX2_2.replay_attacks_blocked
  SHX1_2.replay_attacks_blocked = SHX2_2
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.countActiveNonces
  SHX2_2 = SHX2_2(SHX3_2)
  SHX1_2.active_nonces = SHX2_2
  SHX2_2 = SHX0_2.stats
  SHX2_2 = SHX2_2.total_validated
  if SHX2_2 > 0 then
    SHX2_2 = SHX0_2.stats
    SHX2_2 = SHX2_2.total_validated
    SHX3_2 = SHX0_2.stats
    SHX3_2 = SHX3_2.validation_failures
    SHX2_2 = SHX2_2 - SHX3_2
    SHX3_2 = SHX0_2.stats
    SHX3_2 = SHX3_2.total_validated
    SHX2_2 = SHX2_2 / SHX3_2
    SHX2_2 = SHX2_2 * 100
    if SHX2_2 then
      goto SHX_LABEL_40
    end
  end
  SHX2_2 = 0
  -- [FIX IF ERROR] Move ::SHX_LABEL_40:: outside nested blocks until all 'goto SHX_LABEL_40' can see it
  ::SHX_LABEL_40::
  SHX1_2.success_rate = SHX2_2
  return SHX1_2
end
SHX0_1.getStatistics = SHX11_1
function SHX11_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX1_2 = 0
  SHX2_2 = pairs
  SHX3_2 = SHX0_2.used_nonces
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
  for SHX6_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX1_2 = SHX1_2 + 1
  end
  return SHX1_2
end
SHX0_1.countActiveNonces = SHX11_1
function SHX11_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = {}
  SHX0_2.used_nonces = SHX1_2
  SHX1_2 = SHX9_1
  SHX1_2 = SHX1_2()
  SHX0_2.last_nonce_cleanup = SHX1_2
end
SHX0_1.clearNonces = SHX11_1
function SHX11_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = {}
  SHX1_2.total_protected = 0
  SHX1_2.total_validated = 0
  SHX1_2.validation_failures = 0
  SHX1_2.tampering_detected = 0
  SHX1_2.replay_attacks_blocked = 0
  SHX0_2.stats = SHX1_2
end
SHX0_1.resetStatistics = SHX11_1
SHX12_1 = SHX0_1
SHX11_1 = SHX0_1.new
SHX11_1 = SHX11_1(SHX12_1)
MsgpackProtection = SHX11_1
