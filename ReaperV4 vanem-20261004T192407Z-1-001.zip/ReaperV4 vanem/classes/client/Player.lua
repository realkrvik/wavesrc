-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1
SHX0_1 = class
SHX1_1 = "PlayerClient"
SHX0_1 = SHX0_1(SHX1_1)
SHX1_1 = tostring
SHX2_1 = LocalPlayer
SHX2_1 = SHX2_1.state
SHX3_1 = string
SHX3_1 = SHX3_1.byte
SHX4_1 = IsPedInAnyVehicle
SHX5_1 = GetEntityCoords
SHX6_1 = GetSelectedPedWeapon
SHX7_1 = PlayerPedId
SHX8_1 = GetGameTimer
SHX9_1 = json
SHX9_1 = SHX9_1.encode
SHX10_1 = GetRenderingCam
SHX11_1 = IsEntityVisible
SHX12_1 = type
SHX13_1 = Logger
SHX14_1 = nil
SHX15_1 = nil
SHX16_1 = CreateThread
function SHX17_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  while true do
    SHX0_2 = _G
    SHX0_2 = SHX0_2.Security
    if nil ~= SHX0_2 then
      break
    end
    SHX0_2 = Wait
    SHX1_2 = 20
    SHX0_2(SHX1_2)
  end
  SHX0_2 = _G
  SHX0_2 = SHX0_2.Security
  SHX14_1 = SHX0_2
  SHX0_2 = _G
  SHX0_2 = SHX0_2.RPC
  SHX15_1 = SHX0_2
end
SHX16_1(SHX17_1)
function SHX16_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  if 1 == SHX0_2 or true == SHX0_2 then
    SHX1_2 = true
    return SHX1_2
  else
    SHX1_2 = false
    return SHX1_2
  end
end
function SHX17_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX1_2 = SHX0_2
  SHX2_2 = "f0ad51e9-048479cf-9fba5eee-83b7f0b2-1c28924a"
  SHX1_2 = SHX1_2 .. SHX2_2
  SHX0_2 = SHX1_2
  SHX1_2 = 5381
  SHX2_2 = 1
  SHX3_2 = #SHX0_2
  SHX4_2 = 1
  for SHX5_2 = SHX2_2, SHX3_2, SHX4_2 do
    SHX6_2 = SHX3_1
    SHX7_2 = SHX0_2
    SHX8_2 = SHX5_2
    SHX6_2 = SHX6_2(SHX7_2, SHX8_2)
    SHX7_2 = SHX1_2 * 33
    SHX1_2 = SHX7_2 ~ SHX6_2
  end
  return SHX1_2
end
function SHX18_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2
  SHX2_2 = {}
  SHX0_2.cache = SHX2_2
  SHX2_2 = {}
  SHX0_2.replicated_cached_index = SHX2_2
  SHX2_2 = SHX0_2.private
  SHX3_2 = LocalPlayer
  SHX3_2 = SHX3_2.state
  SHX2_2.state = SHX3_2
end
SHX0_1.constructor = SHX18_1
function SHX18_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX4_2 = SHX0_2.replicated_cached_index
  SHX4_2 = SHX4_2[SHX1_2]
  if SHX4_2 then
    SHX4_2 = SHX0_2.cache
    SHX4_2 = SHX4_2[SHX1_2]
    if SHX4_2 ~= SHX2_2 then
      SHX4_2 = SHX15_1
      SHX5_2 = SHX4_2
      SHX4_2 = SHX4_2.await
      SHX6_2 = "SetReplicatedCacheValue"
      SHX7_2 = SHX1_2
      SHX8_2 = SHX2_2
      SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2)
      if true ~= SHX4_2 then
        SHX5_2 = print
        SHX6_2 = "[ReaperV4] failed to sync replicated cache value. Closing game to prevent issues"
        SHX5_2(SHX6_2)
        SHX5_2 = QuitGame
        SHX5_2()
      end
    end
  end
  SHX4_2 = SHX9_1
  SHX5_2 = SHX0_2.cache
  SHX5_2 = SHX5_2[SHX1_2]
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = SHX9_1
  SHX6_2 = SHX2_2
  SHX5_2 = SHX5_2(SHX6_2)
  if SHX4_2 ~= SHX5_2 then
    SHX4_2 = SHX0_2.cache
    SHX4_2[SHX1_2] = SHX2_2
    if true ~= SHX3_2 then
      SHX4_2 = SHX0_2.cache
      SHX5_2 = "time_set_"
      SHX6_2 = SHX1_2
      SHX5_2 = SHX5_2 .. SHX6_2
      SHX6_2 = SHX8_1
      SHX6_2 = SHX6_2()
      SHX4_2[SHX5_2] = SHX6_2
    end
  end
  SHX4_2 = SHX0_2.cache
  SHX4_2 = SHX4_2[SHX1_2]
  return SHX4_2
end
SHX0_1.set = SHX18_1
function SHX18_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX4_2 = SHX0_2.cache
  SHX4_2 = SHX4_2[SHX1_2]
  if nil == SHX4_2 and nil ~= SHX2_2 then
    SHX4_2 = SHX2_2
    if SHX3_2 then
      SHX6_2 = SHX0_2
      SHX5_2 = SHX0_2.set
      SHX7_2 = SHX1_2
      SHX8_2 = SHX4_2
      SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    end
  end
  return SHX4_2
end
SHX0_1.get = SHX18_1
function SHX18_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2
  SHX2_2 = SHX0_2.replicated_cached_index
  SHX2_2[SHX1_2] = true
  SHX2_2 = 1
  return SHX2_2
end
SHX0_1.registerCacheReplicated = SHX18_1
function SHX18_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX3_2 = SHX8_1
  SHX3_2 = SHX3_2()
  SHX5_2 = SHX0_2
  SHX4_2 = SHX0_2.getSetTime
  SHX6_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX4_2 = SHX3_2 - SHX4_2
  SHX4_2 = SHX2_2 > SHX4_2
  return SHX4_2
end
SHX0_1.getRecentlyChanged = SHX18_1
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.cache
  return SHX1_2
end
SHX0_1.getAllStateData = SHX18_1
function SHX18_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.get
  SHX4_2 = "time_set_"
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2 .. SHX5_2
  SHX5_2 = 0
  return SHX2_2(SHX3_2, SHX4_2, SHX5_2)
end
SHX0_1.getSetTime = SHX18_1
function SHX18_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2
  SHX3_2 = "reaper:"
  SHX4_2 = SHX17_1
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX3_2 = SHX3_2 .. SHX4_2
  SHX4_2 = SHX2_1
  SHX3_2 = SHX4_2[SHX3_2]
  if nil ~= SHX3_2 then
    SHX4_2 = SHX17_1
    SHX5_2 = SHX1_2
    SHX6_2 = SHX1_1
    SHX7_2 = SHX3_2.key3
    SHX6_2 = SHX6_2(SHX7_2)
    SHX7_2 = SHX3_2.key2
    SHX5_2 = SHX5_2 .. SHX6_2 .. SHX7_2
    SHX4_2 = SHX4_2(SHX5_2)
    SHX5_2 = SHX3_2.key
    if SHX4_2 == SHX5_2 then
      goto SHX_LABEL_22
    end
  end
  return SHX2_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_22:: outside nested blocks until all 'goto SHX_LABEL_22' can see it
  ::SHX_LABEL_22::
  SHX4_2 = SHX3_2.key3
  return SHX4_2
end
SHX0_1.getSyncedState = SHX18_1
function SHX18_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX3_2 = SHX8_1
  SHX3_2 = SHX3_2()
  SHX4_2 = SHX1_2
  SHX5_2 = "_synced"
  SHX4_2 = SHX4_2 .. SHX5_2
  SHX6_2 = SHX0_2
  SHX5_2 = SHX0_2.get
  SHX7_2 = SHX4_2
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  if SHX5_2 ~= SHX2_2 then
    SHX6_2 = SHX2_1
    SHX7_2 = SHX6_2
    SHX6_2 = SHX6_2.set
    SHX8_2 = "reaper:"
    SHX9_2 = SHX17_1
    SHX10_2 = SHX1_2
    SHX9_2 = SHX9_2(SHX10_2)
    SHX8_2 = SHX8_2 .. SHX9_2
    SHX9_2 = {}
    SHX10_2 = SHX17_1
    SHX11_2 = SHX1_2
    SHX12_2 = SHX1_1
    SHX13_2 = SHX2_2
    SHX12_2 = SHX12_2(SHX13_2)
    SHX13_2 = SHX3_2
    SHX11_2 = SHX11_2 .. SHX12_2 .. SHX13_2
    SHX10_2 = SHX10_2(SHX11_2)
    SHX9_2.key = SHX10_2
    SHX9_2.key2 = SHX3_2
    SHX9_2.key3 = SHX2_2
    SHX6_2(SHX7_2, SHX8_2, SHX9_2)
    SHX7_2 = SHX0_2
    SHX6_2 = SHX0_2.set
    SHX8_2 = SHX4_2
    SHX9_2 = SHX2_2
    SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  end
end
SHX0_1.setSyncedState = SHX18_1
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX7_1
  return SHX1_2()
end
SHX0_1.getPed = SHX18_1
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = SHX6_1
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getPed
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.currentWeapon = SHX18_1
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX10_1
  return SHX1_2()
end
SHX0_1.getCamId = SHX18_1
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = SHX6_1
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getPed
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.getCurrentWeapon = SHX18_1
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = SHX16_1
  SHX2_2 = SHX11_1
  SHX4_2 = SHX0_2
  SHX3_2 = SHX0_2.getPed
  SHX3_2, SHX4_2 = SHX3_2(SHX4_2)
  SHX2_2, SHX3_2, SHX4_2 = SHX2_2(SHX3_2, SHX4_2)
  return SHX1_2(SHX2_2, SHX3_2, SHX4_2)
end
SHX0_1.isVisible = SHX18_1
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = SHX5_1
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getPed
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.getCoords = SHX18_1
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = SHX4_1
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.getPed
  SHX2_2, SHX3_2 = SHX2_2(SHX3_2)
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.inVehicle = SHX18_1
function SHX18_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX3_2 = SHX14_1
  if nil ~= SHX3_2 then
    SHX4_2 = SHX0_2
    SHX3_2 = SHX0_2.get
    SHX5_2 = "reaperReady"
    SHX6_2 = false
    SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2)
    if false ~= SHX3_2 then
      goto SHX_LABEL_13
    end
  end
  SHX3_2 = true
  SHX4_2 = "Reaper Is Not Started Yet"
  return SHX3_2, SHX4_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_13:: outside nested blocks until all 'goto SHX_LABEL_13' can see it
  ::SHX_LABEL_13::
  SHX3_2 = nil
  if "log" == SHX1_2 then
    SHX3_2 = "Log Player"
  elseif "kick" == SHX1_2 then
    SHX3_2 = "Kick Player"
  elseif "ban" == SHX1_2 then
    SHX3_2 = "Ban Player"
  else
    SHX4_2 = true
    SHX5_2 = "Invalid Action"
    return SHX4_2, SHX5_2
  end
  SHX4_2 = SHX12_1
  SHX5_2 = SHX2_2
  SHX4_2 = SHX4_2(SHX5_2)
  if "string" ~= SHX4_2 then
    SHX4_2 = true
    SHX5_2 = "Invalid Reason"
    return SHX4_2, SHX5_2
  end
  while true do
    SHX4_2 = SHX14_1
    if nil ~= SHX4_2 then
      break
    end
    SHX4_2 = Wait
    SHX5_2 = 20
    SHX4_2(SHX5_2)
  end
  SHX4_2 = false
  SHX5_2 = SHX14_1
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.detection
  SHX7_2 = "customDetection"
  SHX8_2 = {}
  SHX9_2 = SHX2_2
  SHX8_2[1] = SHX9_2
  SHX9_2 = nil
  SHX10_2 = SHX3_2
  SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  return SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
end
SHX0_1.addDetection = SHX18_1
function SHX18_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2
  SHX5_2 = GetInvokingResource
  SHX5_2 = SHX5_2()
  if not SHX5_2 then
    SHX5_2 = "ReaperV4"
  end
  while true do
    SHX6_2 = SHX14_1
    if nil ~= SHX6_2 then
      break
    end
    SHX6_2 = Wait
    SHX7_2 = 20
    SHX6_2(SHX7_2)
  end
  SHX6_2 = SHX14_1
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.detection
  SHX8_2 = SHX1_2
  SHX9_2 = SHX4_2 or SHX9_2
  if not SHX4_2 then
    SHX9_2 = {}
  end
  SHX10_2 = SHX3_2 or SHX10_2
  if not SHX3_2 then
    SHX10_2 = {}
  end
  SHX11_2 = SHX2_2
  SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2)
  SHX6_2 = SHX14_1
  SHX7_2 = SHX6_2
  SHX6_2 = SHX6_2.hash
  SHX8_2 = SHX1_2
  SHX9_2 = SHX5_2
  SHX8_2 = SHX8_2 .. SHX9_2
  return SHX6_2(SHX7_2, SHX8_2)
end
SHX0_1.newDetection = SHX18_1
SHX19_1 = SHX0_1
SHX18_1 = SHX0_1.new
SHX18_1 = SHX18_1(SHX19_1)
Player = SHX18_1
SHX18_1 = CreateThread
function SHX19_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = Wait
  SHX1_2 = 5000
  SHX0_2(SHX1_2)
  SHX0_2 = _G
  SHX0_2.Player = nil
end
SHX18_1(SHX19_1)
