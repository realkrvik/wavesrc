-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1
SHX0_1 = class
SHX1_1 = "Weapons"
SHX0_1 = SHX0_1(SHX1_1)
SHX1_1 = CreateThread
SHX2_1 = LoadResourceFile
SHX3_1 = GetSelectedPedWeapon
SHX4_1 = SHX1_1
function SHX5_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  while true do
    SHX0_2 = _G
    SHX0_2 = SHX0_2.Weapons
    if nil ~= SHX0_2 then
      break
    end
    SHX0_2 = Wait
    SHX1_2 = 20
    SHX0_2(SHX1_2)
  end
  SHX0_2 = _G
  SHX0_2 = SHX0_2.Weapons
  Weapons = SHX0_2
end
SHX4_1(SHX5_1)
function SHX4_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2
  SHX1_2 = json
  SHX1_2 = SHX1_2.decode
  SHX2_2 = SHX2_1
  SHX3_2 = "ReaperV4"
  SHX4_2 = "data_files/weapons.json"
  SHX2_2, SHX3_2, SHX4_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX0_2.weapon_data = SHX1_2
end
SHX0_1.constructor = SHX4_1
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  SHX2_2 = SHX0_2.weapon_data
  SHX3_2 = tostring
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  SHX2_2 = SHX2_2[SHX3_2]
  if not SHX2_2 then
    SHX2_2 = {}
    SHX3_2 = tostring
    SHX4_2 = SHX1_2
    SHX3_2 = SHX3_2(SHX4_2)
    SHX2_2.Name = SHX3_2
  end
  SHX2_2 = SHX2_2.Name
  return SHX2_2
end
SHX0_1.getWeaponName = SHX4_1
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2
  SHX2_2 = SHX0_2.weapon_data
  SHX3_2 = tostring
  SHX4_2 = SHX1_2
  SHX3_2 = SHX3_2(SHX4_2)
  SHX2_2 = SHX2_2[SHX3_2]
  if not SHX2_2 then
    SHX2_2 = {}
  end
  SHX2_2 = SHX2_2.Components
  return SHX2_2
end
SHX0_1.getWeaponComponents = SHX4_1
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX2_2 = SHX3_1
  SHX3_2 = SHX1_2
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = SHX0_2.weapon_data
  SHX4_2 = tostring
  SHX5_2 = SHX2_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX3_2 = SHX3_2[SHX4_2]
  return SHX3_2
end
SHX0_1.getCurrentPedWeapon = SHX4_1
SHX5_1 = SHX0_1
SHX4_1 = SHX0_1.new
SHX4_1 = SHX4_1(SHX5_1)
Weapons = SHX4_1
SHX4_1 = SHX1_1
function SHX5_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = Wait
  SHX1_2 = 5000
  SHX0_2(SHX1_2)
  SHX0_2 = _G
  SHX0_2.Weapons = nil
end
SHX4_1(SHX5_1)
