-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1, SHX16_1, SHX17_1, SHX18_1, SHX19_1, SHX20_1
SHX0_1 = class
SHX1_1 = "NUI"
SHX0_1 = SHX0_1(SHX1_1)
NUI = SHX0_1
SHX0_1 = SendNUIMessage
SHX1_1 = RegisterNUICallback
SHX2_1 = SetNuiFocus
SHX3_1 = promise
SHX3_1 = SHX3_1.new
SHX4_1 = GetGameTimer
SHX5_1 = Citizen
SHX5_1 = SHX5_1.Await
SHX6_1 = GetActiveScreenResolution
SHX7_1 = CreateDui
SHX8_1 = SendDuiMessage
SHX9_1 = IsDuiAvailable
SHX10_1 = json
SHX10_1 = SHX10_1.encode
SHX11_1 = GetConvar
SHX12_1 = Wait
SHX13_1 = nil
SHX14_1 = Logger
SHX15_1 = nil
SHX16_1 = nil
SHX17_1 = CreateThread
function SHX18_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  while true do
    SHX0_2 = _G
    SHX0_2 = SHX0_2.Player
    if nil ~= SHX0_2 then
      SHX0_2 = _G
      SHX0_2 = SHX0_2.Security
      if nil ~= SHX0_2 then
        break
      end
    end
    SHX0_2 = SHX12_1
    SHX1_2 = 25
    SHX0_2(SHX1_2)
  end
  SHX0_2 = _G
  SHX0_2 = SHX0_2.Player
  SHX15_1 = SHX0_2
  SHX0_2 = _G
  SHX0_2 = SHX0_2.Security
  SHX16_1 = SHX0_2
end
SHX17_1(SHX18_1)
SHX17_1 = NUI
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX1_2 = {}
  SHX0_2.callbacks = SHX1_2
  SHX0_2.activeRecording = false
  SHX0_2.activeScreenshot = false
  SHX0_2.activeOCR = false
  SHX1_2 = SHX6_1
  SHX1_2, SHX2_2 = SHX1_2()
  SHX3_2 = SHX11_1
  SHX4_2 = "reaper_clip_length"
  SHX5_2 = "2"
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX4_2 = SHX7_1
  SHX5_2 = "https://my.reaperac.com/nui_tools/index.html?resource=ReaperV4&type=1&clip_length=%s&serverId=%s&security_key=%s"
  SHX6_2 = SHX5_2
  SHX5_2 = SHX5_2.format
  SHX7_2 = SHX3_2
  SHX8_2 = SHX11_1
  SHX9_2 = "serverId"
  SHX8_2 = SHX8_2(SHX9_2)
  SHX9_2 = SHX11_1
  SHX10_2 = "reaperSecurityKey"
  SHX9_2, SHX10_2 = SHX9_2(SHX10_2)
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  SHX6_2 = SHX1_2
  SHX7_2 = SHX2_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX0_2.dui = SHX4_2
  SHX5_2 = SHX0_2
  SHX4_2 = SHX0_2.on
  SHX6_2 = "httpResponse"
  function SHX7_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = SHX0_2.callbacks
    SHX3_3 = SHX0_3.id
    SHX2_3 = SHX2_3[SHX3_3]
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.resolve
    SHX4_3 = SHX0_3.response
    SHX2_3(SHX3_3, SHX4_3)
    SHX2_3 = SHX0_2.callbacks
    SHX3_3 = SHX0_3.id
    SHX2_3[SHX3_3] = nil
    SHX2_3 = SHX1_3
    SHX3_3 = true
    SHX2_3(SHX3_3)
  end
  SHX4_2(SHX5_2, SHX6_2, SHX7_2)
  SHX4_2 = CreateThread
  function SHX5_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3, SHX3_3, SHX4_3
    while true do
      SHX0_3 = SHX9_1
      SHX1_3 = SHX0_2.dui
      SHX0_3 = SHX0_3(SHX1_3)
      if SHX0_3 then
        SHX0_3 = SHX15_1
        if nil ~= SHX0_3 then
          SHX0_3 = SHX15_1
          SHX1_3 = SHX0_3
          SHX0_3 = SHX0_3.get
          SHX2_3 = "config"
          SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
          if nil ~= SHX0_3 then
            break
          end
        end
      end
      SHX0_3 = SHX12_1
      SHX1_3 = 100
      SHX0_3(SHX1_3)
    end
    SHX0_3 = SHX12_1
    SHX1_3 = 5000
    SHX0_3(SHX1_3)
    SHX0_3 = SHX15_1
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.get
    SHX2_3 = "config"
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
    SHX1_3 = tostring
    SHX2_3 = SHX16_1
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.hash
    SHX4_3 = "ScreenRecord"
    SHX2_3, SHX3_3, SHX4_3 = SHX2_3(SHX3_3, SHX4_3)
    SHX1_3 = SHX1_3(SHX2_3, SHX3_3, SHX4_3)
    SHX0_3 = SHX0_3[SHX1_3]
    if SHX0_3 then
      SHX0_3 = SHX14_1
      SHX1_3 = SHX0_3
      SHX0_3 = SHX0_3.log
      SHX2_3 = "RECORD_LAST_GAMEPLAY enabled"
      SHX3_3 = "debug"
      SHX0_3(SHX1_3, SHX2_3, SHX3_3)
      SHX0_3 = SHX8_1
      SHX1_3 = SHX0_2.dui
      SHX2_3 = SHX10_1
      SHX3_3 = {}
      SHX3_3.command = "RECORD_LAST_GAMEPLAY"
      SHX2_3, SHX3_3, SHX4_3 = SHX2_3(SHX3_3)
      SHX0_3(SHX1_3, SHX2_3, SHX3_3, SHX4_3)
    end
  end
  SHX4_2(SHX5_2)
end
SHX17_1.constructor = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2
  SHX3_2 = SHX0_1
  SHX4_2 = {}
  SHX4_2.action = SHX1_2
  SHX4_2.data = SHX2_2
  SHX3_2(SHX4_2)
end
SHX17_1.send = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2
  SHX2_2 = SHX0_1
  SHX3_2 = SHX1_2
  SHX2_2(SHX3_2)
end
SHX17_1.sendRaw = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX4_2 = SHX0_2
  SHX3_2 = SHX0_2.send
  SHX5_2 = "setVisible"
  SHX6_2 = {}
  SHX6_2.component = SHX1_2
  SHX6_2.display = true
  SHX6_2.data = SHX2_2
  SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  SHX3_2 = SHX2_1
  SHX4_2 = true
  SHX5_2 = true
  SHX3_2(SHX4_2, SHX5_2)
end
SHX17_1.open = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2
  SHX3_2 = SHX0_2
  SHX2_2 = SHX0_2.send
  SHX4_2 = "setVisible"
  SHX5_2 = {}
  SHX5_2.component = SHX1_2
  SHX5_2.display = false
  SHX5_2.data = nil
  SHX2_2(SHX3_2, SHX4_2, SHX5_2)
  SHX2_2 = SHX2_1
  SHX3_2 = false
  SHX4_2 = false
  SHX2_2(SHX3_2, SHX4_2)
end
SHX17_1.close = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2
  SHX3_2 = SHX1_1
  SHX4_2 = SHX1_2
  SHX5_2 = SHX2_2
  return SHX3_2(SHX4_2, SHX5_2)
end
SHX17_1.on = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2
  SHX4_2 = SHX3_1
  SHX4_2 = SHX4_2()
  SHX5_2 = SHX4_1
  SHX5_2 = SHX5_2()
  SHX6_2 = SHX0_2.callbacks
  SHX6_2[SHX5_2] = SHX4_2
  SHX7_2 = SHX0_2
  SHX6_2 = SHX0_2.send
  SHX8_2 = "requestHttp"
  SHX9_2 = {}
  SHX9_2.url = SHX1_2
  SHX9_2.body = SHX2_2
  SHX9_2.method = SHX3_2
  SHX9_2.id = SHX5_2
  SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  if SHX4_2 then
    SHX6_2 = SHX5_1
    SHX7_2 = SHX4_2
    return SHX6_2(SHX7_2)
  end
  SHX6_2 = nil
  return SHX6_2
end
SHX17_1.httpRequest = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.callbacks
  return SHX1_2
end
SHX17_1.getActiveRecordingCallbacks = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2
  SHX2_2 = SHX0_2.callbacks
  SHX2_2[SHX1_2] = nil
end
SHX17_1.deleteCallback = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  SHX0_2.activeRecording = SHX1_2
end
SHX17_1.setRecording = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  SHX0_2.activeScreenshot = SHX1_2
end
SHX17_1.setScreenshotState = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  SHX0_2.activeOCR = SHX1_2
end
SHX17_1.setActiveOCRState = SHX18_1
SHX17_1 = NUI
SHX18_1 = SHX17_1
SHX17_1 = SHX17_1.on
SHX19_1 = "request"
function SHX20_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2
  SHX2_2 = SHX1_2
  SHX3_2 = true
  SHX2_2(SHX3_2)
  SHX2_2 = pairs
  SHX3_2 = SHX13_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.getActiveRecordingCallbacks
  SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2 = SHX3_2(SHX4_2)
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX8_2 = SHX0_2.id
    if SHX6_2 == SHX8_2 then
      SHX8_2 = pairs
      SHX9_2 = SHX7_2
      SHX8_2, SHX9_2, SHX10_2, SHX11_2 = SHX8_2(SHX9_2)
      for SHX12_2, SHX13_2 in SHX8_2, SHX9_2, SHX10_2, SHX11_2 do
        SHX14_2 = SHX13_2.type
        if "videoUploaded" == SHX14_2 then
          SHX15_2 = SHX13_2
          SHX14_2 = SHX13_2.resolve
          SHX16_2 = SHX0_2.url
          SHX14_2(SHX15_2, SHX16_2)
          SHX14_2 = SHX13_1
          SHX15_2 = SHX14_2
          SHX14_2 = SHX14_2.setRecording
          SHX16_2 = nil
          SHX14_2(SHX15_2, SHX16_2)
        else
          SHX14_2 = SHX13_2.type
          if "screenshot" == SHX14_2 then
            SHX15_2 = SHX13_2
            SHX14_2 = SHX13_2.resolve
            SHX16_2 = SHX0_2.result
            SHX14_2(SHX15_2, SHX16_2)
            SHX14_2 = SHX13_1
            SHX15_2 = SHX14_2
            SHX14_2 = SHX14_2.setScreenshotState
            SHX16_2 = nil
            SHX14_2(SHX15_2, SHX16_2)
          else
            SHX14_2 = SHX13_2.type
            if "ocr_text" == SHX14_2 then
              SHX15_2 = SHX13_2
              SHX14_2 = SHX13_2.resolve
              SHX16_2 = SHX0_2.result
              SHX14_2(SHX15_2, SHX16_2)
              SHX14_2 = SHX13_1
              SHX15_2 = SHX14_2
              SHX14_2 = SHX14_2.setActiveOCRState
              SHX16_2 = nil
              SHX14_2(SHX15_2, SHX16_2)
            end
          end
        end
      end
      SHX8_2 = SHX13_1
      SHX9_2 = SHX8_2
      SHX8_2 = SHX8_2.deleteCallback
      SHX10_2 = SHX6_2
      SHX8_2(SHX9_2, SHX10_2)
    end
  end
end
SHX17_1(SHX18_1, SHX19_1, SHX20_1)
SHX17_1 = NUI
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX1_2 = SHX14_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "attempting to get text from the players screen"
  SHX4_2 = "debug"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = SHX3_1
  SHX1_2 = SHX1_2()
  SHX2_2 = SHX4_1
  SHX2_2 = SHX2_2()
  SHX1_2.type = "ocr_text"
  SHX3_2 = SHX0_2.activeOCR
  if SHX3_2 then
    SHX3_2 = table
    SHX3_2 = SHX3_2.insert
    SHX4_2 = SHX0_2.callbacks
    SHX5_2 = SHX0_2.activeOCR
    SHX4_2 = SHX4_2[SHX5_2]
    SHX5_2 = SHX1_2
    SHX3_2(SHX4_2, SHX5_2)
  else
    SHX3_2 = SHX0_2.callbacks
    SHX4_2 = {}
    SHX5_2 = SHX1_2
    SHX4_2[1] = SHX5_2
    SHX3_2[SHX2_2] = SHX4_2
    SHX0_2.activeOCR = SHX2_2
    SHX3_2 = SHX8_1
    SHX4_2 = SHX0_2.dui
    SHX5_2 = SHX10_1
    SHX6_2 = {}
    SHX6_2.command = "GET_OCR_TEXT"
    SHX6_2.id = SHX2_2
    SHX5_2, SHX6_2 = SHX5_2(SHX6_2)
    SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  end
  SHX3_2 = SHX5_1
  SHX4_2 = SHX1_2
  return SHX3_2(SHX4_2)
end
SHX17_1.getOCRText = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX1_2 = SHX14_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "attempting to screenshot players screen"
  SHX4_2 = "debug"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = SHX3_1
  SHX1_2 = SHX1_2()
  SHX2_2 = SHX4_1
  SHX2_2 = SHX2_2()
  SHX1_2.type = "screenshot"
  SHX3_2 = SHX0_2.activeScreenshot
  if SHX3_2 then
    SHX3_2 = table
    SHX3_2 = SHX3_2.insert
    SHX4_2 = SHX0_2.callbacks
    SHX5_2 = SHX0_2.activeScreenshot
    SHX4_2 = SHX4_2[SHX5_2]
    SHX5_2 = SHX1_2
    SHX3_2(SHX4_2, SHX5_2)
  else
    SHX3_2 = SHX0_2.callbacks
    SHX4_2 = {}
    SHX5_2 = SHX1_2
    SHX4_2[1] = SHX5_2
    SHX3_2[SHX2_2] = SHX4_2
    SHX0_2.activeScreenshot = SHX2_2
    SHX3_2 = SHX8_1
    SHX4_2 = SHX0_2.dui
    SHX5_2 = SHX10_1
    SHX6_2 = {}
    SHX6_2.command = "SCREENSHOT"
    SHX6_2.id = SHX2_2
    SHX5_2, SHX6_2 = SHX5_2(SHX6_2)
    SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  end
  SHX3_2 = SHX5_1
  SHX4_2 = SHX1_2
  return SHX3_2(SHX4_2)
end
SHX17_1.screenshot = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX1_2 = SHX14_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.log
  SHX3_2 = "attempting to clip players screen"
  SHX4_2 = "debug"
  SHX1_2(SHX2_2, SHX3_2, SHX4_2)
  SHX1_2 = SHX15_1
  SHX2_2 = SHX1_2
  SHX1_2 = SHX1_2.get
  SHX3_2 = "config"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX2_2 = tostring
  SHX3_2 = SHX16_1
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.hash
  SHX5_2 = "ScreenRecord"
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  SHX1_2 = SHX1_2[SHX2_2]
  if false == SHX1_2 then
    SHX1_2 = "SCREEN_RECORDINGS_DISABLED"
    return SHX1_2
  end
  SHX1_2 = SHX3_1
  SHX1_2 = SHX1_2()
  SHX2_2 = SHX4_1
  SHX2_2 = SHX2_2()
  SHX3_2 = math
  SHX3_2 = SHX3_2.random
  SHX4_2 = 1
  SHX5_2 = 999999
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX2_2 = SHX2_2 + SHX3_2
  SHX1_2.type = "videoUploaded"
  SHX3_2 = SHX0_2.activeRecording
  if SHX3_2 then
    SHX3_2 = table
    SHX3_2 = SHX3_2.insert
    SHX4_2 = SHX0_2.callbacks
    SHX5_2 = SHX0_2.activeRecording
    SHX4_2 = SHX4_2[SHX5_2]
    SHX5_2 = SHX1_2
    SHX3_2(SHX4_2, SHX5_2)
  else
    SHX3_2 = SHX0_2.callbacks
    SHX4_2 = {}
    SHX5_2 = SHX1_2
    SHX4_2[1] = SHX5_2
    SHX3_2[SHX2_2] = SHX4_2
    SHX0_2.activeRecording = SHX2_2
    SHX3_2 = SHX8_1
    SHX4_2 = SHX0_2.dui
    SHX5_2 = SHX10_1
    SHX6_2 = {}
    SHX6_2.command = "LAST_GAMEPLAY"
    SHX6_2.id = SHX2_2
    SHX5_2, SHX6_2 = SHX5_2(SHX6_2)
    SHX3_2(SHX4_2, SHX5_2, SHX6_2)
  end
  SHX3_2 = SHX5_1
  SHX4_2 = SHX1_2
  return SHX3_2(SHX4_2)
end
SHX17_1.clipScreen = SHX18_1
SHX17_1 = NUI
function SHX18_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX3_2 = SHX8_1
  SHX4_2 = SHX0_2.dui
  SHX5_2 = SHX10_1
  SHX6_2 = {}
  SHX6_2.command = SHX1_2
  SHX6_2.id = SHX2_2
  SHX5_2, SHX6_2 = SHX5_2(SHX6_2)
  return SHX3_2(SHX4_2, SHX5_2, SHX6_2)
end
SHX17_1.ui_toolsEmit = SHX18_1
SHX17_1 = NUI
SHX18_1 = SHX17_1
SHX17_1 = SHX17_1.new
SHX17_1 = SHX17_1(SHX18_1)
NUI = SHX17_1
SHX13_1 = NUI
SHX17_1 = CreateThread
function SHX18_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX12_1
  SHX1_2 = 5000
  SHX0_2(SHX1_2)
  SHX0_2 = _G
  SHX0_2.NUI = nil
end
SHX17_1(SHX18_1)
