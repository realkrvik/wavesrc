-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1
SHX0_1 = GetConvar
SHX1_1 = GetConvarInt
SHX2_1 = print
SHX3_1 = class
SHX4_1 = "LoggerLoggerC"
SHX3_1 = SHX3_1(SHX4_1)
function SHX4_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = SHX1_1
  SHX2_2 = "reaper_log_level"
  SHX3_2 = 0
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX0_2.level = SHX1_2
  SHX1_2 = SHX0_1
  SHX2_2 = "sv_reaper_custom_build"
  SHX3_2 = "false"
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2)
  SHX1_2 = "true" == SHX1_2
  SHX0_2.custom_artifacts = SHX1_2
  SHX1_2 = {}
  SHX0_2.messages = SHX1_2
  SHX1_2 = RegisterCommand
  SHX2_2 = "reaperreloadloglevel"
  function SHX3_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3, SHX2_3
    SHX0_3 = SHX1_1
    SHX1_3 = "reaper_log_level"
    SHX2_3 = 0
    SHX0_3 = SHX0_3(SHX1_3, SHX2_3)
    SHX0_2.level = SHX0_3
  end
  SHX1_2(SHX2_2, SHX3_2)
end
SHX3_1.constructor = SHX4_1
function SHX4_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.custom_artifacts
  return SHX1_2
end
SHX3_1.customArtifacts = SHX4_1
function SHX4_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.messages
  return SHX1_2
end
SHX3_1.getLogs = SHX4_1
function SHX4_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
  SHX1_2 = SHX0_2.level
  return SHX1_2
end
SHX3_1.getLogLevel = SHX4_1
function SHX4_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2
  SHX4_2 = "debug" ~= SHX2_2
  if "info" == SHX2_2 then
    SHX5_2 = "[^2INFO^7] - "
    SHX6_2 = SHX1_2
    SHX5_2 = SHX5_2 .. SHX6_2
    SHX1_2 = SHX5_2
  elseif "debug" == SHX2_2 then
    SHX5_2 = "[^4DEBUG^7] - "
    SHX6_2 = SHX1_2
    SHX5_2 = SHX5_2 .. SHX6_2
    SHX1_2 = SHX5_2
  elseif "error" == SHX2_2 then
    SHX5_2 = "[^1ERROR^7] - "
    SHX6_2 = SHX1_2
    SHX5_2 = SHX5_2 .. SHX6_2
    SHX1_2 = SHX5_2
  elseif "severe" == SHX2_2 then
    SHX5_2 = "[^6SEVERE^7] - "
    SHX6_2 = SHX1_2
    SHX5_2 = SHX5_2 .. SHX6_2
    SHX1_2 = SHX5_2
  elseif "warn" == SHX2_2 then
    SHX5_2 = "[^3WARNING^7] - "
    SHX6_2 = SHX1_2
    SHX5_2 = SHX5_2 .. SHX6_2
    SHX1_2 = SHX5_2
  end
  if SHX4_2 then
    SHX5_2 = SHX0_2.level
    if -1 ~= SHX5_2 then
      SHX5_2 = SHX2_1
      SHX6_2 = "[^3REAPER^7] %s"
      SHX7_2 = SHX6_2
      SHX6_2 = SHX6_2.format
      SHX8_2 = SHX1_2
      SHX6_2, SHX7_2, SHX8_2 = SHX6_2(SHX7_2, SHX8_2)
      SHX5_2(SHX6_2, SHX7_2, SHX8_2)
    end
  end
  if SHX3_2 then
    SHX5_2 = table
    SHX5_2 = SHX5_2.insert
    SHX6_2 = SHX0_2.messages
    SHX7_2 = SHX1_2
    SHX5_2(SHX6_2, SHX7_2)
  end
end
SHX3_1.log = SHX4_1
SHX5_1 = SHX3_1
SHX4_1 = SHX3_1.new
SHX4_1 = SHX4_1(SHX5_1)
Logger = SHX4_1
SHX4_1 = Logger
SHX5_1 = exports
SHX6_1 = "InvokeCLogger"
function SHX7_1(SHX0_2, ...)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = type
  SHX2_2 = SHX0_2
  SHX1_2 = SHX1_2(SHX2_2)
  if "string" == SHX1_2 then
    SHX1_2 = SHX4_1
    SHX1_2 = SHX1_2[SHX0_2]
    if nil ~= SHX1_2 then
      goto SHX_LABEL_13
    end
  end
  SHX1_2 = "INVALID_METHOD"
  return SHX1_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_13:: outside nested blocks until all 'goto SHX_LABEL_13' can see it
  ::SHX_LABEL_13::
  SHX1_2 = SHX4_1
  SHX1_2 = SHX1_2[SHX0_2]
  SHX2_2 = SHX4_1
  SHX3_2 = ...
  return SHX1_2(SHX2_2, SHX3_2)
end
SHX5_1(SHX6_1, SHX7_1)
SHX5_1 = CreateThread
function SHX6_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = Wait
  SHX1_2 = 5000
  SHX0_2(SHX1_2)
  SHX0_2 = _G
  SHX0_2.Logger = nil
end
SHX5_1(SHX6_1)
