-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1
SHX0_1 = GetPlayerServerId
SHX1_1 = PlayerId
SHX2_1 = msgpack
SHX2_1 = SHX2_1.pack
SHX3_1 = SetStateBagValue
function SHX4_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX3_2 = "player:%s"
  SHX4_2 = SHX3_2
  SHX3_2 = SHX3_2.format
  SHX5_2 = SHX0_1
  SHX6_2 = SHX1_1
  SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX6_2()
  SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  SHX4_2 = SHX2_1
  SHX5_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2)
  SHX5_2 = SHX3_1
  SHX6_2 = SHX3_2
  SHX7_2 = SHX0_2
  SHX8_2 = SHX4_2
  SHX10_2 = SHX4_2
  SHX9_2 = SHX4_2.len
  SHX9_2 = SHX9_2(SHX10_2)
  SHX10_2 = SHX2_2
  return SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
end
SetLocalStateValue = SHX4_1
function SHX4_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX0_2 = {}
  SHX1_2 = GetGamePool
  SHX2_2 = "CVehicle"
  SHX1_2 = SHX1_2(SHX2_2)
  SHX2_2 = GetGamePool
  SHX3_2 = "CNetObject"
  SHX2_2 = SHX2_2(SHX3_2)
  SHX3_2 = GetGamePool
  SHX4_2 = "CPed"
  SHX3_2 = SHX3_2(SHX4_2)
  SHX4_2 = table
  SHX4_2 = SHX4_2.concat_tab
  SHX5_2 = SHX1_2
  SHX6_2 = SHX2_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX0_2 = SHX4_2
  SHX4_2 = table
  SHX4_2 = SHX4_2.concat_tab
  SHX5_2 = SHX0_2
  SHX6_2 = SHX3_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX0_2 = SHX4_2
  return SHX0_2
end
GetAllEntities = SHX4_1
