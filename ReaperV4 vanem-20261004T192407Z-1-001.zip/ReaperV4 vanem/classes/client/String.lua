-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1
SHX0_1 = string
SHX0_1 = SHX0_1.sub
SHX1_1 = string
SHX1_1 = SHX1_1.gmatch
SHX2_1 = table
SHX2_1 = SHX2_1.insert
SHX3_1 = string
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX2_2 = SHX0_1
  SHX3_2 = SHX0_2
  SHX4_2 = 1
  SHX5_2 = string
  SHX5_2 = SHX5_2.len
  SHX6_2 = SHX1_2
  SHX5_2, SHX6_2 = SHX5_2(SHX6_2)
  SHX2_2 = SHX2_2(SHX3_2, SHX4_2, SHX5_2, SHX6_2)
  SHX2_2 = SHX2_2 == SHX1_2
  return SHX2_2
end
SHX3_1.starts = SHX4_1
SHX3_1 = string
function SHX4_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  if nil == SHX1_2 then
    SHX1_2 = "%s"
  end
  SHX2_2 = {}
  SHX3_2 = SHX1_1
  SHX4_2 = SHX0_2
  SHX5_2 = "([^"
  SHX6_2 = SHX1_2
  SHX7_2 = "]+)"
  SHX5_2 = SHX5_2 .. SHX6_2 .. SHX7_2
  SHX3_2, SHX4_2, SHX5_2, SHX6_2 = SHX3_2(SHX4_2, SHX5_2)
  for SHX7_2 in SHX3_2, SHX4_2, SHX5_2, SHX6_2 do
    SHX8_2 = SHX2_1
    SHX9_2 = SHX2_2
    SHX10_2 = SHX7_2
    SHX8_2(SHX9_2, SHX10_2)
  end
  return SHX2_2
end
SHX3_1.split = SHX4_1
