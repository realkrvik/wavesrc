-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1
SHX0_1 = class
SHX1_1 = "bit32"
SHX0_1 = SHX0_1(SHX1_1)
function SHX1_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2
end
SHX0_1.constructor = SHX1_1
function SHX1_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2
  SHX1_2 = SHX1_2 % 4.294967296E9
  SHX2_2 = 4.294967295E9
  SHX2_2 = SHX2_2 - SHX1_2
  return SHX2_2
end
SHX0_1.bnot = SHX1_1
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  if 255 == SHX2_2 then
    SHX3_2 = SHX1_2 % 256
    return SHX3_2
  end
  if 65535 == SHX2_2 then
    SHX3_2 = SHX1_2 % 65536
    return SHX3_2
  end
  if 4294967295 == SHX2_2 then
    SHX3_2 = SHX1_2 % 4294967296
    return SHX3_2
  end
  SHX3_2 = SHX1_2 % 4.294967296E9
  SHX2_2 = SHX2_2 % 4.294967296E9
  SHX1_2 = SHX3_2
  SHX3_2 = 0
  SHX4_2 = 1
  SHX5_2 = 1
  SHX6_2 = 32
  SHX7_2 = 1
  for SHX8_2 = SHX5_2, SHX6_2, SHX7_2 do
    SHX9_2 = SHX1_2 % 2
    SHX10_2 = SHX2_2 % 2
    SHX11_2 = math
    SHX11_2 = SHX11_2.floor
    SHX12_2 = SHX1_2 / 2
    SHX11_2 = SHX11_2(SHX12_2)
    SHX12_2 = math
    SHX12_2 = SHX12_2.floor
    SHX13_2 = SHX2_2 / 2
    SHX12_2 = SHX12_2(SHX13_2)
    SHX2_2 = SHX12_2
    SHX1_2 = SHX11_2
    SHX11_2 = SHX9_2 + SHX10_2
    if 2 == SHX11_2 then
      SHX3_2 = SHX3_2 + SHX4_2
    end
    SHX4_2 = 2 * SHX4_2
  end
  return SHX3_2
end
SHX0_1.band = SHX1_1
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  if 255 == SHX2_2 then
    SHX3_2 = SHX1_2 % 256
    SHX3_2 = SHX1_2 - SHX3_2
    SHX3_2 = SHX3_2 + 255
    return SHX3_2
  end
  if 65535 == SHX2_2 then
    SHX3_2 = SHX1_2 % 65536
    SHX3_2 = SHX1_2 - SHX3_2
    SHX3_2 = SHX3_2 + 65535
    return SHX3_2
  end
  if 4294967295 == SHX2_2 then
    SHX3_2 = 4294967295
    return SHX3_2
  end
  SHX3_2 = SHX1_2 % 4.294967296E9
  SHX2_2 = SHX2_2 % 4.294967296E9
  SHX1_2 = SHX3_2
  SHX3_2 = 0
  SHX4_2 = 1
  SHX5_2 = 1
  SHX6_2 = 32
  SHX7_2 = 1
  for SHX8_2 = SHX5_2, SHX6_2, SHX7_2 do
    SHX9_2 = SHX1_2 % 2
    SHX10_2 = SHX2_2 % 2
    SHX11_2 = math
    SHX11_2 = SHX11_2.floor
    SHX12_2 = SHX1_2 / 2
    SHX11_2 = SHX11_2(SHX12_2)
    SHX12_2 = math
    SHX12_2 = SHX12_2.floor
    SHX13_2 = SHX2_2 / 2
    SHX12_2 = SHX12_2(SHX13_2)
    SHX2_2 = SHX12_2
    SHX1_2 = SHX11_2
    SHX11_2 = SHX9_2 + SHX10_2
    if SHX11_2 >= 1 then
      SHX3_2 = SHX3_2 + SHX4_2
    end
    SHX4_2 = 2 * SHX4_2
  end
  return SHX3_2
end
SHX0_1.bor = SHX1_1
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2
  SHX3_2 = math
  SHX3_2 = SHX3_2.abs
  SHX4_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2)
  if SHX3_2 >= 32 then
    SHX3_2 = 0
    return SHX3_2
  end
  SHX1_2 = SHX1_2 % 4.294967296E9
  if SHX2_2 < 0 then
    SHX3_2 = math
    SHX3_2 = SHX3_2.floor
    SHX4_2 = 2
    SHX4_2 = SHX4_2 ^ SHX2_2
    SHX4_2 = SHX1_2 * SHX4_2
    return SHX3_2(SHX4_2)
  else
    SHX3_2 = 2
    SHX3_2 = SHX3_2 ^ SHX2_2
    SHX3_2 = SHX1_2 * SHX3_2
    SHX3_2 = SHX3_2 % 4.294967296E9
    return SHX3_2
  end
end
SHX0_1.lshift = SHX1_1
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2
  SHX3_2 = math
  SHX3_2 = SHX3_2.abs
  SHX4_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2)
  if SHX3_2 >= 32 then
    SHX3_2 = 0
    return SHX3_2
  end
  SHX1_2 = SHX1_2 % 4.294967296E9
  if SHX2_2 > 0 then
    SHX3_2 = math
    SHX3_2 = SHX3_2.floor
    SHX4_2 = -SHX2_2
    SHX5_2 = 2
    SHX4_2 = SHX5_2 ^ SHX4_2
    SHX4_2 = SHX1_2 * SHX4_2
    return SHX3_2(SHX4_2)
  else
    SHX3_2 = -SHX2_2
    SHX4_2 = 2
    SHX3_2 = SHX4_2 ^ SHX3_2
    SHX3_2 = SHX1_2 * SHX3_2
    SHX3_2 = SHX3_2 % 4.294967296E9
    return SHX3_2
  end
end
SHX0_1.rshift = SHX1_1
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2
  SHX3_2 = math
  SHX3_2 = SHX3_2.abs
  SHX4_2 = SHX2_2
  SHX3_2 = SHX3_2(SHX4_2)
  if SHX3_2 >= 32 then
    SHX3_2 = 0
    return SHX3_2
  end
  SHX1_2 = SHX1_2 % 4.294967296E9
  if SHX2_2 > 0 then
    SHX3_2 = 0
    SHX4_2 = 2.147483648E9
    if SHX1_2 >= SHX4_2 then
      SHX4_2 = 32
      SHX4_2 = SHX4_2 - SHX2_2
      SHX5_2 = 2
      SHX4_2 = SHX5_2 ^ SHX4_2
      SHX5_2 = 4.294967296E9
      SHX3_2 = SHX5_2 - SHX4_2
    end
    SHX4_2 = math
    SHX4_2 = SHX4_2.floor
    SHX5_2 = -SHX2_2
    SHX6_2 = 2
    SHX5_2 = SHX6_2 ^ SHX5_2
    SHX5_2 = SHX1_2 * SHX5_2
    SHX4_2 = SHX4_2(SHX5_2)
    SHX4_2 = SHX4_2 + SHX3_2
    return SHX4_2
  else
    SHX3_2 = -SHX2_2
    SHX4_2 = 2
    SHX3_2 = SHX4_2 ^ SHX3_2
    SHX3_2 = SHX1_2 * SHX3_2
    SHX3_2 = SHX3_2 % 4.294967296E9
    return SHX3_2
  end
end
SHX0_1.arshift = SHX1_1
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2
  SHX3_2 = SHX1_2 % 4.294967296E9
  SHX2_2 = SHX2_2 % 4.294967296E9
  SHX1_2 = SHX3_2
  SHX3_2 = 0
  SHX4_2 = 1
  SHX5_2 = 1
  SHX6_2 = 32
  SHX7_2 = 1
  for SHX8_2 = SHX5_2, SHX6_2, SHX7_2 do
    SHX9_2 = SHX1_2 % 2
    SHX10_2 = SHX2_2 % 2
    SHX11_2 = math
    SHX11_2 = SHX11_2.floor
    SHX12_2 = SHX1_2 / 2
    SHX11_2 = SHX11_2(SHX12_2)
    SHX12_2 = math
    SHX12_2 = SHX12_2.floor
    SHX13_2 = SHX2_2 / 2
    SHX12_2 = SHX12_2(SHX13_2)
    SHX2_2 = SHX12_2
    SHX1_2 = SHX11_2
    SHX11_2 = SHX9_2 + SHX10_2
    if 1 == SHX11_2 then
      SHX3_2 = SHX3_2 + SHX4_2
    end
    SHX4_2 = 2 * SHX4_2
  end
  return SHX3_2
end
SHX0_1.bxor = SHX1_1
SHX2_1 = SHX0_1
SHX1_1 = SHX0_1.new
SHX1_1 = SHX1_1(SHX2_1)
bit32 = SHX1_1
