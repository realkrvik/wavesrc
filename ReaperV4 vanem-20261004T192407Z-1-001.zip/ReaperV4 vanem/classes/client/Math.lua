-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1
SHX0_1 = math
function SHX1_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2
  SHX3_2 = type
  SHX4_2 = SHX0_2
  SHX3_2 = SHX3_2(SHX4_2)
  if "number" == SHX3_2 then
    SHX3_2 = type
    SHX4_2 = SHX1_2
    SHX3_2 = SHX3_2(SHX4_2)
    if "number" == SHX3_2 then
      SHX3_2 = type
      SHX4_2 = SHX2_2
      SHX3_2 = SHX3_2(SHX4_2)
      if not ("number" ~= SHX3_2 or SHX2_2 < SHX1_2) then
        goto SHX_LABEL_20
      end
    end
  end
  SHX3_2 = nil
  return SHX3_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_20:: outside nested blocks until all 'goto SHX_LABEL_20' can see it
  ::SHX_LABEL_20::
  if SHX0_2 < SHX1_2 then
    return SHX1_2
  elseif SHX2_2 < SHX0_2 then
    return SHX2_2
  else
    return SHX0_2
  end
end
SHX0_1.clamp = SHX1_1
