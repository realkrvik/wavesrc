-- [AI CLEANUP] Decompiled Lua - Fix these:
-- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
-- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
-- 3. Replace goto/label with while/repeat-until where possible
-- 4. Remove decompiler comments, add meaningful ones
-- 5. Fix indentation and formatting

local SHX0_1, SHX1_1, SHX2_1, SHX3_1, SHX4_1, SHX5_1, SHX6_1, SHX7_1, SHX8_1, SHX9_1, SHX10_1, SHX11_1, SHX12_1, SHX13_1, SHX14_1, SHX15_1
SHX0_1 = class
SHX1_1 = "NativeRulesClient"
SHX0_1 = SHX0_1(SHX1_1)
SHX1_1 = Logger
SHX2_1 = nil
SHX3_1 = GetConvar
SHX4_1 = table
SHX4_1 = SHX4_1.insert
SHX5_1 = json
SHX5_1 = SHX5_1.decode
SHX6_1 = CreateThread
SHX7_1 = type
SHX8_1 = AddConvarChangeListener
SHX9_1 = Wait
SHX10_1 = tostring
SHX11_1 = tonumber
SHX12_1 = string
SHX12_1 = SHX12_1.gmatch
SHX13_1 = SHX7_1
SHX14_1 = SHX6_1
function SHX15_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  while true do
    SHX0_2 = _G
    SHX0_2 = SHX0_2.RPC
    if nil ~= SHX0_2 then
      break
    end
    SHX0_2 = SHX9_1
    SHX1_2 = 20
    SHX0_2(SHX1_2)
  end
  SHX0_2 = _G
  SHX0_2 = SHX0_2.RPC
  SHX2_1 = SHX0_2
end
SHX14_1(SHX15_1)
function SHX14_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2
  SHX1_2 = {}
  SHX0_2.rules = SHX1_2
  SHX1_2 = {}
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = SHX10_1
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX10_1
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX2_3 = SHX2_3 == SHX3_3
    return SHX2_3
  end
  SHX1_2.eq = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = SHX10_1
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX10_1
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX2_3 = SHX2_3 ~= SHX3_3
    return SHX2_3
  end
  SHX1_2.neq = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = SHX11_1
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX11_1
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    if nil == SHX2_3 or nil == SHX3_3 then
      SHX4_3 = false
      return SHX4_3
    end
    SHX4_3 = SHX2_3 > SHX3_3
    return SHX4_3
  end
  SHX1_2.gt = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = SHX11_1
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX11_1
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    if nil == SHX2_3 or nil == SHX3_3 then
      SHX4_3 = false
      return SHX4_3
    end
    SHX4_3 = SHX2_3 < SHX3_3
    return SHX4_3
  end
  SHX1_2.lt = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = SHX11_1
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX11_1
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    if nil == SHX2_3 or nil == SHX3_3 then
      SHX4_3 = false
      return SHX4_3
    end
    SHX4_3 = SHX2_3 >= SHX3_3
    return SHX4_3
  end
  SHX1_2.gte = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3
    SHX2_3 = SHX11_1
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX11_1
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    if nil == SHX2_3 or nil == SHX3_3 then
      SHX4_3 = false
      return SHX4_3
    end
    SHX4_3 = SHX2_3 <= SHX3_3
    return SHX4_3
  end
  SHX1_2.lte = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3
    SHX2_3 = SHX10_1
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX10_1
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.find
    SHX6_3 = SHX3_3
    SHX7_3 = 1
    SHX8_3 = true
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
    SHX4_3 = nil ~= SHX4_3
    return SHX4_3
  end
  SHX1_2.contains = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3
    SHX2_3 = SHX10_1
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX10_1
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.find
    SHX6_3 = SHX3_3
    SHX7_3 = 1
    SHX8_3 = true
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3, SHX8_3)
    SHX4_3 = nil == SHX4_3
    return SHX4_3
  end
  SHX1_2.notContains = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3
    SHX2_3 = SHX10_1
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX10_1
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.sub
    SHX6_3 = 1
    SHX7_3 = #SHX3_3
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3, SHX7_3)
    SHX4_3 = SHX4_3 == SHX3_3
    return SHX4_3
  end
  SHX1_2.startsWith = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = SHX10_1
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX10_1
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.sub
    SHX6_3 = #SHX3_3
    SHX6_3 = -SHX6_3
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX4_3 = SHX4_3 == SHX3_3
    return SHX4_3
  end
  SHX1_2.endsWith = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = SHX10_1
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX10_1
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.match
    SHX6_3 = SHX3_3
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX4_3 = nil ~= SHX4_3
    return SHX4_3
  end
  SHX1_2.regex = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3
    SHX2_3 = SHX10_1
    SHX3_3 = SHX0_3
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX2_3
    SHX2_3 = SHX2_3.lower
    SHX2_3 = SHX2_3(SHX3_3)
    SHX3_3 = SHX10_1
    SHX4_3 = SHX1_3
    SHX3_3 = SHX3_3(SHX4_3)
    SHX4_3 = SHX3_3
    SHX3_3 = SHX3_3.lower
    SHX3_3 = SHX3_3(SHX4_3)
    SHX5_3 = SHX2_3
    SHX4_3 = SHX2_3.match
    SHX6_3 = SHX3_3
    SHX4_3 = SHX4_3(SHX5_3, SHX6_3)
    SHX4_3 = nil == SHX4_3
    return SHX4_3
  end
  SHX1_2.notRegex = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX2_3 = SHX13_1
    SHX3_3 = SHX1_3
    SHX2_3 = SHX2_3(SHX3_3)
    if "table" ~= SHX2_3 then
      SHX2_3 = false
      return SHX2_3
    end
    SHX2_3 = pairs
    SHX3_3 = SHX1_3
    SHX2_3, SHX3_3, SHX4_3, SHX5_3 = SHX2_3(SHX3_3)
    for SHX6_3, SHX7_3 in SHX2_3, SHX3_3, SHX4_3, SHX5_3 do
      SHX8_3 = SHX10_1
      SHX9_3 = SHX0_3
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = SHX8_3
      SHX8_3 = SHX8_3.lower
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = SHX10_1
      SHX10_3 = SHX7_3
      SHX9_3 = SHX9_3(SHX10_3)
      SHX10_3 = SHX9_3
      SHX9_3 = SHX9_3.lower
      SHX9_3 = SHX9_3(SHX10_3)
      if SHX8_3 == SHX9_3 then
        SHX8_3 = true
        return SHX8_3
      end
    end
    SHX2_3 = false
    return SHX2_3
  end
  SHX1_2["in"] = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3, SHX3_3, SHX4_3, SHX5_3, SHX6_3, SHX7_3, SHX8_3, SHX9_3, SHX10_3
    SHX2_3 = SHX13_1
    SHX3_3 = SHX1_3
    SHX2_3 = SHX2_3(SHX3_3)
    if "table" ~= SHX2_3 then
      SHX2_3 = true
      return SHX2_3
    end
    SHX2_3 = pairs
    SHX3_3 = SHX1_3
    SHX2_3, SHX3_3, SHX4_3, SHX5_3 = SHX2_3(SHX3_3)
    for SHX6_3, SHX7_3 in SHX2_3, SHX3_3, SHX4_3, SHX5_3 do
      SHX8_3 = SHX10_1
      SHX9_3 = SHX0_3
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = SHX8_3
      SHX8_3 = SHX8_3.lower
      SHX8_3 = SHX8_3(SHX9_3)
      SHX9_3 = SHX10_1
      SHX10_3 = SHX7_3
      SHX9_3 = SHX9_3(SHX10_3)
      SHX10_3 = SHX9_3
      SHX9_3 = SHX9_3.lower
      SHX9_3 = SHX9_3(SHX10_3)
      if SHX8_3 == SHX9_3 then
        SHX8_3 = false
        return SHX8_3
      end
    end
    SHX2_3 = true
    return SHX2_3
  end
  SHX1_2.notIn = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3
    SHX2_3 = nil ~= SHX0_3
    return SHX2_3
  end
  SHX1_2.exists = SHX2_2
  function SHX2_2(SHX0_3, SHX1_3)
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX2_3
    SHX2_3 = nil == SHX0_3
    return SHX2_3
  end
  SHX1_2.notExists = SHX2_2
  SHX0_2.operators = SHX1_2
  SHX2_2 = SHX0_2
  SHX1_2 = SHX0_2.build_natives
  SHX1_2(SHX2_2)
  SHX1_2 = SHX8_1
  SHX2_2 = "reaper_native_rules"
  function SHX3_2()
    -- [AI CLEANUP] Decompiled Lua - Fix these:
    -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
    -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
    -- 3. Replace goto/label with while/repeat-until where possible
    -- 4. Remove decompiler comments, add meaningful ones
    -- 5. Fix indentation and formatting
    
    local SHX0_3, SHX1_3
    SHX0_3 = SHX0_2
    SHX1_3 = SHX0_3
    SHX0_3 = SHX0_3.build_natives
    SHX0_3(SHX1_3)
  end
  SHX1_2(SHX2_2, SHX3_2)
end
SHX0_1.constructor = SHX14_1
function SHX14_1(SHX0_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX1_2, SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX1_2 = {}
  SHX0_2.rules = SHX1_2
  SHX1_2 = SHX5_1
  SHX2_2 = SHX3_1
  SHX3_2 = "reaper_native_rules"
  SHX4_2 = "{}"
  SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX2_2(SHX3_2, SHX4_2)
  SHX1_2 = SHX1_2(SHX2_2, SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2)
  SHX2_2 = pairs
  SHX3_2 = SHX1_2
  SHX2_2, SHX3_2, SHX4_2, SHX5_2 = SHX2_2(SHX3_2)
  for SHX6_2, SHX7_2 in SHX2_2, SHX3_2, SHX4_2, SHX5_2 do
    SHX8_2 = SHX0_2.rules
    SHX9_2 = SHX7_2.native
    SHX8_2 = SHX8_2[SHX9_2]
    if nil == SHX8_2 then
      SHX8_2 = SHX0_2.rules
      SHX9_2 = SHX7_2.native
      SHX10_2 = {}
      SHX8_2[SHX9_2] = SHX10_2
    end
    SHX8_2 = SHX4_1
    SHX9_2 = SHX0_2.rules
    SHX10_2 = SHX7_2.native
    SHX9_2 = SHX9_2[SHX10_2]
    SHX10_2 = SHX7_2
    SHX8_2(SHX9_2, SHX10_2)
  end
end
SHX0_1.build_natives = SHX14_1
function SHX14_1(SHX0_2, SHX1_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX2_2
  SHX2_2 = SHX0_2.rules
  SHX2_2 = SHX2_2[SHX1_2]
  return SHX2_2
end
SHX0_1.getNativeRules = SHX14_1
function SHX14_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2
  SHX3_2 = SHX1_2
  SHX4_2 = SHX12_1
  SHX5_2 = SHX2_2
  SHX6_2 = "[^.]+"
  SHX4_2, SHX5_2, SHX6_2, SHX7_2 = SHX4_2(SHX5_2, SHX6_2)
  for SHX8_2 in SHX4_2, SHX5_2, SHX6_2, SHX7_2 do
    SHX9_2 = SHX13_1
    SHX10_2 = SHX3_2
    SHX9_2 = SHX9_2(SHX10_2)
    if "table" ~= SHX9_2 then
      SHX9_2 = nil
      return SHX9_2
    end
    SHX9_2 = SHX11_1
    SHX10_2 = SHX8_2
    SHX9_2 = SHX9_2(SHX10_2)
    if SHX9_2 then
      SHX3_2 = SHX3_2[SHX9_2]
    else
      SHX3_2 = SHX3_2[SHX8_2]
    end
  end
  return SHX3_2
end
SHX0_1.getFieldValue = SHX14_1
function SHX14_1(SHX0_2, SHX1_2, SHX2_2, SHX3_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2
  if not SHX3_2 then
    SHX3_2 = 0
  end
  SHX4_2 = string
  SHX4_2 = SHX4_2.rep
  SHX5_2 = "  "
  SHX6_2 = SHX3_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = SHX3_1
  SHX6_2 = "reaper_debug_native_rules"
  SHX7_2 = "false"
  SHX5_2 = SHX5_2(SHX6_2, SHX7_2)
  SHX5_2 = "true" == SHX5_2
  SHX6_2 = SHX1_2.rules
  if SHX6_2 then
    SHX6_2 = SHX13_1
    SHX7_2 = SHX1_2.rules
    SHX6_2 = SHX6_2(SHX7_2)
    if "table" == SHX6_2 then
      if SHX5_2 then
        SHX6_2 = print
        SHX7_2 = string
        SHX7_2 = SHX7_2.format
        SHX8_2 = "%s^3[Rule Group]^7 type=%s, subrules=%d"
        SHX9_2 = SHX4_2
        SHX10_2 = SHX1_2.type
        if not SHX10_2 then
          SHX10_2 = "none"
        end
        SHX11_2 = SHX1_2.rules
        SHX11_2 = #SHX11_2
        SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2)
        SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
      end
      SHX6_2 = SHX1_2.type
      if "and" == SHX6_2 then
        SHX6_2 = ipairs
        SHX7_2 = SHX1_2.rules
        SHX6_2, SHX7_2, SHX8_2, SHX9_2 = SHX6_2(SHX7_2)
        for SHX10_2, SHX11_2 in SHX6_2, SHX7_2, SHX8_2, SHX9_2 do
          if SHX5_2 then
            SHX12_2 = print
            SHX13_2 = string
            SHX13_2 = SHX13_2.format
            SHX14_2 = "%s^3[AND Rule %d/%d]^7"
            SHX15_2 = SHX4_2
            SHX16_2 = SHX10_2
            SHX17_2 = SHX1_2.rules
            SHX17_2 = #SHX17_2
            SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2)
            SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
          end
          SHX13_2 = SHX0_2
          SHX12_2 = SHX0_2.evaluateRule
          SHX14_2 = SHX11_2
          SHX15_2 = SHX2_2
          SHX16_2 = SHX3_2 + 1
          SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2)
          if not SHX12_2 then
            if SHX5_2 then
              SHX12_2 = print
              SHX13_2 = string
              SHX13_2 = SHX13_2.format
              SHX14_2 = "%s^1[AND Failed]^7 Rule %d returned false"
              SHX15_2 = SHX4_2
              SHX16_2 = SHX10_2
              SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2)
              SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
            end
            SHX12_2 = false
            return SHX12_2
          end
        end
        if SHX5_2 then
          SHX6_2 = print
          SHX7_2 = string
          SHX7_2 = SHX7_2.format
          SHX8_2 = "%s^2[AND Passed]^7 All rules matched"
          SHX9_2 = SHX4_2
          SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = SHX7_2(SHX8_2, SHX9_2)
          SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
        end
        SHX6_2 = true
        return SHX6_2
      else
        SHX6_2 = SHX1_2.type
        if "or" == SHX6_2 then
          SHX6_2 = ipairs
          SHX7_2 = SHX1_2.rules
          SHX6_2, SHX7_2, SHX8_2, SHX9_2 = SHX6_2(SHX7_2)
          for SHX10_2, SHX11_2 in SHX6_2, SHX7_2, SHX8_2, SHX9_2 do
            if SHX5_2 then
              SHX12_2 = print
              SHX13_2 = string
              SHX13_2 = SHX13_2.format
              SHX14_2 = "%s^3[OR Rule %d/%d]^7"
              SHX15_2 = SHX4_2
              SHX16_2 = SHX10_2
              SHX17_2 = SHX1_2.rules
              SHX17_2 = #SHX17_2
              SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2)
              SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
            end
            SHX13_2 = SHX0_2
            SHX12_2 = SHX0_2.evaluateRule
            SHX14_2 = SHX11_2
            SHX15_2 = SHX2_2
            SHX16_2 = SHX3_2 + 1
            SHX12_2 = SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2)
            if SHX12_2 then
              if SHX5_2 then
                SHX12_2 = print
                SHX13_2 = string
                SHX13_2 = SHX13_2.format
                SHX14_2 = "%s^2[OR Passed]^7 Rule %d matched"
                SHX15_2 = SHX4_2
                SHX16_2 = SHX10_2
                SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2)
                SHX12_2(SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
              end
              SHX12_2 = true
              return SHX12_2
            end
          end
          if SHX5_2 then
            SHX6_2 = print
            SHX7_2 = string
            SHX7_2 = SHX7_2.format
            SHX8_2 = "%s^1[OR Failed]^7 No rules matched"
            SHX9_2 = SHX4_2
            SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = SHX7_2(SHX8_2, SHX9_2)
            SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
          end
          SHX6_2 = false
          return SHX6_2
        end
      end
    end
  end
  SHX6_2 = SHX1_2.field
  if SHX6_2 then
    SHX6_2 = SHX1_2.op
    if SHX6_2 then
      goto SHX_LABEL_164
    end
  end
  if SHX5_2 then
    SHX6_2 = print
    SHX7_2 = string
    SHX7_2 = SHX7_2.format
    SHX8_2 = "%s^1[Invalid Rule]^7 Missing field or op"
    SHX9_2 = SHX4_2
    SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = SHX7_2(SHX8_2, SHX9_2)
    SHX6_2(SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
  end
  SHX6_2 = false
  return SHX6_2
  -- [FIX IF ERROR] Move ::SHX_LABEL_164:: outside nested blocks until all 'goto SHX_LABEL_164' can see it
  ::SHX_LABEL_164::
  SHX7_2 = SHX0_2
  SHX6_2 = SHX0_2.getFieldValue
  SHX8_2 = SHX2_2
  SHX9_2 = SHX1_2.field
  SHX6_2 = SHX6_2(SHX7_2, SHX8_2, SHX9_2)
  SHX7_2 = SHX0_2.operators
  SHX8_2 = SHX1_2.op
  SHX7_2 = SHX7_2[SHX8_2]
  if not SHX7_2 then
    SHX8_2 = error
    SHX9_2 = "Unknown operator: "
    SHX10_2 = SHX10_1
    SHX11_2 = SHX1_2.op
    SHX10_2 = SHX10_2(SHX11_2)
    SHX9_2 = SHX9_2 .. SHX10_2
    SHX8_2(SHX9_2)
  end
  SHX8_2 = SHX7_2
  SHX9_2 = SHX6_2
  SHX10_2 = SHX1_2.value
  SHX8_2 = SHX8_2(SHX9_2, SHX10_2)
  if SHX5_2 then
    SHX9_2 = print
    SHX10_2 = string
    SHX10_2 = SHX10_2.format
    SHX11_2 = "%s^3[Comparison]^7 field=%s op=%s value=%s actual=%s result=%s"
    SHX12_2 = SHX4_2
    SHX13_2 = SHX1_2.field
    SHX14_2 = SHX1_2.op
    SHX15_2 = SHX10_1
    SHX16_2 = SHX1_2.value
    SHX15_2 = SHX15_2(SHX16_2)
    SHX16_2 = SHX10_1
    SHX17_2 = SHX6_2
    SHX16_2 = SHX16_2(SHX17_2)
    if SHX8_2 then
      SHX17_2 = "^2PASS^7"
      if SHX17_2 then
        goto SHX_LABEL_205
      end
    end
    SHX17_2 = "^1FAIL^7"
    -- [FIX IF ERROR] Move ::SHX_LABEL_205:: outside nested blocks until all 'goto SHX_LABEL_205' can see it
    ::SHX_LABEL_205::
    SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
    SHX9_2(SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2)
  end
  return SHX8_2
end
SHX0_1.evaluateRule = SHX14_1
function SHX14_1(SHX0_2, SHX1_2, SHX2_2)
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX3_2, SHX4_2, SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2
  SHX3_2 = SHX3_1
  SHX4_2 = "reaper_debug_native_rules"
  SHX5_2 = "false"
  SHX3_2 = SHX3_2(SHX4_2, SHX5_2)
  SHX3_2 = "true" == SHX3_2
  if SHX3_2 then
    SHX4_2 = print
    SHX5_2 = string
    SHX5_2 = SHX5_2.format
    SHX6_2 = "^5============ Native Rule Evaluation ============^7"
    SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX5_2(SHX6_2)
    SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    SHX4_2 = print
    SHX5_2 = string
    SHX5_2 = SHX5_2.format
    SHX6_2 = "^3Native:^7 %s"
    SHX7_2 = SHX10_1
    SHX8_2 = SHX1_2
    SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX7_2(SHX8_2)
    SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    SHX4_2 = print
    SHX5_2 = string
    SHX5_2 = SHX5_2.format
    SHX6_2 = "^3Context:^7 %s"
    SHX7_2 = json
    SHX7_2 = SHX7_2.encode
    SHX8_2 = SHX2_2
    SHX9_2 = {}
    SHX9_2.indent = true
    SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX7_2(SHX8_2, SHX9_2)
    SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX5_2(SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    SHX4_2(SHX5_2, SHX6_2, SHX7_2, SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
  end
  SHX5_2 = SHX0_2
  SHX4_2 = SHX0_2.getNativeRules
  SHX6_2 = SHX1_2
  SHX4_2 = SHX4_2(SHX5_2, SHX6_2)
  SHX5_2 = false
  SHX6_2 = false
  if not SHX4_2 then
    if SHX3_2 then
      SHX7_2 = print
      SHX8_2 = string
      SHX8_2 = SHX8_2.format
      SHX9_2 = "^1[No Rules]^7 No rules configured for native: %s"
      SHX10_2 = SHX10_1
      SHX11_2 = SHX1_2
      SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX10_2(SHX11_2)
      SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
      SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
      SHX7_2 = print
      SHX8_2 = string
      SHX8_2 = SHX8_2.format
      SHX9_2 = "^3Available natives:^7 %s"
      SHX10_2 = json
      SHX10_2 = SHX10_2.encode
      SHX11_2 = table
      SHX11_2 = SHX11_2.map
      SHX12_2 = SHX0_2.rules
      function SHX13_2(SHX0_3, SHX1_3)
        -- [AI CLEANUP] Decompiled Lua - Fix these:
        -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
        -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
        -- 3. Replace goto/label with while/repeat-until where possible
        -- 4. Remove decompiler comments, add meaningful ones
        -- 5. Fix indentation and formatting
        
        return SHX1_3
      end
      SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX11_2(SHX12_2, SHX13_2)
      SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX10_2(SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
      SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
      SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    end
    SHX7_2 = SHX5_2
    SHX8_2 = SHX6_2
    return SHX7_2, SHX8_2
  end
  if SHX3_2 then
    SHX7_2 = print
    SHX8_2 = string
    SHX8_2 = SHX8_2.format
    SHX9_2 = "^2[Found Rules]^7 %d rule(s) configured for %s"
    SHX10_2 = #SHX4_2
    SHX11_2 = SHX10_1
    SHX12_2 = SHX1_2
    SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX11_2(SHX12_2)
    SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
  end
  SHX7_2 = pairs
  SHX8_2 = SHX4_2
  SHX7_2, SHX8_2, SHX9_2, SHX10_2 = SHX7_2(SHX8_2)
  for SHX11_2, SHX12_2 in SHX7_2, SHX8_2, SHX9_2, SHX10_2 do
    if SHX3_2 then
      SHX13_2 = print
      SHX14_2 = string
      SHX14_2 = SHX14_2.format
      SHX15_2 = "^3[Evaluating Rule %d/%d]^7 id=%s"
      SHX16_2 = SHX11_2
      SHX17_2 = #SHX4_2
      SHX18_2 = SHX10_1
      SHX19_2 = SHX12_2.id
      SHX18_2, SHX19_2 = SHX18_2(SHX19_2)
      SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX14_2(SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
      SHX13_2(SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    end
    SHX14_2 = SHX0_2
    SHX13_2 = SHX0_2.evaluateRule
    SHX15_2 = SHX12_2
    SHX16_2 = SHX2_2
    SHX13_2 = SHX13_2(SHX14_2, SHX15_2, SHX16_2)
    if SHX13_2 then
      if SHX3_2 then
        SHX14_2 = print
        SHX15_2 = string
        SHX15_2 = SHX15_2.format
        SHX16_2 = "^2[Rule Matched]^7 Rule %s triggered"
        SHX17_2 = SHX10_1
        SHX18_2 = SHX12_2.id
        SHX17_2, SHX18_2, SHX19_2 = SHX17_2(SHX18_2)
        SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX15_2(SHX16_2, SHX17_2, SHX18_2, SHX19_2)
        SHX14_2(SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
      end
      SHX5_2 = true
      while true do
        SHX14_2 = SHX2_1
        if nil ~= SHX14_2 then
          break
        end
        SHX14_2 = SHX9_1
        SHX15_2 = 100
        SHX14_2(SHX15_2)
      end
      SHX14_2 = SHX2_1
      SHX15_2 = SHX14_2
      SHX14_2 = SHX14_2.await
      SHX16_2 = "native_evaluation_failed"
      SHX17_2 = SHX12_2.id
      SHX18_2 = SHX2_2
      SHX14_2 = SHX14_2(SHX15_2, SHX16_2, SHX17_2, SHX18_2)
      SHX15_2 = SHX14_2.success
      if SHX15_2 then
        SHX6_2 = SHX14_2.continue
      end
      break
    elseif SHX3_2 then
      SHX14_2 = print
      SHX15_2 = string
      SHX15_2 = SHX15_2.format
      SHX16_2 = "^1[Rule Not Matched]^7 Rule %s did not match"
      SHX17_2 = SHX10_1
      SHX18_2 = SHX12_2.id
      SHX17_2, SHX18_2, SHX19_2 = SHX17_2(SHX18_2)
      SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX15_2(SHX16_2, SHX17_2, SHX18_2, SHX19_2)
      SHX14_2(SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    end
  end
  if SHX3_2 then
    SHX7_2 = print
    SHX8_2 = string
    SHX8_2 = SHX8_2.format
    SHX9_2 = "^5============ Evaluation Complete ============^7"
    SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX8_2(SHX9_2)
    SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    SHX7_2 = print
    SHX8_2 = string
    SHX8_2 = SHX8_2.format
    SHX9_2 = "^3Result:^7 matched=%s continue=%s"
    SHX10_2 = SHX10_1
    SHX11_2 = SHX5_2
    SHX10_2 = SHX10_2(SHX11_2)
    SHX11_2 = SHX10_1
    SHX12_2 = SHX6_2
    SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX11_2(SHX12_2)
    SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2 = SHX8_2(SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
    SHX7_2(SHX8_2, SHX9_2, SHX10_2, SHX11_2, SHX12_2, SHX13_2, SHX14_2, SHX15_2, SHX16_2, SHX17_2, SHX18_2, SHX19_2)
  end
  SHX7_2 = SHX5_2
  SHX8_2 = SHX6_2
  return SHX7_2, SHX8_2
end
SHX0_1.evaluateNative = SHX14_1
SHX15_1 = SHX0_1
SHX14_1 = SHX0_1.new
SHX14_1 = SHX14_1(SHX15_1)
NativeRules = SHX14_1
SHX14_1 = SHX6_1
function SHX15_1()
  -- [AI CLEANUP] Decompiled Lua - Fix these:
  -- 1. Move ::SHX_LABEL_XX:: outside nested blocks if 'no visible label' error
  -- 2. Rename SHX0_1, SHX1_2 variables to meaningful names
  -- 3. Replace goto/label with while/repeat-until where possible
  -- 4. Remove decompiler comments, add meaningful ones
  -- 5. Fix indentation and formatting
  
  local SHX0_2, SHX1_2
  SHX0_2 = SHX9_1
  SHX1_2 = 5000
  SHX0_2(SHX1_2)
  SHX0_2 = _G
  SHX0_2.NativeRules = nil
end
SHX14_1(SHX15_1)
